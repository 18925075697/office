package com.dgzrdz.mobile.cocobee.fragment.manager;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.pulltorefreshandloadmore.loadmoreview.DefaultLeLoadMoreView;
import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.loadmoreview.OnLoadMoreListener;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.map.LocationTraceActivity;
import com.dgzrdz.mobile.cocobee.adapter.SearchAdapter;
import com.dgzrdz.mobile.cocobee.adapter.SearchResultAdapter;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.SearchRecResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.dgzrdz.mobile.cocobee.view.ListLineRecordDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/3/27
 * Time:  11:35
 */

public class ManagerSearchFragment extends BaseFragment {

    private static final int REQUEST_CODE_LOCATION = 111;
    @BindView(R.id.et_search)
    EditText mEtSearch;
    @BindView(R.id.tv_cancel)
    TextView mTvCancel;
    @BindView(R.id.recycleview_search_history)
    RecyclerView mRecycleviewSearchHistory;
    @BindView(R.id.recycleview_search_result)
    LoadMoreRecyclerView mRecycleviewSearchResult;
    @BindView(R.id.tv_search_title)
    TextView mTvSearchTitle;
    @BindView(R.id.ll_search)
    LinearLayout mLlSearch;
    @BindView(R.id.tv_no_result)
    TextView mTvNoResult;
    @BindView(R.id.tv_car_label_title)
    TextView mTvCarLabelTitle;
    @BindView(R.id.tv_person_label_title)
    TextView mTvPersonLabelTitle;
    @BindView(R.id.view_car)
    View mViewCar;
    @BindView(R.id.view_person)
    View mViewPerson;
    @BindView(R.id.ll_search_history_title)
    LinearLayout mLlSearchHistoryTitle;
    @BindView(R.id.iv_delete)
    ImageView mIvDelete;
    @BindView(R.id.view)
    View mView;

    private SearchAdapter mSearchAdapter;
    private SearchResultAdapter mSearchResultAdapter;
    private List<String> mHistroyList = new ArrayList<>();
    private List<SearchRecResponse> mSearchResultList = new ArrayList<>();
    private UserInfo mUserLoginInfo;

    private int labelFlag = 1;  //1车辆标签 2人员标签
    private SearchRecResponse mSearchRecResponse;
    private String currentTime;
    private int mCurPage = 1;
    private int pageSize = 20;

    public static ManagerSearchFragment getInstance() {
        ManagerSearchFragment fragment = new ManagerSearchFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        immersiveStatusBar(mView);
        mUserLoginInfo = Utils.getUserLoginInfo();
        initSharedPreference();
        initRecycleView();
        initHistoryRecycleView();
        initEditText();
    }

    private void initRecycleView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(_mActivity);
        mRecycleviewSearchHistory.setLayoutManager(layoutManager);
        mRecycleviewSearchHistory.addItemDecoration(new ListLineDecoration());
        mSearchAdapter = new SearchAdapter(_mActivity, mHistroyList, R.layout.history_search_item);
        mRecycleviewSearchHistory.setAdapter(mSearchAdapter);
        mSearchAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {
                String searchString = mHistroyList.get(position);
                //点击历史记录将搜索文字设置到输入框
                mEtSearch.setText(searchString);
                mEtSearch.setSelection(searchString.length());
                //搜索
                mSearchResultList.clear();
                search(searchString, 1);
            }
        });

        mRecycleviewSearchResult.setLayoutManager(new LinearLayoutManager(_mActivity));
        mRecycleviewSearchResult.addItemDecoration(new ListLineRecordDecoration());
        mRecycleviewSearchResult.setHideLoadingView(true);
        mRecycleviewSearchResult.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                String searchString = mEtSearch.getText().toString().trim();
                search(searchString, mCurPage);
            }
        });
    }

    private void initSharedPreference() {
        List<String> searchList = Utils.getSearchList();
        if (searchList != null && searchList.size() > 0) {
            mHistroyList.clear();
            mHistroyList.addAll(searchList);
        }
    }

    private void initEditText() {
        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String searchText = mEtSearch.getText().toString().trim();
                if (!CheckUtils.isEmpty(searchText)) {
                    mTvNoResult.setVisibility(View.GONE);
                    mRecycleviewSearchResult.setVisibility(View.GONE);
                    mRecycleviewSearchHistory.setVisibility(View.GONE);
                    mLlSearch.setVisibility(View.VISIBLE);
                    mTvSearchTitle.setText(searchText);
                    mLlSearchHistoryTitle.setVisibility(View.GONE);
                } else {
                    mLlSearch.setVisibility(View.GONE);
                    mLlSearchHistoryTitle.setVisibility(View.VISIBLE);
                    //输入框为空时显示历史数据
                    initHistoryRecycleView();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //响应回车键
        mEtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    mSearchResultList.clear();
                    //响应搜索事件
                    search(mEtSearch.getText().toString().trim(), 1);
                }
                return true;
            }
        });
    }

    private void initHistoryRecycleView() {
        mLlSearchHistoryTitle.setVisibility(View.VISIBLE);
        if (mHistroyList.size() == 0) {
            mRecycleviewSearchHistory.setVisibility(View.GONE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mTvNoResult.setVisibility(View.VISIBLE);
            mTvNoResult.setText("暂无历史记录");
        } else {
            mTvNoResult.setVisibility(View.GONE);
            mRecycleviewSearchHistory.setVisibility(View.VISIBLE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mSearchAdapter.notifyDataSetChanged();

        }
    }


    @Override
    protected void initToolbarHere() {
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_manager_search;
    }

    @OnClick({R.id.tv_cancel, R.id.ll_search, R.id.tv_car_label_title, R.id.tv_person_label_title, R.id.iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_cancel:
                _mActivity.finish();
                break;
            case R.id.ll_search://点击搜索
                mSearchResultList.clear();
                String searchString = mEtSearch.getText().toString().trim();
                search(searchString, 1);
                break;
            case R.id.tv_car_label_title://车辆标签
                labelFlag = 1;
                setLabelView();
                changeLabelType();
                break;
            case R.id.tv_person_label_title://人员标签
                labelFlag = 2;
                setLabelView();
                changeLabelType();
                break;
            case R.id.iv_delete://清空历史记录
                showDelDialog();
                break;
        }
    }

    /**
     * 点击切换标签类型,当输入框有数据时搜索
     */
    private void changeLabelType() {
        String value = mEtSearch.getText().toString().trim();
        if (!CheckUtils.isEmpty(value)) {
            mSearchResultList.clear();
            search(value, 1);
        }
    }

    /**
     * 删除提示框
     */
    private void showDelDialog() {
        SweetAlertDialog continueDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.WARNING_TYPE);
        continueDialog.setTitleText("确定删除该车辆吗");
        continueDialog.showCancelButton(true).setCancelText("否");
        continueDialog.setConfirmText("是");
        continueDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();
                //删除
                mHistroyList.clear();
                Utils.putSearchList(mHistroyList);
                initHistoryRecycleView();
            }
        });

        continueDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();

            }
        });
        continueDialog.show();
    }


    private void setLabelView() {
        if (labelFlag == 1) {
            mTvCarLabelTitle.setTextColor(_mActivity.getResources().getColor(R.color.color_008cff));
            mTvPersonLabelTitle.setTextColor(_mActivity.getResources().getColor(R.color.color_000000));
            mViewCar.setVisibility(View.VISIBLE);
            mViewPerson.setVisibility(View.GONE);
        } else {
            mTvCarLabelTitle.setTextColor(_mActivity.getResources().getColor(R.color.color_000000));
            mTvPersonLabelTitle.setTextColor(_mActivity.getResources().getColor(R.color.color_008cff));
            mViewCar.setVisibility(View.INVISIBLE);
            mViewPerson.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 保存搜索历史
     *
     * @param searchString
     */
    private void saveSearchHistory(String searchString) {
        //重复的删除之前的
        if (mHistroyList.contains(searchString)) {
            mHistroyList.remove(searchString);
        }
        //添加进集合第一个
        mHistroyList.add(0, searchString);
        //超过20条删除最早的
        if (mHistroyList.size() > 20) {
            for (int i = 0; i < mHistroyList.size(); i++) {
                if (i == 20) {
                    mHistroyList.remove(i);
                    i--;
                }
            }
        }
        Utils.putSearchList(mHistroyList);

    }

    /**
     * 根据条件搜索
     *
     * @param searchString
     */
    private void search(String searchString, int curPage) {
        //保存搜索记录
        saveSearchHistory(searchString);

        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        ManagerApiUtils.managerSearch(_mActivity, labelFlag + "", searchString, currentTime, curPage + "", pageSize + "", new DialogCallback<List<SearchRecResponse>>(_mActivity, "获取标签信息中...") {
            @Override
            public void onSuccess(List<SearchRecResponse> searchRecResponses, Call call, Response response) {
                //                mSearchResultList.addAll(searchRecResponses);

                initResultRecycleView(searchString, searchRecResponses);
            }

        });

    }

    private void initResultRecycleView(String searchString, List<SearchRecResponse> searchRecResponses) {
        mLlSearch.setVisibility(View.GONE);
        mRecycleviewSearchResult.setVisibility(View.VISIBLE);
        mLlSearchHistoryTitle.setVisibility(View.GONE);
        if (searchRecResponses.size() == 0 && mCurPage == 1) {
            mTvNoResult.setVisibility(View.VISIBLE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mRecycleviewSearchHistory.setVisibility(View.GONE);
            mTvNoResult.setText("未查询到相关结果");
        } else {
            mTvNoResult.setVisibility(View.GONE);
            mRecycleviewSearchResult.setVisibility(View.VISIBLE);
            mRecycleviewSearchHistory.setVisibility(View.GONE);

            mSearchResultAdapter = new SearchResultAdapter(_mActivity, mSearchResultList, searchString, R.layout.search_result_item);
            mRecycleviewSearchResult.setAdapter(mSearchResultAdapter);
            mSearchResultAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
                @Override
                public void onItemClick(BH viewHolder, int position) {
                    //搜索得到的数据
                    mSearchRecResponse = mSearchResultList.get(position);
                    checkPermissions();
                }
            });
        }

        handleRefreshAndLoadListData(searchRecResponses);
    }

    /**
     * 处理刷新加载得到的数据
     */
    public void handleRefreshAndLoadListData(List<SearchRecResponse> list) {
        if (list.size() > 0 || mCurPage != 1) {

            if (mCurPage == 1) {
                mSearchResultList.clear();
            }
            mCurPage = mCurPage + 1;
            mSearchResultList.addAll(list);
            mSearchResultAdapter.notifyDataSetChanged();

            if (list.size() < pageSize || list.size() == 0) {
                mRecycleviewSearchResult.setCanLoadMore(false);
            } else {
                mRecycleviewSearchResult.setCanLoadMore(true);
            }

        }
    }


    /**
     * 检查定位权限
     */
    private void checkPermissions() {
        if (requestPermission(Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_CODE_LOCATION, "权限申请：\n我们需要您开启定位权限")) {
            toLocation();
        }
    }

    /**
     * 跳转轨迹定位页面
     */
    private void toLocation() {
        if (mSearchRecResponse == null) {
            XToastUtils.showShortToast("数据为空,无法跳转");
            return;
        }
        Intent intent = new Intent(_mActivity, LocationTraceActivity.class);
        intent.putExtra("searchRecResponse", mSearchRecResponse);
        startActivity(intent);
    }

    /**
     * 返回true表示已经有权限了
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    private boolean requestPermission(String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(_mActivity, permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(getActivity())
                        .setMessage(info)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(new String[]{permissions}, requestCode);
                            }
                        })
                        .show();
            } else {
                requestPermissions(new String[]{permissions}, requestCode);
            }
            return false;
        }
        return true;
    }

    /**
     * 使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    toLocation();
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启定位权限,是否去设置?", "用户拒绝定位授权");
                }
                break;
            default:
                break;
        }
    }

    /**
     * 判断用户是否点击过不再提醒
     *
     * @param
     * @param permission
     */
    private void sureIfNotNotifiy(String permission, String msg, String toast) {
        //点击了不在提醒
        if (!ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permission)) {
            new AlertDialog.Builder(_mActivity).setMessage(msg).setPositiveButton("设置", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + _mActivity.getPackageName()));
                    startActivity(intent);
                }
            }).setNegativeButton("取消", null).create().show();
        } else {
            XToastUtils.showShortToast(toast);
        }
    }

    @Override
    public void onDestroyView() {
        if (mRecycleviewSearchResult != null && mRecycleviewSearchResult.getLoadMoreView() instanceof DefaultLeLoadMoreView) {
            ((DefaultLeLoadMoreView) mRecycleviewSearchResult.getLoadMoreView()).stop();
            mRecycleviewSearchResult = null;
        }
        super.onDestroyView();
    }
}
