package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/12/26
 * Time:  14:07
 */

public class CloudPayResponse implements Serializable{

    /**
     * uid : xa0000064726420190102115036609
     * payItemCode : 863662720
     * userNo : xa0000064726420190102115036609
     * link : https://yaoyao.cebbank.com/LifePayment/wap/apph5/index.html?canal=xaqhjs&token=12DD69608B653E8A8A50363745C0256A&uid=xa0000064726420190102115036609&telno=13800138110&version=1.0.0&type=0&payItemCode=863662720&userNo=xa0000064726420190102115036609&macValue=F0A9E479A5F2488D1F58FF15014241F7
     * canal : xaqhjs
     * type : 0
     * version : 1.0.0
     * telno : 13800138110
     * token : 12DD69608B653E8A8A50363745C0256A
     */

    private String uid;
    private String payItemCode;
    private String memberOrderNo;
    private String link;
    private String canal;
    private String type;
    private String version;
    private String telno;
    private String token;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPayItemCode() {
        return payItemCode;
    }

    public void setPayItemCode(String payItemCode) {
        this.payItemCode = payItemCode;
    }

    public String getMemberOrderNo() {
        return memberOrderNo;
    }

    public void setMemberOrderNo(String memberOrderNo) {
        this.memberOrderNo = memberOrderNo;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
