package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  资料库
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class DatasApiUtils {
    /**
     * 车主搜索
     *
     * @param context
     * @param value     搜索关键字
     * @param sysAreaId 当前用户组织机构id
     * @param time      当前时间
     * @param pageNo    当前页
     * @param pageSize  每页条数
     * @param callback  回调
     */
    public static void carHostSearch(Context context, String value, String sysAreaId, String time, String pageNo, String pageSize, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("value", value);
        params.put("sysAreaId", sysAreaId);
        params.put("time", time);
        params.put("pageNo", pageNo);
        params.put("pageSize", pageSize);
        OkGo.post(Path.DATA_CAR_HOST_SEARCH_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 查看未绑定车辆信息
     *
     * @param context
     * @param memberId  搜索关键字
     * @param sysAreaId 管理员组织机构id
     * @param callback  回调
     */
    public static void getUnbindCarInfo(Context context, String memberId, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberId", memberId);
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.GET_UNBIND_CAR_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 修改用户信息
     *
     * @param context
     * @param memberAccount         用户手机号
     * @param memberName            真实姓名
     * @param memberCardId          身份证
     * @param memberSix             性别1男2女
     * @param memberRegisterAddress 用户户籍地址
     * @param memberLiveAddress     现居住地址
     * @param memberId              修改对象id
     * @param callback              回调
     */
    public static void updateCarHostInfo(Context context, String memberAccount, String memberName, String memberCardId, String memberSix, String memberRegisterAddress,
                                         String memberLiveAddress, String memberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        if (!CheckUtils.isEmpty(memberAccount)) {
            params.put("memberAccount", memberAccount);
        }

        if (!CheckUtils.isEmpty(memberName)) {
            params.put("memberName", memberName);
        }

        if (!CheckUtils.isEmpty(memberCardId)) {
            params.put("memberCardId", memberCardId);
        }

        if (!CheckUtils.isEmpty(memberSix)) {
            if (CheckUtils.equalsString(memberSix, "女")) {
                params.put("memberSix", "2");
            } else {
                params.put("memberSix", "1");
            }
        }

        if (!CheckUtils.isEmpty(memberRegisterAddress)) {
            params.put("memberRegisterAddress", memberRegisterAddress);
        }

        if (!CheckUtils.isEmpty(memberLiveAddress)) {
            params.put("memberLiveAddress", memberLiveAddress);
        }
        if (!CheckUtils.isEmpty(memberId)) {
            params.put("memberId", memberId);
        }
        OkGo.post(Path.UPDATE_CAR_OWNER_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 报警信息
     *
     * @param context
     * @param pid      用户id
     * @param callback 回调
     */
    public static void getAlarmInfo(Context context, String pid, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("pid", pid);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.GET_ALARM_INFO).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 验证手机号
     *
     * @param context
     * @param memberAccount 手机号码
     * @param callback      回调
     */
    public static void checkPhone1(Context context, String memberAccount, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberAccount", memberAccount);
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        OkGo.post(Path.CHECK_PHONE).tag(context).headers("token", userLoginInfo.getToken()).params(params).execute(callback);
    }

    /**
     * 获取监护对象类型
     *
     * @param context
     * @param sysAreaId 当前用户组织机构id
     * @param callback  回调
     */
    public static void getCarType(Context context, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.GET_CAR_TYPE).tag(context).params(params).execute(callback);
    }

    /**
     * 获取监护对象详情
     *
     * @param context
     * @param memberServiceObjId 当前用户组织机构id
     * @param callback           回调
     */
    public static void getJianhuDetail(Context context, String memberServiceObjId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberServiceObjId", memberServiceObjId);
        OkGo.post(Path.GET_JIAN_HU_DETAIL).tag(context).params(params).execute(callback);
    }

    /**
     * 获取监护对象属性
     *
     * @param context
     * @param sysAreaId        组织机构id
     * @param sysServiceTypeId 服务对象id
     * @param callback         回调
     */
    public static void getObjectValue(Context context, String sysAreaId, String sysServiceTypeId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaId", sysAreaId);
        params.put("sysServiceTypeId", sysServiceTypeId);
        OkGo.post(Path.GET_OBJECT_VALUE).tag(context).params(params).execute(callback);
    }

    /**
     * 获取标签库存
     *
     * @param context
     * @param selecttime 查询时间
     * @param limit      每页条数
     * @param offset     当前页
     * @param code       管理员组织机构code
     * @param callback   回调
     */
    public static void getLabelStock(Context context, String selecttime, String limit, String offset, String code, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("selecttime", selecttime);
        params.put("limit", limit);
        params.put("offset", offset);
        params.put("code", code);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.GET_LABEL_STOCK).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 获取车牌库存
     *
     * @param context
     * @param selecttime 查询时间
     * @param limit      每页条数
     * @param offset     当前页
     * @param code       管理员组织机构code
     * @param callback   回调
     */
    public static void getCnoStock(Context context, String selecttime, String limit, String offset, String code, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("selecttime", selecttime);
        params.put("limit", limit);
        params.put("offset", offset);
        params.put("code", code);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.GET_CNO_STOCK).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 获取消息列表
     *
     * @param context
     * @param time           查询时间
     * @param pageSize       每页条数
     * @param pageNo         当前页
     * @param appAppMemberId 管理员id
     * @param callback       回调
     */
    public static void getMessage(Context context, String time, String pageSize, String pageNo, String appAppMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("time", time);
        params.put("pageSize", pageSize);
        params.put("pageNo", pageNo);
        params.put("appAppMemberId", appAppMemberId);
        OkGo.post(Path.GET_MESSAGE_LIST_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 修改手机号码
     *
     * @param context
     * @param appMemberId     管理员id
     * @param memberAccount   新手机号
     * @param appMemberCardId 身份证
     * @param auth            验证码
     * @param callback        回调
     */
    public static void changePhone(Context context, String appMemberId, String memberAccount, String appMemberCardId, String auth, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        params.put("memberAccount", memberAccount);
        params.put("appMemberCardId", appMemberCardId);
        params.put("auth", auth);
        OkGo.post(Path.CHANGE_PHONE_NUM).tag(context).params(params).execute(callback);
    }

    /**
     * 获取集团单位列表
     *
     * @param context
     * @param sysAreaId     当前用户组织机构id
     * @param callback        回调
     */
    public static void getComputeList(Context context, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.GET_COMPUTE_LIST).tag(context).params(params).execute(callback);
    }
}
