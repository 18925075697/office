package com.dgzrdz.mobile.cocobee.fragment.databank;


import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.roundview.RoundTextView;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.BindingCarActivity;
import com.dgzrdz.mobile.cocobee.activity.data.CarOwnerInfoActivity;
import com.dgzrdz.mobile.cocobee.adapter.CarOwnerSearchDataAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Response;


/**
 * 资料库fragment
 * Created by Administrator on 2017/4/17.
 */

public class DataBankFragment extends RefreshAndLoadFragment<UserBeanResponse> {
    @BindView(R.id.tv_toolbar_title)
    RoundTextView mTvToolbarTitle;
    @BindView(R.id.search_et_input)
    EditText mSearchEtInput;
    @BindView(R.id.search_iv_delete)
    ImageView mSearchIvDelete;

    private CarOwnerSearchDataAdapter adapter;
    private String currentTime;

    public static DataBankFragment getInstance() {
        return new DataBankFragment();
    }

    @Override
    protected boolean lazyLoadMode() {
        return true;
    }

    @Override
    protected void initLazyViews(@Nullable Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        mTvToolbarTitle.setCompoundDrawables(null, null, null, null);
        adapter = new CarOwnerSearchDataAdapter(_mActivity, mList, "");
        initEditText();
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
    }

    private void initEditText() {
        mSearchEtInput.setHint("搜索姓名,手机号");
        mSearchEtInput.addTextChangedListener(new EditChangedListener());

        //响应回车键
        mSearchEtInput.setOnEditorActionListener((textView, actionId, keyEvent) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                notifyStartSearching();
            }
            return true;
        });
    }

    /**
     * 通知监听者 进行搜索操作
     */
    private void notifyStartSearching() {
        //隐藏软键盘
        InputMethodManager imm = (InputMethodManager) _mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;//断言不为空
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);

        mList.clear();
        adapter.notifyDataSetChanged();
        mRcvLoadMore.setCanLoadMore(false);
        loadDataList(1, true);
    }

    @Override
    public void btnRightTextClick() {
        Intent intent = new Intent(_mActivity, CarOwnerInfoActivity.class);
        startActivity(intent);
    }

    @OnClick({R.id.search_iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.search_iv_delete:
                mSearchEtInput.setText("");
                mSearchIvDelete.setVisibility(View.VISIBLE);
                break;
        }
    }

    private class EditChangedListener implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (!"".equals(charSequence.toString())) {
                mSearchIvDelete.setVisibility(View.VISIBLE);
            } else {
                mSearchIvDelete.setVisibility(View.GONE);
                notifyStartSearching();
            }
            setRecycleView(charSequence.toString());
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    }

    private void setRecycleView(String key) {
        adapter = new CarOwnerSearchDataAdapter(_mActivity, mList, key);
        mRcvLoadMore.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithRightText("已登记用户", "新增");
    }

    @Override
    public boolean inVisibleLeftDrawable() {
        return true;
    }


    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_data;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        UserBeanResponse userBeanResponse = mList.get(position);
        Intent intent = new Intent(_mActivity, BindingCarActivity.class);
        intent.putExtra("userBean", userBeanResponse);
        startActivity(intent);
    }

    @Override
    public QuickRcvAdapter<UserBeanResponse> getAdapter() {
        return adapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public boolean canRefresh() {
        return true;
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        String value = mSearchEtInput.getText().toString().trim();

        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        DatasApiUtils.carHostSearch(_mActivity, value, userLoginInfo.getDataList().getSysAreaId(), currentTime, curPage + "", pageSize + "", new RefreshAndLoadCallback<List<UserBeanResponse>>(isPullToRefresh) {

            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<UserBeanResponse> userBeanResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshAndLoadListData(mCurPage, callback, userBeanResponses);
            }

            @Override
            public Drawable emptyDrawable() {
                return _mActivity.getResources().getDrawable(R.drawable.empty);
            }

            @Override
            public String emptyContent() {
                return "暂无记录";
            }
        });
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    @Override
    public void onLoadMore() {
        loadDataList(mCurPage, true);
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.PRE_REGIST_CAR_OWNER_UP_SUCCESS://预登记车主录入成功
            case EventConstants.PRE_REGIST_SUCCESS://预登记车辆录入成功
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
            case EventConstants.CARINFO_DELETE_SUCCESS://车辆删除成功
            case EventConstants.DELETE_CAR_INFO_SUCCESS://车辆删除成功
            case EventConstants.ORGENIZE_SELECT_SUCCESS://组织机构选择成功
            case EventConstants.CAR_BIND_SUCCESS://车辆绑定成功
                if (adapter != null) {//页面加载后才请求
                    loadDataList(1, true);
                }
                break;
        }
    }
}
