package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/5/15.
 */

public class TraceResponse implements Serializable {
    /**
     * address : 广东省深圳市南山区学府路
     * channelid : 3
     * enddate : 2018-06-26 14:10:33
     * eqisconn : 0
     * eqno : 43551030034002D
     * id : 2
     * iotype : 0
     * lat : 22.533566350633272
     * lng : 113.91051049761793
     * startdate : 2018-06-26 14:10:33
     * wireless_ip : 218.17.157.214
     * wireless_port : 4600
     */

    private String address;
    private String channelid;
    private String enddate;
    private String eqisconn;
    private String eqno;
    private String id;
    private String iotype;
    private String lat;
    private String lng;
    private String startdate;
    private String wireless_ip;
    private String wireless_port;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getChannelid() {
        return channelid;
    }

    public void setChannelid(String channelid) {
        this.channelid = channelid;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getEqisconn() {
        return eqisconn;
    }

    public void setEqisconn(String eqisconn) {
        this.eqisconn = eqisconn;
    }

    public String getEqno() {
        return eqno;
    }

    public void setEqno(String eqno) {
        this.eqno = eqno;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIotype() {
        return iotype;
    }

    public void setIotype(String iotype) {
        this.iotype = iotype;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getWireless_ip() {
        return wireless_ip;
    }

    public void setWireless_ip(String wireless_ip) {
        this.wireless_ip = wireless_ip;
    }

    public String getWireless_port() {
        return wireless_port;
    }

    public void setWireless_port(String wireless_port) {
        this.wireless_port = wireless_port;
    }
}
