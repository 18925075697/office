package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

public class SysPropertyOptionListBean implements Serializable {
    /**
     * sysPropertyOptionTop : 0
     * sysPropertyId : 1
     * sysPropertyOptionId : 5
     * sysPropertyOptionValue : 宝马
     * sysPropertyOptionEnabled : 1
     * sysPropertyOptionStatus : 1
     * sysPropertyOptionChar : b
     */

    private String sysPropertyOptionTop;
    private String sysPropertyId;
    private String sysPropertyOptionId;
    private String sysPropertyOptionValue;
    private String sysPropertyOptionEnabled;
    private String sysPropertyOptionStatus;
    private String sysPropertyOptionChar;

    public String getSysPropertyOptionTop() {
        return sysPropertyOptionTop;
    }

    public void setSysPropertyOptionTop(String sysPropertyOptionTop) {
        this.sysPropertyOptionTop = sysPropertyOptionTop;
    }

    public String getSysPropertyId() {
        return sysPropertyId;
    }

    public void setSysPropertyId(String sysPropertyId) {
        this.sysPropertyId = sysPropertyId;
    }


    public String getSysPropertyOptionValue() {
        return sysPropertyOptionValue;
    }

    public void setSysPropertyOptionValue(String sysPropertyOptionValue) {
        this.sysPropertyOptionValue = sysPropertyOptionValue;
    }

    public String getSysPropertyOptionId() {
        return sysPropertyOptionId;
    }

    public void setSysPropertyOptionId(String sysPropertyOptionId) {
        this.sysPropertyOptionId = sysPropertyOptionId;
    }

    public String getSysPropertyOptionEnabled() {
        return sysPropertyOptionEnabled;
    }

    public void setSysPropertyOptionEnabled(String sysPropertyOptionEnabled) {
        this.sysPropertyOptionEnabled = sysPropertyOptionEnabled;
    }

    public String getSysPropertyOptionStatus() {
        return sysPropertyOptionStatus;
    }

    public void setSysPropertyOptionStatus(String sysPropertyOptionStatus) {
        this.sysPropertyOptionStatus = sysPropertyOptionStatus;
    }

    public String getSysPropertyOptionChar() {
        return sysPropertyOptionChar;
    }

    public void setSysPropertyOptionChar(String sysPropertyOptionChar) {
        this.sysPropertyOptionChar = sysPropertyOptionChar;
    }
}