package com.dgzrdz.mobile.cocobee.view;

import android.content.Context;
import android.os.CountDownTimer;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;

public class TimeCount extends CountDownTimer {

    private final TextView mTextView;
    private final Context mContext;

    public TimeCount(Context context, long millisInFuture, long countDownInterval, TextView textView) {
        super(millisInFuture, countDownInterval);
        mContext = context;
        mTextView = textView;
    }


    @Override
    public void onTick(long millisUntilFinished) {
        mTextView.setClickable(false);
        mTextView.setText("重新发送(" + millisUntilFinished / 1000 + "s)");
        mTextView.setTextColor(mContext.getResources().getColor(R.color.color_b3b3b3));
    }

    @Override
    public void onFinish() {
        mTextView.setText("发送验证码");
        mTextView.setClickable(true);
        mTextView.setTextColor(mContext.getResources().getColor(R.color.color_404040));
    }
}