package com.dgzrdz.mobile.cocobee.fragment.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.me.OrderDetailActivity;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.response.PaySuccessResponse;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 绑定成功页面
 * Created by Administrator on 2018/5/2.
 */

public class PaySuccessFragment extends BaseFragment {

    @BindView(R.id.iv_close)
    ImageView mIvClose;
    @BindView(R.id.tv_title)
    TextView mTvTitle;
    @BindView(R.id.tv_policy_detail)
    TextView mTvPolicyDetail;
    @BindView(R.id.tv_to_home)
    TextView mTvToHome;
    @BindView(R.id.tv_policy_effect_time)
    TextView mTvPolicyEffectTime;
    private static PaySuccessResponse paySuccessResponse;

    public static PaySuccessFragment getInstance(PaySuccessResponse paySuccessResponse) {
        PaySuccessFragment.paySuccessResponse = paySuccessResponse;
        PaySuccessFragment fragment = new PaySuccessFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initView();
    }

    private void initView() {
        if (CheckUtils.equalsString(paySuccessResponse.getMemberOrderType(), "1")) {//服务+保险
            mTvTitle.setText("信息登记成功\n请尽快为车主安装车牌及标签");
            mTvPolicyEffectTime.setText("标签服务生效日期:" + paySuccessResponse.getMemberOrderAcviveTime() + "\n保险生效日期:" + paySuccessResponse.getMemberOrderAcviveTime());
        } else if (CheckUtils.equalsString(paySuccessResponse.getMemberOrderType(), "2")) {//服务
            mTvTitle.setText("信息登记成功\n请尽快为车主安装车牌及标签");
            mTvPolicyEffectTime.setText("标签服务生效日期:" + paySuccessResponse.getMemberOrderAcviveTime());
        } else if (CheckUtils.equalsString(paySuccessResponse.getMemberOrderType(), "3")) {//保险
            mTvTitle.setText("保险购买成功");
            mTvPolicyEffectTime.setText("保险生效日期:" + paySuccessResponse.getMemberOrderAcviveTime());
        }
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_pay_success;
    }


    @OnClick({R.id.iv_close, R.id.tv_policy_detail, R.id.tv_to_home})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_close://回首页
                toHome();
                break;
            case R.id.tv_policy_detail://查看详情
                Intent intent = new Intent(_mActivity, OrderDetailActivity.class);
                OrderStatusResponse orderStatusResponse = new OrderStatusResponse();
                orderStatusResponse.setMemberOrderId(paySuccessResponse.getMemberOrderId());
                orderStatusResponse.setMemberOrderProcess("2");
                intent.putExtra("orderStatusResponse", orderStatusResponse);
                startActivity(intent);
                break;
            case R.id.tv_to_home://回首页
                toHome();
                break;
        }
    }

    /**
     * 回首页
     */
    private void toHome() {
        EventBus.getDefault().post(new EventManager(EventConstants.PAY_FINISH_BACK_HOME));
        _mActivity.finish();
    }
}
