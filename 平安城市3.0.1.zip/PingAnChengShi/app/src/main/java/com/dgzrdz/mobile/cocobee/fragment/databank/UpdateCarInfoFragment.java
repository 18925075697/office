package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Description:修改车辆信息
 * Author: Liubingren
 * Data:  2018/11/15
 * Time:  15:56
 */

public class UpdateCarInfoFragment extends BaseFragment {

    private static GuardianObjectDetailResponse guardianObjectDetailResponse;
    @BindView(R.id.et_tag)
    EditText mEtTag;
    @BindView(R.id.tv_pre)
    TextView mTvPre;
    @BindView(R.id.tv_car_type)
    TextView mTvCarType;
    @BindView(R.id.et_car_num)
    EditText mEtCarNum;
    @BindView(R.id.ll_car_num_info)
    LinearLayout mLlCarNumInfo;
    @BindView(R.id.tv_save)
    TextView mTvSave;
    private UserInfo mUserLoginInfo;

    public static UpdateCarInfoFragment getInstance(GuardianObjectDetailResponse guardianObjectDetailResponse) {
        UpdateCarInfoFragment.guardianObjectDetailResponse = guardianObjectDetailResponse;
        UpdateCarInfoFragment fragment = new UpdateCarInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        setView();
    }

    private void setView() {
        if (CheckUtils.equalsString(guardianObjectDetailResponse.getSysServiceTypeSpecialType(),"1") &&
               CheckUtils.equalsString( guardianObjectDetailResponse.getSysAreaCarNumEnabled(),"1") &&
                CheckUtils.equalsString(guardianObjectDetailResponse.getSysServiceTypeEnabled(),"1")) {//有车牌
            mLlCarNumInfo.setVisibility(View.VISIBLE);
            mTvPre.setText(guardianObjectDetailResponse.getSysAreaCarNumPrefix());
            mTvCarType.setText(guardianObjectDetailResponse.getSysServiceTypeCode());
            mEtCarNum.setText(guardianObjectDetailResponse.gethPlateNo());
        } else {
            mLlCarNumInfo.setVisibility(View.GONE);
        }
        mEtTag.setText(guardianObjectDetailResponse.getHLabelNo());
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("修改标签信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_update_car_info;
    }


    @OnClick({R.id.tv_save})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_save://保存
                String tag = mEtTag.getText().toString().trim();
                String carNum = mEtCarNum.getText().toString().trim();

                if (CheckUtils.equalsString(guardianObjectDetailResponse.getSysServiceTypeSpecialType(),"1") &&
                        CheckUtils.equalsString( guardianObjectDetailResponse.getSysAreaCarNumEnabled(),"1") &&
                        CheckUtils.equalsString(guardianObjectDetailResponse.getSysServiceTypeEnabled(),"1")) {//有车牌
                    if (CheckUtils.isEmpty(carNum)) {
                        XToastUtils.showShortToast("车牌号不能为空");
                        break;
                    }
                }

                if (CheckUtils.isEmpty(tag)) {
                    XToastUtils.showShortToast("标签号不能为空");
                } else {
                    save(tag, carNum);
                }
                break;
        }
    }

    /**
     * 保存
     *
     * @param tag
     * @param carNum
     */
    private void save(String tag, String carNum) {
        HomeApiUtils.updateTagInfo(_mActivity, guardianObjectDetailResponse.getMemberServiceObjId(), tag, guardianObjectDetailResponse.getSysAreaId(),
                mUserLoginInfo.getDataList().getAppMemberId(), guardianObjectDetailResponse.getSysAreaCarNumPrefix(), guardianObjectDetailResponse.getSysServiceTypeCode(),
                carNum, guardianObjectDetailResponse.getMemberServiceObjActiveFlag(), new DialogCallback<Object>(_mActivity, "获取监护对象详情...") {
                    @Override
                    public void onSuccess(Object o, Call call, Response response) {
                        EventBus.getDefault().post(new EventManager(EventConstants.UPDATE_TAG_INFO_SUCCESS));
                        XToastUtils.showShortToast("监护对象标签信息修改成功");
                        _mActivity.finish();
                    }
                });
    }
}
