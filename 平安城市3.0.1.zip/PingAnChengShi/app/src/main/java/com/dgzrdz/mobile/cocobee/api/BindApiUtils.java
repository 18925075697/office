package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.dgzrdz.mobile.cocobee.common.Path;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  绑定标签
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class BindApiUtils {
    private static Gson gson = new Gson();

    /**
     * 上传纸质保单
     *
     * @param context
     * @param thirdId             第三方id(车id)
     * @param creator             创建人
     * @param beforePaperWarranty 纸质保单前照
     * @param RearPaperWarranty   纸质保单后照
     * @param callback            回调
     */
    public static void uploadPaperPolicy(Context context, String thirdId, String creator, String beforePaperWarranty, String RearPaperWarranty, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("thirdId", thirdId);
        params.put("creator", creator);
        params.put("beforePaperWarranty", beforePaperWarranty);
        params.put("RearPaperWarranty", RearPaperWarranty);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.UPLOAD_PAPER_POLICY).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 查看电子保单
     *
     * @param context
     * @param thirdId     第三id（车id）
     * @param orderStatus 订单状态10未付款，20已付款，已失效
     * @param callback    回调
     */
    public static void viewEPolicy(Context context, String thirdId, String orderStatus, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("thirdId", thirdId);
        params.put("orderStatus", orderStatus);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.SEE_E_POLICY).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 查询车辆详情信息
     *
     * @param context
     * @param cid      登录用户id
     * @param callback 回调
     */
    public static void getCarDetailInfo(Context context, String cid, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("cid", cid);
        OkGo.post(Path.GET_CAR_DETAIL_INFO).tag(context).params(params).execute(callback);
    }
}
