package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.recyclerview.swipe.SwipeMenuAdapter;
import com.bql.recyclerview.swipe.SwipeMenuCreator;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.MainActivity;
import com.dgzrdz.mobile.cocobee.activity.me.MessageDetailActivity;
import com.dgzrdz.mobile.cocobee.adapter.MessageAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.SwipeRefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.MsgResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import okhttp3.Response;


/**
 * Description: 消息列表
 * Author: Liubingren
 * Data:  2016/10/26
 * Time:  15:04
 */
public class MessageFragment extends SwipeRefreshAndLoadFragment<MsgResponse> {
    MessageAdapter mMessageAdapter;
    private UserInfo mUserLoginInfo;
    private String currentTime;

    public static MessageFragment getInstance() {
        MessageFragment fragment = new MessageFragment();
        return fragment;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        Intent intent = new Intent(_mActivity, MessageDetailActivity.class);
        intent.putExtra("msgResponse", mList.get(position));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_message;
    }

    @Override
    public SwipeMenuAdapter getAdapter() {
        return mMessageAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public SwipeMenuCreator getSwipeMenuCreator() {
        return null;
    }

    @Override
    public void onLeftSwipeMenuClick(int adapterPosition, int menuPosition) {

    }

    @Override
    public void onRightSwipeMenuClick(int adapterPosition, int menuPosition) {
    }


    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(final int curPage, final boolean isPullToRefresh) {
        if (mUserLoginInfo == null){
            return;
        }
        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        DatasApiUtils.getMessage(_mActivity, currentTime, pageSize + "", curPage + "", mUserLoginInfo.getDataList().getAppMemberId(),
                new RefreshAndLoadCallback<List<MsgResponse>>(_mActivity, isPullToRefresh) {
                    @Override
                    public void errorLeftOrEmptyBtnClick(View v) {
                        loadDataList(1, false);
                    }

                    @Override
                    public void onResultSuccess(List<MsgResponse> msgResponses, @Nullable Response response, LoadingViewCallback callback) {
                        handleRefreshAndLoadListData(curPage, callback, msgResponses);
                    }

                });
    }


    @Override
    public void onLoadMore() {
        loadDataList(mCurPage, true);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("消息");
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mMessageAdapter = new MessageAdapter(_mActivity, mList);
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    public void onDestroyView() {
        if (Utils.isBackground(_mActivity)) {//后台打开返回主页面
            startActivity(new Intent(_mActivity, MainActivity.class));
        }
        super.onDestroyView();
    }
}