package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/14
 * Time:  16:40
 */

public class GuardianObjectDetailResponse implements Serializable {

    /**
     * hLabelNo :
     * memberServiceObjId : 27
     * memberServiceObjNumber :
     * sysAreaId : 12
     * memberServiceObjActiveFlag : 1
     * sysServiceTypeId : 1
     * customize : [{"sysPropertyInputTypeName":"下拉框选择输入","sysPropertyOptionList":[{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"5","sysPropertyOptionValue":"宝马","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"b"},{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"6","sysPropertyOptionValue":"玛莎拉蒂","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"m"}],"sysPropertyId":"1","sysPropertyOptionId":"6","sysPropertyShowStyle":"2","sysPropertyInputType":"5","sysPropertyRequired":"1","sysPropertyValue":"玛莎拉蒂","sysPropertyName":"车辆品牌"},{"sysPropertyInputTypeName":"下拉框选择输入","sysPropertyOptionList":[{"sysPropertyOptionTop":"2","sysPropertyId":"2","sysPropertyOptionId":"1","sysPropertyOptionValue":"黑色","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"h"},{"sysPropertyOptionTop":"2","sysPropertyId":"2","sysPropertyOptionId":"2","sysPropertyOptionValue":"白色","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"b"},{"sysPropertyOptionTop":"2","sysPropertyId":"2","sysPropertyOptionId":"3","sysPropertyOptionValue":"红色","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"h"},{"sysPropertyOptionTop":"2","sysPropertyId":"2","sysPropertyOptionId":"4","sysPropertyOptionValue":"深灰色2","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"s"}],"sysPropertyId":"2","sysPropertyOptionId":"2","sysPropertyShowStyle":"1","sysPropertyInputType":"5","sysPropertyRequired":"1","sysPropertyValue":"白色","sysPropertyName":"车辆颜色"},{"sysPropertyInputTypeName":"数字+点号（价格）","sysPropertyId":"3","sysPropertyOptionId":"0","sysPropertyShowStyle":"1","sysPropertyInputType":"2","sysPropertyRequired":"1","sysPropertyValue":"566","sysPropertyName":"车辆价格"}]
     * sysServiceTypeSpecialType :
     */

    private String hLabelNo;//标签号
    private String memberServiceObjId;//对象属性id
    private String sysServiceTypeName;//监护对象名称
    private String sysAreaId;//组织机构id
    private String memberServiceObjActiveFlag;//对象激活标志\n1 未激活\n2 锁定中\n3 已激活、有效中\n4 已过期\n5 删除了\n
    private String sysServiceTypeId;//监护对象类型ID
    private String sysServiceTypeSpecialType;//特定服务\n0：无额外服务\n1：需要车牌服务
    private String sysAreaCarNumEnabled;//是否启用车牌，1启用，2禁用
    private String sysServiceTypeCode;//车牌代码M D
    private String hPlateNo;//车牌号
    private String hPlateId;//车牌id
    private String memberServiceObjNumber;//车牌号(前缀+代码+号码)
    private String sysServiceTypeEnabled;//是否启用，1启用，2禁用
    private String sysAreaCarNumPrefix;//车牌前缀
    private String memberServiceActiveTime;//对象激活时间
    private List<CustomizeBean> customize;

    public String getMemberServiceActiveTime() {
        return memberServiceActiveTime;
    }

    public void setMemberServiceActiveTime(String memberServiceActiveTime) {
        this.memberServiceActiveTime = memberServiceActiveTime;
    }

    public String getSysServiceTypeSpecialType() {
        return sysServiceTypeSpecialType;
    }

    public void setSysServiceTypeSpecialType(String sysServiceTypeSpecialType) {
        this.sysServiceTypeSpecialType = sysServiceTypeSpecialType;
    }

    public String getSysAreaCarNumEnabled() {
        return sysAreaCarNumEnabled;
    }

    public void setSysAreaCarNumEnabled(String sysAreaCarNumEnabled) {
        this.sysAreaCarNumEnabled = sysAreaCarNumEnabled;
    }

    public String getSysServiceTypeEnabled() {
        return sysServiceTypeEnabled;
    }

    public void setSysServiceTypeEnabled(String sysServiceTypeEnabled) {
        this.sysServiceTypeEnabled = sysServiceTypeEnabled;
    }

    public String gethLabelNo() {
        return hLabelNo;
    }

    public void sethLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }


    public String getSysServiceTypeCode() {
        return sysServiceTypeCode;
    }

    public void setSysServiceTypeCode(String sysServiceTypeCode) {
        this.sysServiceTypeCode = sysServiceTypeCode;
    }

    public String gethPlateNo() {
        return hPlateNo;
    }

    public void sethPlateNo(String hPlateNo) {
        this.hPlateNo = hPlateNo;
    }

    public String gethPlateId() {
        return hPlateId;
    }

    public void sethPlateId(String hPlateId) {
        this.hPlateId = hPlateId;
    }

    public String getMemberServiceObjNumber() {
        return memberServiceObjNumber;
    }

    public void setMemberServiceObjNumber(String memberServiceObjNumber) {
        this.memberServiceObjNumber = memberServiceObjNumber;
    }


    public String getSysAreaCarNumPrefix() {
        return sysAreaCarNumPrefix;
    }

    public void setSysAreaCarNumPrefix(String sysAreaCarNumPrefix) {
        this.sysAreaCarNumPrefix = sysAreaCarNumPrefix;
    }

    public String getHLabelNo() {
        return hLabelNo;
    }

    public void setHLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getMemberServiceObjActiveFlag() {
        return memberServiceObjActiveFlag;
    }

    public void setMemberServiceObjActiveFlag(String memberServiceObjActiveFlag) {
        this.memberServiceObjActiveFlag = memberServiceObjActiveFlag;
    }

    public String getSysServiceTypeId() {
        return sysServiceTypeId;
    }

    public void setSysServiceTypeId(String sysServiceTypeId) {
        this.sysServiceTypeId = sysServiceTypeId;
    }


    public List<CustomizeBean> getCustomize() {
        return customize;
    }

    public void setCustomize(List<CustomizeBean> customize) {
        this.customize = customize;
    }

    public static class CustomizeBean implements Serializable {
        /**
         * sysPropertyInputTypeName : 下拉框选择输入
         * sysPropertyOptionList : [{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"5","sysPropertyOptionValue":"宝马","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"b"},{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"6","sysPropertyOptionValue":"玛莎拉蒂","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"m"}]
         * sysPropertyId : 1
         * sysPropertyOptionId : 6
         * sysPropertyShowStyle : 2
         * sysPropertyInputType : 5
         * sysPropertyRequired : 1
         * sysPropertyValue : 玛莎拉蒂
         * sysPropertyName : 车辆品牌
         */

        private String sysPropertyInputTypeName;
        private String sysPropertyId;
        private String sysPropertyOptionId;
        private String sysPropertyShowStyle;
        private int sysPropertyInputType;
        private String sysPropertyRequired;
        private String sysPropertyValue;
        private String sysPropertyValueId;
        private String sysPropertyName;
        private String sysPropertySort;
        private String localUrl;//本地图片选择地址
        private List<SysPropertyOptionListBean> sysPropertyOptionList;

        public String getSysPropertySort() {
            return sysPropertySort;
        }

        public void setSysPropertySort(String sysPropertySort) {
            this.sysPropertySort = sysPropertySort;
        }

        public String getLocalUrl() {
            return localUrl;
        }

        public void setLocalUrl(String localUrl) {
            this.localUrl = localUrl;
        }

        public String getSysPropertyInputTypeName() {
            return sysPropertyInputTypeName;
        }

        public void setSysPropertyInputTypeName(String sysPropertyInputTypeName) {
            this.sysPropertyInputTypeName = sysPropertyInputTypeName;
        }

        public String getSysPropertyValueId() {
            return sysPropertyValueId;
        }

        public void setSysPropertyValueId(String sysPropertyValueId) {
            this.sysPropertyValueId = sysPropertyValueId;
        }

        public String getSysPropertyId() {
            return sysPropertyId;
        }

        public void setSysPropertyId(String sysPropertyId) {
            this.sysPropertyId = sysPropertyId;
        }

        public String getSysPropertyOptionId() {
            return sysPropertyOptionId;
        }

        public void setSysPropertyOptionId(String sysPropertyOptionId) {
            this.sysPropertyOptionId = sysPropertyOptionId;
        }

        public String getSysPropertyShowStyle() {
            return sysPropertyShowStyle;
        }

        public void setSysPropertyShowStyle(String sysPropertyShowStyle) {
            this.sysPropertyShowStyle = sysPropertyShowStyle;
        }

        public int getSysPropertyInputType() {
            return sysPropertyInputType;
        }

        public void setSysPropertyInputType(int sysPropertyInputType) {
            this.sysPropertyInputType = sysPropertyInputType;
        }

        public String getSysPropertyRequired() {
            return sysPropertyRequired;
        }

        public void setSysPropertyRequired(String sysPropertyRequired) {
            this.sysPropertyRequired = sysPropertyRequired;
        }

        public String getSysPropertyValue() {
            return sysPropertyValue;
        }

        public void setSysPropertyValue(String sysPropertyValue) {
            this.sysPropertyValue = sysPropertyValue;
        }

        public String getSysPropertyName() {
            return sysPropertyName;
        }

        public void setSysPropertyName(String sysPropertyName) {
            this.sysPropertyName = sysPropertyName;
        }

        public List<SysPropertyOptionListBean> getSysPropertyOptionList() {
            return sysPropertyOptionList;
        }

        public void setSysPropertyOptionList(List<SysPropertyOptionListBean> sysPropertyOptionList) {
            this.sysPropertyOptionList = sysPropertyOptionList;
        }

//        public static class SysPropertyOptionListBean implements Serializable {
//            /**
//             * sysPropertyOptionTop : 0
//             * sysPropertyId : 1
//             * sysPropertyOptionId : 5
//             * sysPropertyOptionValue : 宝马
//             * sysPropertyOptionEnabled : 1
//             * sysPropertyOptionStatus : 1
//             * sysPropertyOptionChar : b
//             */
//
//            private String sysPropertyOptionTop;
//            private String sysPropertyId;
//            private String sysPropertyOptionId;
//            private String sysPropertyOptionValue;
//            private String sysPropertyOptionEnabled;
//            private String sysPropertyOptionStatus;
//            private String sysPropertyOptionChar;
//
//            public String getSysPropertyOptionTop() {
//                return sysPropertyOptionTop;
//            }
//
//            public void setSysPropertyOptionTop(String sysPropertyOptionTop) {
//                this.sysPropertyOptionTop = sysPropertyOptionTop;
//            }
//
//            public String getSysPropertyId() {
//                return sysPropertyId;
//            }
//
//            public void setSysPropertyId(String sysPropertyId) {
//                this.sysPropertyId = sysPropertyId;
//            }
//
//            public String getSysPropertyOptionId() {
//                return sysPropertyOptionId;
//            }
//
//            public void setSysPropertyOptionId(String sysPropertyOptionId) {
//                this.sysPropertyOptionId = sysPropertyOptionId;
//            }
//
//            public String getSysPropertyOptionValue() {
//                return sysPropertyOptionValue;
//            }
//
//            public void setSysPropertyOptionValue(String sysPropertyOptionValue) {
//                this.sysPropertyOptionValue = sysPropertyOptionValue;
//            }
//
//            public String getSysPropertyOptionEnabled() {
//                return sysPropertyOptionEnabled;
//            }
//
//            public void setSysPropertyOptionEnabled(String sysPropertyOptionEnabled) {
//                this.sysPropertyOptionEnabled = sysPropertyOptionEnabled;
//            }
//
//            public String getSysPropertyOptionStatus() {
//                return sysPropertyOptionStatus;
//            }
//
//            public void setSysPropertyOptionStatus(String sysPropertyOptionStatus) {
//                this.sysPropertyOptionStatus = sysPropertyOptionStatus;
//            }
//
//            public String getSysPropertyOptionChar() {
//                return sysPropertyOptionChar;
//            }
//
//            public void setSysPropertyOptionChar(String sysPropertyOptionChar) {
//                this.sysPropertyOptionChar = sysPropertyOptionChar;
//            }
//        }
    }
}
