package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectDetailActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectUnArcActivity;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 查看车辆信息的recycleView的adapter
 */

public class SelectBindingCarAdapter extends QuickRcvAdapter<GuardianObjectResponse> {


    private final Context mContext;
    private final UserInfo mUserLoginInfo;
    private final UserBeanResponse mUserBeanResponse;

    public SelectBindingCarAdapter(Context context, UserBeanResponse userBeanResponse, List<GuardianObjectResponse> data, int... layoutId) {
        super(context, data, R.layout.item_select_car_binding);
        mContext = context;
        mUserBeanResponse = userBeanResponse;
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, final GuardianObjectResponse guardianObjectResponse) {
        ImageView checkedImg = viewHolder.getView(R.id.chackedImg);
        ImageView bikeImg = viewHolder.getView(R.id.bikeImg);
        TextView tvEdit = viewHolder.getView(R.id.tv_edit);
        TextView statusTxt = viewHolder.getView(R.id.statusTxt);
        TextView carNumberTxt = viewHolder.getView(R.id.carNumberTxt);
        carNumberTxt.setText(guardianObjectResponse.getSysServiceTypeName());
        tvEdit.setText(guardianObjectResponse.getSysPropertyValueStr());

        //1 未激活2 锁定中3 已激活、有效中4 已过期5 删除了
        if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 2) {
            statusTxt.setText("锁定中");
            statusTxt.setTextColor(mContext.getResources().getColor(R.color.color_ff0000));
        } else if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 3) {
            statusTxt.setText("已激活");
            statusTxt.setTextColor(mContext.getResources().getColor(R.color.color_12bc00));
        } else if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 4) {
            statusTxt.setText("已过期");
            statusTxt.setTextColor(mContext.getResources().getColor(R.color.color_999999));
        } else {
            statusTxt.setText("未激活");
            statusTxt.setTextColor(mContext.getResources().getColor(R.color.color_333333));
        }

        ImageUtil.loadJianhuObjectPic(mContext, guardianObjectResponse.getSysServiceTypeIcon(), bikeImg);

        if (guardianObjectResponse.isCheck()) {
            checkedImg.setImageResource(R.drawable.list_radio_checked);
        } else {
            checkedImg.setImageResource(R.drawable.list_radio_default);
        }

        tvEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GuardianObjectResponse guardianObjectResponse = mList.get(position);
                Intent intent;
                if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {//未激活
                    intent = new Intent(mContext, JianHuObjectUnArcActivity.class);
                    intent.putExtra("userBean", mUserBeanResponse);
                    intent.putExtra("isSelect", true);
                } else {
                    intent = new Intent(mContext, JianHuObjectDetailActivity.class);
                }
                intent.putExtra("guardianObjectResponse", guardianObjectResponse);
                mContext.startActivity(intent);
            }
        });
    }


}
