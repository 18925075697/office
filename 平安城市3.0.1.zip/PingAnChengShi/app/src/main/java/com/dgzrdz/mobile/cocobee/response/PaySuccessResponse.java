package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:支付成功响应
 * Author: Liubingren
 * Data:  2018/12/17
 * Time:  14:41
 */

public class PaySuccessResponse implements Serializable{

    /**
     * memberOrderAcviveTime : 2018-12-18 00:00:00
     * memberOrderType : 1
     */

    private String memberOrderAcviveTime;
    private String memberOrderType;//订单类型，\n1 服务+保险\n2 服务\n3 保险
    private String memberOrderId;//订单id

    public String getMemberOrderId() {
        return memberOrderId;
    }

    public void setMemberOrderId(String memberOrderId) {
        this.memberOrderId = memberOrderId;
    }

    public String getMemberOrderAcviveTime() {
        return memberOrderAcviveTime;
    }

    public void setMemberOrderAcviveTime(String memberOrderAcviveTime) {
        this.memberOrderAcviveTime = memberOrderAcviveTime;
    }

    public String getMemberOrderType() {
        return memberOrderType;
    }

    public void setMemberOrderType(String memberOrderType) {
        this.memberOrderType = memberOrderType;
    }
}
