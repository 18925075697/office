package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baoyz.actionsheet.ActionSheet;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.kernal.passportreader.sdk.CardsCameraActivity;
import com.kernal.passportreader.sdk.utils.ManageIDCardRecogResult;

import org.greenrobot.eventbus.EventBus;

import java.text.ParseException;

import butterknife.BindView;
import butterknife.OnClick;
import kernal.idcard.android.ResultMessage;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/12
 * Time:  10:55
 */

public class ChangeIdentityInfoFragment extends BaseFragment {
    private static final int REQUEST_CAMARA_CODE = 111;
    private static final int REQUEST_READ_PHONE_STATE_CODE = 222;
    private static UserBeanResponse userBeanResponse;
    @BindView(R.id.tv_ocr_scan)
    TextView mTvOcrScan;
    @BindView(R.id.nameEdt)
    EditText mNameEdt;
    @BindView(R.id.idEdt)
    EditText mIdEdt;
    @BindView(R.id.sexTxt)
    TextView mSexTxt;
    @BindView(R.id.iv_sex_more)
    ImageView mIvSexMore;
    @BindView(R.id.reg_addressTxt)
    EditText mRegAddressTxt;
    @BindView(R.id.addressTxt)
    TextView mAddressTxt;
    @BindView(R.id.addressEdt)
    EditText mAddressEdt;
    @BindView(R.id.tv_save)
    TextView mTvSave;

    public static ChangeIdentityInfoFragment getInstance(UserBeanResponse userBeanResponse) {
        ChangeIdentityInfoFragment.userBeanResponse = userBeanResponse;
        ChangeIdentityInfoFragment fragment = new ChangeIdentityInfoFragment();
        return fragment;
    }


    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setView();
        initListener();
    }

    private void setView() {
        mNameEdt.setText(userBeanResponse.getMemberName());
        mIdEdt.setText(userBeanResponse.getMemberCardId());
        mSexTxt.setText(CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? "男" : "女");
        mAddressEdt.setText(userBeanResponse.getMemberLiveAddress());
        mRegAddressTxt.setText(userBeanResponse.getMemberRegisterAddress());
    }

    private void initListener() {
        //限制姓名输入特殊字符
        mNameEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String editable = mNameEdt.getText().toString();
                String str = Utils.stringFilter(editable.toString());
                if (!editable.equals(str)) {
                    mNameEdt.setText(str);
                    //设置新的光标所在位置
                    mNameEdt.setSelection(str.length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("修改身份信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_change_identity_info;
    }


    @OnClick({R.id.tv_ocr_scan, R.id.sexTxt, R.id.tv_save})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_ocr_scan:
                if (PermissionUtils.requestPermission(this, Manifest.permission.CAMERA, REQUEST_CAMARA_CODE, "权限申请：\n我们需要您开启相机权限")
                        && PermissionUtils.requestPermission(this, Manifest.permission.READ_PHONE_STATE, REQUEST_READ_PHONE_STATE_CODE, "权限申请：\n我们需要您开启手机识别权限")) {
                    toCamera();
                }
                break;
            case R.id.sexTxt://选择性别
                sexSelect();
                break;
            case R.id.tv_save://保存
                save();
                break;
        }
    }

    /**
     * 保存
     */
    private void save() {
        String name = mNameEdt.getText().toString().trim();
        String idcard = mIdEdt.getText().toString().trim();
        String sex = mSexTxt.getText().toString().trim();
        String regAddress = mRegAddressTxt.getText().toString().trim();
        String address = mAddressEdt.getText().toString().trim();

        String idCArdNum = "";

        try {
            idCArdNum = CheckUtils.IDCardValidate(idcard);
        } catch (ParseException e) {
            e.printStackTrace();
            XToastUtils.showLongToast("身份证无效");
        } catch (Exception e) {
            idCArdNum = "身份证格式错误";
            e.printStackTrace();
            XToastUtils.showLongToast("身份证无效");
        }

        if (CheckUtils.isEmpty(name)) {
            XToastUtils.showShortToast("请输入姓名");
        } else if (CheckUtils.isEmpty(idcard)) {
            XToastUtils.showShortToast("请输入身份证号码");
        } else if (!CheckUtils.equalsString(idCArdNum, "")) {
            XToastUtils.showLongToast("身份证无效");
        } else if (CheckUtils.isEmpty(sex)) {
            XToastUtils.showShortToast("请选择性别");
        } else if (CheckUtils.isEmpty(regAddress)) {
            XToastUtils.showShortToast("请输入户籍地址");
        } else {
            upload(name, idcard, sex, regAddress, address);
        }
    }

    /**
     * 保存
     *
     * @param name
     * @param idcard
     * @param sex
     * @param regAddress
     * @param address
     */
    private void upload(String name, String idcard, String sex, String regAddress, String address) {
        DatasApiUtils.updateCarHostInfo(_mActivity, "", name, idcard, sex, regAddress, address, userBeanResponse.getMemberId(), new DialogCallback<Object>(_mActivity, "修改中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                userBeanResponse.setMemberName(name);
                userBeanResponse.setMemberCardId(idcard);
                userBeanResponse.setMemberSix(CheckUtils.equalsString(sex, "女") ? "2" : "1");
                userBeanResponse.setMemberRegisterAddress(regAddress);
                userBeanResponse.setMemberLiveAddress(address);
                EventBus.getDefault().post(new EventManager(EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS, userBeanResponse));
                XToastUtils.showShortToast("修改成功");
                pop();
            }
        });
    }

    /**
     * 性别选择
     */
    private void sexSelect() {
        ActionSheet.createBuilder(_mActivity, getFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("男(man)", "女(woman)")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {
                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                mSexTxt.setText("男");
                                break;
                            case 1:
                                mSexTxt.setText("女");
                                break;
                        }
                    }
                }).show();
    }


    private void toCamera() {
//        Utils.startActivity(_mActivity, CameraMiddleActivity.class);
        Utils.setOcrValue(_mActivity.getApplicationContext());
        Intent intent=new Intent(getActivity(), CardsCameraActivity.class);
        startActivityForResult(intent,6611);

    }

    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMARA_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (PermissionUtils.requestPermission(_mActivity, Manifest.permission.READ_PHONE_STATE, REQUEST_READ_PHONE_STATE_CODE, "权限申请：\n我们需要您开启手机识别权限")) {
                        toCamera();
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(_mActivity, Manifest.permission.CAMERA, "app需要开启相机权限,是否去设置?", "用户拒绝相机授权");
                }
                break;

            case REQUEST_READ_PHONE_STATE_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (PermissionUtils.requestPermission(_mActivity, Manifest.permission.CAMERA, REQUEST_CAMARA_CODE, "权限申请：\n我们需要您开启相机权限")) {
                        toCamera();
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(_mActivity, Manifest.permission.READ_PHONE_STATE, "app需要开启手机识别权限,是否去设置?", "用户拒绝手机识别授权");
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 6611) {
            Bundle bundle=data.getBundleExtra("resultbundle");
            ResultMessage resultMessage=(ResultMessage) bundle.getSerializable("resultMessage");
            //数据的封装
            String result= ManageIDCardRecogResult.managerSucessRecogResult(resultMessage);
//            EventBus.getDefault().post(new EventManager(EventConstants.OCR_SCAN_SUCCESS, result));
            ocrSuccess(result);
        }
//        finish();
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.OCR_SCAN_SUCCESS://ocr扫描成功
                Intent data = (Intent) eventManager.getData();
//                ocrSuccess(data);
                break;
        }
    }

    /**
     * OCR扫描成功
     *
     * @param data
     */
    private void ocrSuccess(String data) {
        String cardid = "";
        String name = "";
        String gender = "";
        String birth = "";
        String address = "";

        String[] split = data.split(",");
        if (split.length < 6) {
            XToastUtils.showLongToast("未识别身份证");
            return;
        }
        name = split[0].split(":")[1];
        gender = split[1].split(":")[1];
        birth = split[3].split(":")[1];
        address = split[4].split(":")[1];
        cardid = split[5].split(":")[1];


        mNameEdt.setText(name);
        mIdEdt.setText(cardid);
        mSexTxt.setText(gender);
        mRegAddressTxt.setText(address);
//        String cardid = "";
//        String name = "";
//        String gender = "";
//        String birth = "";
//        String address = "";
//        if (data == null) {
//            XToastUtils.showShortToast("识别失败");
//        } else {
//            String exception = data.getStringExtra("exception");
//            if (!CheckUtils.isEmpty(exception)) {
//                XToastUtils.showShortToast(exception);
//            } else {
//                cardid = data.getStringExtra("cardid");
//                name = data.getStringExtra("name");
//                gender = data.getStringExtra("gender");
//                birth = data.getStringExtra("birth");
//                address = data.getStringExtra("address");
//            }
//        }
//        mNameEdt.setText(name);
//        mIdEdt.setText(cardid);
//        mSexTxt.setText(gender);
//        mRegAddressTxt.setText(address);
    }
}
