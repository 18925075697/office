package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;

public class UserInfo implements Serializable {

    /**
     * dataList : {"appMemberInfo":"test","appMemberStatus":"1","appMemberAddTime":"2018-10-27","appMemberId":"1","appMemberAccount":"18507552562","sysInstallPlaceId":"1","appMemberName":"李总","sysAreaId":"1","appMemberEnabled":"1","RoleName":"业务人员","appMemberSex":"1","appMemberCardId":"431081","sysAreaName":"全部"}
     * token : 76244e4d84c414265343fe3745727664
     */

    private DataListBean dataList;
    private String token;

    public DataListBean getDataList() {
        return dataList;
    }

    public void setDataList(DataListBean dataList) {
        this.dataList = dataList;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public static class DataListBean implements Serializable{
        /**
         * appMemberInfo : test
         * appMemberStatus : 1
         * appMemberAddTime : 2018-10-27
         * appMemberId : 1
         * appMemberAccount : 18507552562
         * sysInstallPlaceId : 1
         * appMemberName : 李总
         * sysAreaId : 1
         * appMemberEnabled : 1
         * RoleName : 业务人员
         * appMemberSex : 1
         * appMemberCardId : 431081
         * sysAreaName : 全部
         */

        private String appMemberInfo;
        private String appMemberStatus;
        private String appMemberAddTime;
        private String appMemberId;
        private String appMemberAccount;
        private String sysInstallPlaceId;
        private String appMemberName;
        private String sysAreaId;
        private String appMemberEnabled;
        private String RoleName;
        private String appMemberSex;
        private String appMemberCardId;
        private String sysAreaName;
        private String Picture_prefix_url;//图片前缀

        public String getPicture_prefix_url() {
            return Picture_prefix_url;
        }

        public void setPicture_prefix_url(String picture_prefix_url) {
            Picture_prefix_url = picture_prefix_url;
        }

        public String getAppMemberInfo() {
            return appMemberInfo;
        }

        public void setAppMemberInfo(String appMemberInfo) {
            this.appMemberInfo = appMemberInfo;
        }

        public String getAppMemberStatus() {
            return appMemberStatus;
        }

        public void setAppMemberStatus(String appMemberStatus) {
            this.appMemberStatus = appMemberStatus;
        }

        public String getAppMemberAddTime() {
            return appMemberAddTime;
        }

        public void setAppMemberAddTime(String appMemberAddTime) {
            this.appMemberAddTime = appMemberAddTime;
        }

        public String getAppMemberId() {
            return appMemberId;
        }

        public void setAppMemberId(String appMemberId) {
            this.appMemberId = appMemberId;
        }

        public String getAppMemberAccount() {
            return appMemberAccount;
        }

        public void setAppMemberAccount(String appMemberAccount) {
            this.appMemberAccount = appMemberAccount;
        }

        public String getSysInstallPlaceId() {
            return sysInstallPlaceId;
        }

        public void setSysInstallPlaceId(String sysInstallPlaceId) {
            this.sysInstallPlaceId = sysInstallPlaceId;
        }

        public String getAppMemberName() {
            return appMemberName;
        }

        public void setAppMemberName(String appMemberName) {
            this.appMemberName = appMemberName;
        }

        public String getSysAreaId() {
            return sysAreaId;
        }

        public void setSysAreaId(String sysAreaId) {
            this.sysAreaId = sysAreaId;
        }

        public String getAppMemberEnabled() {
            return appMemberEnabled;
        }

        public void setAppMemberEnabled(String appMemberEnabled) {
            this.appMemberEnabled = appMemberEnabled;
        }

        public String getRoleName() {
            return RoleName;
        }

        public void setRoleName(String RoleName) {
            this.RoleName = RoleName;
        }

        public String getAppMemberSex() {
            return appMemberSex;
        }

        public void setAppMemberSex(String appMemberSex) {
            this.appMemberSex = appMemberSex;
        }

        public String getAppMemberCardId() {
            return appMemberCardId;
        }

        public void setAppMemberCardId(String appMemberCardId) {
            this.appMemberCardId = appMemberCardId;
        }

        public String getSysAreaName() {
            return sysAreaName;
        }

        public void setSysAreaName(String sysAreaName) {
            this.sysAreaName = sysAreaName;
        }
    }
}
