package com.dgzrdz.mobile.cocobee.fragment.manager;

import android.Manifest;
import android.app.Dialog;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.BarCodeScanActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.BluetoothUpgradeActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.ConnectAct;
import com.dgzrdz.mobile.cocobee.activity.manager.ConvenienceActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.DeviceDebugAct;
import com.dgzrdz.mobile.cocobee.activity.manager.HplateInfoActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.LocationActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.PointManageListAct;
import com.dgzrdz.mobile.cocobee.activity.manager.ReadTagActivity;
import com.dgzrdz.mobile.cocobee.activity.manager.SearchTagAct;
import com.dgzrdz.mobile.cocobee.activity.manager.ShowMapAct;
import com.dgzrdz.mobile.cocobee.adapter.ManagerAdapter;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.btreader.BlueToothHelper;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback1;
import com.dgzrdz.mobile.cocobee.common.AppConstants;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.CarInfoResponse;
import com.dgzrdz.mobile.cocobee.response.ManagerResponse;
import com.dgzrdz.mobile.cocobee.response.PowerResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.lang.ref.WeakReference;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;


/**
 * 工具的fragment
 * Created by Administrator on 2017/4/17.
 */

public class ManagerFragment extends RefreshAndLoadFragment<ManagerResponse> {

    private ManagerAdapter mManagerAdapter;

    //蓝牙
    private BlueToothHelper reader;// Blue Tooth reader
    private SweetAlertDialog sDialog;

    private Handler handler = new MyHandler(ManagerFragment.this);
    private static final int REQUEST_TIAOXINMA_CODE = 1;
    private static final int REQUEST_LOCATION_CODE = 2;
    private static final int REQUEST_STORAGE_CODE = 3;


    static class MyHandler extends Handler {

        private final WeakReference mManagerFragment;

        public MyHandler(ManagerFragment managerFragment) {
            mManagerFragment = new WeakReference(managerFragment);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            ManagerFragment managerFragment = (ManagerFragment) mManagerFragment.get();
            if (managerFragment != null) {
                managerFragment.getHandleMessage(msg);
            }
        }
    }

    private void getHandleMessage(Message msg) {
        switch (msg.what) {
            case BlueToothHelper.MSG_CARRIER_TEST_OK://发送载波指令成功
                XToastUtils.showShortToast("指令发送成功");
                break;

            case BlueToothHelper.MSG_CARRIER_TEST_FIAL://发送载波指令失败
                XToastUtils.showShortToast("指令发送失败");
                break;
            case BlueToothHelper.MSG_GET_DEVICE_POWER_OK://读取电量成功
                sDialog.dismiss();
                XToastUtils.showShortToast("读取电量成功");
                PowerResponse powerResponse = (PowerResponse) msg.obj;
                showPowerDialog(powerResponse);
                break;
            case BlueToothHelper.MSG_GET_DEVICE_POWER_FAIL://读取电量失败
                sDialog.dismiss();
                XToastUtils.showShortToast("读取电量失败");
                break;
            case BlueToothHelper.MSG_NO_BLUETOOTH_SOCKET:
                XToastUtils.showShortToast("蓝牙Socket已丢失，请重新连接设备");
                break;
            case BlueToothHelper.MSG_CHECK_PWD_OK://密码校验成功
                sDialog.dismiss();
                XToastUtils.showShortToast("密码校验成功");
                break;
            case BlueToothHelper.MSG_CHECK_PWD_FAIL://密码校验失败
                sDialog.dismiss();
                XToastUtils.showShortToast("密码校验失败");
                break;
            default:
                break;

        }
    }


    /**
     * 读取电池电量成功弹窗显示电量
     *
     * @param powerResponse 电量信息
     */
    private void showPowerDialog(PowerResponse powerResponse) {
        View view1 = View.inflate(_mActivity, R.layout.power_percent, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(_mActivity, view1, 270, 89);
        TextView tvPower = (TextView) alertDialog.findViewById(R.id.tv_power);
        int power = powerResponse.getPower();
        tvPower.setText(power + "%");
    }

    public static ManagerFragment getInstance() {
        return new ManagerFragment();
    }

    @Override
    protected boolean lazyLoadMode() {
        return true;
    }

    @Override
    protected void initLazyViews(@Nullable Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        mManagerAdapter = new ManagerAdapter(_mActivity, mList);
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
    }

    /**
     * 根据标识跳转相应的页面
     *
     * @param position 点击条目位置
     */
    private void toPaper(int position) {
        ManagerResponse managerResponse = mList.get(position);
        switch (Utils.getNaviValue(managerResponse.getPermissionValue())) {
            case 5://连接设备
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, ConnectAct.class));
                }
                break;
            case 6://电池电量
                getDevicePower();
                break;
            case 7://标签搜索
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_STORAGE_CODE, "权限申请：\n我们需要您开启设备存储权限")) {
                    startActivity(new Intent(_mActivity, SearchTagAct.class));
                }
                break;
            case 8://手动踩点
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, ShowMapAct.class).putExtra("flag", Constant.SDCD));
                }
                break;
            case 9://安装调试
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, DeviceDebugAct.class));
                }
                break;
            case 10://点位管理
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, PointManageListAct.class));
                }
                break;
            case 11://标签读取
                startActivity(new Intent(_mActivity, ReadTagActivity.class));
                break;
            case 12://基站信息
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, LocationActivity.class));
                }
                break;
            case 13://蓝牙升级
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_STORAGE_CODE, "权限申请：\n我们需要您开启设备存储权限")) {
                    startActivity(new Intent(_mActivity, BluetoothUpgradeActivity.class));
                }
                break;
            case 14://便民服务
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
                    startActivity(new Intent(_mActivity, ConvenienceActivity.class));
                }
                break;
            case 19://车牌读取
                if (PermissionUtils.requestPermission(ManagerFragment.this, Manifest.permission.CAMERA, REQUEST_TIAOXINMA_CODE, "权限申请：\n我们需要您开启相机权限")) {
                    erWeiMa();
                }
                break;
        }
    }

    /**
     * 二维码扫描
     */
    private void erWeiMa() {
        startActivityForResult(new Intent(_mActivity, BarCodeScanActivity.class), 1666);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1666 && resultCode == AppConstants.SCAN_LABEL_RESULT_CODE) {
            String scanResult = data.getStringExtra("scanResult");
            System.out.println("#############scanResult: " + scanResult);
            getCarInfo(scanResult);
            return;
        }
    }

    /**
     * 通过扫码获取车牌密文获取车辆信息
     *
     * @param scanResult 车牌密文
     */
    private void getCarInfo(String scanResult) {
        ManagerApiUtils.getCarInfoByCno(_mActivity, scanResult, new DialogCallback1<CarInfoResponse>(_mActivity, "获取车辆信息中...") {
            @Override
            public void onSuccess(CarInfoResponse carInfoResponse, Call call, Response response) {
                if (carInfoResponse != null) {
                    Intent intent = new Intent(_mActivity, HplateInfoActivity.class);
                    intent.putExtra("carInfoResponse", carInfoResponse);
                    startActivity(intent);
                } else {
                    XToastUtils.showShortToast("暂未获取到相关信息");
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        reader = BlueToothHelper.getInstance(handler);
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_manager;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        toPaper(position);
    }

    @Override
    public QuickRcvAdapter<ManagerResponse> getAdapter() {
        return mManagerAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(_mActivity, 3);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        mList.add(new ManagerResponse("设备连接", "Linkingdevice", R.drawable.mgt_connecting_device));
        mList.add(new ManagerResponse("安装调试", "InstallationDebugging", R.drawable.mgt_nstallation));
        mList.add(new ManagerResponse("点位管理", "PointManagement", R.drawable.mgt_pointmgt));
        mList.add(new ManagerResponse("手动采点", "ManuallyCheckPoints", R.drawable.mgt_setpoint));
        mList.add(new ManagerResponse("电池电量", "BatteryPower", R.drawable.mgt_cellele));
        mList.add(new ManagerResponse("标签搜索", "TagSearch", R.drawable.mgt_searchtag));
        mList.add(new ManagerResponse("标签读取", "TagReading", R.drawable.mgt_tagreading));
        mList.add(new ManagerResponse("基站信息", "EquipmentInformation", R.drawable.mgt_station_infor));
        mList.add(new ManagerResponse("蓝牙升级", "BluetoothUpgrade", R.drawable.mgt_btupdate));
        mList.add(new ManagerResponse("车牌读取", "CarNumReader", R.drawable.mgt_platenumber));

        mManagerAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean inVisibleLeftDrawable() {
        return true;
    }

    @Override
    public boolean canRefresh() {
        return false;
    }

    /**
     * 获取设备电池的电量
     */
    private void getDevicePower() {
        if (!isConnected()) {
            XToastUtils.showShortToast("未连接设备，无法读取");
            return;
        }

        sDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.PROGRESS_TYPE);
        sDialog.setTitleText("正在读取...");
        sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        sDialog.setCancelable(true);
        sDialog.setCanceledOnTouchOutside(true);
        sDialog.show();
        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            reader.getDevicePower();
        } else {
            reader.bleSendCmd(Constant.BLE_LOOK_DEVICE_POWER, BlueToothHelper.GET_DEVICE_POWER, false);
        }
    }

    //判断蓝牙设备是否已经连接
    private boolean isConnected() {
        SharedPreferences sp = _mActivity.getSharedPreferences(Constant.SP_CONNECT_STATUS, Context.MODE_PRIVATE);
        boolean status = sp.getBoolean(Constant.CONNECT_STATUS, false);

        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC && status && (reader.getSocket() == null || !reader.getSocket().isConnected())) { //如果当前标记已连接，但是socket连接实际已经断了
            SharedPreferences.Editor editor = sp.edit();
            editor.putBoolean(Constant.CONNECT_STATUS, false);
            editor.commit();
            status = false;
        }
        return status;
    }

    @Override
    public void onLoadMore() {
    }

    /**
     * 提示是否验证密码
     */
    private void showPwdCheckDialog() {
        SweetAlertDialog continueDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.NORMAL_TYPE);
        continueDialog.setTitleText("温馨提示");
        continueDialog.setContentText("是否需要密码校验");
        continueDialog.showCancelButton(true).setCancelText("不校验");
        continueDialog.setConfirmText("校验");
        continueDialog.setConfirmClickListener(sweetAlertDialog -> {
            sweetAlertDialog.dismiss();
            checkPwd();
        });

        continueDialog.setCancelClickListener(Dialog::dismiss);

        continueDialog.show();
    }

    /**
     * 验证密码
     */
    private void checkPwd() {
        sDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.PROGRESS_TYPE);
        sDialog.setTitleText("正在校验密码...");
        sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        sDialog.setCancelable(true);
        sDialog.setCanceledOnTouchOutside(true);
        sDialog.show();
        reader.sendPwdCommend(Constant.BLE_CHECK_PWD, BlueToothHelper.BLUETOOTH_PWD_CHECK);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.BLE_CONNECT_SUCCESS://蓝牙连接成功,进行密码验证提示
                showPwdCheckDialog();
                break;
        }
    }
}
