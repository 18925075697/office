package com.dgzrdz.mobile.cocobee.fragment.manager;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.ThreadPool;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.DeviceUpdatePathAdapter;
import com.dgzrdz.mobile.cocobee.btreader.BlueToothHelper;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.DeviceUpdateResponse;
import com.dgzrdz.mobile.cocobee.utils.FileUtils;
import com.dgzrdz.mobile.cocobee.utils.Tools;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.lzy.okgo.OkGo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Administrator on 2017/12/16.
 */

public class BluetoothUpgradeFragment extends BaseFragment {
    private static final int MSG_DOWNLOAD_OK = 1;
    private static final int MSG_DOWNLOAD_FAIL = 3;
    private static final int REQUEST_CODE_DOWNLOAD = 2;
    @BindView(R.id.tv_start_upgrade)
    TextView mTvStartUpgrade;
    @BindView(R.id.tv_start_upload)
    TextView mTvStartUpload;

    String path = Path.PROJECT_FILE_PATH + "upgrade_.bin";//存在手机里面的文件
    @BindView(R.id.tv_upgrade_status)
    TextView mTvUpgradeStatus;

    private SweetAlertDialog sDialog;
    private BlueToothHelper reader;// Blue Tooth reader
    private boolean isSending;//正在发送标识


    private final Handler handler = new MyHandler(BluetoothUpgradeFragment.this);

    static class MyHandler extends Handler{

        private final BluetoothUpgradeFragment mBluetoothUpgradeFragment;

        public MyHandler(BluetoothUpgradeFragment bluetoothUpgradeFragment) {
            mBluetoothUpgradeFragment = bluetoothUpgradeFragment;
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mBluetoothUpgradeFragment.handleSuccess(msg);
        }
    }

    private void handleSuccess(Message msg) {
        if (sDialog != null && sDialog.isShowing()) {
            sDialog.dismiss();
        }
        isSending = false;
        switch (msg.what) {
            case BlueToothHelper.MSG_START_UPGRADE_OK://开始升级成功
                XToastUtils.showShortToast("升级开始成功,开始发送文件");
                System.out.println("############升级开始成功,开始发送文件");
                showDialog("正在发送...");
                isSending = true;
                sendFile();
                break;
            case BlueToothHelper.MSG_START_UPGRADE_FAIL://开始升级失败
                XToastUtils.showShortToast("升级开始失败");
                System.out.println("############升级开始失败");
                break;
            case BlueToothHelper.MSG_SEND_UPGRADE_CONTENT_OK:
                XToastUtils.showShortToast("发送升级包内容完成");
                System.out.println("############发送升级包内容完成");
                showDialog("正在升级...");
                isSending = true;
                sendUpgradeFinish();
                break;
            case BlueToothHelper.MSG_SEND_UPGRADE_CONTENT_FAIL:
                XToastUtils.showShortToast("发送升级包内容失败");
                System.out.println("########发送升级包内容失败");
                break;
            case BlueToothHelper.MSG_UPGRADE_FINISH_OK://升级结束指令发送成功
                XToastUtils.showShortToast("升级结束");
                System.out.println("########升级结束");
                //设备重启会发送无关数据,所以结束继续接收数据
                reader.setBleCmdType(Constant.BLE_GET_UPGRADE_NO);
                mTvUpgradeStatus.setVisibility(View.VISIBLE);
                mTvUpgradeStatus.setText("升级成功");
                break;
            case BlueToothHelper.MSG_UPGRADE_FINISH_FAIL://升级结束指令发送失败
                XToastUtils.showShortToast("升级失败,请重新升级");
                System.out.println("########升级失败");
                mTvUpgradeStatus.setVisibility(View.VISIBLE);
                mTvUpgradeStatus.setText("升级失败,请重新升级");
                break;
            case BlueToothHelper.MSG_NO_BLUETOOTH_SOCKET:
                XToastUtils.showShortToast("蓝牙Socket已丢失，请重新连接设备");
                break;
            case MSG_DOWNLOAD_OK:
                hideDialog();
                XToastUtils.showShortToast("升级文件下载成功");
                break;
            case MSG_DOWNLOAD_FAIL:
                hideDialog();
                XToastUtils.showShortToast("升级文件下载失败");
                break;

            default:
                break;

        }
    }

    /**
     * 升级包内容发送完成,发送升级结束指令
     */
    private void sendUpgradeFinish() {
        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            reader.getUpgradeFinish();
        } else {
            reader.bleSendCmd(Constant.BLE_UPGRADE_FINISH, BlueToothHelper.UPGRADE_FINISH, false);
        }
    }

    /**
     * 开始升级成功后发送文件
     */
    private void sendFile() {
        byte[] fileBytes = Tools.getFileBytes(path);
        int totalPakage = (fileBytes.length - 1) / 64 + 1; // 需要发送的包数
        System.out.println("############" + fileBytes.length);
        ThreadPool.runOnWorker(new Runnable() {
            @Override
            public void run() {
                for (int count = 0; count < totalPakage; count++) {
                    byte[] sendBytes = new byte[64];
                    if (count == totalPakage - 1) {//最后一包
                        for (int i = 0; i < 64; i++) {
                            if ((count * 64 + i) < (fileBytes.length)) {
                                sendBytes[i] = fileBytes[count * 64 + i];
                            } else {
                                sendBytes[i] = 0;
                            }
                        }

                    } else {
                        for (int i = 0; i < 64; i++) {
                            sendBytes[i] = fileBytes[count * 64 + i];
                        }
                    }
                    sendCommend(sendBytes);
                    SystemClock.sleep(400);
                }

                //2.0和4.0的发送升级包内容都不需要回应,直接发送结束指令
                sendUpgradeFinish();
            }
        });
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        }).start();
    }

    /**
     * 拼接升级内容分包指令
     *
     * @param sendBytes 升级包内容
     */
    private void sendCommend(byte[] sendBytes) {
        byte[] cmd = new byte[69];
        cmd[0] = 0x0A; //sof
        cmd[1] = (byte) 0xFF;  //addr
        cmd[2] = 0x42;//len
        cmd[3] = 0x32; //cmd
        for (int i = 0; i < sendBytes.length; i++) {
            cmd[4 + i] = sendBytes[i];
        }
        cmd[cmd.length - 1] = Tools.calCheck(cmd);
        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            reader.sendUpgradeContent(cmd);
        } else {
            reader.upgradeCommend(Constant.BLE_UPGRADE_CONTENT, cmd);
        }

    }

    public static BluetoothUpgradeFragment getInstance() {
        BluetoothUpgradeFragment fragment = new BluetoothUpgradeFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
    }

    private void showDialog(String dialogString) {
        sDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.PROGRESS_TYPE);
        sDialog.setTitleText(dialogString);
        sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        sDialog.setCancelable(true);
        sDialog.setCanceledOnTouchOutside(false);
        sDialog.show();
    }

    private void hideDialog() {
        if (sDialog != null && sDialog.isShowing()) {
            sDialog.dismiss();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        reader = BlueToothHelper.getInstance(handler);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("蓝牙升级");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_bluetooth_upgrade;
    }

    @OnClick({R.id.tv_start_upgrade, R.id.tv_start_upload})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_start_upload:
                if (requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_CODE_DOWNLOAD, "权限申请：\n我们需要您开启设备存储权限")) {
                    getDownloadPath();
                }
                break;
            case R.id.tv_start_upgrade:
                if (!Utils.isFastClick()) {
                    return;
                }
                if (!isConnected()) {
                    XToastUtils.showShortToast("未连接设备，无法读取");
                    return;
                }
                if (isSending) {
                    XToastUtils.showShortToast("当前正在发送中,请耐心等待");
                    showDialog("正在发送...");
                } else {
                    mTvUpgradeStatus.setVisibility(View.GONE);
                    getUpgradeFile();
                }

                break;
        }
    }

    /**
     * 获取升级包下载地址
     */
    private void getDownloadPath() {
        OkGo.post(Path.DEVICE_UPDATE_PATH).execute(new DialogCallback<List<DeviceUpdateResponse>>(_mActivity, "获取下载地址中...") {

            @Override
            public void onSuccess(List<DeviceUpdateResponse> deviceUpdateResponses, Call call, Response response) {
                if (deviceUpdateResponses != null && deviceUpdateResponses.size() > 0) {
                    showSelectDialog(deviceUpdateResponses);
                }
            }
        });

    }

    /**
     * 选择下载版本
     *
     * @param deviceUpdateResponses
     */
    private void showSelectDialog(List<DeviceUpdateResponse> deviceUpdateResponses) {
        View view = View.inflate(_mActivity, R.layout.label_list, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(_mActivity, view, 270, 270);
        RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.listView);
        TextView tvTitleCarLabel = (TextView) alertDialog.findViewById(R.id.tv_title_car_label);
        tvTitleCarLabel.setText("请选择下载版本");
        DeviceUpdatePathAdapter adapter = new DeviceUpdatePathAdapter(_mActivity, deviceUpdateResponses);
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new ListLineDecoration());
        recyclerView.setLayoutManager(new LinearLayoutManager(_mActivity));
        adapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {
                alertDialog.dismiss();
                DeviceUpdateResponse deviceUpdateResponse = deviceUpdateResponses.get(position);
                downLoad(deviceUpdateResponse.getAddress(), "upgrade_.bin");
            }
        });
    }

    /**
     * 获取手机中的升级文件
     */
    private void getUpgradeFile() {
        File file = new File(path);
        if (file.exists()) {
            try {
                FileInputStream fis = new FileInputStream(file);
                int length = fis.available();
                byte[] fileLengthByte = Tools.intToBytes2(length);
                byte[] cmd = new byte[5 + fileLengthByte.length];
                cmd[0] = 0x0A; //sof
                cmd[1] = (byte) 0xFF;  //addr
                cmd[2] = 0x06; //len
                cmd[3] = 0x31; //cmd
                for (int i = 0; i < fileLengthByte.length; i++) {
                    cmd[4 + i] = fileLengthByte[i];
                }
                cmd[cmd.length - 1] = Tools.calCheck(cmd);

                showDialog("正在发送...");
                isSending = true;
                if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                    reader.startUpgrade(cmd);
                } else {
                    reader.bleSendCmd(Constant.BLE_UPGRADE_START, cmd, false);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            XToastUtils.showShortToast("升级文件不存在 ,请先下载升级文件");
        }
    }

    private boolean isConnected() {

        SharedPreferences sp = _mActivity.getSharedPreferences(Constant.SP_CONNECT_STATUS, Context.MODE_PRIVATE);
        boolean status = sp.getBoolean(Constant.CONNECT_STATUS, false);

        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC && status && (reader.getSocket() == null || !reader.getSocket().isConnected())) { //如果当前标记已连接，但是socket连接实际已经断了
            SharedPreferences.Editor editor = sp.edit();
            editor.putBoolean(Constant.CONNECT_STATUS, false);
            editor.commit();
            status = false;
        }


        return status;
    }


    @Override
    public void onDestroy() {
        hideDialog();
        super.onDestroy();

    }

    /**
     * 从服务器下载文件
     *
     * @param path     下载文件的地址
     * @param FileName 文件名字
     */
    public void downLoad(final String path, final String FileName) {
        showDialog("正在下载...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(path);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setReadTimeout(5000);
                    con.setConnectTimeout(5000);
                    con.setRequestProperty("Charset", "UTF-8");
                    con.setRequestMethod("GET");
                    if (con.getResponseCode() == 200) {
                        InputStream is = con.getInputStream();//获取输入流
                        FileOutputStream fileOutputStream = null;//文件输出流
                        if (is != null) {
                            FileUtils fileUtils = new FileUtils();
                            fileOutputStream = new FileOutputStream(fileUtils.createFile(FileName));//指定文件保存路径，代码看下一步
                            byte[] buf = new byte[1024];
                            int ch;
                            while ((ch = is.read(buf)) != -1) {
                                fileOutputStream.write(buf, 0, ch);//将获取到的流写入文件中
                            }
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.flush();
                            fileOutputStream.close();
                        }
                        handler.sendEmptyMessage(MSG_DOWNLOAD_OK);
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(MSG_DOWNLOAD_FAIL);
                }
                handler.sendEmptyMessage(MSG_DOWNLOAD_FAIL);
            }
        }).start();
    }

    /**
     * 返回true表示已经有权限了
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    private boolean requestPermission(String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(_mActivity, permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(getActivity())
                        .setMessage(info)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(new String[]{permissions}, requestCode);
                            }
                        })
                        .show();
            } else {
                requestPermissions(new String[]{permissions}, requestCode);
            }
            return false;
        }
        return true;
    }


    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_DOWNLOAD:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    getDownloadPath();
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启设备存储权限,是否去设置?", "用户拒绝设备存储授权");
                }
                break;
            default:
                break;
        }
    }


    /**
     * 判断用户是否点击过不再提醒
     *
     * @param
     * @param permission
     */
    private void sureIfNotNotifiy(String permission, String msg, String toast) {
        //点击了不在提醒
        if (!ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permission)) {
            new AlertDialog.Builder(_mActivity)
                    .setMessage(msg)
                    .setPositiveButton("设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + _mActivity.getPackageName()));
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .create()
                    .show();
        } else {
            XToastUtils.showShortToast(toast);
        }
    }

}
