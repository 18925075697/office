package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bql.recyclerview.swipe.SwipeMenuAdapter;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.MsgResponse;

import java.util.List;

/**
 * Created by liu on 2016/10/29.
 * 消息adapter
 */
public class MessageAdapter extends SwipeMenuAdapter<MessageAdapter.MessageAdapterViewHolder> {
    private List<MsgResponse> mList;
    private Context mContext;

    public MessageAdapter(Context context, List<MsgResponse> list) {
        mList = list;
        this.mContext = context;
    }

    @Override
    public View onCreateContentView(ViewGroup parent, int viewType) {
        return LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false);
    }

    @Override
    public MessageAdapterViewHolder onCompatCreateViewHolder(View realContentView, int viewType) {
        return new MessageAdapterViewHolder(realContentView);
    }

    @Override
    public void onBindViewHolder(MessageAdapterViewHolder holder, int position) {
        holder.setData(mContext, mList.get(position));

    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }


    static class MessageAdapterViewHolder extends RecyclerView.ViewHolder {

        private final TextView time;
        private final TextView content;
        private final TextView title;

        public MessageAdapterViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.tv_mes_title);
            content = (TextView) itemView.findViewById(R.id.tv_mes_content);
            time = (TextView) itemView.findViewById(R.id.tv_mes_time);
        }

        public void setData(Context context, MsgResponse msgResponse) {
            title.setText(msgResponse.getSysMessageTitle());
            content.setText(msgResponse.getSysMessageContent());
            time.setText(msgResponse.getSysMessageAddTime());
        }
    }
}