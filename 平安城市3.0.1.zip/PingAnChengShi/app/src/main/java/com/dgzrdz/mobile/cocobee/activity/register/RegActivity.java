package com.dgzrdz.mobile.cocobee.activity.register;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.LoginApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.TimeCount;
import com.lzy.okgo.OkGo;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 注册Activity
 * Created by Administrator on 2017/4/13.
 */

public class RegActivity extends BaseToolbarActivity {

    @BindView(R.id.phone_et)
    EditText mPhoneEt;
    @BindView(R.id.check_code_et)
    EditText mCheckCodeEt;
    @BindView(R.id.get_checkcode_btn)
    Button mGetCheckcodeBtn;
    @BindView(R.id.check_box)
    CheckBox mCheckBox;
    @BindView(R.id.user_xieyi)
    TextView mUserXieyi;
    @BindView(R.id.reg_next)
    TextView mRegNext;
    private TimeCount timeCount;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_reg;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("用户注册");
        timeCount = new TimeCount(this, 60000, 1000, mGetCheckcodeBtn);
    }

    @OnClick({R.id.get_checkcode_btn, R.id.user_xieyi, R.id.reg_next})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.get_checkcode_btn:
                getPhone();
                break;
            case R.id.user_xieyi://用户协议
                startActivity(new Intent(this, UserManagerActivity.class));
                break;
            case R.id.reg_next://下一步
                String checkNum = mCheckCodeEt.getText().toString().trim();
                String phone = mPhoneEt.getText().toString().trim();
                if (CheckUtils.isEmpty(phone)) {
                    XToastUtils.showLongToast("请输入手机号");
                } else if (!CheckUtils.isMobilePhone(phone)) {
                    XToastUtils.showLongToast("手机号码格式不正确");
                } else if (CheckUtils.isEmpty(checkNum)) {
                    XToastUtils.showLongToast("请输入验证码");
                } else if (!mCheckBox.isChecked()) {
                    XToastUtils.showLongToast("请选择阅读并同意电动车管理用户协议");
                } else {//请求接口,提交参数下一步
                    getServerVerifyCode(phone, checkNum);
                }
                break;
        }
    }

    private void getPhone() {
        String phone = mPhoneEt.getText().toString().trim();
        if (CheckUtils.isEmpty(phone)) {
            XToastUtils.showShortToast("请输入手机号");
        } else if (!CheckUtils.isMobilePhone(phone)) {
            XToastUtils.showShortToast("手机号格式错误");
        } else {
            sendVerifyCode(phone);
        }
    }


    public void sendVerifyCode(String phone) {
        LoginApiUtils.sendCheckCodeReg(this, phone, new DialogCallback<Object>(this, "正在获取验证码...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                timeCount.start();
                XToastUtils.showShortToast("验证码发送成功");
            }
        });
    }

    //验证验证码是否正确
    private void getServerVerifyCode(final String phone, String checkNum) {
        LoginApiUtils.verificationCodeReg(this, phone, checkNum, new DialogCallback<Object>(this,"正在验证验证码...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                Intent intent = new Intent(RegActivity.this, ChangePwdActivity.class);
                intent.putExtra("phone", phone);
                intent.putExtra("type", "1");// 1为注册 2为忘记密码
                startActivity(intent);
            }
        });
    }

    private void stopCountTimer() {
        if (timeCount != null) {
            timeCount.cancel();
            timeCount = null;
        }
    }

    @Override
    protected void onDestroy() {
        stopCountTimer();
        OkGo.getInstance().cancelTag(this);
        super.onDestroy();
    }

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.REGISTER_SUCCESS://注册成功
                finish();
                break;
        }
    }
}
