package com.dgzrdz.mobile.cocobee.common;

import com.dgzrdz.mobile.cocobee.model.UserInfo;

public class JsonToken {

	private int retCode;
	private String retMsg;
	private UserInfo data;

	public int getRetCode() {
		return retCode;
	}

	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}

	public UserInfo getData() {
		return data;
	}

	public void setData(UserInfo data) {
		this.data = data;
	}
}
