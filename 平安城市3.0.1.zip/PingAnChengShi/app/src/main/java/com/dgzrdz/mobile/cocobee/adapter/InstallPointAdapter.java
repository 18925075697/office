package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.InstallPointInfoResponse;

import java.util.List;

/**
 * Created by Administrator on 2018/6/21.
 * 安装点adapter
 */

public class InstallPointAdapter extends QuickRcvAdapter<InstallPointInfoResponse> {


    public InstallPointAdapter(Context context, List<InstallPointInfoResponse> data, int... layoutId) {
        super(context, data, R.layout.item_install_point);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int position, InstallPointInfoResponse installPointInfoResponse) {
        quickRcvHolder.setText(R.id.tv_area_name, installPointInfoResponse.getOrgName());
    }
}
