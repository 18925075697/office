package com.dgzrdz.mobile.cocobee.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.manager.PointMapManageAct;
import com.dgzrdz.mobile.cocobee.activity.manager.ShowMapAct;
import com.dgzrdz.mobile.cocobee.adapter.ConvenienceAdapter;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.ConveniencePoint;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Response;

/**
 * 便民服务
 * Created by Administrator on 2017/6/14.
 */

public class ConvenienceFragment extends RefreshAndLoadFragment<ConveniencePoint> {
    private ConvenienceAdapter mConvenienceAdapter;
    private List<ConveniencePoint> convenienceList = new ArrayList<>();
    private UserInfo mUserLoginInfo;

    public static ConvenienceFragment getInstance() {
        ConvenienceFragment fragment = new ConvenienceFragment();
        return fragment;
    }

    @Override
    public void onLoadMore() {
        loadDataList(mCurPage, true);
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        Intent i = new Intent(_mActivity, PointMapManageAct.class);
        i.putExtra("flag", Constant.BMFW);
        i.putExtra("currentPosition", position);
        i.putExtra("list", (Serializable) convenienceList);
        startActivity(i);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_convenience;
    }

    @Override
    public QuickRcvAdapter<ConveniencePoint> getAdapter() {
        return mConvenienceAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        mCurPage = curPage;

        ManagerApiUtils.getConvinience(_mActivity, mUserLoginInfo.getDataList().getSysAreaId(), new RefreshAndLoadCallback<List<ConveniencePoint>>(isPullToRefresh) {

            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<ConveniencePoint> conveniencePoints, @Nullable Response response, LoadingViewCallback callback) {
                convenienceList = conveniencePoints;
                handleRefreshAndLoadListData(mCurPage, callback, conveniencePoints);
            }
        });
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mConvenienceAdapter = new ConvenienceAdapter(_mActivity, mList);
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithRightText("便民服务", "上传");
    }

    @Override
    public void btnRightTextClick() {
        startActivity(new Intent(_mActivity, ShowMapAct.class).putExtra("flag", Constant.BMFW));
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.NEED_REFRESH_CONVENIENCE_LIST:
                loadDataList(1, true);
                break;
        }
    }
}
