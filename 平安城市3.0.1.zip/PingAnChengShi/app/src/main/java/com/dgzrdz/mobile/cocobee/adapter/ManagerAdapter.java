package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.ImageView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.ManagerResponse;

import java.util.List;

/**
 * 查询的recycleView的adapter
 */

public class ManagerAdapter extends QuickRcvAdapter<ManagerResponse> {

    public ManagerAdapter(Context context, List<ManagerResponse> data, int... layoutId) {
        super(context, data, R.layout.manager_rec_item);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, ManagerResponse item) {
        ImageView view = viewHolder.getView(R.id.iv_home_pic);
        view.setImageResource(item.getUri());
        viewHolder.setText(R.id.tv_home_title, item.getName());
    }
}
