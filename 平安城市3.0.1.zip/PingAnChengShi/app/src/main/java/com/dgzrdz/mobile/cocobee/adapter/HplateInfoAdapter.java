package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.ImageView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 车辆图片的recycleView的adapter
 */

public class HplateInfoAdapter extends QuickRcvAdapter<String> {


    private final Context mContext;
    private final UserInfo mUserLoginInfo;

    public HplateInfoAdapter(Context context, List<String> data, int... layoutId) {
        super(context, data, R.layout.car_pic_rec_item);
        mContext = context;
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, String item) {
        ImageView ivPlate = viewHolder.getView(R.id.iv_phlate);
        if (CheckUtils.isWebUrl(item)) {//是全路径
            ImageUtil.loadPic(mContext, item, ivPlate);
        } else {
            ImageUtil.loadPic(mContext, mUserLoginInfo.getDataList().getPicture_prefix_url() + item, ivPlate);
        }
    }
}
