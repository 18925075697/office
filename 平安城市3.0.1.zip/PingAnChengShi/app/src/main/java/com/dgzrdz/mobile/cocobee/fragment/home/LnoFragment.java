package com.dgzrdz.mobile.cocobee.fragment.home;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.ultraptr.PtrClassicFrameLayout;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.LabelInventoryAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseViewPagerFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.LabelInventoryResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

import butterknife.BindView;
import okhttp3.Response;

/**
 * 标签库存
 * Created by Administrator on 2018/6/26.
 */

public class LnoFragment extends BaseViewPagerFragment<LabelInventoryResponse> {

    @BindView(R.id.rcv_load_more)
    LoadMoreRecyclerView mRcvLoadMore;
    @BindView(R.id.prt_layout_)
    PtrClassicFrameLayout mPrtLayout;
    private LabelInventoryAdapter mLabelInventoryAdapter;
    private String currentTime;
    private UserInfo mUserLoginInfo;

    public static LnoFragment getInstance() {
        LnoFragment fragment = new LnoFragment();
        return fragment;
    }

    @Override
    public void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mLabelInventoryAdapter = new LabelInventoryAdapter(_mActivity, mList);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_lno;
    }

    @Override
    protected void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    protected void onRefresh() {
        initData(1,true);
    }

    @Override
    protected RecyclerView.Adapter getAdapter() {
        return mLabelInventoryAdapter;
    }

    @Override
    protected void initData(int curPage,boolean isPullToRefresh) {
        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        DatasApiUtils.getLabelStock(_mActivity, currentTime, pageSize + "", curPage + "", mUserLoginInfo.getDataList().getSysAreaId(), new RefreshAndLoadCallback<List<LabelInventoryResponse>>(true) {

            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                initData(1,false);
            }

            @Override
            public void onResultSuccess(List<LabelInventoryResponse> labelInventoryResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshAndLoadListData(mCurPage, callback, labelInventoryResponses);
            }

            @Override
            public Drawable emptyDrawable() {
                return _mActivity.getResources().getDrawable(R.drawable.norecord);
            }

            @Override
            public String emptyContent() {
                return "暂无记录";
            }
        });
    }

    @Override
    public void onLoadMore() {
        initData(mCurPage,false);
    }
}
