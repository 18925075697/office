package com.dgzrdz.mobile.cocobee.activity.pay;

import android.os.Bundle;

import com.bql.utils.SystemBarUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.pay.PaySuccessFragment;
import com.dgzrdz.mobile.cocobee.response.PaySuccessResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * 支付成功/绑定成功
 * Created by _H_JY on 2017/1/19.
 */
public class PaySuccessActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        //状态栏透明
        SystemBarUtils.immersiveStatusBar(this, 0);
        PaySuccessResponse paySuccessResponse = (PaySuccessResponse) getIntent().getSerializableExtra("paySuccessResponse");
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, PaySuccessFragment.getInstance(paySuccessResponse));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }

    @Override
    protected boolean isApplyStatusBarTranslucent() {
        return true;
    }

    @Override
    protected boolean isStatusDarkMode() {
        return false;
    }
}