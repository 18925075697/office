package com.dgzrdz.mobile.cocobee.activity;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bql.tablayout.CommonTabLayout;
import com.bql.tablayout.listener.CustomTabEntity;
import com.bql.tablayout.listener.OnTabSelectListener2;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.common.AppManager;
import com.dgzrdz.mobile.cocobee.common.ElectricVehicleApp;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.fragment.databank.DataBankFragment;
import com.dgzrdz.mobile.cocobee.fragment.home.HomeFragment;
import com.dgzrdz.mobile.cocobee.fragment.manager.ManagerFragment;
import com.dgzrdz.mobile.cocobee.fragment.me.MeFragment;
import com.dgzrdz.mobile.cocobee.fragment.trace.TraceLookFragment;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.utils.DataProviderUtils;
import com.dgzrdz.mobile.cocobee.utils.MainTabEntity;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Tools;
import com.dgzrdz.mobile.cocobee.utils.UpdateManager;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;
import me.yokeyword.fragmentation.SupportFragment;

/**
 * 主界面
 */

public class MainActivity extends BaseActivity {
    public static final int REQUEST_LOCATION_CODE = 11;
    public static final int REQUEST_WRITE_CODE = 22;

    @BindView(R.id.main_tab_layout)
    CommonTabLayout mMainTabLayout;
    @BindView(R.id.rl_content)
    RelativeLayout mRlContent;
    private Context context;

    public static final int POSITION_QUERY = 0;//业务办理Position

    public static final int POSITION_DATA = 1;//资料库Position

    public static final int POSITION_TRACE = 2;//轨迹查询Position

    public static final int POSITION_SETTING = 3;//工具Position

    public static final int POSITION_ME = 4;//我Position

    //主页Tab未选中ID数组
    private int[] mMainIconNorIds;

    //主页Tab选中ID数组
    private int[] mMainIconSelIds;

    //Tab标题数组
    private String[] mMainTitles;

    //主页Fragment数组
    private SupportFragment[] mMainFragments;

    //Tab集合
    private ArrayList<CustomTabEntity> mMainTabs = new ArrayList<>();

    //Tab动画
    private Animation mTabAnimation = null;

    private int currentPosition;

    /*极光推送*/
    public static boolean isForeground = false;
    public static final String MESSAGE_RECEIVED_ACTION = "com.example.jpushdemo.MESSAGE_RECEIVED_ACTION";
    public static final String KEY_MESSAGE = "message";
    public static final String KEY_EXTRAS = "extras";

    private boolean exitFlag = false;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.act_main;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setSwipeBackEnable(false);//禁止滑动返回
        ButterKnife.bind(this);
        context = this;
        checkPermission();
        makeProjectFileDir();
        //极光推送
        loadJPush();
        //初始化tab
        initMainTabs();
        initFragment(savedInstanceState);
        //版本检查
        versionCheck();
    }

    @Override
    protected boolean isStatusDarkMode() {
        return false;
    }

    /**
     * 申请定位权限
     */
    private void checkPermission() {
        if (PermissionUtils.requestPermission(this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限")) {
            PermissionUtils.requestPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_WRITE_CODE, "权限申请：\n我们需要您开启设备存储权限");
        }
    }

    /**
     * 使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    PermissionUtils.requestPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_WRITE_CODE, "权限申请：\n我们需要您开启设备存储权限");
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION, "app需要开启地理位置权限,是否去设置?", "用户拒绝地理位置授权");
                }
                break;
            case REQUEST_WRITE_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    PermissionUtils.requestPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_LOCATION_CODE, "权限申请：\n我们需要您开启地理位置权限");
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "app需要开启设备存储权限,是否去设置?", "用户拒绝设备存储授权");
                }
                break;
            default:
                break;
        }
    }

    //版本检查
    private void versionCheck() {
        VersionInfo updateVersionInfo = Utils.getUpdateVersionInfo();
        if (updateVersionInfo == null) {
            return;
        }
        Date lastSaveDate = updateVersionInfo.getDate();
        boolean unRemind = updateVersionInfo.isUnRemind();
        long diffDays = 0;
        if (lastSaveDate != null) {
            Date todayDate = new Date(System.currentTimeMillis());
            long diffTime = todayDate.getTime() - lastSaveDate.getTime(); //计算时间间距：毫秒
            diffDays = diffTime / (1000 * 60 * 60 * 24); //计算时间间距(单位：天)
        }

        if (updateVersionInfo.isNeedUpdate() && (!unRemind || (diffDays >= 2))) { //即使选择“不再提醒”，过两天还是会弹出对话框提示更新
            UpdateManager updateManager = new UpdateManager(context);
            updateManager.showNoticeDialog();
        }

    }

    //加载极光推送
    private void loadJPush() {
        SharedPreferences sharedPreferences = getSharedPreferences("jpush_setalis_state", Context.MODE_PRIVATE);
        boolean aliaHaveSet = sharedPreferences.getBoolean("status", false);
        String alias = sharedPreferences.getString("alias", "");


        if (user != null && (!aliaHaveSet || !TextUtils.equals(user.getDataList().getAppMemberId(), alias))) {
            //极光推送，设置别名，可以指定用户推送
            String pid = user.getDataList().getAppMemberId();
            if (!TextUtils.isEmpty(pid)) {
                if (Tools.isValidTagAndAlias(pid)) {
                    // 调用 Handler 来异步设置别名
                    handler.sendMessage(handler.obtainMessage(MSG_SET_ALIAS, pid));
                }
            }
        }

    }

    private final TagAliasCallback mAliasCallback = new TagAliasCallback() {
        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            switch (code) {
                case 0:
                    // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
                    SharedPreferences sharedPreferences = getSharedPreferences("jpush_setalis_state", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("status", true);
                    editor.putString("alias", alias);
                    editor.commit();
                    break;
                case 6002:
                    // 延迟 60 秒来调用 Handler 设置别名
                    handler.sendMessageDelayed(handler.obtainMessage(MSG_SET_ALIAS, alias), 1000 * 60);
                    break;
                default:
            }

        }
    };


    private static final int MSG_SET_ALIAS = 1001;
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_SET_ALIAS:
                    // 调用 JPush 接口来设置别名。
                    JPushInterface.setAliasAndTags(context, (String) msg.obj, null, mAliasCallback);
                    break;
                default:
                    break;

            }
        }
    };

    /*预先创建好项目所需文件目录*/
    private void makeProjectFileDir() {
        //检查手机上是否有外部存储卡
        boolean sdCardExist = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
        if (!sdCardExist) {
            XToastUtils.showLongToast("请插入外部存储设备");
        } else {
            /*********************创建扫描记录文件夹*******************/
            File recordFile = new File(Path.RECORD_FILE_PATH);
            if (!recordFile.exists()) {
                recordFile.mkdirs();
            }

            /*********************创建临时图片文件夹*******************/
            File tempImageFile = new File(Path.IMAGE_TEMP_FILE_PATH);
            if (!tempImageFile.exists()) {
                tempImageFile.mkdirs();
            }
        }
    }

    /**
     * 初始化Tab
     */
    private void initMainTabs() {
        mTabAnimation = AnimationUtils.loadAnimation(this, R.anim.anim_main_tab);
        mMainIconNorIds = DataProviderUtils.getMainIconNorIds(this);
        mMainIconSelIds = DataProviderUtils.getMainIconSelIds(this);
        mMainTitles = DataProviderUtils.getMainTabTitles();
        for (int i = 0; i < mMainTitles.length; i++) {
            mMainTabs.add(new MainTabEntity(mMainTitles[i], mMainIconNorIds[i], mMainIconSelIds[i]));
        }
        mMainTabLayout.setTabData(mMainTabs);
        mMainTabLayout.setOnTabSelectListener(new OnTabSelectListener2() {
            @Override
            public void onTabSelect(int position, int lastPos) {
                currentPosition = position;
                switchPage(position, lastPos);
                switch (position) {
                    //业务办理
                    case POSITION_QUERY:
                        break;
                    case POSITION_DATA:
                        break;
                    case POSITION_TRACE://轨迹查询
                        break;
                    //工具
                    case POSITION_SETTING:
                        break;

                    //我
                    case POSITION_ME:
                        if (mMainFragments[3] != null && mMainFragments[3] instanceof MeFragment) {
                        }
                        break;
                }
            }

            @Override
            public void onTabReselect(int position) {
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    /**
     * 初始化Fragment
     *
     * @param savedInstanceState
     */
    private void initFragment(Bundle savedInstanceState) {
        mMainFragments = new SupportFragment[5];
        if (savedInstanceState == null) {
            mMainFragments[0] = HomeFragment.getInstance();
            mMainFragments[1] = DataBankFragment.getInstance();
            mMainFragments[2] = TraceLookFragment.getInstance();
            mMainFragments[3] = ManagerFragment.getInstance();
            mMainFragments[4] = MeFragment.getInstance();
            loadMultipleRootFragment(R.id.fl_content, POSITION_QUERY, mMainFragments);
        } else {
            mMainFragments[0] = findFragment(HomeFragment.class);
            mMainFragments[1] = findFragment(DataBankFragment.class);
            mMainFragments[2] = findFragment(TraceLookFragment.class);
            mMainFragments[3] = findFragment(ManagerFragment.class);
            mMainFragments[4] = findFragment(MeFragment.class);
        }
    }


    /**
     * 切换页面
     *
     * @param curPos
     * @param lastPos
     */
    public void switchPage(int curPos, int lastPos) {
        startTabAnim(curPos, lastPos);
        showHideFragment(mMainFragments[curPos], mMainFragments[lastPos]);
    }

    //切换到首页
    public void switchToHome() {
        switchPage(0, currentPosition);
        mMainTabLayout.setCurrentTab(0);
        currentPosition = 0;
    }

    //切换到首页
    public void switchToData() {
        switchPage(1, currentPosition);
        mMainTabLayout.setCurrentTab(1);
        currentPosition = 1;
    }

    /**
     * 点击Tab动画效果
     *
     * @param curPos
     * @param prePos
     */
    public void startTabAnim(int curPos, int prePos) {
        mMainTabLayout.getIconView(prePos).clearAnimation();
        mMainTabLayout.getIconView(curPos).startAnimation(mTabAnimation);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //如果不在主页,退回主页
            if (currentPosition != POSITION_QUERY) {
                switchToHome();
                return false;
            }
            if (!exitFlag) {
                Toast.makeText(context, "再点一次退出软件", Toast.LENGTH_SHORT).show();
                exitFlag = true;
                final Timer mTimer = new Timer();
                TimerTask mTimerTask = new TimerTask() {
                    @Override
                    public void run() {
                        exitFlag = false;
                        mTimer.cancel();
                    }
                };
                mTimer.schedule(mTimerTask, 3000, 10000);
            } else {

                if (app == null) {
                    app = (ElectricVehicleApp) this.getApplication();
                }
                AppManager.getAppManager().AppExit(context);
            }
        }

        return false;
    }
}
