package com.dgzrdz.mobile.cocobee.activity.map;

import android.content.Intent;
import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.map.TraceTimeSelectFragment;
import com.dgzrdz.mobile.cocobee.response.SearchRecResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2017/5/11
 * Time:  10:44
 */

public class TraceTimeSelectActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            Intent intent = getIntent();
            SearchRecResponse searchRecResponse = (SearchRecResponse) intent.getSerializableExtra("searchRecResponse");
            loadRootFragment(R.id.fl_container, TraceTimeSelectFragment.getInstance(searchRecResponse));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}
