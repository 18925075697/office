package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2017/5/15
 * Time:  13:50
 */

public class MsgResponse implements Serializable {

    /**
     * sysMessageAppMemberReadTime :
     * sysMessageAddTime : 2018-11-15 10:00:00
     * sysMessageId : 2
     * sysMessageSender : 系统管理员
     * sysMessageTitle : 3.0新版本准备升级，各管理员注意
     * sysMessageContent : 3.0新版本准备升级，各管理员注意
     * sysMessageStatus : 1
     * sysMessageMemberType : 1
     * sysMessageDelete : 0
     * sysAreaId : 12
     * sysMessageAppMemberRead : 0
     */

    private String sysMessageAppMemberReadTime;//阅读时间
    private String sysMessageAddTime;//发送时间
    private String sysMessageId;//消息id
    private String sysMessageSender;//系统管理员
    private String sysMessageTitle;//消息标题
    private String sysMessageContent;//消息内容
    private String sysMessageStatus;//状态 1:发送成功 2：发送失败
    private String sysMessageMemberType;//发送用户类型 0：所有 1：app管理员 2：用户
    private String sysMessageDelete;//是否删除 0 正常 1 删除
    private String sysAreaId;//组织机构id
    private String sysMessageAppMemberRead;//是否阅读 0：否 1：是
    private String sysMessageAppMemberId;//消息和管理员id关联id

    public String getSysMessageAppMemberId() {
        return sysMessageAppMemberId;
    }

    public void setSysMessageAppMemberId(String sysMessageAppMemberId) {
        this.sysMessageAppMemberId = sysMessageAppMemberId;
    }

    public String getSysMessageAppMemberReadTime() {
        return sysMessageAppMemberReadTime;
    }

    public void setSysMessageAppMemberReadTime(String sysMessageAppMemberReadTime) {
        this.sysMessageAppMemberReadTime = sysMessageAppMemberReadTime;
    }

    public String getSysMessageAddTime() {
        return sysMessageAddTime;
    }

    public void setSysMessageAddTime(String sysMessageAddTime) {
        this.sysMessageAddTime = sysMessageAddTime;
    }

    public String getSysMessageId() {
        return sysMessageId;
    }

    public void setSysMessageId(String sysMessageId) {
        this.sysMessageId = sysMessageId;
    }

    public String getSysMessageSender() {
        return sysMessageSender;
    }

    public void setSysMessageSender(String sysMessageSender) {
        this.sysMessageSender = sysMessageSender;
    }

    public String getSysMessageTitle() {
        return sysMessageTitle;
    }

    public void setSysMessageTitle(String sysMessageTitle) {
        this.sysMessageTitle = sysMessageTitle;
    }

    public String getSysMessageContent() {
        return sysMessageContent;
    }

    public void setSysMessageContent(String sysMessageContent) {
        this.sysMessageContent = sysMessageContent;
    }

    public String getSysMessageStatus() {
        return sysMessageStatus;
    }

    public void setSysMessageStatus(String sysMessageStatus) {
        this.sysMessageStatus = sysMessageStatus;
    }

    public String getSysMessageMemberType() {
        return sysMessageMemberType;
    }

    public void setSysMessageMemberType(String sysMessageMemberType) {
        this.sysMessageMemberType = sysMessageMemberType;
    }

    public String getSysMessageDelete() {
        return sysMessageDelete;
    }

    public void setSysMessageDelete(String sysMessageDelete) {
        this.sysMessageDelete = sysMessageDelete;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getSysMessageAppMemberRead() {
        return sysMessageAppMemberRead;
    }

    public void setSysMessageAppMemberRead(String sysMessageAppMemberRead) {
        this.sysMessageAppMemberRead = sysMessageAppMemberRead;
    }
}
