package com.dgzrdz.mobile.cocobee.common;

import java.util.List;

public class TraceDataHolder {
  private List<TraceJson.DataBean.LocusBean> data;
  private static final TraceDataHolder holder = new TraceDataHolder();
  public static TraceDataHolder getInstance() {return holder;}

  public List<TraceJson.DataBean.LocusBean> getData() {
    return data;
  }

  public void setData(List<TraceJson.DataBean.LocusBean> data) {
    this.data = data;
  }
}