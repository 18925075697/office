package com.dgzrdz.mobile.cocobee.utils;

import com.dgzrdz.mobile.cocobee.common.Path;

import java.io.File;

public class FileUtils {
    private String path = Path.PROJECT_FILE_PATH;

    public FileUtils() {
        File file = new File(path);
        /**
         *  如果文件夹不存在就创建
         */
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    /**
     * 创建一个文件
     *
     * @param fileName 文件名
     * @return
     */
    public File createFile(String fileName) {
        File file = new File(path, fileName);
        if (file.exists()) {
            file.delete();
        }
        return new File(path, fileName);
    }
}