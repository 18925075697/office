package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.fragment.databank.ChangPhoneFragment;
import com.dgzrdz.mobile.cocobee.fragment.databank.ChangeIdentityInfoFragment;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Description: 实名信息
 * Author: Liubingren
 * Data:  2018/5/16
 * Time:  10:33
 */

public class RealNameInfoFragment extends BaseFragment {
    private static UserBeanResponse userBeanResponse;
    @BindView(R.id.tv_select_org)
    TextView mTvSelectOrg;
    @BindView(R.id.nameEdt)
    TextView mNameEdt;
    @BindView(R.id.idEdt)
    TextView mIdEdt;
    @BindView(R.id.sexTxt)
    TextView mSexTxt;
    @BindView(R.id.tv_phone_num)
    TextView mTvPhoneNum;
    @BindView(R.id.addressTxt)
    TextView mAddressTxt;
    @BindView(R.id.addressEdt)
    TextView mAddressEdt;
    @BindView(R.id.reg_addressTxt)
    TextView mRegAddressTxt;
    @BindView(R.id.tv_change_phone)
    TextView mTvChangePhone;
    @BindView(R.id.tv_change_shenfen_info)
    TextView mTvChangeShenfenInfo;

    public static RealNameInfoFragment getInstance(UserBeanResponse userBeanResponse) {
        RealNameInfoFragment.userBeanResponse = userBeanResponse;
        RealNameInfoFragment fragment = new RealNameInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setView();
    }

    private void setView() {
        mTvSelectOrg.setText(userBeanResponse.getSysAreaName());
        mNameEdt.setText(userBeanResponse.getMemberName());
        mIdEdt.setText(userBeanResponse.getMemberCardId());
        mSexTxt.setText(CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? "男" : "女");
        mTvPhoneNum.setText(userBeanResponse.getMemberAccount());
        mAddressEdt.setText(userBeanResponse.getMemberLiveAddress());
        mRegAddressTxt.setText(userBeanResponse.getMemberRegisterAddress());
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("实名信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_real_name_info;
    }


    @OnClick({R.id.tv_change_phone, R.id.tv_change_shenfen_info})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_change_phone://修改手机号
                start(ChangPhoneFragment.getInstance(userBeanResponse));
                break;
            case R.id.tv_change_shenfen_info://修改身份信息
                start(ChangeIdentityInfoFragment.getInstance(userBeanResponse));
                break;
        }
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                userBeanResponse = (UserBeanResponse) eventManager.getData();
                setView();
                break;
        }
    }
}
