package com.dgzrdz.mobile.cocobee.activity.data;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.databank.UpdateCarInfoFragment;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/15
 * Time:  17:06
 */

public class UpdateCarInfoActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            GuardianObjectDetailResponse guardianObjectDetailResponse = (GuardianObjectDetailResponse) getIntent().getSerializableExtra("guardianObjectDetailResponse");
            loadRootFragment(R.id.fl_container, UpdateCarInfoFragment.getInstance(guardianObjectDetailResponse));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}
