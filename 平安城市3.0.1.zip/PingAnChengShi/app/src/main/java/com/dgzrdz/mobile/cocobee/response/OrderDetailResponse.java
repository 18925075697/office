package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/28
 * Time:  19:36
 */

public class OrderDetailResponse implements Serializable {
    /**
     * memberOrderProcess : 4
     * sysPropertySort : chaen
     * appMemberAccount : 15889762042
     * memberName : ck
     * sysMobileName :
     * memberOrderNeedPay : 100.00
     * appMemberName : 李总
     * sysCityName :
     * LabelService_PackageList : [{"sysServiceSetPropOptionName":"3000M","sysConfType":"2","sysServiceSetPropName":"流量套餐1","sysServiceSetPropValueId":"2","sysMobileName":"","sysCityName":"","sysServiceSetPropValueStr":"","sysServiceSetConfName":"流量套餐","sysServiceSetConfInfo":"办标签服务送流量","sysServiceSetYears":"2","sysServiceSetPropOptionInputName":"手机号码","sysServiceSetPropOptionSpecial":"1","sysServiceSetPropOptionInputInfo":"请输入用于办理套餐的手机号","sysServiceSetPrice":"300.00"},{"sysServiceSetPropOptionName":"3000M","sysConfType":"1","sysServiceSetPropName":"宽带","sysServiceSetPropValueId":"3","sysMobileName":"","sysCityName":"","sysServiceSetPropValueStr":"","sysServiceSetConfName":"","sysServiceSetConfInfo":"","sysServiceSetYears":"3","sysServiceSetPropOptionInputName":"手机号码","sysServiceSetPropOptionSpecial":"1","sysServiceSetPropOptionInputInfo":"请输入用于办理套餐的手机号","sysServiceSetPrice":"300.00"},{"sysServiceSetPropOptionName":"3000M","sysConfType":"2","sysServiceSetPropName":"宽带","sysServiceSetPropValueId":"3","sysMobileName":"","sysCityName":"","sysServiceSetPropValueStr":"","sysServiceSetConfName":"","sysServiceSetConfInfo":"","sysServiceSetYears":"1","sysServiceSetPropOptionInputName":"手机号码","sysServiceSetPropOptionSpecial":"1","sysServiceSetPropOptionInputInfo":"请输入用于办理套餐的手机号","sysServiceSetPrice":"300.00"},{"sysServiceSetPropOptionName":"3000M","sysConfType":"2","sysServiceSetPropName":"宽带","sysServiceSetPropValueId":"3","sysMobileName":"","sysCityName":"","sysServiceSetPropValueStr":"","sysServiceSetConfName":"流量套餐","sysServiceSetConfInfo":"办标签服务送流量","sysServiceSetYears":"2","sysServiceSetPropOptionInputName":"手机号码","sysServiceSetPropOptionSpecial":"1","sysServiceSetPropOptionInputInfo":"请输入用于办理套餐的手机号","sysServiceSetPrice":"300.00"}]
     * Insurance_PackageList : [{"sysInsuranceName":"平安保险","sysInsuranceExpiredTime":"2019-11-07 16:00:00","appMemberId":"1","sysInsuranceValueId":"1","sysInstallPlaceId":"2","sysAreaId":"12","sysInsuranceConfYears":"1","sysServiceTypeId":"1","sysInsurancePrice":"100.00","sysInsuranceActiveTime":"2018-11-07 16:00:00","sysInsuranceAddTime":"2018-11-07 16:00:00","dataId":"6","sysInsuranceConfPriceId":"0","sysInsuranceTypeId":"1","sysInsuranceProcess":"2","sysCityId":"1","sysInsuranceTypeName":"三责险","memberServiceObjId":"8","sysInsuranceId":"1"},{"sysInsuranceName":"平安保险","sysInsuranceExpiredTime":"2020-11-07 16:00:00","appMemberId":"1","sysInsuranceValueId":"2","sysInstallPlaceId":"2","sysAreaId":"12","sysInsuranceConfYears":"2","sysServiceTypeId":"1","sysInsurancePrice":"300.00","sysInsuranceActiveTime":"2018-11-07 16:00:00","sysInsuranceAddTime":"2018-11-07 16:00:00","dataId":"6","sysInsuranceConfPriceId":"0","sysInsuranceTypeId":"1","sysInsuranceProcess":"2","sysCityId":"1","sysInsuranceTypeName":"盗抢险","memberServiceObjId":"8","sysInsuranceId":"1"}]
     * memberServiceObjId : 8
     * memberAccount : 13242967410
     * memberOrderNo : 1006
     * sysAreaName : 火车站街道
     * sysServiceTypeName : 老人
     * memberId : 30
     * memberOrderTotalPay : 100.00
     * memberOrderId : 6
     * memberOrderType : 1
     * memberOrderAddTime : 2018-11-27 17:29:35
     * memberOrderPayType : 20
     * sysInstallPlaceName : 第三个安装点222
     * memberOrderExpiredTime : 20180912
     * memberOrderYMD : 20180912
     * memberOrderAcviveTime : 20181103
     * OrdersysInstallPlaceName : 第三个安装点222
     */

    private String memberOrderProcess;
    private String sysPropertySort;
    private String appMemberAccount;
    private String memberName;
    private String sysMobileName;
    private double memberOrderNeedPay;
    private double memberOrderActualPay;
    private String appMemberName;
    private String sysCityName;//归属地
    private String sysProName;//归属地省份
    private String memberServiceObjId;
    private String memberAccount;
    private String memberOrderNo;
    private String sysAreaName;
    private String sysServiceTypeName;
    private String memberId;
    private double memberOrderTotalPay;
    private String memberOrderId;
    private String memberOrderType;
    private String memberOrderAddTime;
    private int memberOrderPayType;
    private String sysInstallPlaceName;
    private String memberOrderExpiredTime;
    private String memberOrderYMD;
    private String memberOrderAcviveTime;
    private String OrdersysInstallPlaceName;
    private String appPasswordPayCodeStr;
    private int memberServiceObjActiveFlag;//对象激活标志\n1 未激活\n2 锁定中\n3 已激活、有效中\n4 已过期\n5 删除了\n
    private String sysAreaId;//组织机构id
    private String memberCardId;//身份证号
    private String memberSix;//性别1男2女
    private String memberRegisterAddress;//用户户籍地址
    private String memberLiveAddress;//现居住地址
    private String sysConfType;//类型，1 个人业务，2集团业务
    private String memberOrderCancelTime;//订单取消时间
    private String timeNow;//服务器时间
    private String sysServiceSetYears;//标签服务年限
    private String paymentTime;//支付时间
    private String sysGroupName;//集团单位
    private double sysServiceSetPrice;//套餐总金额
    private List<LabelServicePackageListBean> LabelService_PackageList;
    private List<InsurancePackageListBean> Insurance_PackageList;

    public String getSysGroupName() {
        return sysGroupName;
    }

    public void setSysGroupName(String sysGroupName) {
        this.sysGroupName = sysGroupName;
    }

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getSysProName() {
        return sysProName;
    }

    public void setSysProName(String sysProName) {
        this.sysProName = sysProName;
    }

    public double getSysServiceSetPrice() {
        return sysServiceSetPrice;
    }

    public void setSysServiceSetPrice(double sysServiceSetPrice) {
        this.sysServiceSetPrice = sysServiceSetPrice;
    }

    public double getMemberOrderActualPay() {
        return memberOrderActualPay;
    }

    public void setMemberOrderActualPay(double memberOrderActualPay) {
        this.memberOrderActualPay = memberOrderActualPay;
    }

    public String getSysServiceSetYears() {
        return sysServiceSetYears;
    }

    public void setSysServiceSetYears(String sysServiceSetYears) {
        this.sysServiceSetYears = sysServiceSetYears;
    }

    public String getTimeNow() {
        return timeNow;
    }

    public void setTimeNow(String timeNow) {
        this.timeNow = timeNow;
    }

    public String getMemberOrderCancelTime() {
        return memberOrderCancelTime;
    }

    public void setMemberOrderCancelTime(String memberOrderCancelTime) {
        this.memberOrderCancelTime = memberOrderCancelTime;
    }

    public String getSysConfType() {
        return sysConfType;
    }

    public void setSysConfType(String sysConfType) {
        this.sysConfType = sysConfType;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getMemberCardId() {
        return memberCardId;
    }

    public void setMemberCardId(String memberCardId) {
        this.memberCardId = memberCardId;
    }

    public String getMemberSix() {
        return memberSix;
    }

    public void setMemberSix(String memberSix) {
        this.memberSix = memberSix;
    }

    public String getMemberRegisterAddress() {
        return memberRegisterAddress;
    }

    public void setMemberRegisterAddress(String memberRegisterAddress) {
        this.memberRegisterAddress = memberRegisterAddress;
    }

    public String getMemberLiveAddress() {
        return memberLiveAddress;
    }

    public void setMemberLiveAddress(String memberLiveAddress) {
        this.memberLiveAddress = memberLiveAddress;
    }

    public int getMemberServiceObjActiveFlag() {
        return memberServiceObjActiveFlag;
    }

    public void setMemberServiceObjActiveFlag(int memberServiceObjActiveFlag) {
        this.memberServiceObjActiveFlag = memberServiceObjActiveFlag;
    }

    public String getAppPasswordPayCodeStr() {
        return appPasswordPayCodeStr;
    }

    public void setAppPasswordPayCodeStr(String appPasswordPayCodeStr) {
        this.appPasswordPayCodeStr = appPasswordPayCodeStr;
    }

    public String getMemberOrderProcess() {
        return memberOrderProcess;
    }

    public void setMemberOrderProcess(String memberOrderProcess) {
        this.memberOrderProcess = memberOrderProcess;
    }

    public String getSysPropertySort() {
        return sysPropertySort;
    }

    public void setSysPropertySort(String sysPropertySort) {
        this.sysPropertySort = sysPropertySort;
    }

    public String getAppMemberAccount() {
        return appMemberAccount;
    }

    public void setAppMemberAccount(String appMemberAccount) {
        this.appMemberAccount = appMemberAccount;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getSysMobileName() {
        return sysMobileName;
    }

    public void setSysMobileName(String sysMobileName) {
        this.sysMobileName = sysMobileName;
    }

    public double getMemberOrderNeedPay() {
        return memberOrderNeedPay;
    }

    public void setMemberOrderNeedPay(double memberOrderNeedPay) {
        this.memberOrderNeedPay = memberOrderNeedPay;
    }

    public String getAppMemberName() {
        return appMemberName;
    }

    public void setAppMemberName(String appMemberName) {
        this.appMemberName = appMemberName;
    }

    public String getSysCityName() {
        return sysCityName;
    }

    public void setSysCityName(String sysCityName) {
        this.sysCityName = sysCityName;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public String getMemberOrderNo() {
        return memberOrderNo;
    }

    public void setMemberOrderNo(String memberOrderNo) {
        this.memberOrderNo = memberOrderNo;
    }

    public String getSysAreaName() {
        return sysAreaName;
    }

    public void setSysAreaName(String sysAreaName) {
        this.sysAreaName = sysAreaName;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public double getMemberOrderTotalPay() {
        return memberOrderTotalPay;
    }

    public void setMemberOrderTotalPay(double memberOrderTotalPay) {
        this.memberOrderTotalPay = memberOrderTotalPay;
    }

    public String getMemberOrderId() {
        return memberOrderId;
    }

    public void setMemberOrderId(String memberOrderId) {
        this.memberOrderId = memberOrderId;
    }

    public String getMemberOrderType() {
        return memberOrderType;
    }

    public void setMemberOrderType(String memberOrderType) {
        this.memberOrderType = memberOrderType;
    }

    public String getMemberOrderAddTime() {
        return memberOrderAddTime;
    }

    public void setMemberOrderAddTime(String memberOrderAddTime) {
        this.memberOrderAddTime = memberOrderAddTime;
    }

    public int getMemberOrderPayType() {
        return memberOrderPayType;
    }

    public void setMemberOrderPayType(int memberOrderPayType) {
        this.memberOrderPayType = memberOrderPayType;
    }

    public String getSysInstallPlaceName() {
        return sysInstallPlaceName;
    }

    public void setSysInstallPlaceName(String sysInstallPlaceName) {
        this.sysInstallPlaceName = sysInstallPlaceName;
    }

    public String getMemberOrderExpiredTime() {
        return memberOrderExpiredTime;
    }

    public void setMemberOrderExpiredTime(String memberOrderExpiredTime) {
        this.memberOrderExpiredTime = memberOrderExpiredTime;
    }

    public String getMemberOrderYMD() {
        return memberOrderYMD;
    }

    public void setMemberOrderYMD(String memberOrderYMD) {
        this.memberOrderYMD = memberOrderYMD;
    }

    public String getMemberOrderAcviveTime() {
        return memberOrderAcviveTime;
    }

    public void setMemberOrderAcviveTime(String memberOrderAcviveTime) {
        this.memberOrderAcviveTime = memberOrderAcviveTime;
    }

    public String getOrdersysInstallPlaceName() {
        return OrdersysInstallPlaceName;
    }

    public void setOrdersysInstallPlaceName(String OrdersysInstallPlaceName) {
        this.OrdersysInstallPlaceName = OrdersysInstallPlaceName;
    }

    public List<LabelServicePackageListBean> getLabelService_PackageList() {
        return LabelService_PackageList;
    }

    public void setLabelService_PackageList(List<LabelServicePackageListBean> LabelService_PackageList) {
        this.LabelService_PackageList = LabelService_PackageList;
    }

    public List<InsurancePackageListBean> getInsurance_PackageList() {
        return Insurance_PackageList;
    }

    public void setInsurance_PackageList(List<InsurancePackageListBean> Insurance_PackageList) {
        this.Insurance_PackageList = Insurance_PackageList;
    }

    public static class LabelServicePackageListBean implements Serializable {
        /**
         * sysServiceSetPropOptionName : 3000M
         * sysConfType : 2
         * sysServiceSetPropName : 流量套餐1
         * sysServiceSetPropValueId : 2
         * sysMobileName :
         * sysCityName :
         * sysServiceSetPropValueStr :
         * sysServiceSetConfName : 流量套餐
         * sysServiceSetConfInfo : 办标签服务送流量
         * sysServiceSetYears : 2
         * sysServiceSetPropOptionInputName : 手机号码
         * sysServiceSetPropOptionSpecial : 1
         * sysServiceSetPropOptionInputInfo : 请输入用于办理套餐的手机号
         * sysServiceSetPrice : 300.00
         */

        private String sysServiceSetPropOptionName;
        private String sysConfType;
        private String sysServiceSetPropName;
        private String sysServiceSetPropValueId;
        private String sysMobileName;//运营商
        private String sysCityName;//归属地
        private String sysProName;//归属地省份
        private String sysServiceSetPropValueStr;
        private String sysServiceSetConfName;
        private String sysServiceSetConfInfo;
        private String sysServiceSetYears;
        private String sysServiceSetPropOptionInputName;
        private String sysServiceSetPropOptionSpecial;
        private String sysServiceSetPropOptionInputInfo;
        private double sysServiceSetPrice;
        private String sysServiceSetPropOptionInput;//是否需要采集额外输入\n1 需要\n2 不需要
        private String sysServiceSetPropExValueStr;//规格输入属性值

        public String getSysProName() {
            return sysProName;
        }

        public void setSysProName(String sysProName) {
            this.sysProName = sysProName;
        }

        public String getSysServiceSetPropExValueStr() {
            return sysServiceSetPropExValueStr;
        }

        public void setSysServiceSetPropExValueStr(String sysServiceSetPropExValueStr) {
            this.sysServiceSetPropExValueStr = sysServiceSetPropExValueStr;
        }

        public String getSysServiceSetPropOptionInput() {
            return sysServiceSetPropOptionInput;
        }

        public void setSysServiceSetPropOptionInput(String sysServiceSetPropOptionInput) {
            this.sysServiceSetPropOptionInput = sysServiceSetPropOptionInput;
        }

        public String getSysServiceSetPropOptionName() {
            return sysServiceSetPropOptionName;
        }

        public void setSysServiceSetPropOptionName(String sysServiceSetPropOptionName) {
            this.sysServiceSetPropOptionName = sysServiceSetPropOptionName;
        }

        public String getSysConfType() {
            return sysConfType;
        }

        public void setSysConfType(String sysConfType) {
            this.sysConfType = sysConfType;
        }

        public String getSysServiceSetPropName() {
            return sysServiceSetPropName;
        }

        public void setSysServiceSetPropName(String sysServiceSetPropName) {
            this.sysServiceSetPropName = sysServiceSetPropName;
        }

        public String getSysServiceSetPropValueId() {
            return sysServiceSetPropValueId;
        }

        public void setSysServiceSetPropValueId(String sysServiceSetPropValueId) {
            this.sysServiceSetPropValueId = sysServiceSetPropValueId;
        }

        public String getSysMobileName() {
            return sysMobileName;
        }

        public void setSysMobileName(String sysMobileName) {
            this.sysMobileName = sysMobileName;
        }

        public String getSysCityName() {
            return sysCityName;
        }

        public void setSysCityName(String sysCityName) {
            this.sysCityName = sysCityName;
        }

        public String getSysServiceSetPropValueStr() {
            return sysServiceSetPropValueStr;
        }

        public void setSysServiceSetPropValueStr(String sysServiceSetPropValueStr) {
            this.sysServiceSetPropValueStr = sysServiceSetPropValueStr;
        }

        public String getSysServiceSetConfName() {
            return sysServiceSetConfName;
        }

        public void setSysServiceSetConfName(String sysServiceSetConfName) {
            this.sysServiceSetConfName = sysServiceSetConfName;
        }

        public String getSysServiceSetConfInfo() {
            return sysServiceSetConfInfo;
        }

        public void setSysServiceSetConfInfo(String sysServiceSetConfInfo) {
            this.sysServiceSetConfInfo = sysServiceSetConfInfo;
        }

        public String getSysServiceSetYears() {
            return sysServiceSetYears;
        }

        public void setSysServiceSetYears(String sysServiceSetYears) {
            this.sysServiceSetYears = sysServiceSetYears;
        }

        public String getSysServiceSetPropOptionInputName() {
            return sysServiceSetPropOptionInputName;
        }

        public void setSysServiceSetPropOptionInputName(String sysServiceSetPropOptionInputName) {
            this.sysServiceSetPropOptionInputName = sysServiceSetPropOptionInputName;
        }

        public String getSysServiceSetPropOptionSpecial() {
            return sysServiceSetPropOptionSpecial;
        }

        public void setSysServiceSetPropOptionSpecial(String sysServiceSetPropOptionSpecial) {
            this.sysServiceSetPropOptionSpecial = sysServiceSetPropOptionSpecial;
        }

        public String getSysServiceSetPropOptionInputInfo() {
            return sysServiceSetPropOptionInputInfo;
        }

        public void setSysServiceSetPropOptionInputInfo(String sysServiceSetPropOptionInputInfo) {
            this.sysServiceSetPropOptionInputInfo = sysServiceSetPropOptionInputInfo;
        }

        public double getSysServiceSetPrice() {
            return sysServiceSetPrice;
        }

        public void setSysServiceSetPrice(double sysServiceSetPrice) {
            this.sysServiceSetPrice = sysServiceSetPrice;
        }
    }

    public static class InsurancePackageListBean implements Serializable {
        /**
         * sysInsuranceName : 平安保险
         * sysInsuranceExpiredTime : 2019-11-07 16:00:00
         * appMemberId : 1
         * sysInsuranceValueId : 1
         * sysInstallPlaceId : 2
         * sysAreaId : 12
         * sysInsuranceConfYears : 1
         * sysServiceTypeId : 1
         * sysInsurancePrice : 100.00
         * sysInsuranceActiveTime : 2018-11-07 16:00:00
         * sysInsuranceAddTime : 2018-11-07 16:00:00
         * dataId : 6
         * sysInsuranceConfPriceId : 0
         * sysInsuranceTypeId : 1
         * sysInsuranceProcess : 2
         * sysCityId : 1
         * sysInsuranceTypeName : 三责险
         * memberServiceObjId : 8
         * sysInsuranceId : 1
         */

        private String sysInsuranceName;
        private String sysInsuranceExpiredTime;
        private String appMemberId;
        private String sysInsuranceValueId;
        private String sysInstallPlaceId;
        private String sysAreaId;
        private String sysInsuranceConfYears;
        private String sysServiceTypeId;
        private double sysInsurancePrice;
        private String sysInsuranceActiveTime;
        private String sysInsuranceAddTime;
        private String dataId;
        private String sysInsuranceConfPriceId;
        private String sysInsuranceTypeId;
        private String sysInsuranceProcess;
        private String sysCityId;
        private String sysInsuranceTypeName;
        private String memberServiceObjId;
        private String sysInsuranceId;
        private String sysInsuranceTypeSpecial;//一些额外的校验，比如1：校验手机号码 ，2：校验身份证号码，3：校验纯数字，4：宽带账号，5：其他(新加)
        private String sysInsuranceExValueStr;//保险规格输入值
        private String sysInsuranceTypeInput;//是否需要采集额外输入 1 需要 2 不需要
        private String sysCityName;//归属地
        private String sysProName;//归属地省份
        private String sysMobileName;//运营商
        private String sysInsuranceTypeInputName;//规格字段描述
        private String sysInsuranceTemplateUrl;//电子凭证地址

        public String getSysInsuranceTemplateUrl() {
            return sysInsuranceTemplateUrl;
        }

        public void setSysInsuranceTemplateUrl(String sysInsuranceTemplateUrl) {
            this.sysInsuranceTemplateUrl = sysInsuranceTemplateUrl;
        }

        public String getSysProName() {
            return sysProName;
        }

        public void setSysProName(String sysProName) {
            this.sysProName = sysProName;
        }

        public String getSysInsuranceTypeInputName() {
            return sysInsuranceTypeInputName;
        }

        public void setSysInsuranceTypeInputName(String sysInsuranceTypeInputName) {
            this.sysInsuranceTypeInputName = sysInsuranceTypeInputName;
        }

        public String getSysInsuranceTypeSpecial() {
            return sysInsuranceTypeSpecial;
        }

        public void setSysInsuranceTypeSpecial(String sysInsuranceTypeSpecial) {
            this.sysInsuranceTypeSpecial = sysInsuranceTypeSpecial;
        }

        public String getSysInsuranceExValueStr() {
            return sysInsuranceExValueStr;
        }

        public void setSysInsuranceExValueStr(String sysInsuranceExValueStr) {
            this.sysInsuranceExValueStr = sysInsuranceExValueStr;
        }

        public String getSysInsuranceTypeInput() {
            return sysInsuranceTypeInput;
        }

        public void setSysInsuranceTypeInput(String sysInsuranceTypeInput) {
            this.sysInsuranceTypeInput = sysInsuranceTypeInput;
        }

        public String getSysCityName() {
            return sysCityName;
        }

        public void setSysCityName(String sysCityName) {
            this.sysCityName = sysCityName;
        }

        public String getSysMobileName() {
            return sysMobileName;
        }

        public void setSysMobileName(String sysMobileName) {
            this.sysMobileName = sysMobileName;
        }

        public String getSysInsuranceName() {
            return sysInsuranceName;
        }

        public void setSysInsuranceName(String sysInsuranceName) {
            this.sysInsuranceName = sysInsuranceName;
        }

        public String getSysInsuranceExpiredTime() {
            return sysInsuranceExpiredTime;
        }

        public void setSysInsuranceExpiredTime(String sysInsuranceExpiredTime) {
            this.sysInsuranceExpiredTime = sysInsuranceExpiredTime;
        }

        public String getAppMemberId() {
            return appMemberId;
        }

        public void setAppMemberId(String appMemberId) {
            this.appMemberId = appMemberId;
        }

        public String getSysInsuranceValueId() {
            return sysInsuranceValueId;
        }

        public void setSysInsuranceValueId(String sysInsuranceValueId) {
            this.sysInsuranceValueId = sysInsuranceValueId;
        }

        public String getSysInstallPlaceId() {
            return sysInstallPlaceId;
        }

        public void setSysInstallPlaceId(String sysInstallPlaceId) {
            this.sysInstallPlaceId = sysInstallPlaceId;
        }

        public String getSysAreaId() {
            return sysAreaId;
        }

        public void setSysAreaId(String sysAreaId) {
            this.sysAreaId = sysAreaId;
        }

        public String getSysInsuranceConfYears() {
            return sysInsuranceConfYears;
        }

        public void setSysInsuranceConfYears(String sysInsuranceConfYears) {
            this.sysInsuranceConfYears = sysInsuranceConfYears;
        }

        public String getSysServiceTypeId() {
            return sysServiceTypeId;
        }

        public void setSysServiceTypeId(String sysServiceTypeId) {
            this.sysServiceTypeId = sysServiceTypeId;
        }

        public double getSysInsurancePrice() {
            return sysInsurancePrice;
        }

        public void setSysInsurancePrice(double sysInsurancePrice) {
            this.sysInsurancePrice = sysInsurancePrice;
        }

        public String getSysInsuranceActiveTime() {
            return sysInsuranceActiveTime;
        }

        public void setSysInsuranceActiveTime(String sysInsuranceActiveTime) {
            this.sysInsuranceActiveTime = sysInsuranceActiveTime;
        }

        public String getSysInsuranceAddTime() {
            return sysInsuranceAddTime;
        }

        public void setSysInsuranceAddTime(String sysInsuranceAddTime) {
            this.sysInsuranceAddTime = sysInsuranceAddTime;
        }

        public String getDataId() {
            return dataId;
        }

        public void setDataId(String dataId) {
            this.dataId = dataId;
        }

        public String getSysInsuranceConfPriceId() {
            return sysInsuranceConfPriceId;
        }

        public void setSysInsuranceConfPriceId(String sysInsuranceConfPriceId) {
            this.sysInsuranceConfPriceId = sysInsuranceConfPriceId;
        }

        public String getSysInsuranceTypeId() {
            return sysInsuranceTypeId;
        }

        public void setSysInsuranceTypeId(String sysInsuranceTypeId) {
            this.sysInsuranceTypeId = sysInsuranceTypeId;
        }

        public String getSysInsuranceProcess() {
            return sysInsuranceProcess;
        }

        public void setSysInsuranceProcess(String sysInsuranceProcess) {
            this.sysInsuranceProcess = sysInsuranceProcess;
        }

        public String getSysCityId() {
            return sysCityId;
        }

        public void setSysCityId(String sysCityId) {
            this.sysCityId = sysCityId;
        }

        public String getSysInsuranceTypeName() {
            return sysInsuranceTypeName;
        }

        public void setSysInsuranceTypeName(String sysInsuranceTypeName) {
            this.sysInsuranceTypeName = sysInsuranceTypeName;
        }

        public String getMemberServiceObjId() {
            return memberServiceObjId;
        }

        public void setMemberServiceObjId(String memberServiceObjId) {
            this.memberServiceObjId = memberServiceObjId;
        }

        public String getSysInsuranceId() {
            return sysInsuranceId;
        }

        public void setSysInsuranceId(String sysInsuranceId) {
            this.sysInsuranceId = sysInsuranceId;
        }
    }
}
