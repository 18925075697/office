package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.dgzrdz.mobile.cocobee.adapter.AlarmInfoAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.AlarmInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import okhttp3.Response;


/**
 * Created by liu on 2016/10/26.
 * 报警记录
 */
public class AlarmInfoFragment extends RefreshAndLoadFragment<AlarmInfoResponse> {
    AlarmInfoAdapter mAlarmInfoAdapter;
    private UserInfo mUserLoginInfo;

    public static AlarmInfoFragment getInstance() {
        AlarmInfoFragment fragment = new AlarmInfoFragment();
        return fragment;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        AlarmInfoResponse alarmInfoResponse = mList.get(position);
        start(AlarmInfoDetailFragment.getInstance(alarmInfoResponse));
    }

    @Override
    public QuickRcvAdapter getAdapter() {
        return mAlarmInfoAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(final int curPage, final boolean isPullToRefresh) {
        mCurPage = curPage;
        DatasApiUtils.getAlarmInfo(_mActivity, mUserLoginInfo.getDataList().getAppMemberId(), new RefreshAndLoadCallback<List<AlarmInfoResponse>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<AlarmInfoResponse> alarmInfoResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshListData(callback, alarmInfoResponses, null);
            }
        });
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("报警记录");
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mAlarmInfoAdapter = new AlarmInfoAdapter(_mActivity, mList);
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    public void onLoadMore() {

    }
}