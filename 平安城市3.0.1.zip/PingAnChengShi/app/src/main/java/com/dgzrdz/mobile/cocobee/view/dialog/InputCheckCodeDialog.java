package com.dgzrdz.mobile.cocobee.view.dialog;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.pay.PaySuccessActivity;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.PaySuccessResponse;
import com.dgzrdz.mobile.cocobee.response.SelectPayResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 口令支付验证码校验弹窗
 * Created: 2016/11/29 19:54
 */
public class InputCheckCodeDialog extends DialogFragment {
    @BindView(R.id.tv_confirm)
    TextView mTvConfirm;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.tv_hint_title)
    TextView mTvHintTitle;
    @BindView(R.id.et_kouling_num)
    EditText mEtKoulingNum;
    @BindView(R.id.sure_use)
    TextView mSureUse;
    private Unbinder mBind;
    private SelectPayResponse selectPayResponse;
    private UserInfo mUserLoginInfo;
    private Context mContext;
    private AlertDialog mAlertDialog;

    public void setOrderInfoResponse(SelectPayResponse selectPayResponse) {
        this.selectPayResponse = selectPayResponse;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.MyDialog);
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = Utils.getScreenWidth();
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.windowAnimations = R.style.DialogAnimation;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_input_check_code_pwd, container);
        mBind = ButterKnife.bind(this, view);
        initView();
        showSoftInput();
        return view;
    }

    private void initView() {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mContext = getContext();
        mMtvPayNum.setAmount(selectPayResponse.getMemberOrderTotalPay());
        String appMemberAccount = mUserLoginInfo.getDataList().getAppMemberAccount();
        String pre = appMemberAccount.substring(0, 3);
        String last = appMemberAccount.substring(7, 11);
        mTvHintTitle.setText("已向" + pre + "****" + last + "发送8位数口令码,5分钟有效");
    }

    /**
     * 显示键盘
     */
    public void showSoftInput(){
        InputMethodManager  imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        //显示软键盘
        if(mEtKoulingNum!=null) {
            mEtKoulingNum.postDelayed(new Runnable() {
                @Override
                public void run() {
                    imm.showSoftInput(mEtKoulingNum, 0);
                }
            },200);
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mBind.unbind();
    }

    @OnClick({R.id.tv_confirm, R.id.sure_use})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_confirm://取消
                dismiss();
                break;
            case R.id.sure_use://确认使用
                String koulinNum = mEtKoulingNum.getText().toString().trim();
                if (CheckUtils.isEmpty(koulinNum)) {
                    XToastUtils.showShortToast("请输入口令码");
                } else if (koulinNum.length() < 8){
                    XToastUtils.showShortToast("口令码格式不对");
                }else {
                    showUseDialog(koulinNum);
                }
                break;
        }
    }

    /**
     * 使用确认弹框
     *
     * @param koulinNum
     */
    private void showUseDialog(String koulinNum) {
        View view = View.inflate(getContext(), R.layout.use_sure_dialog, null);
        mAlertDialog = Utils.showCornerDialog(getContext(), view, 260, 160);
        MoneyTextView payNum = (MoneyTextView) mAlertDialog.findViewById(R.id.mtv_pay_num);
        TextView kouLin = (TextView) mAlertDialog.findViewById(R.id.tv_koulin_code);
        TextView name = (TextView) mAlertDialog.findViewById(R.id.tv_name);
        TextView cancel = (TextView) mAlertDialog.findViewById(R.id.tv_cancel);
        TextView use = (TextView) mAlertDialog.findViewById(R.id.tv_use);

        payNum.setAmount(selectPayResponse.getMemberOrderTotalPay());
        kouLin.setText(koulinNum);
        name.setText(mUserLoginInfo.getDataList().getAppMemberName());

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAlertDialog.dismiss();
            }
        });

        use.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passwordCodeCheck(koulinNum);
            }
        });
    }

    /**
     * 口令码验证
     *
     * @param koulinNum
     */
    private void passwordCodeCheck(String koulinNum) {
        PayApiUtils.checkKouLinCode(mContext, koulinNum, selectPayResponse.getMemberOrderId(), mUserLoginInfo.getDataList().getAppMemberId(), new DialogCallback<PaySuccessResponse>(mContext, "验证口令码...") {
            @Override
            public void onSuccess(PaySuccessResponse paySuccessResponse, Call call, Response response) {
                mAlertDialog.dismiss();
                dismiss();
                paySuccess(paySuccessResponse);
            }
        });
    }

    /**
     * 支付成功
     *
     * @param paySuccessResponse
     */
    private void paySuccess(PaySuccessResponse paySuccessResponse) {
        EventBus.getDefault().post(new EventManager(EventConstants.SURE_USE_FREE_PWD));

        paySuccessResponse.setMemberOrderId(selectPayResponse.getMemberOrderId());
        Intent intent = new Intent(mContext, PaySuccessActivity.class);
        intent.putExtra("paySuccessResponse", paySuccessResponse);
        startActivity(intent);
    }

}
