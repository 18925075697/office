package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  17:28
 */

public class PolicyServiceResponse implements Serializable {
    private String title;//保险标题
    private List<PolicyServiceTypeListBean> serviceTypeList;
    private int position = -1;//外层对应的内层选中条目

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<PolicyServiceTypeListBean> getServiceTypeList() {
        return serviceTypeList;
    }

    public void setServiceTypeList(List<PolicyServiceTypeListBean> serviceTypeList) {
        this.serviceTypeList = serviceTypeList;
    }

    public static class PolicyServiceTypeListBean implements Serializable{

        /**
         * name : 盗抢
         * sysInsuranceConfId : 6
         * sysInsuranceConfPriceId : 1
         * sysInsuranceConfYears : 1
         * sysInsuranceId : 4
         * sysInsurancePrice : 100.00
         * sysInsuranceTypeId : 2
         * sysInsuranceTypeName : 盗抢
         */

        private String name;
        private String sysInsuranceConfId;
        private String sysInsuranceConfPriceId;
        private String sysInsuranceConfYears;//年限id
        private String sysInsuranceConfYearsShow;//显示1年
        private String sysInsuranceId;
        private double sysInsurancePrice;
        private String sysInsuranceTypeId;
        private String sysInsuranceTypeName;
        private String sysInsuranceTypeInput;//是否需要采集额外输入 1 需要 2 不需要
        private String sysInsuranceTypeInputName;//额外输入title
        private String sysInsuranceTypeInputInfo;//额外输入描述
        private String sysInsuranceTypeSpecial;//额外的校验 1手机号 2身份证
        private int select = -1;

        public String getSysInsuranceTypeSpecial() {
            return sysInsuranceTypeSpecial;
        }

        public void setSysInsuranceTypeSpecial(String sysInsuranceTypeSpecial) {
            this.sysInsuranceTypeSpecial = sysInsuranceTypeSpecial;
        }

        public int getSelect() {
            return select;
        }

        public void setSelect(int select) {
            this.select = select;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSysInsuranceConfId() {
            return sysInsuranceConfId;
        }

        public void setSysInsuranceConfId(String sysInsuranceConfId) {
            this.sysInsuranceConfId = sysInsuranceConfId;
        }

        public String getSysInsuranceConfPriceId() {
            return sysInsuranceConfPriceId;
        }

        public void setSysInsuranceConfPriceId(String sysInsuranceConfPriceId) {
            this.sysInsuranceConfPriceId = sysInsuranceConfPriceId;
        }

        public String getSysInsuranceConfYears() {
            return sysInsuranceConfYears;
        }

        public void setSysInsuranceConfYears(String sysInsuranceConfYears) {
            this.sysInsuranceConfYears = sysInsuranceConfYears;
        }

        public String getSysInsuranceId() {
            return sysInsuranceId;
        }

        public void setSysInsuranceId(String sysInsuranceId) {
            this.sysInsuranceId = sysInsuranceId;
        }

        public double getSysInsurancePrice() {
            return sysInsurancePrice;
        }

        public void setSysInsurancePrice(double sysInsurancePrice) {
            this.sysInsurancePrice = sysInsurancePrice;
        }

        public String getSysInsuranceTypeId() {
            return sysInsuranceTypeId;
        }

        public void setSysInsuranceTypeId(String sysInsuranceTypeId) {
            this.sysInsuranceTypeId = sysInsuranceTypeId;
        }

        public String getSysInsuranceTypeName() {
            return sysInsuranceTypeName;
        }

        public void setSysInsuranceTypeName(String sysInsuranceTypeName) {
            this.sysInsuranceTypeName = sysInsuranceTypeName;
        }

        public String getSysInsuranceConfYearsShow() {
            return sysInsuranceConfYearsShow;
        }

        public void setSysInsuranceConfYearsShow(String sysInsuranceConfYearsShow) {
            this.sysInsuranceConfYearsShow = sysInsuranceConfYearsShow;
        }

        public String getSysInsuranceTypeInput() {
            return sysInsuranceTypeInput;
        }

        public void setSysInsuranceTypeInput(String sysInsuranceTypeInput) {
            this.sysInsuranceTypeInput = sysInsuranceTypeInput;
        }

        public String getSysInsuranceTypeInputName() {
            return sysInsuranceTypeInputName;
        }

        public void setSysInsuranceTypeInputName(String sysInsuranceTypeInputName) {
            this.sysInsuranceTypeInputName = sysInsuranceTypeInputName;
        }

        public String getSysInsuranceTypeInputInfo() {
            return sysInsuranceTypeInputInfo;
        }

        public void setSysInsuranceTypeInputInfo(String sysInsuranceTypeInputInfo) {
            this.sysInsuranceTypeInputInfo = sysInsuranceTypeInputInfo;
        }
    }
}
