package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/30
 * Time:  15:47
 */

public class OrderNumResponse implements Serializable{

    /**
     * personal_Pay : 3
     * personal_total : 4
     * personal_wait : 0
     * group_wait : 0
     * group_cancel : 0
     * group_Pay : 2
     * personal_cancel : 1
     * group_total : 2
     */

    private String personal_Pay;
    private String personal_total;
    private String personal_wait;
    private String group_wait;
    private String group_cancel;
    private String group_Pay;
    private String personal_cancel;
    private String group_total;

    public String getPersonal_Pay() {
        return personal_Pay;
    }

    public void setPersonal_Pay(String personal_Pay) {
        this.personal_Pay = personal_Pay;
    }

    public String getPersonal_total() {
        return personal_total;
    }

    public void setPersonal_total(String personal_total) {
        this.personal_total = personal_total;
    }

    public String getPersonal_wait() {
        return personal_wait;
    }

    public void setPersonal_wait(String personal_wait) {
        this.personal_wait = personal_wait;
    }

    public String getGroup_wait() {
        return group_wait;
    }

    public void setGroup_wait(String group_wait) {
        this.group_wait = group_wait;
    }

    public String getGroup_cancel() {
        return group_cancel;
    }

    public void setGroup_cancel(String group_cancel) {
        this.group_cancel = group_cancel;
    }

    public String getGroup_Pay() {
        return group_Pay;
    }

    public void setGroup_Pay(String group_Pay) {
        this.group_Pay = group_Pay;
    }

    public String getPersonal_cancel() {
        return personal_cancel;
    }

    public void setPersonal_cancel(String personal_cancel) {
        this.personal_cancel = personal_cancel;
    }

    public String getGroup_total() {
        return group_total;
    }

    public void setGroup_total(String group_total) {
        this.group_total = group_total;
    }
}
