package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/6/29.
 */

public class LabelInventoryResponse implements Serializable{

    /**
     * lno : 20200701                               标签号
     * modifytime : 2018-07-16 00:00:00             领取时间
     * packNumber : 55                               包装盒号
     */

    private String lno;
    private String modifytime;
    private String packNumber;

    public String getLno() {
        return lno;
    }

    public void setLno(String lno) {
        this.lno = lno;
    }

    public String getModifytime() {
        return modifytime;
    }

    public void setModifytime(String modifytime) {
        this.modifytime = modifytime;
    }

    public String getPackNumber() {
        return packNumber;
    }

    public void setPackNumber(String packNumber) {
        this.packNumber = packNumber;
    }
}
