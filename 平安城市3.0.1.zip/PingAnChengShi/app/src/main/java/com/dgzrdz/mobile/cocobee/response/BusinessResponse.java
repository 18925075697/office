package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/20
 * Time:  17:23
 */

public class BusinessResponse implements Serializable{

    private List<TotalBean> total;
    private List<TotalBean> today;
    private List<TotalBean> Seven;
    private List<TotalBean> thirty;

    public List<TotalBean> getTotal() {
        return total;
    }

    public void setTotal(List<TotalBean> total) {
        this.total = total;
    }

    public List<TotalBean> getToday() {
        return today;
    }

    public void setToday(List<TotalBean> today) {
        this.today = today;
    }

    public List<TotalBean> getSeven() {
        return Seven;
    }

    public void setSeven(List<TotalBean> seven) {
        Seven = seven;
    }

    public List<TotalBean> getThirty() {
        return thirty;
    }

    public void setThirty(List<TotalBean> thirty) {
        this.thirty = thirty;
    }

    public static class TotalBean {
        /**
         * total : 0
         * sysConfType : 1
         */

        private String total;
        private int sysConfType;//类型，1：个人业务，2集团业务

        public String getTotal() {
            return total;
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public int getSysConfType() {
            return sysConfType;
        }

        public void setSysConfType(int sysConfType) {
            this.sysConfType = sysConfType;
        }
    }

}
