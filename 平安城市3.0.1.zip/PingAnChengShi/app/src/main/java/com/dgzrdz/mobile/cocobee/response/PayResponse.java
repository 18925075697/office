package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/6/22.
 */

public class PayResponse implements Serializable{
    private String orderid;
    private String qrcodetype;
    private String waittime;
    private String traceid;
    private String errmsg;
    private String sign;
    private String errcode;
    private String result;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getQrcodetype() {
        return qrcodetype;
    }

    public void setQrcodetype(String qrcodetype) {
        this.qrcodetype = qrcodetype;
    }

    public String getWaittime() {
        return waittime;
    }

    public void setWaittime(String waittime) {
        this.waittime = waittime;
    }

    public String getTraceid() {
        return traceid;
    }

    public void setTraceid(String traceid) {
        this.traceid = traceid;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getErrcode() {
        return errcode;
    }

    public void setErrcode(String errcode) {
        this.errcode = errcode;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
