package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseTabFragment;
import com.dgzrdz.mobile.cocobee.utils.DataProviderUtils;

import java.util.ArrayList;

/**
 * Description: 个人业务订单
 * Author: Liubingren
 * Data:  18/11/27
 * Time:  14:05
 */
public class ViewPagerFragment extends BaseTabFragment {

    private static int pageNum;
    private static int sysConfType;//业务类型 1个人业务  2集团业务
    private ArrayList<Fragment> mFragments;

    public static ViewPagerFragment getInstance(int pageNum, int sysConfType) {
        ViewPagerFragment.pageNum = pageNum;
        ViewPagerFragment.sysConfType = sysConfType;
        ViewPagerFragment fragment = new ViewPagerFragment();
        return fragment;
    }

    @Override
    public String[] getTabTitles() {
        return DataProviderUtils.getOrderStatusTabTitles();
    }

    @Override
    public ArrayList<Fragment> getFragments() {
        //1个人业务  2集团业务
        mFragments = new ArrayList<>();
        mFragments.add(TotalOrderFragment.getInstance(sysConfType));
        mFragments.add(UnPayOrderFragment.getInstance(sysConfType));
        mFragments.add(PayedOrderFragment.getInstance(sysConfType));
        mFragments.add(OutDateOrderFragment.getInstance(sysConfType));
        mFragments.add(CanceledOrderFragment.getInstance(sysConfType));
        return mFragments;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        mViewpager.setCurrentItem(pageNum);
    }

    @Override
    protected void initToolbarHere() {
        if (sysConfType == 2) {
            initToolbarWithRightDrawable("集团业务订单", R.drawable.search_search);
        } else {
            initToolbarWithRightDrawable("个人业务订单", R.drawable.search_search);
        }
    }

    @Override
    public void btnRightImageClick() {
        start(OrderSearchFragment.getInstance());
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_viewpager;
    }
}
