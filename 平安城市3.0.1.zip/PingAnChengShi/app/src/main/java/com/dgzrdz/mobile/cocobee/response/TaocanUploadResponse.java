package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/30
 * Time:  15:47
 */

public class TaocanUploadResponse implements Serializable {

    /**
     * sysServiceSetPropId : 1
     * sysServiceSetPropOptionId : 2
     * sysServiceSetPropExValueStr : 2
     * realid : 300
     */

    private String sysServiceSetPropId;//套餐属性配置id
    private String sysServiceSetPropOptionId;//属性规格值id
    private String sysServiceSetPropExValueStr;//扩展输入
    private String realid;//所选年限

    public String getSysServiceSetPropId() {
        return sysServiceSetPropId;
    }

    public void setSysServiceSetPropId(String sysServiceSetPropId) {
        this.sysServiceSetPropId = sysServiceSetPropId;
    }

    public String getSysServiceSetPropOptionId() {
        return sysServiceSetPropOptionId;
    }

    public void setSysServiceSetPropOptionId(String sysServiceSetPropOptionId) {
        this.sysServiceSetPropOptionId = sysServiceSetPropOptionId;
    }

    public String getSysServiceSetPropExValueStr() {
        return sysServiceSetPropExValueStr;
    }

    public void setSysServiceSetPropExValueStr(String sysServiceSetPropExValueStr) {
        this.sysServiceSetPropExValueStr = sysServiceSetPropExValueStr;
    }

    public String getRealid() {
        return realid;
    }

    public void setRealid(String realid) {
        this.realid = realid;
    }
}
