package com.dgzrdz.mobile.cocobee.activity.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import com.bql.tablayout.SlidingTabLayout;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.MyPagerAdapter;
import com.dgzrdz.mobile.cocobee.fragment.home.CnoFragment;
import com.dgzrdz.mobile.cocobee.fragment.home.LnoFragment;
import com.dgzrdz.mobile.cocobee.utils.StatusBarUtil;
import com.dgzrdz.mobile.cocobee.view.CustomViewPager;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created by Administrator on 2018/6/26.
 * 库存查看
 */

public class InventoryActivity extends AppCompatActivity {
    @BindView(R.id.sliding_tab)
    SlidingTabLayout mSlidingTab;
    @BindView(R.id.viewpager)
    CustomViewPager mViewpager;
    @BindView(R.id.iv_back)
    ImageView mIvBack;
    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private final String[] mTitles = {"标签库存", "车牌库存"};
    private Unbinder mBind;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_check);
        StatusBarUtil.setLightMode(this);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.color_f9faf7), 0);
        mBind = ButterKnife.bind(this);
        mFragments.add(LnoFragment.getInstance());
        mFragments.add(CnoFragment.getInstance());
        mViewpager.setOffscreenPageLimit(2);
        mViewpager.setAdapter(new MyPagerAdapter(getSupportFragmentManager(), mFragments, mTitles));
        mSlidingTab.setViewPager(mViewpager);
    }

    @Override
    protected void onDestroy() {
        mBind.unbind();
        super.onDestroy();
    }

    @OnClick({R.id.iv_back})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                finish();
                break;
        }
    }
}
