package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/5/5.
 */

public class PaperPolicyResponse implements Serializable{

    /**
     * createtime : 2018-04-21 14:55:00
     * creator : admin
     * id : 72d4fb9bc6a44d38a68fb278b1f52342
     * isdelete : null
     * modifier : null
     * modifytime : null
     * name : null      7前照 8后照
     * size : null
     * url : /upload/d70e3048439c11e8b77300ff02317479/2018-04-21/0纸质保单11.jpg
     */

    private String createtime;
    private String creator;
    private String id;
    private String isdelete;
    private String modifier;
    private String modifytime;
    private String name;
    private String size;
    private String url;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(String isdelete) {
        this.isdelete = isdelete;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getModifytime() {
        return modifytime;
    }

    public void setModifytime(String modifytime) {
        this.modifytime = modifytime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
