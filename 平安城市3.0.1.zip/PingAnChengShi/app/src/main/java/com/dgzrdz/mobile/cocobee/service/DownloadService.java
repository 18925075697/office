package com.dgzrdz.mobile.cocobee.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.MainActivity;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.utils.NotificationDownload;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.FileCallback;

import java.io.File;

import okhttp3.Call;
import okhttp3.Response;


/**
 * @author _H_JY
 *         2015-10-26下午4:00:05
 *         <p>
 *         功能：在后台下载软件新版本安装包
 */
public class DownloadService extends Service {
    // 自定义通知栏类
    private NotificationDownload myNotification;
    private VersionInfo mVersionInfo;

    public DownloadService() {

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mVersionInfo = Utils.getUpdateVersionInfo();
    }

    @Override
    public void onDestroy() {
        stopSelf();
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mVersionInfo.setDownload(true);
        //注册Notification
        Intent updateIntent = new Intent(this, MainActivity.class);
        PendingIntent updatePendingIntent = PendingIntent.getActivity(this, 0, updateIntent, 0);
        myNotification = new NotificationDownload(this, updatePendingIntent, 1);
        myNotification.showCustomizeNotification(R.drawable.app_logo, "平安城市.apk", R.layout.download_view);

        downLoad(Path.APK_DOWNLOAD_URL, Path.PROJECT_FILE_PATH, "平安城市.apk");
        sendBroadcast(0, 0);
        return START_REDELIVER_INTENT;
    }

    /**
     * 下载文件
     *
     * @param url          下载地址
     * @param destFileDir  保存文件路径
     * @param destFileName 保存文件名
     */
    private void downLoad(String url, String destFileDir, String destFileName) {
        mVersionInfo.setDownload(true);
        OkGo.get(url).tag(this)
                .execute(new FileCallback(destFileDir, destFileName) {  //文件下载时，可以指定下载的文件目录和文件名
                    @Override
                    public void onSuccess(File file, Call call, Response response) {
                        installApk(file);
                        mVersionInfo.setDownload(false);
                        sendBroadcast(100, 2);
                        // 需要手动停止服务
                        stopSelf();
                        // file 即为文件数据，文件保存在指定目录
                        openFile(file);
                    }

                    @Override
                    public void downloadProgress(long currentSize, long totalSize, float progress, long networkSpeed) {
                        //这里回调下载进度(该回调在主线程,可以直接更新ui)
                        //currentSize totalSize以字节byte为单位
                        int i = (int) (progress * 100);
                        myNotification.changeProgressStatus(i);
                        sendBroadcast(i, 1);

                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        sendBroadcast(0, 3);
                        // 下载失败
                        myNotification.changeNotificationText("文件下载失败！");
                        mVersionInfo.setDownload(false);
                        stopSelf();
                    }
                });
    }

    /**
     * @param i     进度
     * @param count 0开始 1下载中 2下载完成 3下载失败
     */
    private void sendBroadcast(int i, int count) {
        //发送广播
        Intent intent = new Intent();
        intent.putExtra("count", count);
        intent.putExtra("i", i);
        intent.setAction("com.dgzrdz.mobile.cocobee.utils.UpdateManager.ShowDialogReceiver");
        sendBroadcast(intent);
    }

    /**
     * 点击安装
     *
     * @param file
     */
    private void installApk(File file) {
        // 点击安装PendingIntent
        Uri uri = Uri.fromFile(file);
        Intent installIntent = new Intent(Intent.ACTION_VIEW);
        //打开安装包是正常的，并提示“要覆盖原有的程序”，但是安装后不出现选择“完成，打开”的窗口，但程序已经更新的了.调用此行代码可解决这个问题
        installIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        installIntent.setDataAndType(uri, "application/vnd.android.package-archive");
        PendingIntent updatePendingIntent = PendingIntent.getActivity(DownloadService.this, 0, installIntent, 0);
        myNotification.changeContentIntent(updatePendingIntent);
        myNotification.notification.defaults = Notification.DEFAULT_SOUND;// 铃声提醒
        myNotification.changeNotificationText("下载完成，请点击安装！");
    }

    /**
     * 下载完后自动安装
     *
     * @param file
     */
    private void openFile(File file) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(android.content.Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        startActivity(intent);

    }

    @Override
    @Deprecated
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }
}
