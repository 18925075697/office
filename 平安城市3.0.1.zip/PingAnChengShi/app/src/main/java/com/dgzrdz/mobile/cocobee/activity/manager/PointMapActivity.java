package com.dgzrdz.mobile.cocobee.activity.manager;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ZoomControls;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.model.LatLng;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.Point;
import com.dgzrdz.mobile.cocobee.view.dialog.ShowMarkerInfoDialog;

import java.io.Serializable;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Description: 点位管理地图页面,展示所有点位的位置
 * Author: Liubingren
 * Data:  2018/9/12
 * Time:  13:44
 */
public class PointMapActivity extends BaseToolbarActivity implements BaiduMap.OnMapLoadedCallback {

    @BindView(R.id.mapView)
    MapView mMapView;
    @BindView(R.id.iv_search)
    ImageView mIvSearch;

    private BaiduMap mBaiduMap;
    private MapStatus ms;

    public MyLocationListener myListener;

    //定位
    private LocationClient locationClient;
    private double mLongitude = 106.662893;
    private double mLatitude = 26.616185;
    boolean isFirstLoad = true;

    private List<Point> mPoints;
    private ShowMarkerInfoDialog mDialog;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_point_position_map;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        //不能滑动返回
        setSwipeBackEnable(false);
        initToolbarWithRightText("点位管理", "文字列表");
        myListener = new MyLocationListener();
        initMap();
        getCurrentLocation();
        initIntent();
        if (mPoints == null || mPoints.size() == 0) {
            mIvSearch.setVisibility(View.GONE);
            return;
        }
        addBaseStationMarkers();
    }

    private void initIntent() {
        Intent intent = getIntent();
        mPoints = (List<Point>) intent.getSerializableExtra("points");
    }

    private void getCurrentLocation() {
        /*使用百度SDK获取经纬度*/
        locationClient = new LocationClient(getApplicationContext());
        locationClient.registerLocationListener(myListener);
        LocationClientOption option = new LocationClientOption();
        option.setIsNeedAddress(true);
        option.setOpenGps(true);        //是否打开GPS
        option.setCoorType("bd09ll");       //设置返回值的坐标类型。
        option.setPriority(LocationClientOption.NetWorkFirst);  //设置定位优先级
        option.setProdName("Cocobee"); //设置产品线名称。强烈建议您使用自定义的产品线名称，方便我们以后为您提供更高效准确的定位服务。
        option.setScanSpan(600000);  //设置定时定位的时间间隔为10分钟。单位毫秒
        locationClient.setLocOption(option);
        locationClient.start();
        /*
         *当所设的整数值大于等于1000（ms）时，定位SDK内部使用定时定位模式。
         *调用requestLocation( )后，每隔设定的时间，定位SDK就会进行一次定位。
         *如果定位SDK根据定位依据发现位置没有发生变化，就不会发起网络请求，
         *返回上一次定位的结果；如果发现位置改变，就进行网络请求进行定位，得到新的定位结果。
         *定时定位时，调用一次requestLocation，会定时监听到定位结果。
         */
        locationClient.requestLocation();
    }

    //初始化地图
    private void initMap() {
        // 隐藏百度的LOGO
        View child = mMapView.getChildAt(1);
        if (child != null && (child instanceof ImageView || child instanceof ZoomControls)) {
            child.setVisibility(View.INVISIBLE);
        }
        // 不显示地图缩放控件（按钮控制栏）
        mMapView.showZoomControls(false);

        mBaiduMap = mMapView.getMap();
        mBaiduMap.setOnMapLoadedCallback(this);
        mBaiduMap.setMyLocationEnabled(true);
        //设置地图状态
        setMap();
        setListener();
    }

    /**
     * 添加markers
     */
    private void addBaseStationMarkers() {
        double lat;
        double lng;
        BitmapDescriptor bitmap = BitmapDescriptorFactory.fromResource(R.drawable.position_uninstall);
        BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromResource(R.drawable.position_offline);
        BitmapDescriptor bitmap2 = BitmapDescriptorFactory.fromResource(R.drawable.position_online);

        for (int i = 0; i < mPoints.size(); i++) {
            Point point = mPoints.get(i);
            if (CheckUtils.isEmpty(point.getEqlat())) {
                continue;
            }
            lat = Double.parseDouble(point.getEqlat());
            lng = Double.parseDouble(point.getEqlng());
            LatLng latLng = new LatLng(lat, lng);
            //准备 marker option 添加 marker 使用
            Bundle bundle = new Bundle();
            bundle.putSerializable("info", point);
            bundle.putInt("position", i);

            MarkerOptions markerOptions;
            if (CheckUtils.equalsString(point.getInstall_flag(), "2")) {//已安装
                markerOptions = new MarkerOptions().icon(bitmap).position(latLng).zIndex(5);
            } else {//未安装
                markerOptions = new MarkerOptions().icon(bitmap1).position(latLng).zIndex(5);
            }
            Marker marker = (Marker) mBaiduMap.addOverlay(markerOptions);
            marker.setExtraInfo(bundle);
        }

    }

    /**
     * 设置地图的监听事件
     */
    private void setListener() {
        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                //点击地图
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {
                return false;
            }
        });

        mBaiduMap.setOnMarkerClickListener(marker -> {
            Point info = (Point) marker.getExtraInfo().get("info");
            int position = marker.getExtraInfo().getInt("position");
            //展示
            showDetail(info, position);
            return true;
        });
    }

    @Override
    public void btnRightTextClick() {
        Intent intent = new Intent(this, PointManageListAct.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }


    @Override
    protected void onPause() {
        if (mMapView != null) {
            mMapView.onPause();
        }
        //关闭定位图层
        if (mBaiduMap != null) {
            mBaiduMap.setMyLocationEnabled(false);
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (mMapView != null) {
            mMapView.onResume();
        }
        //开启定位图层
        if (mBaiduMap != null) {
            mBaiduMap.setMyLocationEnabled(true);
        }
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        if (locationClient != null) {
            locationClient.stop();
        }
        if (mBaiduMap != null) { //关闭定位图层
            mBaiduMap.setMyLocationEnabled(false);
        }

        if (mMapView != null) {
            mMapView.onDestroy();
            mMapView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onMapLoaded() {
        ms = new MapStatus.Builder().zoom(17).build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));
    }

    @OnClick({R.id.iv_search})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_search://搜索
                gotoActivity();
                break;
        }
    }

    /**
     * 跳转进入下一个页面
     */
    private void gotoActivity() {
        Intent intent = new Intent(this, PointSearchAct.class);
        intent.putExtra("points", (Serializable) mPoints);
        startActivity(intent);
    }

    class MyLocationListener implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            if (location == null)
                return;
            mLongitude = location.getLongitude(); //获取经度
            mLatitude = location.getLatitude();

            if (isFirstLoad) {
                isFirstLoad = false;
                setMap();
            }
        }
    }

    /**
     * 设置地图
     */
    private void setMap() {
        //定位成功之后设置地图更新
        MyLocationData locData = new MyLocationData.Builder()
                .accuracy(0).direction(0).latitude(mLatitude).longitude(mLongitude).build();
        mBaiduMap.setMyLocationData(locData);
        ms = new MapStatus.Builder().target(new LatLng(mLatitude, mLongitude)).zoom(17).build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));
    }


    /**
     * 展示明细
     */
    private void showDetail(Point info, int position) {
        mDialog = new ShowMarkerInfoDialog();
        mDialog.setPoint(info);
        mDialog.setPoints(mPoints);
        mDialog.setPosition(position);
        mDialog.show(getSupportFragmentManager(), "marker");
    }

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.MAP_SELECT_DIALOG_DISMISS://导航地图选择弹框消失
                if (mDialog != null) {
                    mDialog.show(getSupportFragmentManager(), "marker");
                }
                break;
            case EventConstants.NEED_REFRESH_POINTLIST:
            case EventConstants.DEVICE_UPLOAD_SUCCESS:
                loadData();
                break;
        }
    }

    private void loadData() {
        ManagerApiUtils.getPointsInfo(this, user.getDataList().getAppMemberId(), new DialogCallback<List<Point>>(this, "更新点位数据...") {
            @Override
            public void onSuccess(List<Point> points, Call call, Response response) {
                mPoints.clear();
                mBaiduMap.clear();
                if (points != null && points.size() > 0) {
                    mPoints.addAll(points);
                    addBaseStationMarkers();
                } else {
                    mIvSearch.setVisibility(View.GONE);
                }
            }
        });
    }
}

