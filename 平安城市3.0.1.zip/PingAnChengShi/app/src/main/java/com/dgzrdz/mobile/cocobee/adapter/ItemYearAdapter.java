package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.TagServiceResponse;

import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  16:33
 */

public class ItemYearAdapter extends QuickRcvAdapter<TagServiceResponse.ServiceTypeListBean> {

    private final Context mContext;

    public ItemYearAdapter(Context context, List<TagServiceResponse.ServiceTypeListBean> data, int... layoutId) {
        super(context, data, R.layout.item_year_view);
        mContext = context;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int position, TagServiceResponse.ServiceTypeListBean serviceTypeListBean) {
        TextView serviceType = quickRcvHolder.getView(R.id.service_type);
        serviceType.setText(serviceTypeListBean.getName());
        if (!serviceTypeListBean.isEnable()) {
            serviceType.setPaintFlags(serviceType.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);//添加删除线
            serviceType.setBackgroundResource(R.drawable.tag_service_normal);
            serviceType.setTextColor(mContext.getResources().getColor(R.color.color_dddddd));
            return;
        }

        if (serviceTypeListBean.getSelect() == position) {//选中的条目
            serviceType.setPaintFlags(serviceType.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));//取消删除线
            serviceType.setBackgroundResource(R.drawable.tag_service_select);
            serviceType.setTextColor(mContext.getResources().getColor(R.color.color_008cff));
        } else {
            serviceType.setPaintFlags(serviceType.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));//取消删除线
            serviceType.setBackgroundResource(R.drawable.tag_service_normal);
            serviceType.setTextColor(mContext.getResources().getColor(R.color.color_333333));
        }
    }
}
