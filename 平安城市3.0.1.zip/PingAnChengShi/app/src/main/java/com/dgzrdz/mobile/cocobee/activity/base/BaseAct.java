package com.dgzrdz.mobile.cocobee.activity.base;

import android.app.Activity;
import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.common.AppManager;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.lang.ref.WeakReference;

/**
 * 基Activity
 * Created by _H_JY on 2017/3/17.
 */
public abstract class BaseAct extends Activity {

    protected UserInfo user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppManager.getAppManager().addActivity(this);
        user = Utils.getUserLoginInfo();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppManager.getAppManager().finishActivity(new WeakReference<Activity>(this));
    }

}
