package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.CarOwnerInfo;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by admin on 2018/4/25.
 */

public class CarOwnerSearchAdapter extends QuickRcvAdapter<CarOwnerInfo> {
    private final Context mContext;
    String keyStr;

    public CarOwnerSearchAdapter(Context context, List<CarOwnerInfo> data, String key) {
        super(context, data, R.layout.item_car_owner);
        keyStr = key;
        mContext = context;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, CarOwnerInfo carOwnerInfo) {
        TextView nameTxt = quickRcvHolder.getView(R.id.nameTxt);
        TextView telTxt = quickRcvHolder.getView(R.id.telTxt);
        TextView bindingSizeTxt = quickRcvHolder.getView(R.id.bindingSizeTxt);

        if (!CheckUtils.isEmpty(keyStr)) {
            nameTxt.setText(matcherSearchText(mContext.getResources().getColor(R.color.color_008cff), carOwnerInfo.getName(), keyStr));
            telTxt.setText(matcherSearchText(mContext.getResources().getColor(R.color.color_008cff), "(" + carOwnerInfo.getMobile() + ")", keyStr));
        } else {
            nameTxt.setText(carOwnerInfo.getName());
            telTxt.setText("(" + carOwnerInfo.getMobile() + ")");
        }

        bindingSizeTxt.setText(carOwnerInfo.getTotal());
    }

    public static SpannableString matcherSearchText(int color, String text, String keyword) {
        SpannableString ss = new SpannableString(text);
        Pattern pattern = Pattern.compile(keyword);
        Matcher matcher = pattern.matcher(ss);

        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            ss.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return ss;
    }


}
