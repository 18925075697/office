package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/4/17.
 */

public class TestModeResponse implements Serializable {
    private String testResult;//测试结果
    private String gprsConnect;//GPRS连接状态
    private String fireConnect;//有线连接状态
    private String gprsRssi;//gprs信号质量
    private String principal;//主天线门限
    private String subordinate;//从天线门限
    private String eastP;//东主测试结果
    private String eastPRssi;//东主rssi值
    private String eastS;//东从测试结果
    private String eastSRssi;//东从Rssi值
    private String southP;//南主测试结果
    private String southPRssi;//南主rssi值
    private String southS;//南从测试结果
    private String southSRssi;//南从Rssi值
    private String westP;//西主测试结果
    private String westPRssi;//西主rssi值
    private String westS;//西从测试结果
    private String westSRssi;//西从Rssi值
    private String northP;//北主测试结果
    private String northPRssi;//北主rssi值
    private String northS;//北从测试结果
    private String northSRssi;//北从Rssi值

    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    public String getGprsConnect() {
        return gprsConnect;
    }

    public void setGprsConnect(String gprsConnect) {
        this.gprsConnect = gprsConnect;
    }

    public String getFireConnect() {
        return fireConnect;
    }

    public void setFireConnect(String fireConnect) {
        this.fireConnect = fireConnect;
    }

    public String getGprsRssi() {
        return gprsRssi;
    }

    public void setGprsRssi(String gprsRssi) {
        this.gprsRssi = gprsRssi;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }

    public String getSubordinate() {
        return subordinate;
    }

    public void setSubordinate(String subordinate) {
        this.subordinate = subordinate;
    }

    public String getEastP() {
        return eastP;
    }

    public void setEastP(String eastP) {
        this.eastP = eastP;
    }

    public String getEastPRssi() {
        return eastPRssi;
    }

    public void setEastPRssi(String eastPRssi) {
        this.eastPRssi = eastPRssi;
    }

    public String getEastS() {
        return eastS;
    }

    public void setEastS(String eastS) {
        this.eastS = eastS;
    }

    public String getEastSRssi() {
        return eastSRssi;
    }

    public void setEastSRssi(String eastSRssi) {
        this.eastSRssi = eastSRssi;
    }

    public String getSouthP() {
        return southP;
    }

    public void setSouthP(String southP) {
        this.southP = southP;
    }

    public String getSouthPRssi() {
        return southPRssi;
    }

    public void setSouthPRssi(String southPRssi) {
        this.southPRssi = southPRssi;
    }

    public String getSouthS() {
        return southS;
    }

    public void setSouthS(String southS) {
        this.southS = southS;
    }

    public String getSouthSRssi() {
        return southSRssi;
    }

    public void setSouthSRssi(String southSRssi) {
        this.southSRssi = southSRssi;
    }

    public String getWestP() {
        return westP;
    }

    public void setWestP(String westP) {
        this.westP = westP;
    }

    public String getWestPRssi() {
        return westPRssi;
    }

    public void setWestPRssi(String westPRssi) {
        this.westPRssi = westPRssi;
    }

    public String getWestS() {
        return westS;
    }

    public void setWestS(String westS) {
        this.westS = westS;
    }

    public String getWestSRssi() {
        return westSRssi;
    }

    public void setWestSRssi(String westSRssi) {
        this.westSRssi = westSRssi;
    }

    public String getNorthP() {
        return northP;
    }

    public void setNorthP(String northP) {
        this.northP = northP;
    }

    public String getNorthPRssi() {
        return northPRssi;
    }

    public void setNorthPRssi(String northPRssi) {
        this.northPRssi = northPRssi;
    }

    public String getNorthS() {
        return northS;
    }

    public void setNorthS(String northS) {
        this.northS = northS;
    }

    public String getNorthSRssi() {
        return northSRssi;
    }

    public void setNorthSRssi(String northSRssi) {
        this.northSRssi = northSRssi;
    }
}
