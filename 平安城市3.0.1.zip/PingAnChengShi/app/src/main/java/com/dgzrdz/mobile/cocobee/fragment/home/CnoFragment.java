package com.dgzrdz.mobile.cocobee.fragment.home;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.ultraptr.PtrClassicFrameLayout;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.CarNumInventoryAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseViewPagerFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.CarNumInventoryResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

import butterknife.BindView;
import okhttp3.Response;

/**
 * Created by Administrator on 2018/6/26.
 */

public class CnoFragment extends BaseViewPagerFragment<CarNumInventoryResponse> {
    @BindView(R.id.rcv_load_more)
    LoadMoreRecyclerView mRcvLoadMore;
    @BindView(R.id.prt_layout_)
    PtrClassicFrameLayout mPrtLayout;
    private CarNumInventoryAdapter mCarNumInventoryAdapter;
    private String currentTime;
    private UserInfo mUserLoginInfo;

    public static CnoFragment getInstance() {
        CnoFragment fragment = new CnoFragment();
        return fragment;
    }

    @Override
    public void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mCarNumInventoryAdapter = new CarNumInventoryAdapter(_mActivity, mList);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_cno;
    }

    @Override
    protected void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    protected void onRefresh() {
        initData(1,true);
    }

    @Override
    protected RecyclerView.Adapter getAdapter() {
        return mCarNumInventoryAdapter;
    }

    @Override
    protected void initData(int curPage ,boolean isPullToRefresh) {
        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        DatasApiUtils.getCnoStock(_mActivity, currentTime, pageSize + "", curPage + "", mUserLoginInfo.getDataList().getSysAreaId(), new RefreshAndLoadCallback<List<CarNumInventoryResponse>>(true) {

            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                initData(1,false);
            }

            @Override
            public void onResultSuccess(List<CarNumInventoryResponse> carNumInventoryResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshAndLoadListData(mCurPage, callback, carNumInventoryResponses);
            }

            @Override
            public Drawable emptyDrawable() {
                return _mActivity.getResources().getDrawable(R.drawable.norecord);
            }

            @Override
            public String emptyContent() {
                return "暂无记录";
            }
        });
    }

    @Override
    public void onLoadMore() {
        initData(mCurPage,false);
    }
}