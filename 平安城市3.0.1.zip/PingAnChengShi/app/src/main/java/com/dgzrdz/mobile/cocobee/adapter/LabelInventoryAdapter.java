package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.LabelInventoryResponse;

import java.util.List;

/**
 * Created by Administrator on 2018/6/29.
 */

public class LabelInventoryAdapter extends QuickRcvAdapter<LabelInventoryResponse> {

    private final Context mContext;

    public LabelInventoryAdapter(Context context, List<LabelInventoryResponse> data, int... layoutId) {
        super(context, data, R.layout.item_label_inventory);
        mContext = context;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, LabelInventoryResponse labelInventoryResponse) {
        quickRcvHolder.setText(R.id.tv_label,labelInventoryResponse.getLno());
        quickRcvHolder.setText(R.id.tv_type,labelInventoryResponse.getPackNumber());
        quickRcvHolder.setText(R.id.tv_time,labelInventoryResponse.getModifytime());
    }
}
