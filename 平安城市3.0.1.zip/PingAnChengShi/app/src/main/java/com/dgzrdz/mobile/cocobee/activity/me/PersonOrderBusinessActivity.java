package com.dgzrdz.mobile.cocobee.activity.me;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.me.ViewPagerFragment;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/27
 * Time:  13:45
 */

public class PersonOrderBusinessActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        if (savedInstanceState == null) {
            int pageNum = getIntent().getIntExtra("pageNum", 0);
            int sysConfType = getIntent().getIntExtra("sysConfType", 0);
            loadRootFragment(R.id.fl_container, ViewPagerFragment.getInstance(pageNum,sysConfType));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}
