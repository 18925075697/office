package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description: 用户信息
 * Author: Liubingren
 * Data:  2018/6/28
 * Time:  15:55
 */

public class UserBeanResponse implements Serializable {
    /**
     * memberLiveProvinceId : 0
     * memberPass : 96e79218965eb72c92a549dd5a330112
     * memberSix : 1
     * appMemberId : 1
     * memberRegTime : 2018-10-27
     * memberName : test
     * memberStatus : 1
     * memberLiveDistrictId : 0
     * sysAreaId : 1
     * memberEnabled : 1
     * memberRegisterProvinceId : 0
     * memberLiveCityId : 0
     * memberAddTime : 2018-10-11 14:44:32
     * memberCardId : 431003166563330214
     * memberRegisterAddress : 1
     * memberLiveAddress : 1
     * memberRegisterCityId : 0
     * memberRegType : 1
     * memberAccount : 18507552562
     * memberRegisterDistrictId : 0
     * memberId : 1
     */

    private String memberLiveProvinceId;
    private String memberPass;
    private String memberSix;
    private String appMemberId;
    private String memberRegTime;
    private String memberName;
    private String memberStatus;
    private String memberLiveDistrictId;
    private String sysAreaId;
    private String sysAreaName;
    private String memberEnabled;
    private String memberRegisterProvinceId;
    private String memberLiveCityId;
    private String memberAddTime;
    private String memberCardId;
    private String memberRegisterAddress;
    private String memberLiveAddress;
    private String memberRegisterCityId;
    private String memberRegType;
    private String memberAccount;
    private String memberRegisterDistrictId;
    private String memberId;
    private String total;
    private String sysMobileName;//运营商
    private String sysCityName;//归属地
    private String sysProName;//归属地省份

    public String getSysProName() {
        return sysProName;
    }

    public void setSysProName(String sysProName) {
        this.sysProName = sysProName;
    }

    public String getSysMobileName() {
        return sysMobileName;
    }

    public void setSysMobileName(String sysMobileName) {
        this.sysMobileName = sysMobileName;
    }

    public String getSysCityName() {
        return sysCityName;
    }

    public void setSysCityName(String sysCityName) {
        this.sysCityName = sysCityName;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getSysAreaName() {
        return sysAreaName;
    }

    public void setSysAreaName(String sysAreaName) {
        this.sysAreaName = sysAreaName;
    }

    public String getMemberLiveProvinceId() {
        return memberLiveProvinceId;
    }

    public void setMemberLiveProvinceId(String memberLiveProvinceId) {
        this.memberLiveProvinceId = memberLiveProvinceId;
    }

    public String getMemberPass() {
        return memberPass;
    }

    public void setMemberPass(String memberPass) {
        this.memberPass = memberPass;
    }

    public String getMemberSix() {
        return memberSix;
    }

    public void setMemberSix(String memberSix) {
        this.memberSix = memberSix;
    }

    public String getAppMemberId() {
        return appMemberId;
    }

    public void setAppMemberId(String appMemberId) {
        this.appMemberId = appMemberId;
    }

    public String getMemberRegTime() {
        return memberRegTime;
    }

    public void setMemberRegTime(String memberRegTime) {
        this.memberRegTime = memberRegTime;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(String memberStatus) {
        this.memberStatus = memberStatus;
    }

    public String getMemberLiveDistrictId() {
        return memberLiveDistrictId;
    }

    public void setMemberLiveDistrictId(String memberLiveDistrictId) {
        this.memberLiveDistrictId = memberLiveDistrictId;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getMemberEnabled() {
        return memberEnabled;
    }

    public void setMemberEnabled(String memberEnabled) {
        this.memberEnabled = memberEnabled;
    }

    public String getMemberRegisterProvinceId() {
        return memberRegisterProvinceId;
    }

    public void setMemberRegisterProvinceId(String memberRegisterProvinceId) {
        this.memberRegisterProvinceId = memberRegisterProvinceId;
    }

    public String getMemberLiveCityId() {
        return memberLiveCityId;
    }

    public void setMemberLiveCityId(String memberLiveCityId) {
        this.memberLiveCityId = memberLiveCityId;
    }

    public String getMemberAddTime() {
        return memberAddTime;
    }

    public void setMemberAddTime(String memberAddTime) {
        this.memberAddTime = memberAddTime;
    }

    public String getMemberCardId() {
        return memberCardId;
    }

    public void setMemberCardId(String memberCardId) {
        this.memberCardId = memberCardId;
    }

    public String getMemberRegisterAddress() {
        return memberRegisterAddress;
    }

    public void setMemberRegisterAddress(String memberRegisterAddress) {
        this.memberRegisterAddress = memberRegisterAddress;
    }

    public String getMemberLiveAddress() {
        return memberLiveAddress;
    }

    public void setMemberLiveAddress(String memberLiveAddress) {
        this.memberLiveAddress = memberLiveAddress;
    }

    public String getMemberRegisterCityId() {
        return memberRegisterCityId;
    }

    public void setMemberRegisterCityId(String memberRegisterCityId) {
        this.memberRegisterCityId = memberRegisterCityId;
    }

    public String getMemberRegType() {
        return memberRegType;
    }

    public void setMemberRegType(String memberRegType) {
        this.memberRegType = memberRegType;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public String getMemberRegisterDistrictId() {
        return memberRegisterDistrictId;
    }

    public void setMemberRegisterDistrictId(String memberRegisterDistrictId) {
        this.memberRegisterDistrictId = memberRegisterDistrictId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
}
