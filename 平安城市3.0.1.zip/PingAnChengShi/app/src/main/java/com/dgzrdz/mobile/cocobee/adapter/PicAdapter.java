package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.ImageView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.ObjectValueResponse;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 查询的recycleView的adapter
 */

public class PicAdapter extends QuickRcvAdapter<ObjectValueResponse> {

    private final Context mContext;
    private final UserInfo mUserLoginInfo;

    public PicAdapter(Context context, List<ObjectValueResponse> data, int... layoutId) {
        super(context, data, R.layout.item_pic);
        mContext = context;
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, ObjectValueResponse item) {
        ImageView addPic = viewHolder.getView(R.id.iv_add_pic);
        viewHolder.setText(R.id.tv_pic_title, item.getSysPropertyName());
        if (!CheckUtils.isEmpty(item.getLocalUrl())) {//本地图片地址不为空,说明选择过图片了
            ImageUtil.loadCarPicCommen(mContext, item.getLocalUrl(), addPic);
        } else {//为空说明没选图片,加载网络图片
            if (CheckUtils.isWebUrl(item.getSysPropertyOptionId())) {
                ImageUtil.loadObjectPic(mContext, item.getSysPropertyOptionId(), addPic);
            } else {
                ImageUtil.loadObjectPic(mContext, mUserLoginInfo.getDataList().getPicture_prefix_url() + item.getSysPropertyOptionId(), addPic);
            }
        }
    }


}
