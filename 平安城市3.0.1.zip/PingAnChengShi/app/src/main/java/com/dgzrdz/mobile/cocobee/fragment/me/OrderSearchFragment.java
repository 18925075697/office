package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.pulltorefreshandloadmore.loadmoreview.DefaultLeLoadMoreView;
import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.loadmoreview.OnLoadMoreListener;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.me.OrderDetailActivity;
import com.dgzrdz.mobile.cocobee.adapter.OrderSearchAdapter;
import com.dgzrdz.mobile.cocobee.adapter.SearchAdapter;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.dgzrdz.mobile.cocobee.view.ListLineRecordDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 订单搜索
 * Author: Liubingren
 * Data:  2018/3/27
 * Time:  11:35
 */

public class OrderSearchFragment extends BaseFragment {
    @BindView(R.id.et_search)
    EditText mEtSearch;
    @BindView(R.id.tv_cancel)
    TextView mTvCancel;
    @BindView(R.id.recycleview_search_history)
    RecyclerView mRecycleviewSearchHistory;
    @BindView(R.id.recycleview_search_result)
    LoadMoreRecyclerView mRecycleviewSearchResult;
    @BindView(R.id.tv_search_title)
    TextView mTvSearchTitle;
    @BindView(R.id.ll_search)
    LinearLayout mLlSearch;
    @BindView(R.id.tv_no_result)
    TextView mTvNoResult;
    @BindView(R.id.ll_search_history_title)
    LinearLayout mLlSearchHistoryTitle;
    @BindView(R.id.iv_delete)
    ImageView mIvDelete;
    @BindView(R.id.view)
    View mView;

    private SearchAdapter mSearchAdapter;
    private OrderSearchAdapter mSearchResultAdapter;
    private List<String> mHistroyList = new ArrayList<>();
    private List<OrderStatusResponse> mSearchResultList = new ArrayList<>();
    private UserInfo mUserLoginInfo;

    private String currentTime;
    private int mCurPage = 1;
    private int pageSize = 20;
    private OrderStatusResponse mOrderStatusResponse;

    public static OrderSearchFragment getInstance() {
        OrderSearchFragment fragment = new OrderSearchFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        immersiveStatusBar(mView);
        mUserLoginInfo = Utils.getUserLoginInfo();
        initSharedPreference();
        initRecycleView();
        initHistoryRecycleView();
        initEditText();
    }

    private void initRecycleView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(_mActivity);
        mRecycleviewSearchHistory.setLayoutManager(layoutManager);
        mRecycleviewSearchHistory.addItemDecoration(new ListLineDecoration());
        mSearchAdapter = new SearchAdapter(_mActivity, mHistroyList, R.layout.history_search_item);
        mRecycleviewSearchHistory.setAdapter(mSearchAdapter);
        mSearchAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {
                String searchString = mHistroyList.get(position);
                //点击历史记录将搜索文字设置到输入框
                mEtSearch.setText(searchString);
                mEtSearch.setSelection(searchString.length());
                //搜索
                mSearchResultList.clear();
                search(searchString, 1);
            }
        });


        mRecycleviewSearchResult.setLayoutManager(new LinearLayoutManager(_mActivity));
        mRecycleviewSearchResult.addItemDecoration(new ListLineRecordDecoration());
        mRecycleviewSearchResult.setHideLoadingView(true);
        mRecycleviewSearchResult.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                String searchString = mEtSearch.getText().toString().trim();
                search(searchString, mCurPage);
            }
        });
    }

    private void initSharedPreference() {
        List<String> searchList = Utils.getSearchList();
        if (searchList != null && searchList.size() > 0) {
            mHistroyList.clear();
            mHistroyList.addAll(searchList);
        }
    }

    private void initEditText() {
        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String searchText = mEtSearch.getText().toString().trim();
                if (!CheckUtils.isEmpty(searchText)) {
                    mTvNoResult.setVisibility(View.GONE);
                    mRecycleviewSearchResult.setVisibility(View.GONE);
                    mRecycleviewSearchHistory.setVisibility(View.GONE);
                    mLlSearch.setVisibility(View.VISIBLE);
                    mTvSearchTitle.setText(searchText);
                    mLlSearchHistoryTitle.setVisibility(View.GONE);
                } else {
                    mLlSearch.setVisibility(View.GONE);
                    mLlSearchHistoryTitle.setVisibility(View.VISIBLE);
                    //输入框为空时显示历史数据
                    initHistoryRecycleView();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //响应回车键
        mEtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    mSearchResultList.clear();
                    //响应搜索事件
                    search(mEtSearch.getText().toString().trim(), 1);
                }
                return true;
            }
        });
    }

    private void initHistoryRecycleView() {
        mLlSearchHistoryTitle.setVisibility(View.VISIBLE);
        if (mHistroyList.size() == 0) {
            mRecycleviewSearchHistory.setVisibility(View.GONE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mTvNoResult.setVisibility(View.VISIBLE);
            mTvNoResult.setText("暂无历史记录");
        } else {
            mTvNoResult.setVisibility(View.GONE);
            mRecycleviewSearchHistory.setVisibility(View.VISIBLE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mSearchAdapter.notifyDataSetChanged();
        }
    }


    @Override
    protected void initToolbarHere() {
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_order_search;
    }

    @OnClick({R.id.tv_cancel, R.id.ll_search, R.id.iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_cancel:
                pop();
                break;
            case R.id.ll_search://点击搜索
                mSearchResultList.clear();
                String searchString = mEtSearch.getText().toString().trim();
                search(searchString, 1);
                break;
            case R.id.iv_delete://清空历史记录
                showDelDialog();
                break;
        }
    }

    /**
     * 删除提示框
     */
    private void showDelDialog() {
        SweetAlertDialog continueDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.WARNING_TYPE);
        continueDialog.setTitleText("确定删除该车辆吗");
        continueDialog.showCancelButton(true).setCancelText("否");
        continueDialog.setConfirmText("是");
        continueDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();
                //删除
                mHistroyList.clear();
                Utils.putSearchList(mHistroyList);
                initHistoryRecycleView();
            }
        });

        continueDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();

            }
        });
        continueDialog.show();
    }

    /**
     * 保存搜索历史
     *
     * @param searchString
     */
    private void saveSearchHistory(String searchString) {
        //重复的删除之前的
        if (mHistroyList.contains(searchString)) {
            mHistroyList.remove(searchString);
        }
        //添加进集合第一个
        mHistroyList.add(0, searchString);
        //超过20条删除最早的
        if (mHistroyList.size() > 20) {
            for (int i = 0; i < mHistroyList.size(); i++) {
                if (i == 20) {
                    mHistroyList.remove(i);
                    i--;
                }
            }
        }
        Utils.putSearchList(mHistroyList);

    }

    /**
     * 根据条件搜索
     *
     * @param searchString
     */
    private void search(String searchString, int curPage) {
        //保存搜索记录
        saveSearchHistory(searchString);

        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        PayApiUtils.getOrderInfo(_mActivity, "", "", mUserLoginInfo.getDataList().getAppMemberId(), searchString, currentTime, pageSize + "", new DialogCallback<List<OrderStatusResponse>>(_mActivity, "获取标签信息中...") {
            @Override
            public void onSuccess(List<OrderStatusResponse> orderStatusResponses, Call call, Response response) {
                initResultRecycleView(orderStatusResponses);
                if (orderStatusResponses != null && orderStatusResponses.size() >= pageSize){
                    if (mCurPage == 1) {//第一页,存最后一条数据的时间
                        currentTime = orderStatusResponses.get(orderStatusResponses.size() - 1).getMemberOrderAddTime();
                    }
                }
            }

        });
    }

    private void initResultRecycleView(List<OrderStatusResponse> searchRecResponses) {
        mLlSearch.setVisibility(View.GONE);
        mRecycleviewSearchResult.setVisibility(View.VISIBLE);
        mLlSearchHistoryTitle.setVisibility(View.GONE);
        if ((searchRecResponses == null || searchRecResponses.size() == 0) && mCurPage == 1) {
            mTvNoResult.setVisibility(View.VISIBLE);
            mRecycleviewSearchResult.setVisibility(View.GONE);
            mRecycleviewSearchHistory.setVisibility(View.GONE);
            mTvNoResult.setText("未查询到相关结果");
        } else {
            mTvNoResult.setVisibility(View.GONE);
            mRecycleviewSearchResult.setVisibility(View.VISIBLE);
            mRecycleviewSearchHistory.setVisibility(View.GONE);

            mSearchResultAdapter = new OrderSearchAdapter(_mActivity, mSearchResultList, R.layout.item_order_status);
            mRecycleviewSearchResult.setAdapter(mSearchResultAdapter);
            mSearchResultAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
                @Override
                public void onItemClick(BH viewHolder, int position) {
                    //搜索得到的数据
                    mOrderStatusResponse = mSearchResultList.get(position);
                    Intent intent = new Intent(_mActivity, OrderDetailActivity.class);
                    intent.putExtra("orderStatusResponse", mOrderStatusResponse);
                    startActivity(intent);
                }
            });
        }

        handleRefreshAndLoadListData(searchRecResponses);
    }

    /**
     * 处理刷新加载得到的数据
     */
    public void handleRefreshAndLoadListData(List<OrderStatusResponse> list) {
        if (list == null) {
            if (mCurPage == 1) {
                mSearchResultList.clear();
            }
            mCurPage = mCurPage + 1;
            if (mSearchResultAdapter != null) {
                mSearchResultAdapter.notifyDataSetChanged();
            }
            mRecycleviewSearchResult.setCanLoadMore(false);
        } else if (list.size() > 0 || mCurPage != 1) {

            if (mCurPage == 1) {
                mSearchResultList.clear();
            }
            mCurPage = mCurPage + 1;
            mSearchResultList.addAll(list);
            mSearchResultAdapter.notifyDataSetChanged();

            if (list.size() < pageSize || list.size() == 0) {
                mRecycleviewSearchResult.setCanLoadMore(false);
            } else {
                mRecycleviewSearchResult.setCanLoadMore(true);
            }
        }
    }

    @Override
    public void onDestroyView() {
        if (mRecycleviewSearchResult != null && mRecycleviewSearchResult.getLoadMoreView() instanceof DefaultLeLoadMoreView) {
            ((DefaultLeLoadMoreView) mRecycleviewSearchResult.getLoadMoreView()).stop();
            mRecycleviewSearchResult = null;
        }
        super.onDestroyView();
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.ORDER_CANCEL_SUCCESS://订单取消成功
                if (mUserLoginInfo != null) {
                    Intent data = (Intent) eventManager.getData();
                    String pageNum = data.getStringExtra("pageNum");
                    if (!CheckUtils.equalsString(pageNum, "5")) {//非本页面
                        String searchString = mEtSearch.getText().toString().trim();
                        search(searchString, 1);
                    }
                }
                break;
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
                search(mEtSearch.getText().toString().trim(), 1);
                break;
        }
    }
}
