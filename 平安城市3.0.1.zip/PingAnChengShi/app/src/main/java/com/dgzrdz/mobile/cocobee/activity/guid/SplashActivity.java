package com.dgzrdz.mobile.cocobee.activity.guid;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;

import com.bql.utils.ManifestUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.MainActivity;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.activity.register.LoginActivity;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.CountDownProgress;
import com.lzy.okgo.OkGo;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * ClassName: SplashActivity <br>
 * Description: 启动页面<br>
 * Author: Cyarie <br>
 * Created: 2016/10/28 14:54 <br>
 * Update Time：<br>
 * Update Description：<br>
 */
public class SplashActivity extends BaseActivity {

    @BindView(R.id.countdown_view)
    CountDownProgress mCountdownView;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.act_splash;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (!isTaskRoot()) {//防止重复点开
            finish();
            return;
        }
        checkVersion();
        mCountdownView.setTimeMillis(5000);
        mCountdownView.setProgressColor(getResources().getColor(R.color.color_333333));
        mCountdownView.start();

        mCountdownView.setOnFinishListener(new CountDownProgress.OnFinishListener() {
            @Override
            public void onFinish() {
                next();
            }
        });
    }


    // 检测版本号，判断软件是否需要更新
    public void checkVersion() {
        int versionCodeLocal = ManifestUtils.getVersionCode(this);

        OkGo.post(Path.GET_VERSION_INFO).tag(this).execute(new JsonCallback<List<VersionInfo>>(this) {

            @Override
            public void onSuccess(List<VersionInfo> versionInfos, Call call, Response response) {
                if (versionInfos != null && versionInfos.size() > 0){
                    VersionInfo versionInfo = versionInfos.get(0);
                    if (versionInfo != null && Integer.parseInt(versionInfo.getAndroidVersion()) > versionCodeLocal) {//需要更新
                        versionInfo.setNeedUpdate(true);
                    }
                    Utils.putUpdateVersionInfo(versionInfo);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                VersionInfo versionInfo = new VersionInfo();
                Utils.putUpdateVersionInfo(versionInfo);
            }
        });
    }

    @OnClick(R.id.countdown_view)
    public void onClick() {
        mCountdownView.setClickable(false);
        next();
    }

    private void next() {
        mCountdownView.stop();
        final Intent intent;
        Boolean isFirst = Utils.getUserIsFirst();
        if (isFirst) {//第一次进入本应用
//                        intent = new Intent(this, GuideActivity.class);
            Utils.putUserIsFirst(false);
            intent = new Intent(this, LoginActivity.class);
        } else if (user != null) {//不是第一次进入本应用,且用户登录过
            intent = new Intent(this, MainActivity.class);
        } else {
            intent = new Intent(this, LoginActivity.class);
        }
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        mCountdownView.stop();
        super.onDestroy();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if(event.getKeyCode() == KeyEvent.KEYCODE_BACK ) {
            return true;
        }else {
            return super.dispatchKeyEvent(event);
        }
    }
}
