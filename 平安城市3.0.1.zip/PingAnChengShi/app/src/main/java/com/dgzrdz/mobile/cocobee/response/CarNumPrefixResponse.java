package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/16.
 */

public class CarNumPrefixResponse implements Serializable{
    /**
     * id : 5a76c59fcca84983b603f78024be4f86
     * name : 株洲A
     * prefixType : A
     */

    private String id;
    private String name;
    private String prefixType;
    private String ename;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrefixType() {
        return prefixType;
    }

    public void setPrefixType(String prefixType) {
        this.prefixType = prefixType;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }
}
