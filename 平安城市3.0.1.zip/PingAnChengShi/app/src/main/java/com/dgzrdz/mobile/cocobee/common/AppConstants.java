package com.dgzrdz.mobile.cocobee.common;

public class AppConstants {

    /**
     * 用户登录信息
     */
    public static final String USER_LOGIN_INFO = "user_login_info";

    /**
     * 版本升级信息
     */
    public static final String VERSION_UPDATE_INFO = "version_update_info";

    /**
     * 用户输入登录账号
     */
    public static final String USER_LOGIN_NUM = "user_login_num";

    /**
     * 测试模式的标签号
     */
    public static final String TEST_MODE_TAG = "test_mode_tag";

    /**
     * 测试模式的主天线门限
     */
    public static final String TEST_MODE_P = "test_mode_p";

    /**
     * 测试模式的从天线门限
     */
    public static final String TEST_MODE_S = "test_mode_s";

    /**
     * share preference文件名
     */
    public static final String PREFERS_CONFIG = "prefers_electr_config";
    /**
     * 用户是否第一次进入应用
     */
    public static final String IS_USER_FIRST = "is_user_first";

    /**
     * 用户选择的语言
     */

    public final static String LANGUAGE_ID = "languageId";

    /**
     * 搜索历史记录
     */
    public static final String SEARCH_HISTORY_INFO = "search_history_info";

    /**
     * Glide缓存大小
     */
    public static final int DISK_MAX_CACHE_SIZE = 80 * 1024 * 1024;//100MB

    //扫描标签
    public static final int SCAN_LABEL_REQUEST_CODE = 1666;//请求码
    public static final int SCAN_LABEL_RESULT_CODE = 1667;//结果码


}
