package com.dgzrdz.mobile.cocobee.fragment.me;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.home.BusinessStatisticsActivity;
import com.dgzrdz.mobile.cocobee.activity.me.ChangePwdOrgActivity;
import com.dgzrdz.mobile.cocobee.activity.me.MessageActivity;
import com.dgzrdz.mobile.cocobee.activity.me.PersonOrderBusinessActivity;
import com.dgzrdz.mobile.cocobee.activity.me.UserInfoActivity;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.response.OrderNumResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.UpdateManager;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Description: 我的fragment
 * Author: Liubingren
 * Data:  2017/4/17
 * Time:  11:16
 */

public class MeFragment extends BaseFragment {

    private static final int REQUEST_CODE_CALL = 1;
    @BindView(R.id.tv_user_name)
    TextView mTvUserName;
    @BindView(R.id.tv_user_type)
    TextView mTvUserType;
    @BindView(R.id.ll_connect_us)
    LinearLayout mLlConnectUs;
    @BindView(R.id.iv_exit)
    ImageView mIvExit;
    @BindView(R.id.tv_total_order)
    TextView mTvTotalOrder;
    @BindView(R.id.tv_un_pay_num)
    TextView mTvUnPayNum;
    @BindView(R.id.ll_person_un_pay)
    LinearLayout mLlPersonUnPay;
    @BindView(R.id.tv_payed_num)
    TextView mTvPayedNum;
    @BindView(R.id.ll_person_payed)
    LinearLayout mLlPersonPayed;
    @BindView(R.id.tv_cancel_num)
    TextView mTvCancelNum;
    @BindView(R.id.ll_person_cancel)
    LinearLayout mLlPersonCancel;
    @BindView(R.id.tv_group_total)
    TextView mTvGroupTotal;
    @BindView(R.id.ll_group_un_pay)
    LinearLayout mLlGroupUnPay;
    @BindView(R.id.ll_group_payed)
    LinearLayout mLlGroupPayed;
    @BindView(R.id.ll_group_cancel)
    LinearLayout mLlGroupCancel;
    @BindView(R.id.ll_business_statistics)
    LinearLayout mLlBusinessStatistics;
    @BindView(R.id.ll_message_center)
    LinearLayout mLlMessageCenter;
    @BindView(R.id.ll_change_pwd)
    LinearLayout mLlChangePwd;
    @BindView(R.id.ll_check_version)
    LinearLayout mLlCheckVersion;
    @BindView(R.id.tv_group_un_pay)
    TextView mTvGroupUnPay;
    @BindView(R.id.tv_group_pay)
    TextView mTvGroupPay;
    @BindView(R.id.tv_group_cancel)
    TextView mTvGroupCancel;
    @BindView(R.id.iv_user_head)
    ImageView mIvUserHead;
    Unbinder unbinder;
    private UserInfo mUserLoginInfo;

    public static MeFragment getInstance() {
        return new MeFragment();
    }

    @Override
    protected boolean lazyLoadMode() {
        return true;
    }

    @Override
    protected void initLazyViewsAndEvents(@Nullable Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        mUserLoginInfo = Utils.getUserLoginInfo();
        setView();
        initData();
    }

    /**
     * 获取订单统计数
     */
    private void initData() {
        PayApiUtils.getOrderTotal(_mActivity, mUserLoginInfo.getDataList().getAppMemberId(), new JsonCallback<OrderNumResponse>(_mActivity) {
            @Override
            public void onSuccess(OrderNumResponse orderNumResponse, Call call, Response response) {
                if (orderNumResponse != null) {
                    setOrderNum(orderNumResponse);
                }
            }
        });
    }

    /**
     * 设置订单统计数
     *
     * @param orderNumResponse 订单统计数据
     */
    private void setOrderNum(OrderNumResponse orderNumResponse) {
        mTvUnPayNum.setText(orderNumResponse.getPersonal_wait());
        mTvPayedNum.setText(orderNumResponse.getPersonal_Pay());
        mTvCancelNum.setText(orderNumResponse.getPersonal_cancel());
        mTvGroupUnPay.setText(orderNumResponse.getGroup_wait());
        mTvGroupPay.setText(orderNumResponse.getGroup_Pay());
        mTvGroupCancel.setText(orderNumResponse.getGroup_cancel());
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
    }

    private void setView() {
        mTvUserName.setText(mUserLoginInfo.getDataList().getAppMemberName());
        mTvUserType.setText(mUserLoginInfo.getDataList().getRoleName());
        mIvUserHead.setImageResource(CheckUtils.equalsString(mUserLoginInfo.getDataList().getAppMemberSex(), "1") ? R.drawable.man : R.drawable.women);
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {
    }


    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_me;
    }

    @OnClick({R.id.ll_connect_us, R.id.iv_exit, R.id.tv_total_order, R.id.ll_person_un_pay, R.id.ll_person_payed, R.id.ll_person_cancel, R.id.tv_group_total,
            R.id.ll_group_un_pay, R.id.ll_group_payed, R.id.ll_group_cancel, R.id.ll_business_statistics, R.id.ll_message_center, R.id.ll_change_pwd,
            R.id.ll_check_version, R.id.iv_user_head})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_connect_us://联系客服
                if (PermissionUtils.requestPermission(this, Manifest.permission.CALL_PHONE, REQUEST_CODE_CALL, "权限申请：\n我们需要您开启拨打电话权限")) {
                    startCall();
                }
                break;
            case R.id.iv_user_head://个人资料
                Utils.startActivity(_mActivity, UserInfoActivity.class);
                break;
            case R.id.iv_exit://退出登录
                Utils.exitLogin(_mActivity);
                break;
            case R.id.tv_total_order://个人业务全部订单
                initData();
                Intent intent = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent.putExtra("pageNum", 0);
                intent.putExtra("sysConfType", 1);
                startActivity(intent);
                break;
            case R.id.ll_person_un_pay://个人业务待支付
                initData();
                Intent intent1 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent1.putExtra("pageNum", 1);
                intent1.putExtra("sysConfType", 1);
                startActivity(intent1);
                break;
            case R.id.ll_person_payed://个人业务已支付
                initData();
                Intent intent2 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent2.putExtra("pageNum", 2);
                intent2.putExtra("sysConfType", 1);
                startActivity(intent2);
                break;
            case R.id.ll_person_cancel://个人业务已取消
                initData();
                Intent intent3 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent3.putExtra("pageNum", 4);
                intent3.putExtra("sysConfType", 1);
                startActivity(intent3);
                break;
            case R.id.tv_group_total://集团业务全部订单
                initData();
                Intent intent4 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent4.putExtra("pageNum", 0);
                intent4.putExtra("sysConfType", 2);
                startActivity(intent4);
                break;
            case R.id.ll_group_un_pay://集团业务待支付
                initData();
                Intent intent5 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent5.putExtra("pageNum", 1);
                intent5.putExtra("sysConfType", 2);
                startActivity(intent5);
                break;
            case R.id.ll_group_payed://集团业务已支付
                initData();
                Intent intent6 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent6.putExtra("pageNum", 2);
                intent6.putExtra("sysConfType", 2);
                startActivity(intent6);
                break;
            case R.id.ll_group_cancel://集团业务已取消
                initData();
                Intent intent7 = new Intent(_mActivity, PersonOrderBusinessActivity.class);
                intent7.putExtra("pageNum", 4);
                intent7.putExtra("sysConfType", 2);
                startActivity(intent7);
                break;
            case R.id.ll_business_statistics://业务办理统计
                Utils.startActivity(_mActivity, BusinessStatisticsActivity.class);
                break;
            case R.id.ll_message_center://消息中心
                Utils.startActivity(_mActivity, MessageActivity.class);
                break;
            case R.id.ll_change_pwd://修改登录密码
                startActivity(new Intent(_mActivity, ChangePwdOrgActivity.class));
                break;
            case R.id.ll_check_version://检查更新
                VersionInfo versionInfo = Utils.getUpdateVersionInfo();
                if (versionInfo != null && versionInfo.isNeedUpdate()) { //有最新版本,需要更新
                    UpdateManager updateManager = new UpdateManager(_mActivity);
                    updateManager.showNoticeDialog();
                } else {
                    XToastUtils.showShortToast("已是最新版本");
                }
                break;
        }
    }

    private void startCall() {
        //用intent启动拨打电话
        //        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:075526546392"));
        //        startActivity(intent);

        //跳转拨号界面
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:075526546392"));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    /**
     * 使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_CALL:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    startCall();
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(_mActivity, permissions[0], "app需要开启拨打电话权限,是否去设置?", "用户拒绝拨打电话授权");
                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.ORDER_CREATER_SUCCESS://订单生成成功
            case EventConstants.ORDER_CANCEL_SUCCESS://订单取消成功
            case EventConstants.ORDER_CANCEL_AUTO_SUCCESS://自动取消订单成功
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
                if (mUserLoginInfo != null) {
                    initData();
                }
                break;
        }
    }
}
