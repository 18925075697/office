package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/6/27.
 */

public class CarTypeResponse implements Serializable {

    /**
     * sysServiceTypeId : 1
     * sysServiceTypeName : 摩托车
     */

    private String sysServiceTypeId;
    private String sysServiceTypeName;

    public String getSysServiceTypeId() {
        return sysServiceTypeId;
    }

    public void setSysServiceTypeId(String sysServiceTypeId) {
        this.sysServiceTypeId = sysServiceTypeId;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }
}
