package com.dgzrdz.mobile.cocobee.view;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.bql.recyclerview.swipe.ResCompat;
import com.dgzrdz.mobile.cocobee.common.ElectricVehicleApp;

/**
 * ClassName: ListLineDecorationHorizontal <br>
 * Description: 横向纵向RecycleView通用分割线<br>
 * Author: Cyarie <br>
 * Created: 2016/10/14 15:58 <br>
 * Update Time：<br>
 * Update Description：<br>
 */
public class ListLineDecorationHorizontal extends RecyclerView.ItemDecoration {

    private final int mOrientation;
    private Drawable mDrawable;

    public ListLineDecorationHorizontal(int drawableId, int orientation) {
        mDrawable = ResCompat.getDrawable(ElectricVehicleApp.getApp(), drawableId);
        mOrientation = orientation;
    }

    @Override
    public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
        super.onDraw(c, parent, state);
        if (mDrawable != null) {
            //需要传入画布和当前recyclerview
            if (mOrientation == LinearLayout.HORIZONTAL) {
                drawHorizontal(c, parent);
            } else {
                drawVertical(c, parent);
            }
        }
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        if (mDrawable != null) {
            //需要传入画布和当前recyclerview
            if (mOrientation == LinearLayout.HORIZONTAL) {
                drawHorizontal(c, parent);
            } else {
                drawVertical(c, parent);
            }
        }
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        //item之间的位移量
        if (mOrientation == LinearLayout.HORIZONTAL) {
            outRect.set(0, 0, mDrawable.getIntrinsicWidth(), 0);
        } else {
            outRect.set(0, 0, 0, mDrawable.getIntrinsicHeight());
        }
    }

    //绘制竖直方向的横线
    private void drawVertical(Canvas c, RecyclerView parent) {
        int left = parent.getPaddingLeft();//横线左右随父容器
        int right = parent.getWidth() - parent.getPaddingRight();
        for (int i = 0; i < parent.getChildCount(); i++) {
            //遍历recyclerview的每个子view
            View child = parent.getChildAt(i);
            //分割线的top,left,right,bottom
            int top = child.getBottom();
            int bottom = child.getBottom() + mDrawable.getIntrinsicHeight();
            mDrawable.setBounds(left, top, right, bottom);//设置分割线的区域
            mDrawable.draw(c);//绘制到画布
        }
    }

    //绘制水平方向的竖线
    private void drawHorizontal(Canvas c, RecyclerView parent) {
        int top = parent.getPaddingTop();//竖线上下随父容器
        int bottom = parent.getBottom();
        for (int i = 0; i < parent.getChildCount(); i++) {
            //遍历recyclerview的每个子view
            View child = parent.getChildAt(i);
            //分割线的top,left,right,bottom
            int left = child.getRight();
            int right = left + mDrawable.getIntrinsicWidth();
            mDrawable.setBounds(left, top, right, bottom);//设置分割线的区域
            mDrawable.draw(c);//绘制到画布
        }
    }

}
