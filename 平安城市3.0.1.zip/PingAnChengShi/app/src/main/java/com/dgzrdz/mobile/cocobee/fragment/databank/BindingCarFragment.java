package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.recyclerview.swipe.SwipeMenu;
import com.bql.recyclerview.swipe.SwipeMenuAdapter;
import com.bql.recyclerview.swipe.SwipeMenuCreator;
import com.bql.recyclerview.swipe.SwipeMenuItem;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectDetailActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectUnArcActivity;
import com.dgzrdz.mobile.cocobee.adapter.BindingCarAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.SwipeRefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.fragment.me.RealNameInfoFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 用户资料
 * Created by admin on 2018/4/25.
 */

public class BindingCarFragment extends SwipeRefreshAndLoadFragment<GuardianObjectResponse> {

    @BindView(R.id.userHeadImg)
    ImageView mUserHeadImg;
    @BindView(R.id.userNameTxt)
    TextView mUserNameTxt;
    @BindView(R.id.tv_user_name)
    TextView mTvUserName;
    @BindView(R.id.telTxt)
    TextView mTelTxt;
    @BindView(R.id.ieTxt)
    TextView mIeTxt;
    @BindView(R.id.ll_car_owner_info)
    LinearLayout mLlCarOwnerInfo;
    private BindingCarAdapter adapter;
    private static UserBeanResponse userBeanResponse;
    private UserInfo mUserLoginInfo;

    public static BindingCarFragment getInstance(UserBeanResponse userBeanResponse) {
        BindingCarFragment.userBeanResponse = userBeanResponse;
        BindingCarFragment fragment = new BindingCarFragment();
        return fragment;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.act_car_owner_binding_car;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        GuardianObjectResponse guardianObjectResponse = mList.get(position);
        Intent intent;
        if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {//未激活
            intent = new Intent(_mActivity, JianHuObjectUnArcActivity.class);
            intent.putExtra("userBean", userBeanResponse);
        } else {
            intent = new Intent(_mActivity, JianHuObjectDetailActivity.class);
        }
        intent.putExtra("guardianObjectResponse", guardianObjectResponse);
        startActivity(intent);
    }

    @Override
    public SwipeMenuAdapter getAdapter() {
        return adapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public SwipeMenuCreator getSwipeMenuCreator() {
        return new SwipeMenuCreator() {
            @Override
            public void onCreateMenu(SwipeMenu swipeLeftMenu, SwipeMenu swipeRightMenu, int i) {
                SwipeMenuItem delItem = new SwipeMenuItem(_mActivity).setBackgroundColor(getResources().getColor(R.color.color_f91c4c))
                        .setText("删除")
                        .setTextColor(Color.WHITE)
                        .setWidth(getResources().getDimensionPixelSize(R.dimen.size70));
                swipeRightMenu.addMenuItem(delItem);
            }
        };
    }

    /**
     * 删除提示框
     *
     * @param adapterPosition
     */
    private void showDelDialog(final int adapterPosition) {
        SweetAlertDialog continueDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.WARNING_TYPE);
        continueDialog.setTitleText("确定删除该车辆吗");
        continueDialog.showCancelButton(true).setCancelText("否");
        continueDialog.setConfirmText("是");
        continueDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();
                //删除
                deleteCar(adapterPosition);
            }
        });

        continueDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();

            }
        });
        continueDialog.show();
    }

    /**
     * 删除对应的车辆
     *
     * @param adapterPosition
     */
    private void deleteCar(int adapterPosition) {
        GuardianObjectResponse guardianObjectResponse = mList.get(adapterPosition);
        HomeApiUtils.deleteObject(_mActivity, guardianObjectResponse.getMemberServiceObjId(), new DialogCallback<Object>(_mActivity, "删除中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("删除成功");
                mList.remove(adapterPosition);
                adapter.notifyItemRemoved(adapterPosition);
                adapter.notifyItemRangeChanged(adapterPosition, mList.size());
                EventBus.getDefault().post(new EventManager(EventConstants.CARINFO_DELETE_SUCCESS));
            }
        });
    }

    @Override
    public void onLeftSwipeMenuClick(int adapterPosition, int menuPosition) {

    }

    @Override
    public void onRightSwipeMenuClick(int adapterPosition, int menuPosition) {
        GuardianObjectResponse guardianObjectResponse = mList.get(adapterPosition);
        if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {
            showDelDialog(adapterPosition);
        } else {
            XToastUtils.showShortToast("只支持未激活对象的删除");
        }
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        if (userBeanResponse == null) {
            return;
        }
        DatasApiUtils.getUnbindCarInfo(_mActivity, userBeanResponse.getMemberId(), mUserLoginInfo.getDataList().getSysAreaId(), new RefreshAndLoadCallback<List<GuardianObjectResponse>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, true);
            }

            @Override
            public void onResultSuccess(List<GuardianObjectResponse> guardianObjectResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshListData(callback, guardianObjectResponses);
            }
        });
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        adapter = new BindingCarAdapter(_mActivity, mList);
        setCarOwner();
    }

    /**
     * 设置车主信息
     */
    private void setCarOwner() {
        if (userBeanResponse == null) {
            return;
        }
        mTvUserName.setText(userBeanResponse.getMemberName());
        mUserNameTxt.setText("性别:" + (CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? "男" : "女"));
        mTelTxt.setText("电话:" + userBeanResponse.getMemberAccount());
        mIeTxt.setText("身份证:" + userBeanResponse.getMemberCardId());
        mUserHeadImg.setImageResource(CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? R.drawable.male_portrait : R.drawable.women);
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithRightText("用户资料", "增加对象");
    }

    @Override
    public void onLoadMore() {

    }

    @OnClick({R.id.ll_car_owner_info})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_car_owner_info:
                start(RealNameInfoFragment.getInstance(userBeanResponse));
                break;
        }
    }

    @Override
    public void btnRightTextClick() {
        Intent intent = new Intent(_mActivity, JianHuObjectActivity.class);
        intent.putExtra("userBean", userBeanResponse);
        startActivity(intent);
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                userBeanResponse = (UserBeanResponse) eventManager.getData();
                setCarOwner();
                break;
            case EventConstants.UPDATE_CAR_INFO_SUCCESS://车辆信息修改成功
            case EventConstants.DELETE_CAR_INFO_SUCCESS://车辆信息删除成功
            case EventConstants.PRE_REGIST_SUCCESS://新增车辆成功
                loadDataList(1, true);
                break;
        }
    }
}
