package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.me.OrderDetailActivity;
import com.dgzrdz.mobile.cocobee.adapter.OrderStatusAdapter;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseViewPagerFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/27
 * Time:  14:09
 */

public class CanceledOrderFragment extends BaseViewPagerFragment<OrderStatusResponse> {
    private static int sysConfType;
    private OrderStatusAdapter mOrderStatusAdapter;
    private String currentTime;
    private UserInfo mUserLoginInfo;

    public static CanceledOrderFragment getInstance(int sysConfType) {
        CanceledOrderFragment.sysConfType = sysConfType;
        CanceledOrderFragment fragment = new CanceledOrderFragment();
        return fragment;
    }

    @Override
    public void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mOrderStatusAdapter = new OrderStatusAdapter(_mActivity, "4", mList);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.view_ptr_load;
    }

    @Override
    protected void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        OrderStatusResponse orderStatusResponse = mList.get(position);
        Intent intent = new Intent(_mActivity, OrderDetailActivity.class);
        intent.putExtra("orderStatusResponse", orderStatusResponse);
        startActivity(intent);
    }

    @Override
    protected void onRefresh() {
        initData(1, true);
    }

    @Override
    protected RecyclerView.Adapter getAdapter() {
        return mOrderStatusAdapter;
    }

    @Override
    protected void initData(int curPage, boolean isPullToRefresh) {
        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }
        PayApiUtils.getOrderInfo(_mActivity, "3", sysConfType + "", mUserLoginInfo.getDataList().getAppMemberId(), "", currentTime, pageSize + "", new RefreshAndLoadCallback<List<OrderStatusResponse>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                initData(1, false);
            }

            @Override
            public void onResultSuccess(List<OrderStatusResponse> orderStatusResponses, @Nullable Response response, LoadingViewCallback callback) {
                if (orderStatusResponses != null && orderStatusResponses.size() >= pageSize) {
                    if (mCurPage == 1) {//第一页,存最后一条数据的时间
                        currentTime = orderStatusResponses.get(orderStatusResponses.size() - 1).getMemberOrderAddTime();
                    }
                }
                handleRefreshAndLoadListData(mCurPage, callback, orderStatusResponses);
            }

            @Override
            public Drawable emptyDrawable() {
                return _mActivity.getResources().getDrawable(R.drawable.norecord);
            }

            @Override
            public String emptyContent() {
                return "暂无记录";
            }
        });
    }

    @Override
    public void onLoadMore() {
        initData(mCurPage, true);
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.ORDER_CANCEL_SUCCESS://订单取消成功
            case EventConstants.ORDER_CANCEL_AUTO_SUCCESS://自动取消订单成功
            case EventConstants.PHONE_CHANGE_SUCCESS://手机号修改成功
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                if (mUserLoginInfo != null) {
                    initData(1, true);
                }
                break;
        }
    }
}