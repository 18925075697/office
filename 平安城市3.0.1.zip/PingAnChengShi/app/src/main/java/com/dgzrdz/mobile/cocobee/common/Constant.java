package com.dgzrdz.mobile.cocobee.common;

public class Constant {

    public static final int REQUEST_BLUETOOTH_ENABLE = 0;
    public static final int REQUEST_BLUETOOTH_CONNECT = 1;
    // Message types sent from the BluetoothHelper Handler
    public static final int MESSAGE_STATE_CHANGE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    // Constants that indicate the current connection state

    public static final int STATE_CONNECTE_ERROR = 9;  // now connected error to a remote device
    public static final int STATE_CONNECTE_LOST = 10;  // now connected lost a remote device

    /*图片压缩大小限制*/
    public final static long PIC_SIZE_LIMIT = 1024 * 100; //500KB

    /*地图所需参数*/
    public final static String LONGITUDE = "longitude";
    public final static String LATITUDE = "latitude";
    public final static String RADIUS = "radius";
    public final static String DIRECTION = "direction";

    public final static int SDCD = 1111;
    public final static int AZTS = 2222;
    public final static int DWGL = 3333;
    public final static int BMFW = 4444;
    public final static int AFTER_UPLOAD_DEVICE_INFO_SUCCESS = 1383;
    public final static int AFTER_CHOOSE_LOOK_DEVICE_INFO = 1384;


    /*BLE指令类型*/
    public static final int BLE_DO_NONE = 7100;
    public static final int BLE_READ_DEVICE_INFO = 7101;
    public static final int BLE_READ_IMEI = 7102;
    public static final int BLE_READ_FACTORY_NUM = 7103;
    public static final int BLE_READ_GPRS_NUM = 7104;
    public static final int BLE_READ_SYS_TIME = 7105;
    public static final int BLE_SET_SYS_TIME = 7106;
    public static final int BLE_SET_PARAMS = 7107;
    public static final int BLE_DEBUG_TX = 7108;
    public static final int BLE_STOP_DEBUG_TX = 7109;
    public static final int BLE_READ_TX_INFO = 7110;
    public static final int OPEN_TAG_DATA_OUTPUT = 7111;
    public static final int BLE_SCAN_TAG = 7112;
    public static final int BLE_FILTER_TAG = 7113;
    public static final int BLE_FILTER_TAG_NUM = 7114;
    public static final int BLE_CLOSE_TAG_DATA_OUTPUT = 7115;
    public static final int BLE_READ_GPRS_CONNECT_STATE = 7116;
    public static final int BLE_READ_LAN_CONNECT_STATE = 7117;
    public static final int BLE_READ_CACHE_TAG_NUM = 7118;
    public static final int BLE_SEND_CARRIER_TEST = 7119;//发送载波测试指令
    public static final int BLE_LOOK_DEVICE_POWER = 7121;//查看设备电量
    public static final int BLE_UPGRADE_START = 7122;//发送升级开始
    public static final int BLE_UPGRADE_CONTENT = 7123;//发送升级内容
    public static final int BLE_UPGRADE_FINISH = 7124;//发送升级结束
    public static final int BLE_GET_UPGRADE_CONTENT = 7125;//获得升级内容发送完成返回
    public static final int BLE_GET_UPGRADE_NO = 7126;//升级结束,结束结束数据
    public static final int BLE_CHECK_PWD = 7127;//验证蓝牙密码


    /*共享文件及其参数*/
    public final static String SP_CONNECT_STATUS = "bluetooth";
    public final static String CONNECT_STATUS = "status";

    /**
     * 条形码： REQUEST_SCAN_MODE_BARCODE_MODE
     */
    public static final int REQUEST_SCAN_MODE_BARCODE_MODE = 0X100;

    public static final int BLE_OPEN_RF = 7120;
    public static final int GET_DATA = 7130;
    public static final int BLE_CLOSE_RF = 7140;
    public static final int BLE_SET_MODE_ONE = 7150;
    public static final int BLE_SET_MODE_TWO = 7160;
    public static final int BLE_CLOSE_DEVICE = 7170;

    //设置测试模式
    public static final int BLE_SET_TEST_MODE = 7210;
    public static final int BLE_GET_TEST_RESULT = 7220;
    public static final int BLE_SET_NORMAL_MODE = 7230;

    /*语言环境参数*/
    public final static int LANGUAGE_SIMPLE_CHINESE = 1; //简体中文
    public final static int LANGUAGE_ENGLISH = 2; //英文

}
