package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.response.BaoxianUploadResponse;
import com.dgzrdz.mobile.cocobee.response.TaocanUploadResponse;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  支付
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class PayApiUtils {
    /**
     * 生成未支付订单
     *
     * @param context
     * @param sysConfType                类型，1 个人业务，2集团业务
     * @param sysServiceTypeId           服务对象类型，电动车，人，单车
     * @param memberServiceObjId         服务对象id
     * @param memberServiceObjActiveFlag 服务对象状态，对象激活标志 1 未激活 2 锁定中 3 已激活、有效中 4 已过期 5 删除了
     * @param appMemberId                app管理员id
     * @param sysAreaId                  机构id
     * @param memberOrderTotalPay        总金额
     * @param porpertyJSON               保险json，"sysInsuranceConfPriceId": 1, //价格id "sysInsuranceId": 5,
     *                                   //保险公司id "sysInsuranceTypeId": 5,//保险类型id "sysInsuranceTypeName":"三责险",//保险名称 "realid":1 //所选年限ID
     * @param exvalueJSON                额外输入的值json ，如果是保险补办，这个json值置为空字符串，"sysServiceSetPropId":1,//套餐属性配置id "sysServiceSetPropOptionId":2,
     *                                   //属性规格值id "sysServiceSetPropExValueStr":2,//扩展输入 "realid":1 //所选年限
     * @param hLabelNo                   标签号
     * @param hPlateNo                   车牌号（仅为车牌号码，不包括前缀和代码）
     * @param hPlateAll                  车牌号（包括前缀和代码）
     * @param insType                    是否保险补办 1是 0否
     * @param sysInstallPlaceId          app管理员安装点id
     * @param callback                   回调
     */
    public static void creatOrder(Context context, String sysConfType, String sysServiceTypeId, String memberServiceObjId, String memberServiceObjActiveFlag,
                                  String appMemberId, String sysAreaId, String memberOrderTotalPay, List<BaoxianUploadResponse> porpertyJSON,
                                  List<TaocanUploadResponse> exvalueJSON, String hLabelNo, String hPlateNo, String hPlateAll, String insType, String sysInstallPlaceId,
                                  AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysConfType", sysConfType);
        params.put("sysServiceTypeId", sysServiceTypeId);
        params.put("memberServiceObjId", memberServiceObjId);
        params.put("memberServiceObjActiveFlag", memberServiceObjActiveFlag);
        params.put("appMemberId", appMemberId);
        params.put("sysAreaId", sysAreaId);
        params.put("memberOrderTotalPay", memberOrderTotalPay);
        params.put("hLabelNo", hLabelNo);
        params.put("hPlateNo", hPlateNo);
        params.put("hPlateAll", hPlateAll);
        params.put("insType", insType);
        params.put("sysInstallPlaceId", sysInstallPlaceId);

        Gson gson = new Gson();
        if (porpertyJSON != null) {
            String s = gson.toJson(porpertyJSON);
            params.put("porpertyJSON", s);
        }

        if (exvalueJSON != null) {
            String s1 = gson.toJson(exvalueJSON);
            params.put("exvalueJSON", s1);
        }

        OkGo.post(Path.CREATE_UNPAYED_ORDER).tag(context).params(params).execute(callback);
    }

    /**
     * 验证是否支付成功
     *
     * @param context
     * @param memberOrderId 订单id
     * @param memberOrderNo 订单号
     * @param paymethodId
     * @param callback      回调
     */
    public static void checkPayStatus(Context context, String memberOrderId, String memberOrderNo, String paymethodId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderId", memberOrderId);
        params.put("memberOrderNo", memberOrderNo);
        params.put("paymethodId", paymethodId);
        OkGo.post(Path.CHECK_PAY_OK).tag(context).params(params).execute(callback);
    }

    /**
     * 0元支付,通知服务器支付成功
     *
     * @param context
     * @param memberOrderNo 订单号
     * @param callback      回调
     */
    public static void notifyPaySuccess(Context context, String memberOrderNo, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderNo", memberOrderNo);
        OkGo.get(Path.NOTIFY_PAY_SUCCESS).tag(context).params(params).execute(callback);
    }

    /**
     * 用户取消订单
     *
     * @param context
     * @param memberOrderType    订单类型，\n1 服务+保险\n2 服务\n3 保险'
     * @param memberOrderId      订单号
     * @param memberServiceObjId 对象id
     * @param callback           回调
     */
    public static void userCancelOrder(Context context, String memberOrderType, String memberOrderId, String memberServiceObjId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderType", memberOrderType);
        params.put("memberOrderId", memberOrderId);
        params.put("memberServiceObjId", memberServiceObjId);
        OkGo.get(Path.USER_CANCEL_ORDER).tag(context).params(params).execute(callback);
    }

    /**
     * 获取选择支付页面数据
     *
     * @param context
     * @param memberOrderId 订单号
     * @param appMemberId   订单号
     * @param callback      回调
     */
    public static void getSelectPay(Context context, String memberOrderId, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderId", memberOrderId);
        params.put("appMemberId", appMemberId);
        OkGo.get(Path.GET_SELECT_PAY).tag(context).params(params).execute(callback);
    }

    /**
     * 获取服务套餐
     *
     * @param context
     * @param appMemberId      管理员id
     * @param memberId         车主id
     * @param sysServiceTypeId 监护对象类型
     * @param sysAreaId        组织机构id
     * @param sysGroupId       集团单位id
     * @param callback         回调
     */
    public static void getService(Context context, String appMemberId, String memberId, String sysServiceTypeId, String sysAreaId, String sysGroupId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        params.put("memberId", memberId);
        params.put("sysServiceTypeId", sysServiceTypeId);
        params.put("sysAreaId", sysAreaId);
        if (!CheckUtils.isEmpty(sysGroupId)) {
            params.put("sysGroupId", sysGroupId);
        }
        OkGo.get(Path.GET_SERVICE_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 获取保险套餐
     *
     * @param context
     * @param sysServiceTypeId 监护对象类型
     * @param sysAreaId        组织机构id
     * @param sysGroupId       集团单位id
     * @param callback         回调
     */
    public static void getPolicy(Context context, String sysServiceTypeId, String sysAreaId, String sysGroupId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysServiceTypeId", sysServiceTypeId);
        params.put("sysAreaId", sysAreaId);
        if (!CheckUtils.isEmpty(sysGroupId)) {
            params.put("sysGroupId", sysGroupId);
        }
        OkGo.get(Path.GET_POLICY_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 查询订单信息
     *
     * @param context
     * @param memberOrderProcess 订单状态 1待付款 2 已付款 3 已取消 4 已过期
     * @param sysConfType        /类型，1 个人业务，2集团业务
     * @param appMemberId        管理员id
     * @param value              查询条件
     * @param time               时间
     * @param pageSize           每页条数
     * @param callback           回调
     */
    public static void getOrderInfo(Context context, String memberOrderProcess, String sysConfType, String appMemberId, String value, String time, String pageSize, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderProcess", memberOrderProcess);
        if (!CheckUtils.isEmpty(sysConfType)) {
            params.put("sysConfType", sysConfType);
        }
        params.put("appMemberId", appMemberId);
        params.put("value", value);
        params.put("time", time);
        params.put("pageSize", pageSize);
        OkGo.post(Path.GET_ORDER_LIST_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 获取订单详情信息
     *
     * @param context
     * @param memberOrderId 对象id
     * @param callback      回调
     */
    public static void getOrderDetailInfo(Context context, String memberOrderId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderId", memberOrderId);
        OkGo.post(Path.GET_ORDER_DETAIL_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 套餐修改手机号码
     *
     * @param context
     * @param sysServiceSetPropValueId  套餐属性规格填写值ID
     * @param sysServiceSetPropValueStr 手机号
     * @param sysInsuranceActiveTime    激活时间
     * @param callback                  回调
     */
    public static void changePhone(Context context, String sysServiceSetPropValueId, String sysServiceSetPropValueStr, String sysInsuranceActiveTime, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysServiceSetPropValueId", sysServiceSetPropValueId);
        params.put("sysServiceSetPropValueStr", sysServiceSetPropValueStr);
        params.put("sysInsuranceActiveTime", sysInsuranceActiveTime);
        OkGo.post(Path.CHANGE_TAOCAN_PHONE).tag(context).params(params).execute(callback);
    }

    /**
     * 保险修改手机号码
     *
     * @param context
     * @param sysInsuranceValueId    保险套餐规格填写值ID
     * @param sysInsuranceExValueStr 值
     * @param sysInsuranceActiveTime 激活时间
     * @param callback               回调
     */
    public static void policyChangePhone(Context context, String sysInsuranceValueId, String sysInsuranceExValueStr, String sysInsuranceActiveTime, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysInsuranceValueId", sysInsuranceValueId);
        params.put("sysInsuranceExValueStr", sysInsuranceExValueStr);
        params.put("sysInsuranceActiveTime", sysInsuranceActiveTime);
        OkGo.post(Path.CHANGE_POLICY_PHONE).tag(context).params(params).execute(callback);
    }

    /**
     * 获取订单统计数
     *
     * @param context
     * @param appMemberId 登录人id
     * @param callback    回调
     */
    public static void getOrderTotal(Context context, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        OkGo.post(Path.GET_ORDER_TOTAL_NUM).tag(context).params(params).execute(callback);
    }

    /**
     * 获取口令短信
     *
     * @param context
     * @param appMemberAccount 手机号码
     * @param appMemberId      管理员id
     * @param memberOrderId    管理员id
     * @param callback         回调
     */
    public static void getKouLinMsg(Context context, String appMemberAccount, String appMemberId, String memberOrderId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberAccount", appMemberAccount);
        params.put("appMemberId", appMemberId);
        params.put("memberOrderId", memberOrderId);
        OkGo.post(Path.GET_KOULIN_MSG).tag(context).params(params).execute(callback);
    }

    /**
     * 口令码验证
     *
     * @param context
     * @param appPasswordPayCodeStr 口令码
     * @param memberOrderId         订单id
     * @param appMemberId           管理员id
     * @param callback              回调
     */
    public static void checkKouLinCode(Context context, String appPasswordPayCodeStr, String memberOrderId, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appPasswordPayCodeStr", appPasswordPayCodeStr);
        params.put("memberOrderId", memberOrderId);
        params.put("appMemberId", appMemberId);
        OkGo.post(Path.CHECK_KOULIN_CODE).tag(context).params(params).execute(callback);
    }

    /**
     * 立即支付
     *
     * @param context
     * @param memberOrderNo 订单号
     * @param paymethodId   支付方式
     * @param payclass
     * @param memberAccount 用户手机号[非app用户, 指电动车的主人]
     * @param hLabelNo      标签号
     * @param hPlateNo      车牌号
     * @param callback      回调
     */
    public static void payNow(Context context, String memberOrderNo, String paymethodId, String payclass, String memberAccount, String hLabelNo, String hPlateNo, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberOrderNo", memberOrderNo);
        params.put("paymethodId", paymethodId);
        params.put("payclass", payclass);
        params.put("memberAccount", memberAccount);
        params.put("hLabelNo", hLabelNo);
        params.put("hPlateNo", hPlateNo);
        OkGo.get(Path.PAY_NOW_PATH).tag(context).params(params).execute(callback);
    }

}
