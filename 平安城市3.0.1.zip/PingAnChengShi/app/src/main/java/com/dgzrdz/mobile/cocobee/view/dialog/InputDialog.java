package com.dgzrdz.mobile.cocobee.view.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.SelectPayResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 免密支付输入口令弹窗
 * Created: 2016/11/29 19:54
 */
public class InputDialog extends DialogFragment {
    @BindView(R.id.pc_1)
    PhoneCode mPc1;
    @BindView(R.id.tv_confirm)
    TextView mTvConfirm;
    @BindView(R.id.tv_phone_pre)
    TextView mTvPhonePre;
    @BindView(R.id.tv_phone_last)
    TextView mTvPhoneLast;
    @BindView(R.id.tv_check_result_notice)
    TextView mTvCheckResultNotice;
    private Unbinder mBind;
    private SelectPayResponse selectPayResponse;
    private UserInfo mUserLoginInfo;

    public void setOrderInfoResponse(SelectPayResponse selectPayResponse) {
        this.selectPayResponse = selectPayResponse;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.MyDialog);
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = Utils.getScreenWidth();
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.windowAnimations = R.style.DialogAnimation;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_input_pwd, container);
        mBind = ButterKnife.bind(this, view);
        mUserLoginInfo = Utils.getUserLoginInfo();
        initView();
        return view;
    }

    private void initView() {
        mPc1.showSoftInput();
        String appMemberAccount = mUserLoginInfo.getDataList().getAppMemberAccount();
        String pre = appMemberAccount.substring(0, 3);
        String last = appMemberAccount.substring(7, 11);
        mTvPhonePre.setText(pre);
        mTvPhoneLast.setText(last);
        mPc1.setOnFinishListener(new PhoneCode.OnFinishListener() {
            @Override
            public void onFinish() {
                mTvCheckResultNotice.setVisibility(View.GONE);
                String phoneCode = mPc1.getPhoneCode();
                String phone = pre + phoneCode + last;
                sendMsg(phone);
            }
        });
    }

    /**
     * 发送短信验证码
     *
     * @param phone
     */
    private void sendMsg(String phone) {
        PayApiUtils.getKouLinMsg(getContext(), phone, mUserLoginInfo.getDataList().getAppMemberId(),selectPayResponse.getMemberOrderId() ,new DialogCallback<Object>(getContext(), "验证身份...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                showInputDialog();
                dismiss();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                mTvCheckResultNotice.setVisibility(View.VISIBLE);
            }
        });
    }

    /**
     * 显示输入口令dialog
     */
    private void showInputDialog() {
        InputCheckCodeDialog dialog = new InputCheckCodeDialog();
        dialog.setOrderInfoResponse(selectPayResponse);
        dialog.show(getFragmentManager(), "freeCodePwd");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mBind.unbind();
    }

    @OnClick({R.id.tv_confirm})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_confirm://取消
                dismiss();
                break;
        }
    }

}
