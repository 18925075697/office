package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/30
 * Time:  15:47
 */

public class BaoxianUploadResponse implements Serializable {

    /**
     * sysInsuranceConfPriceId : 1
     * sysInsuranceId : 5
     * sysInsuranceTypeId : 5
     * sysInsuranceTypeName : 三责险
     * sysInsuranceConfYears : 1年
     */

    private String sysInsuranceConfPriceId;//价格id
    private String sysInsuranceId;//保险公司id
    private String sysInsuranceTypeId;//保险类型id
    private String sysInsuranceTypeName;//保险名称
    private String sysInsuranceConfYears;//所选年限ID
    private String sysInsuranceExValueStr;//保险额外值
    private String sysInsurancePrice;//保险价格

    public String getSysInsurancePrice() {
        return sysInsurancePrice;
    }

    public void setSysInsurancePrice(String sysInsurancePrice) {
        this.sysInsurancePrice = sysInsurancePrice;
    }

    public String getSysInsuranceExValueStr() {
        return sysInsuranceExValueStr;
    }

    public void setSysInsuranceExValueStr(String sysInsuranceExValueStr) {
        this.sysInsuranceExValueStr = sysInsuranceExValueStr;
    }

    public String getSysInsuranceConfPriceId() {
        return sysInsuranceConfPriceId;
    }

    public void setSysInsuranceConfPriceId(String sysInsuranceConfPriceId) {
        this.sysInsuranceConfPriceId = sysInsuranceConfPriceId;
    }

    public String getSysInsuranceId() {
        return sysInsuranceId;
    }

    public void setSysInsuranceId(String sysInsuranceId) {
        this.sysInsuranceId = sysInsuranceId;
    }

    public String getSysInsuranceTypeId() {
        return sysInsuranceTypeId;
    }

    public void setSysInsuranceTypeId(String sysInsuranceTypeId) {
        this.sysInsuranceTypeId = sysInsuranceTypeId;
    }

    public String getSysInsuranceTypeName() {
        return sysInsuranceTypeName;
    }

    public void setSysInsuranceTypeName(String sysInsuranceTypeName) {
        this.sysInsuranceTypeName = sysInsuranceTypeName;
    }

    public String getSysInsuranceConfYears() {
        return sysInsuranceConfYears;
    }

    public void setSysInsuranceConfYears(String sysInsuranceConfYears) {
        this.sysInsuranceConfYears = sysInsuranceConfYears;
    }
}
