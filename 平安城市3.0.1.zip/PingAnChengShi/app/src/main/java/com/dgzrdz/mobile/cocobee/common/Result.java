package com.dgzrdz.mobile.cocobee.common;

import com.dgzrdz.mobile.cocobee.model.Equipment;

import java.io.Serializable;

public class Result implements Serializable{

	/**
	 * code : 400
	 * msg : 基站不存在
	 */

	private int code;
	private String msg;
	private Equipment result;

	public Equipment getResult() {
		return result;
	}

	public void setResult(Equipment result) {
		this.result = result;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
