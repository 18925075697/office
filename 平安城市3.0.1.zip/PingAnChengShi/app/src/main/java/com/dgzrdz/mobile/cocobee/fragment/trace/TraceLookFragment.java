package com.dgzrdz.mobile.cocobee.fragment.trace;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.roundview.RoundTextView;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.map.LocationTraceActivity;
import com.dgzrdz.mobile.cocobee.activity.map.TraceActivity;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.StringDialogCallback;
import com.dgzrdz.mobile.cocobee.common.LocationJson;
import com.dgzrdz.mobile.cocobee.common.TraceDataHolder;
import com.dgzrdz.mobile.cocobee.common.TraceJson;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jzxiang.pickerview.TimePickerDialog;
import com.jzxiang.pickerview.data.Type;
import com.jzxiang.pickerview.listener.OnDateSetListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Description: 轨迹查询fragment
 * Author: Liubingren
 * Data:  2018/10/29
 * Time:  15:15
 */

public class TraceLookFragment extends BaseFragment implements OnDateSetListener {
    @BindView(R.id.tv_toolbar_title)
    RoundTextView mTvToolbarTitle;
    @BindView(R.id.tv_trace)
    TextView mTvTrace;
    @BindView(R.id.tv_location)
    TextView mTvLocation;
    @BindView(R.id.et_tag_num)
    EditText mEtTagNum;
    @BindView(R.id.tv_search)
    TextView mTvSearch;
    @BindView(R.id.tv_start_time)
    TextView mTvStartTime;
    @BindView(R.id.ll_start_time)
    LinearLayout mLlStartTime;
    @BindView(R.id.tv_end_time)
    TextView mTvEndTime;
    @BindView(R.id.ll_end_time)
    LinearLayout mLlEndTime;
    @BindView(R.id.tv_clear)
    TextView mTvClear;
    @BindView(R.id.iv_clear)
    ImageView mIvClear;

    private TimePickerDialog mDialogAll;
    private TimePickerDialog.Builder timePickerBuilder;
    long tenYears = 10L * 365 * 1000 * 60 * 60 * 24L;
    long threeDays = 3 * 24 * 60 * 60 * 1000;
    private int timeDialogFlag = 0;

    private long startMill;
    private long endMill;

    private int selectType; //0查轨迹  1查位置

    public static TraceLookFragment getInstance() {
        return new TraceLookFragment();
    }

    @Override
    protected boolean lazyLoadMode() {
        return true;
    }

    @Override
    protected void initLazyViewsAndEvents(@Nullable Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        initTimePick();
        mTvToolbarTitle.setCompoundDrawables(null, null, null, null);
        initListener();
    }

    private void initListener() {
        mEtTagNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (CheckUtils.isEmpty(s.toString())) {
                    mIvClear.setVisibility(View.GONE);
                } else {
                    mIvClear.setVisibility(View.VISIBLE);
                }

            }
        });
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
    }

    private void initTimePick() {
        timePickerBuilder = new TimePickerDialog.Builder()
                .setCallBack(this)
                .setCancelStringId("取消")
                .setSureStringId("确定")
                .setTitleStringId("请选择时间")
                .setYearText("年")
                .setMonthText("月")
                .setDayText("日")
                .setHourText("时")
                .setMinuteText("分")
                .setCyclic(false)
                .setMinMillseconds(System.currentTimeMillis() - 3 * tenYears)
                .setMaxMillseconds(System.currentTimeMillis())
                .setThemeColor(getResources().getColor(R.color.timepicker_dialog_bg))
                .setType(Type.ALL)
                .setWheelItemTextNormalColor(getResources().getColor(R.color.timetimepicker_default_text_color))
                .setWheelItemTextSelectorColor(getResources().getColor(R.color.timepicker_toolbar_bg))
                .setWheelItemTextSize(12);

        mDialogAll = timePickerBuilder.build();
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("轨迹查询");
    }

    @Override
    public boolean inVisibleLeftDrawable() {
        return true;
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_trace_look;
    }

    @OnClick({R.id.tv_trace, R.id.tv_location, R.id.tv_search, R.id.tv_start_time, R.id.tv_end_time, R.id.tv_clear, R.id.iv_clear})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_trace://查轨迹
                selectType = 0;
                setView(mTvTrace, mTvLocation);
                mLlStartTime.setVisibility(View.VISIBLE);
                mLlEndTime.setVisibility(View.VISIBLE);
                mTvClear.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_location://查位置
                selectType = 1;
                setView(mTvLocation, mTvTrace);
                mLlStartTime.setVisibility(View.GONE);
                mLlEndTime.setVisibility(View.GONE);
                mTvClear.setVisibility(View.GONE);
                break;
            case R.id.tv_start_time://开始时间
                if (endMill != 0) {
                    timePickerBuilder.setMinMillseconds(endMill - threeDays);
                    timePickerBuilder.setMaxMillseconds(endMill);
                } else {
                    timePickerBuilder.setCurrentMillseconds(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
                    timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                    timePickerBuilder.setMinMillseconds(System.currentTimeMillis() - 3 * tenYears);
                }

                if (!mDialogAll.isAdded()) { //判断是否已经添加，避免因重复添加导致异常
                    mDialogAll.show(getFragmentManager(), "all");
                }

                timeDialogFlag = 1;
                break;
            case R.id.tv_end_time://结束时间
                if (startMill != 0) {
                    timePickerBuilder.setMinMillseconds(startMill);
                    if (System.currentTimeMillis() < (startMill + threeDays)) {
                        timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                    } else {
                        timePickerBuilder.setMaxMillseconds(startMill + threeDays);
                    }
                } else {
                    timePickerBuilder.setCurrentMillseconds(System.currentTimeMillis());
                    timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                    timePickerBuilder.setMinMillseconds(System.currentTimeMillis() - 3 * tenYears);
                }

                if (!mDialogAll.isAdded()) {
                    mDialogAll.show(getFragmentManager(), "all");
                }

                timeDialogFlag = 2;
                break;
            case R.id.tv_search://查询
                String tag = mEtTagNum.getText().toString().trim();
                String startTime = mTvStartTime.getText().toString().trim();
                String endTime = mTvEndTime.getText().toString().trim();
                if (CheckUtils.isEmpty(tag)) {
                    XToastUtils.showShortToast("请输入标签号");
                } else if (selectType == 0 && CheckUtils.isEmpty(startTime)) {
                    XToastUtils.showShortToast("请选择开始时间");
                } else if (selectType == 0 && CheckUtils.isEmpty(endTime)) {
                    XToastUtils.showShortToast("请选择结束时间");
                } else {
                    toSearch(tag, startTime, endTime);
                }
                break;
            case R.id.tv_clear://清除
                mTvStartTime.setText("");
                mTvEndTime.setText("");
                startMill = 0;
                endMill = 0;
                break;
            case R.id.iv_clear:
                mEtTagNum.setText("");
                break;
        }
    }

    /**
     * 去查询
     *
     * @param tag       标签号
     * @param startTime 开始时间
     * @param endTime   结束时间
     */
    private void toSearch(String tag, String startTime, String endTime) {
        if (selectType == 0) {//查轨迹
            getTrace(tag, startTime, endTime);
        } else {//查位置
            getLocation(tag);
        }
    }

    /**
     * 获取位置
     *
     * @param tag 标签号
     */
    private void getLocation(String tag) {
        ManagerApiUtils.getLabelLastPosition(_mActivity, tag, new StringDialogCallback(_mActivity, "获取车辆最后位置...") {
            @Override
            public void onSuccess(String s, Call call, Response response) {
                if (!TextUtils.isEmpty(s)) {
                    LocationJson locationJson = new Gson().fromJson(s, new TypeToken<LocationJson>() {
                    }.getType());
                    if (locationJson != null && locationJson.getDm_error() == 0) { //请求成功
                        LocationJson.DataBean data = locationJson.getData();
                        if (data != null) {
                            if (CheckUtils.isEmpty(data.getEqlat()) || CheckUtils.isEmpty(data.getEqLng())) {//经纬度为空
                                XToastUtils.showShortToast("经纬度为空,无法跳转");
                            } else {
                                toLocation(data);
                            }
                        } else {
                            XToastUtils.showShortToast("暂无轨迹数据");
                        }
                    } else if (locationJson != null) {
                        XToastUtils.showShortToast(locationJson.getError_msg());
                    } else {
                        XToastUtils.showShortToast("暂无数据");
                    }
                } else {
                    XToastUtils.showShortToast("暂无数据");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                XToastUtils.showShortToast("网络错误");
            }
        });
    }

    /**
     * 获取轨迹
     *
     * @param tag       标签号
     * @param startTime 开始时间
     * @param endTime   结束时间
     */
    private void getTrace(String tag, String startTime, String endTime) {
        ManagerApiUtils.getLabelTrace(_mActivity, tag, startTime, endTime, new StringDialogCallback(_mActivity, "获取轨迹...") {
            @Override
            public void onSuccess(String s, Call call, Response response) {
                if (!TextUtils.isEmpty(s)) {
                    TraceJson traceJson = new Gson().fromJson(s, new TypeToken<TraceJson>() {
                    }.getType());
                    if (traceJson != null && traceJson.getDm_error() == 0) { //请求成功
                        TraceJson.DataBean data = traceJson.getData();
                        if (data != null) {
                            List<TraceJson.DataBean.LocusBean> locus = data.getLocus();
                            if (locus != null && locus.size() > 0) {
                                toTrace(locus);
                            } else {
                                XToastUtils.showShortToast("暂无轨迹数据");
                            }
                        } else {
                            XToastUtils.showShortToast("暂无轨迹数据");
                        }
                    } else if (traceJson != null) {
                        XToastUtils.showShortToast(traceJson.getError_msg());
                    } else {
                        XToastUtils.showShortToast("暂无数据");
                    }
                } else {
                    XToastUtils.showShortToast("暂无数据");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                XToastUtils.showShortToast("网络错误");
            }
        });
    }

    /**
     * 跳转位置
     *
     * @param positionResponse 位置数据
     */
    private void toLocation(LocationJson.DataBean positionResponse) {
        Intent intent = new Intent(_mActivity, LocationTraceActivity.class);
        intent.putExtra("positionResponse", positionResponse);
        startActivity(intent);
    }

    /**
     * 跳转轨迹
     *
     * @param traceResponses 轨迹数据
     */
    private void toTrace(List<TraceJson.DataBean.LocusBean> traceResponses) {

        List<TraceJson.DataBean.LocusBean> userfulLocations = new ArrayList<>();
        if (traceResponses != null && traceResponses.size() > 0) {
            //过滤掉空的经纬度
            for (int i = 0; i < traceResponses.size(); i++) {
                TraceJson.DataBean.LocusBean traceResponse = traceResponses.get(i);
                if (!TextUtils.isEmpty(traceResponse.getEqLat()) && !TextUtils.isEmpty(traceResponse.getEqlng())) {
                    userfulLocations.add(traceResponse);
                }
            }

            //过滤掉重复的经纬度
            for (int i = 0; i < userfulLocations.size(); i++) {
                if (i != 0) {
                    TraceJson.DataBean.LocusBean locusBean = userfulLocations.get(i);
                    TraceJson.DataBean.LocusBean locusBean1 = userfulLocations.get(i - 1);
                    if (CheckUtils.equalsString(locusBean.getEqLat(), locusBean1.getEqLat()) && CheckUtils.equalsString(locusBean.getEqlng(), locusBean1.getEqlng())) {//与前一个经纬度相同
                        userfulLocations.remove(i);
                        i--;
                    }
                }
            }
        }
        Intent intent = new Intent(_mActivity, TraceActivity.class);
        TraceDataHolder.getInstance().setData(userfulLocations);
        startActivity(intent);
    }

    private void setView(TextView tvTrace, TextView tvLocation) {
        tvTrace.setTextColor(_mActivity.getResources().getColor(R.color.white));
        tvTrace.setBackgroundColor(_mActivity.getResources().getColor(R.color.color_008cff));
        tvLocation.setTextColor(_mActivity.getResources().getColor(R.color.color_666666));
        tvLocation.setBackgroundColor(_mActivity.getResources().getColor(R.color.white));
    }

    @Override
    public void onDateSet(TimePickerDialog timePickerView, long millseconds) {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis < millseconds) {
            XToastUtils.showShortToast("选择的时间超出当前时间,请重新选择");
            return;
        }
        switch (timeDialogFlag) {
            case 1:
                mTvStartTime.setText(DateUtils.getDateToString(millseconds, DateUtils.DATE_TIME_FORMAT_S));
                startMill = millseconds;
                break;
            case 2:
                if (startMill != 0 && millseconds - startMill > threeDays) {//已选开始时间,且超出3天
                    XToastUtils.showShortToast("选择的时间超出查询范围,请重新选择");
                    return;
                }
                mTvEndTime.setText(DateUtils.getDateToString(millseconds, DateUtils.DATE_TIME_FORMAT_S));
                endMill = millseconds;
                break;
        }
    }
}
