package com.dgzrdz.mobile.cocobee.activity.data;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.kernal.passportreader.sdk.CardsCameraActivity;
import com.kernal.passportreader.sdk.utils.DefaultPicSavePath;
import com.kernal.passportreader.sdk.utils.ManageIDCardRecogResult;

import org.greenrobot.eventbus.EventBus;

import kernal.idcard.android.ResultMessage;
import kernal.idcard.camera.CardOcrRecogConfigure;
import kernal.idcard.camera.SharedPreferencesHelper;

/**
 * ocr识别中间类
 * Created by Administrator on 2018/8/21.
 */

public class CameraMiddleActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return 0;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        CardOcrRecogConfigure.getInstance()
                .initLanguage(getApplicationContext())
                .setSaveCut(true)
                .setnMainId(2)
                .setnSubID( 0)
                .setFlag(0)
                .setnCropType(0)
                .setSavePath(new DefaultPicSavePath());
        Intent intent=new Intent(this,CardsCameraActivity.class);
        startActivityForResult(intent,6611);

//        Intent intent = new Intent(this, CardsCameraActivity.class);
//        intent.putExtra("nMainId", 2);
//        intent.putExtra("nSubID", 0);
//        intent.putExtra("devcode", "");
//        intent.putExtra("flag", 0);
//        intent.putExtra("nCropType", 0);
//        startActivityForResult(intent, 6611);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 6611) {
            Bundle bundle=data.getBundleExtra("resultbundle");
            ResultMessage resultMessage=(ResultMessage) bundle.getSerializable("resultMessage");
            //数据的封装
            String result= ManageIDCardRecogResult.managerSucessRecogResult(resultMessage);
            EventBus.getDefault().post(new EventManager(EventConstants.OCR_SCAN_SUCCESS, result));
        }
        finish();
    }
}
