package com.dgzrdz.mobile.cocobee.view.dialog;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.baoyz.actionsheet.ActionSheet;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.manager.DeviceDebugAct;
import com.dgzrdz.mobile.cocobee.activity.manager.PointMapManageAct;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.Point;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import org.greenrobot.eventbus.EventBus;

import java.io.Serializable;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Description: 点击点位管理地图,显示点位数据
 * Author: Liubingren
 * Data:  2018/9/14
 * Time:  10:09
 */
public class ShowMarkerInfoDialog extends DialogFragment {

    @BindView(R.id.recogcode_tv)
    TextView mRecogcodeTv;
    @BindView(R.id.type_iv)
    ImageView mTypeIv;
    @BindView(R.id.coordinates_tv)
    TextView mCoordinatesTv;
    @BindView(R.id.online_status_tv)
    TextView mOnlineStatusTv;
    @BindView(R.id.address_tv)
    TextView mAddressTv;
    @BindView(R.id.install_status_tv)
    TextView mInstallStatusTv;
    @BindView(R.id.install_debug)
    TextView mInstallDebug;
    @BindView(R.id.change_position)
    TextView mChangePosition;
    @BindView(R.id.to_there)
    TextView mToThere;
    private Unbinder mBind;
    private Point mPoint;
    private List<Point> mPoints;
    private int mPosition;
    private Context mContext;

    public void setPoint(Point point) {
        mPoint = point;
    }

    public void setPoints(List<Point> points) {
        mPoints = points;
    }

    public void setPosition(int position) {
        mPosition = position;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.MyDialog);
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = Utils.getScreenWidth();
        lp.height = Utils.dp2px(180);
        lp.windowAnimations = R.style.DialogAnimation;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.show_marker_info_dialog, container);
        mBind = ButterKnife.bind(this, view);
        mContext = getContext();
        setView();
        return view;
    }

    private void setView() {
        mRecogcodeTv.setText(Html.fromHtml("110识别码：<font color='blue'>" + mPoint.getIdentity() + "</font>"));
        mAddressTv.setText("地址：" + mPoint.getEqaddr());
        mCoordinatesTv.setText("经纬度： ( " + mPoint.getEqlng() + " , " + mPoint.getEqlat() + " )");

        String pointInstallStatus = mPoint.getInstall_flag();
        if (pointInstallStatus != null && pointInstallStatus.equals("2")) {
            mInstallStatusTv.setText(Html.fromHtml("安装状态：<font color='#136006'>已安装</font>"));
        } else {
            mInstallStatusTv.setText(Html.fromHtml("安装状态：<font color='red'>未安装</font>"));
        }
    }

    private void updatePointData(int position) {
        Intent i = new Intent(getContext(), PointMapManageAct.class);
        i.putExtra("flag", Constant.DWGL);
        i.putExtra("currentPosition", position);
        i.putExtra("points", (Serializable) mPoints);
        startActivity(i);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mBind.unbind();
    }

    @OnClick({R.id.install_debug, R.id.change_position, R.id.to_there})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.install_debug:
                Intent intent = new Intent(getContext(), DeviceDebugAct.class);
                intent.putExtra("point", mPoint);
                startActivity(intent);
                break;
            case R.id.change_position:
                updatePointData(mPosition);
                break;
            case R.id.to_there:
                dismiss();
                showGotoMap(mPoint);
                break;
        }
    }

    private void showGotoMap(Point info) {
        ActionSheet.createBuilder(getContext(), getFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("百度地图导航", "高德地图导航")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {
                        EventBus.getDefault().post(new EventManager(EventConstants.MAP_SELECT_DIALOG_DISMISS));
                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                Utils.gotoBaiduMap(mContext, info.getEqlng(), info.getEqlat(), info.getEqaddr());
                                break;
                            case 1:
                                Utils.gotoGaodeMap(mContext, info.getEqlng(), info.getEqlat(), info.getEqaddr());
                                break;
                            default:
                                break;
                        }
                    }
                }).show();

    }
}
