package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/12/14.
 */

public class PowerResponse implements Serializable{
    private int power;
    private int hasPower;

    public PowerResponse(int power, int hasPower) {
        this.power = power;
        this.hasPower = hasPower;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getHasPower() {
        return hasPower;
    }

    public void setHasPower(int hasPower) {
        this.hasPower = hasPower;
    }
}
