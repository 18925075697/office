package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2018/6/22.
 */

public class SelectPayResponse implements Serializable {

    /**
     * sysPropertySort : 宝马
     * memberOrderTotalPay : 500.00
     * memberOrderId : 20
     * timeNow : 2018-12-10 17:28:20.0
     * memberName : 匿名
     * sysMobileName : 联通
     * memberOrderType : 1
     * memberOrderAddTime : 2018-12-10 14:23:15
     * sysCityName : 佛山市
     * sysServiceSetYears : 1
     * Insurance_PackageList : [{"sysInsuranceName":"财产保险","sysInsuranceExpiredTime":"","appMemberId":"1","sysInsuranceValueId":"16","sysInstallPlaceId":"0","sysAreaId":"12","sysInsuranceConfYears":"2","sysServiceTypeId":"1","sysInsurancePrice":"200.00","sysInsuranceActiveTime":"","sysInsuranceAddTime":"2018-12-10 14:23:24","dataId":"20","sysInsuranceExValueStr":"13488889999","sysInsuranceConfPriceId":"8","sysInsuranceTypeId":"2","sysInsuranceProcess":"1","sysCityId":"44","sysInsuranceTypeName":"盗抢","sysInsuranceCancelTime":"","sysInsuranceTypeSpecial":"2","memberServiceObjId":"94","sysInsuranceId":"4"}]
     * memberServiceObjId : 94
     * memberAccount : 15889762042
     * memberOrderNo : 154442299540685
     * sysServiceTypeName : 摩托车
     * memberId : 36
     */

    private String sysPropertySort;
    private double memberOrderTotalPay;
    private String memberOrderId;
    private String timeNow;
    private String memberName;
    private String sysMobileName;
    private String memberOrderType;
    private String memberOrderAddTime;
    private String sysCityName;
    private String sysServiceSetYears;
    private String memberServiceObjId;
    private String memberAccount;
    private String memberOrderNo;
    private String sysServiceTypeName;
    private String memberId;
    private String hLabelNo;
    private String hPlateNo;
    private String memberServiceObjNumber;
    private List<InsurancePackageListBean> Insurance_PackageList;
    private List<PaymentwaysBean> paymentways;

    public String gethPlateNo() {
        return hPlateNo;
    }

    public void sethPlateNo(String hPlateNo) {
        this.hPlateNo = hPlateNo;
    }

    public String gethLabelNo() {
        return hLabelNo;
    }

    public void sethLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }

    public String getMemberServiceObjNumber() {
        return memberServiceObjNumber;
    }

    public void setMemberServiceObjNumber(String memberServiceObjNumber) {
        this.memberServiceObjNumber = memberServiceObjNumber;
    }

    public String getSysPropertySort() {
        return sysPropertySort;
    }

    public void setSysPropertySort(String sysPropertySort) {
        this.sysPropertySort = sysPropertySort;
    }

    public double getMemberOrderTotalPay() {
        return memberOrderTotalPay;
    }

    public void setMemberOrderTotalPay(double memberOrderTotalPay) {
        this.memberOrderTotalPay = memberOrderTotalPay;
    }

    public String getMemberOrderId() {
        return memberOrderId;
    }

    public void setMemberOrderId(String memberOrderId) {
        this.memberOrderId = memberOrderId;
    }

    public String getTimeNow() {
        return timeNow;
    }

    public void setTimeNow(String timeNow) {
        this.timeNow = timeNow;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getSysMobileName() {
        return sysMobileName;
    }

    public void setSysMobileName(String sysMobileName) {
        this.sysMobileName = sysMobileName;
    }

    public String getMemberOrderType() {
        return memberOrderType;
    }

    public void setMemberOrderType(String memberOrderType) {
        this.memberOrderType = memberOrderType;
    }

    public String getMemberOrderAddTime() {
        return memberOrderAddTime;
    }

    public void setMemberOrderAddTime(String memberOrderAddTime) {
        this.memberOrderAddTime = memberOrderAddTime;
    }

    public String getSysCityName() {
        return sysCityName;
    }

    public void setSysCityName(String sysCityName) {
        this.sysCityName = sysCityName;
    }

    public String getSysServiceSetYears() {
        return sysServiceSetYears;
    }

    public void setSysServiceSetYears(String sysServiceSetYears) {
        this.sysServiceSetYears = sysServiceSetYears;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public String getMemberOrderNo() {
        return memberOrderNo;
    }

    public void setMemberOrderNo(String memberOrderNo) {
        this.memberOrderNo = memberOrderNo;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public List<InsurancePackageListBean> getInsurance_PackageList() {
        return Insurance_PackageList;
    }

    public void setInsurance_PackageList(List<InsurancePackageListBean> Insurance_PackageList) {
        this.Insurance_PackageList = Insurance_PackageList;
    }

    public List<PaymentwaysBean> getPaymentways() {
        return paymentways;
    }

    public void setPaymentways(List<PaymentwaysBean> paymentways) {
        this.paymentways = paymentways;
    }

    public static class InsurancePackageListBean {
        /**
         * sysInsuranceName : 财产保险
         * sysInsuranceExpiredTime :
         * appMemberId : 1
         * sysInsuranceValueId : 16
         * sysInstallPlaceId : 0
         * sysAreaId : 12
         * sysInsuranceConfYears : 2
         * sysServiceTypeId : 1
         * sysInsurancePrice : 200.00
         * sysInsuranceActiveTime :
         * sysInsuranceAddTime : 2018-12-10 14:23:24
         * dataId : 20
         * sysInsuranceExValueStr : 13488889999
         * sysInsuranceConfPriceId : 8
         * sysInsuranceTypeId : 2
         * sysInsuranceProcess : 1
         * sysCityId : 44
         * sysInsuranceTypeName : 盗抢
         * sysInsuranceCancelTime :
         * sysInsuranceTypeSpecial : 2
         * memberServiceObjId : 94
         * sysInsuranceId : 4
         */

        private String sysInsuranceName;
        private String sysInsuranceExpiredTime;
        private String appMemberId;
        private String sysInsuranceValueId;
        private String sysInstallPlaceId;
        private String sysAreaId;
        private String sysInsuranceConfYears;
        private String sysServiceTypeId;
        private double sysInsurancePrice;
        private String sysInsuranceActiveTime;
        private String sysInsuranceAddTime;
        private String dataId;
        private String sysInsuranceExValueStr;
        private String sysInsuranceConfPriceId;
        private String sysInsuranceTypeId;
        private String sysInsuranceProcess;
        private String sysCityId;
        private String sysInsuranceTypeName;
        private String sysInsuranceCancelTime;
        private String sysInsuranceTypeSpecial;
        private String memberServiceObjId;
        private String sysInsuranceId;

        public String getSysInsuranceName() {
            return sysInsuranceName;
        }

        public void setSysInsuranceName(String sysInsuranceName) {
            this.sysInsuranceName = sysInsuranceName;
        }

        public String getSysInsuranceExpiredTime() {
            return sysInsuranceExpiredTime;
        }

        public void setSysInsuranceExpiredTime(String sysInsuranceExpiredTime) {
            this.sysInsuranceExpiredTime = sysInsuranceExpiredTime;
        }

        public String getAppMemberId() {
            return appMemberId;
        }

        public void setAppMemberId(String appMemberId) {
            this.appMemberId = appMemberId;
        }

        public String getSysInsuranceValueId() {
            return sysInsuranceValueId;
        }

        public void setSysInsuranceValueId(String sysInsuranceValueId) {
            this.sysInsuranceValueId = sysInsuranceValueId;
        }

        public String getSysInstallPlaceId() {
            return sysInstallPlaceId;
        }

        public void setSysInstallPlaceId(String sysInstallPlaceId) {
            this.sysInstallPlaceId = sysInstallPlaceId;
        }

        public String getSysAreaId() {
            return sysAreaId;
        }

        public void setSysAreaId(String sysAreaId) {
            this.sysAreaId = sysAreaId;
        }

        public String getSysInsuranceConfYears() {
            return sysInsuranceConfYears;
        }

        public void setSysInsuranceConfYears(String sysInsuranceConfYears) {
            this.sysInsuranceConfYears = sysInsuranceConfYears;
        }

        public String getSysServiceTypeId() {
            return sysServiceTypeId;
        }

        public void setSysServiceTypeId(String sysServiceTypeId) {
            this.sysServiceTypeId = sysServiceTypeId;
        }

        public double getSysInsurancePrice() {
            return sysInsurancePrice;
        }

        public void setSysInsurancePrice(double sysInsurancePrice) {
            this.sysInsurancePrice = sysInsurancePrice;
        }

        public String getSysInsuranceActiveTime() {
            return sysInsuranceActiveTime;
        }

        public void setSysInsuranceActiveTime(String sysInsuranceActiveTime) {
            this.sysInsuranceActiveTime = sysInsuranceActiveTime;
        }

        public String getSysInsuranceAddTime() {
            return sysInsuranceAddTime;
        }

        public void setSysInsuranceAddTime(String sysInsuranceAddTime) {
            this.sysInsuranceAddTime = sysInsuranceAddTime;
        }

        public String getDataId() {
            return dataId;
        }

        public void setDataId(String dataId) {
            this.dataId = dataId;
        }

        public String getSysInsuranceExValueStr() {
            return sysInsuranceExValueStr;
        }

        public void setSysInsuranceExValueStr(String sysInsuranceExValueStr) {
            this.sysInsuranceExValueStr = sysInsuranceExValueStr;
        }

        public String getSysInsuranceConfPriceId() {
            return sysInsuranceConfPriceId;
        }

        public void setSysInsuranceConfPriceId(String sysInsuranceConfPriceId) {
            this.sysInsuranceConfPriceId = sysInsuranceConfPriceId;
        }

        public String getSysInsuranceTypeId() {
            return sysInsuranceTypeId;
        }

        public void setSysInsuranceTypeId(String sysInsuranceTypeId) {
            this.sysInsuranceTypeId = sysInsuranceTypeId;
        }

        public String getSysInsuranceProcess() {
            return sysInsuranceProcess;
        }

        public void setSysInsuranceProcess(String sysInsuranceProcess) {
            this.sysInsuranceProcess = sysInsuranceProcess;
        }

        public String getSysCityId() {
            return sysCityId;
        }

        public void setSysCityId(String sysCityId) {
            this.sysCityId = sysCityId;
        }

        public String getSysInsuranceTypeName() {
            return sysInsuranceTypeName;
        }

        public void setSysInsuranceTypeName(String sysInsuranceTypeName) {
            this.sysInsuranceTypeName = sysInsuranceTypeName;
        }

        public String getSysInsuranceCancelTime() {
            return sysInsuranceCancelTime;
        }

        public void setSysInsuranceCancelTime(String sysInsuranceCancelTime) {
            this.sysInsuranceCancelTime = sysInsuranceCancelTime;
        }

        public String getSysInsuranceTypeSpecial() {
            return sysInsuranceTypeSpecial;
        }

        public void setSysInsuranceTypeSpecial(String sysInsuranceTypeSpecial) {
            this.sysInsuranceTypeSpecial = sysInsuranceTypeSpecial;
        }

        public String getMemberServiceObjId() {
            return memberServiceObjId;
        }

        public void setMemberServiceObjId(String memberServiceObjId) {
            this.memberServiceObjId = memberServiceObjId;
        }

        public String getSysInsuranceId() {
            return sysInsuranceId;
        }

        public void setSysInsuranceId(String sysInsuranceId) {
            this.sysInsuranceId = sysInsuranceId;
        }
    }

    public static class PaymentwaysBean implements Serializable{
        /**
         * payclass :
         * paymethodId :
         * paytype :
         * payname :
         */

        private String payclass;
        private String paymethodId;
        private String paytype;
        private String payname;

        public String getPayclass() {
            return payclass;
        }

        public void setPayclass(String payclass) {
            this.payclass = payclass;
        }

        public String getPaymethodId() {
            return paymethodId;
        }

        public void setPaymethodId(String paymethodId) {
            this.paymethodId = paymethodId;
        }

        public String getPaytype() {
            return paytype;
        }

        public void setPaytype(String paytype) {
            this.paytype = paytype;
        }

        public String getPayname() {
            return payname;
        }

        public void setPayname(String payname) {
            this.payname = payname;
        }
    }
}
