package com.dgzrdz.mobile.cocobee.view.dialog;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.PolicyServiceAdapter;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;
import com.dgzrdz.mobile.cocobee.view.MyLinearLayoutManager;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 选择保险弹框
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  15:15
 */
public class SelectPolicyDialog extends DialogFragment {
    @BindView(R.id.tv_org_name)
    TextView mTvOrgName;
    @BindView(R.id.iv_close_dialog)
    ImageView mIvCloseDialog;
    @BindView(R.id.tv_car_type)
    TextView mTvCarType;
    @BindView(R.id.recycle_view_policy)
    RecyclerView mRecycleViewPolicy;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.ll_sure_service)
    LinearLayout mLlSureService;
    private Unbinder mBind;
    private List<PolicyServiceResponse> policyList = new ArrayList<>();//保险服务集合
    private PolicyServiceAdapter mPolicyServiceAdapter;
    private double baoxianPrice;
    private GuardianObjectResponse mGuardianObjectResponse;
    private UserInfo mUserLoginInfo;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.MyDialog);
    }

    public void setPolicyList(List<PolicyServiceResponse> policyList1) {
        policyList.clear();
        policyList.addAll(policyList1);
    }

    /**
     * 设置选中的监护对象信息
     *
     * @param guardianObjectResponse
     */
    public void setGuardianObjectResponse(GuardianObjectResponse guardianObjectResponse) {
        mGuardianObjectResponse = guardianObjectResponse;
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = Utils.getScreenWidth();
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.windowAnimations = R.style.DialogAnimation;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_select_policy, container);
        mBind = ButterKnife.bind(this, view);
        mUserLoginInfo = Utils.getUserLoginInfo();
        initPolicyRecycleView();
        setView();
        if (policyList.size() > 0) {
            mPolicyServiceAdapter.notifyDataSetChanged();
            getSelectPolicy();
        } else {
            initData();
        }
        return view;
    }

    /**
     * 设置选中服务弹框的组织机构,电话等
     */
    private void setView() {
        mTvOrgName.setText("当前机构:" + mUserLoginInfo.getDataList().getSysAreaName());
        mTvCarType.setText(mGuardianObjectResponse.getSysServiceTypeName());
    }

    /**
     * 获取保险
     */
    private void initData() {
        PayApiUtils.getPolicy(getContext(), mGuardianObjectResponse.getSysServiceTypeId(), mUserLoginInfo.getDataList().getSysAreaId(), mGuardianObjectResponse.getSysGroupId(), new JsonCallback<List<PolicyServiceResponse>>(getContext()) {
            @Override
            public void onSuccess(List<PolicyServiceResponse> policyServiceResponses, Call call, Response response) {
                if (policyServiceResponses != null && policyServiceResponses.size() > 0) {
                    policyList.addAll(policyServiceResponses);
                    mPolicyServiceAdapter.notifyDataSetChanged();
                } else {
                    XToastUtils.showShortToast("暂未配置保险");
                    dismiss();
                }
            }
        });
    }

    private void initPolicyRecycleView() {
        //保险服务列表
        mRecycleViewPolicy.setLayoutManager(new MyLinearLayoutManager(getContext()));
        mPolicyServiceAdapter = new PolicyServiceAdapter(getContext(), policyList);
        mRecycleViewPolicy.setAdapter(mPolicyServiceAdapter);
        mPolicyServiceAdapter.setPolicyItemOnClickListener(new PolicyServiceAdapter.PolicyItemOnClick() {
            @Override
            public void onItemClick(int position, int positions) {
                PolicyServiceResponse policyServiceResponse = policyList.get(position);
                policyServiceResponse.setPosition(positions);
                List<PolicyServiceResponse.PolicyServiceTypeListBean> policyServiceTypeList = policyServiceResponse.getServiceTypeList();
                for (int i = 0; i < policyServiceTypeList.size(); i++) {
                    PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceTypeList.get(i);
                    if (i == positions && policyServiceTypeListBean.getSelect() == positions) {//点击的条目原来是选中的,取消选中
                        policyServiceTypeListBean.setSelect(-1);
                        policyServiceResponse.setPosition(-1);
                    } else if (i == positions) {
                        policyServiceTypeListBean.setSelect(positions);
                    } else {
                        policyServiceTypeListBean.setSelect(-1);
                    }
                }

                mPolicyServiceAdapter.notifyDataSetChanged();

                //得到选中的保险
                getSelectPolicy();
            }
        });
    }

    /**
     * 获取选中的保险
     */
    private void getSelectPolicy() {
        String selectId = "";
        double price = 0;
        for (int i = 0; i < policyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = policyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                //                selectId = selectId + policyServiceTypeListBean.getId() + ",";
                price = price + policyServiceTypeListBean.getSysInsurancePrice();
            }
        }
        if (!CheckUtils.isEmpty(selectId)) {
            selectId = selectId.substring(0, selectId.length() - 1);
        }
        baoxianPrice = price;
        mMtvPayNum.setAmount(baoxianPrice);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        OkGo.getInstance().cancelTag(this);
        mBind.unbind();
    }

    @OnClick({R.id.iv_close_dialog, R.id.ll_sure_service})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_close_dialog:
                dismiss();
                break;
            case R.id.ll_sure_service:
                sure();
                break;
        }
    }

    /**
     * 确定
     */
    private void sure() {
        boolean isBaoxianOk = false;
        for (int i = 0; i < policyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = policyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {
                isBaoxianOk = true;
            }
        }

        if (!isBaoxianOk) {
            XToastUtils.showShortToast("请至少选择一项保险服务");
        } else {
            Intent intent = new Intent();
            intent.putExtra("policyList", (Serializable) policyList);
            EventBus.getDefault().post(new EventManager(EventConstants.POLICY_SELECT_SUCCESS, intent));
            dismiss();
        }

    }
}
