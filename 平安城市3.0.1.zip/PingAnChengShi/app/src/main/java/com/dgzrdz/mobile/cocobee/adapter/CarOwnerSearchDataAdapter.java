package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 资料库adapter
 * Created by admin on 2018/4/25.
 */

public class CarOwnerSearchDataAdapter extends QuickRcvAdapter<UserBeanResponse> {
    private final Context mContext;
    String keyStr;

    public CarOwnerSearchDataAdapter(Context context, List<UserBeanResponse> data, String key) {
        super(context, data, R.layout.item_car_owner);
        keyStr = key;
        mContext = context;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, UserBeanResponse userBeanResponse) {
        TextView nameTxt = quickRcvHolder.getView(R.id.nameTxt);
        TextView telTxt = quickRcvHolder.getView(R.id.telTxt);
        TextView bindingSizeTxt = quickRcvHolder.getView(R.id.bindingSizeTxt);
        ImageView userHeadImg = quickRcvHolder.getView(R.id.userHeadImg);

        if (!CheckUtils.isEmpty(keyStr)) {
            nameTxt.setText(Utils.matcherSearchText(mContext.getResources().getColor(R.color.color_008cff), userBeanResponse.getMemberName(), keyStr));
            telTxt.setText(Utils.matcherSearchText(mContext.getResources().getColor(R.color.color_008cff), "(" + userBeanResponse.getMemberAccount() + ")", keyStr));
        } else {
            nameTxt.setText(userBeanResponse.getMemberName());
            nameTxt.setTextColor(mContext.getResources().getColor(R.color.color_808080));
            telTxt.setText("(" + userBeanResponse.getMemberAccount() + ")");
            telTxt.setTextColor(mContext.getResources().getColor(R.color.color_808080));
        }

        bindingSizeTxt.setText(userBeanResponse.getTotal());
        if (CheckUtils.equalsString(userBeanResponse.getMemberSix(),"1")){//男
            userHeadImg.setImageResource(R.drawable.male_portrait);
        }else {//女
            userHeadImg.setImageResource(R.drawable.women);
        }
    }
}
