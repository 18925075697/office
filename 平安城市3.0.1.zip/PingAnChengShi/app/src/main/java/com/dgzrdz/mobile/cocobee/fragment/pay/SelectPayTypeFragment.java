package com.dgzrdz.mobile.cocobee.fragment.pay;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.pay.PaySuccessActivity;
import com.dgzrdz.mobile.cocobee.activity.register.WebXiAnActivity;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.model.WXPay;
import com.dgzrdz.mobile.cocobee.response.CloudPayResponse;
import com.dgzrdz.mobile.cocobee.response.PayResponse;
import com.dgzrdz.mobile.cocobee.response.PaySuccessResponse;
import com.dgzrdz.mobile.cocobee.response.SelectPayResponse;
import com.dgzrdz.mobile.cocobee.response.XCodeResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.WXPayUtils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;
import com.dgzrdz.mobile.cocobee.view.TimeCountUnPayOrder;
import com.dgzrdz.mobile.cocobee.view.dialog.InputDialog;
import com.dgzrdz.mobile.cocobee.zxing.encode.EncodingHandler;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 选择支付页面
 * Author: Liubingren
 * Data:  2018/7/2
 * Time:  11:26
 */

public class SelectPayTypeFragment extends BaseFragment {

    private static boolean isOrder;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.tv_service_name)
    TextView mTvServiceName;
    @BindView(R.id.car_owner_name)
    TextView mCarOwnerName;
    @BindView(R.id.tv_car_brand)
    TextView mTvCarBrand;
    @BindView(R.id.tv_label_num)
    TextView mTvLabelNum;
    @BindView(R.id.tv_car_num)
    TextView mTvCarNum;
    @BindView(R.id.ll_get_money)
    LinearLayout mLlGetMoney;
    @BindView(R.id.ll_wechat_pay)
    LinearLayout mLlWechatPay;
    @BindView(R.id.ll_cloud_pay)
    LinearLayout mLlCloudPay;
    @BindView(R.id.ll_koulin_pay)
    LinearLayout mLlKoulinPay;
    @BindView(R.id.tv_order_num)
    TextView mTvOrderNum;
    @BindView(R.id.ll_add_service_policy)
    LinearLayout mLlAddServicePolicy;
    @BindView(R.id.tv_cancel)
    TextView mTvCancel;
    @BindView(R.id.ll_tag_service)
    LinearLayout mLlTagService;
    @BindView(R.id.tv_tag_service)
    TextView mTvTagService;
    @BindView(R.id.tv_zero_pay)
    TextView mTvZeroPay;

    private AlertDialog mAlertDialog;
    private int payType;//1二维码支付 2微信支付 云支付 4口令支付
    private TimeCountUnPayOrder mTimeCountUnPayOrder;
    private int cancelFlag;//1取消订单 2取消订单返回修改
    private static String memberOrderId;
    private SelectPayResponse mSelectPayResponse;
    private UserInfo mUserLoginInfo;
    private SelectPayResponse.PaymentwaysBean mPaymentwaysBean;

    public static SelectPayTypeFragment getInstance(String memberOrderId, boolean isOrder) {
        SelectPayTypeFragment.memberOrderId = memberOrderId;
        SelectPayTypeFragment.isOrder = isOrder;
        SelectPayTypeFragment fragment = new SelectPayTypeFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mTvTitle.setCompoundDrawables(null, null, null, null);
        if (isOrder) {
            mTvCancel.setVisibility(View.GONE);
        }
        mUserLoginInfo = Utils.getUserLoginInfo();
        initData();

    }

    private void initData() {
        PayApiUtils.getSelectPay(_mActivity, memberOrderId, mUserLoginInfo.getDataList().getAppMemberId(), new DialogCallback<SelectPayResponse>(_mActivity, "获取订单信息...") {

            @Override
            public void onSuccess(SelectPayResponse selectPayResponse, Call call, Response response) {
                if (selectPayResponse != null) {
                    mSelectPayResponse = selectPayResponse;
                    initView();
                    initTimeCount();
                } else {
                    XToastUtils.showShortToast("暂无数据");
                }
            }
        });
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    private void initTimeCount() {
        String memberOrderAddTime = mSelectPayResponse.getMemberOrderAddTime();//订单生成时间
        long currentTimeMillis = DateUtils.getLongFromString(mSelectPayResponse.getTimeNow(), "yyyy-MM-dd HH:mm:ss");//当前时间
        long longFromString = DateUtils.getLongFromString(memberOrderAddTime, "yyyy-MM-dd HH:mm:ss");
        long l = longFromString + 20 * 60 * 1000;//截止时间
        if (l > currentTimeMillis) {
            mTimeCountUnPayOrder = new TimeCountUnPayOrder(_mActivity, l - currentTimeMillis, 1000, mTvServiceName);
            mTimeCountUnPayOrder.start();
            mTvServiceName.setVisibility(View.VISIBLE);
        } else {
            mTvServiceName.setVisibility(View.GONE);
        }
    }

    private void initView() {
        mCarOwnerName.setText(mSelectPayResponse.getMemberName() + "(" + mSelectPayResponse.getMemberAccount() + ")");
        mTvCarBrand.setText(mSelectPayResponse.getSysServiceTypeName() + "(" + mSelectPayResponse.getSysPropertySort() + ")");
        mTvLabelNum.setText(mSelectPayResponse.gethLabelNo());
        mTvCarNum.setText(mSelectPayResponse.getMemberServiceObjNumber());
        mTvOrderNum.setText(mSelectPayResponse.getMemberOrderNo());
        mMtvPayNum.setAmount(mSelectPayResponse.getMemberOrderTotalPay());

        if (CheckUtils.equalsString(mSelectPayResponse.getMemberOrderType(), "3")) {//保险
            mLlTagService.setVisibility(View.GONE);
            setPolicy();
        } else if (CheckUtils.equalsString(mSelectPayResponse.getMemberOrderType(), "2")) {//服务
            mLlTagService.setVisibility(View.VISIBLE);
            mTvTagService.setText(mSelectPayResponse.getSysServiceSetYears() + "年");
        } else {//保险加服务
            mLlTagService.setVisibility(View.VISIBLE);
            mTvTagService.setText(mSelectPayResponse.getSysServiceSetYears() + "年");
            setPolicy();
        }

        if (mSelectPayResponse.getMemberOrderTotalPay() == 0) {//支付金额为0
            mTvZeroPay.setVisibility(View.VISIBLE);
            mLlKoulinPay.setVisibility(View.GONE);
            return;
        }

        List<SelectPayResponse.PaymentwaysBean> paymentways = mSelectPayResponse.getPaymentways();
        if (paymentways == null || paymentways.size() == 0) {
            XToastUtils.showShortToast("暂未配置支付方式");
            return;
        }
        for (int i = 0; i < paymentways.size(); i++) {
            SelectPayResponse.PaymentwaysBean paymentwaysBean = paymentways.get(i);
            if (CheckUtils.equalsString(paymentwaysBean.getPaytype(), "1")) {//二维码
                mLlGetMoney.setVisibility(View.VISIBLE);
            } else if (CheckUtils.equalsString(paymentwaysBean.getPaytype(), "2")) {//微信支付
                mLlWechatPay.setVisibility(View.VISIBLE);
            } else if (CheckUtils.equalsString(paymentwaysBean.getPaytype(), "3")) {//云支付
                mLlCloudPay.setVisibility(View.VISIBLE);
            } else if (CheckUtils.equalsString(paymentwaysBean.getPaytype(), "4")) {//口令支付
                mLlKoulinPay.setVisibility(View.VISIBLE);
            }
        }
    }

    private void setPolicy() {
        List<SelectPayResponse.InsurancePackageListBean> insurance_packageList = mSelectPayResponse.getInsurance_PackageList();
        for (int i = 0; i < insurance_packageList.size(); i++) {
            SelectPayResponse.InsurancePackageListBean insurancePackageListBean = insurance_packageList.get(i);
            addPolicyTextView(insurancePackageListBean);
        }
    }

    /**
     * 添加保险文本输入模式控件
     *
     * @param insurancePackageListBean
     */
    private void addPolicyTextView(SelectPayResponse.InsurancePackageListBean insurancePackageListBean) {
        View view = View.inflate(_mActivity, R.layout.view_tagservice_item, null);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        TextView tvText = (TextView) view.findViewById(R.id.tv_text);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlAddServicePolicy.addView(view, layoutParams);

        tvTextTitle.setText(insurancePackageListBean.getSysInsuranceTypeName());
        tvText.setText(insurancePackageListBean.getSysInsuranceConfYears() + "年/¥" + insurancePackageListBean.getSysInsurancePrice());
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithRightText("支付中心", "取消订单");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_select_pay_type;
    }

    @Override
    public void btnRightTextClick() {
        cancelFlag = 1;
        showCancelDialog();
    }

    /**
     * 显示取消订单提示
     */
    private void showCancelDialog() {
        SweetAlertDialog dialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.WARNING_TYPE);
        dialog.setContentText("确定取消此订单吗?");
        dialog.setTitleText("温馨提示");
        dialog.showCancelButton(true).setCancelText("暂不");
        dialog.setConfirmText("确定取消");
        dialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismissWithAnimation();
                userCancelOrder();
            }
        }).show();
    }

    @OnClick({R.id.ll_get_money, R.id.ll_wechat_pay, R.id.ll_cloud_pay, R.id.ll_koulin_pay, R.id.tv_cancel, R.id.tv_zero_pay})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_get_money://收款码
                payType = 1;
                updatePayStateStart();
//                getPayQrCode();
                break;
            case R.id.ll_wechat_pay://微信支付
                payType = 2;
                if (WXPayUtils.checkIsSupportWXPay(_mActivity)) {
                    //获取微信支付信息
                    if (mSelectPayResponse != null) {
                        getPayInfo();
                    } else {
                        XToastUtils.showShortToast("无法获取");
                    }
                }
                break;
            case R.id.ll_cloud_pay://云支付
                payType = 3;
                payNow();
                break;
            case R.id.ll_koulin_pay://口令支付
                payType = 4;
                showInputDialog();
                break;
            case R.id.tv_zero_pay://0元支付
                notifyPaySuccess();
                break;
            case R.id.tv_cancel://取消订单并返回修改
                cancelFlag = 2;
                showCancelDialog();
                break;
        }
    }

    /**
     * 查询支付状态
     */
    private void updatePayStateStart() {
        mPaymentwaysBean = getPaymentwaysBean("1");
        PayApiUtils.checkPayStatus(_mActivity, mSelectPayResponse.getMemberOrderId(), mSelectPayResponse.getMemberOrderNo(), mPaymentwaysBean.getPaymethodId(), new DialogCallback<PaySuccessResponse>(_mActivity, "查询支付状态...") {
            @Override
            public void onSuccess(PaySuccessResponse paySuccessResponse, Call call, Response response) {
                if (paySuccessResponse != null) {//付款成功
                    paySuccess(paySuccessResponse);
                } else {
                    getPayQrCode();
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                getPayQrCode();
            }
        });
    }

    /**
     * 金额为0,直接通知服务器支付成功,跳转成功页
     */
    private void notifyPaySuccess() {
        PayApiUtils.notifyPaySuccess(_mActivity, mSelectPayResponse.getMemberOrderNo(), new DialogCallback<PaySuccessResponse>(_mActivity, "查询支付状态...") {
            @Override
            public void onSuccess(PaySuccessResponse paySuccessResponse, Call call, Response response) {
                if (paySuccessResponse != null) {//通知成功,相当于支付成功
                    paySuccess(paySuccessResponse);
                } else {
                    XToastUtils.showShortToast(msg);
                }
            }
        });
    }

    /**
     * 显示输入口令dialog
     */
    private void showInputDialog() {
        InputDialog dialog = new InputDialog();
        dialog.setOrderInfoResponse(mSelectPayResponse);
        dialog.show(getFragmentManager(), "freePwd");
    }

    /**
     * 用户主动取消订单
     */
    private void userCancelOrder() {
        PayApiUtils.userCancelOrder(_mActivity, mSelectPayResponse.getMemberOrderType(), memberOrderId, mSelectPayResponse.getMemberServiceObjId(), new DialogCallback<PayResponse>(_mActivity, "取消支付订单...") {
            @Override
            public void onSuccess(PayResponse payResponse, Call call, Response response) {
                if (cancelFlag == 2) {//取消订单返回修改
                    XToastUtils.showShortToast("订单已取消,请重新生成订单进行支付");
                } else {
                    XToastUtils.showShortToast("订单已取消");
                    EventBus.getDefault().post(new EventManager(EventConstants.ORDER_CANCEL_SUCCESS));
                }
                _mActivity.finish();
            }
        });
    }

    /**
     * 微信支付获取支付信息
     */
    private void getPayInfo() {
        mPaymentwaysBean = getPaymentwaysBean("2");
        PayApiUtils.payNow(_mActivity, mSelectPayResponse.getMemberOrderNo(), mPaymentwaysBean.getPaymethodId(), mPaymentwaysBean.getPayclass(),mSelectPayResponse.getMemberAccount(),mSelectPayResponse.gethLabelNo(),
               mSelectPayResponse.gethPlateNo() , new DialogCallback<WXPay>(_mActivity, "获取支付信息中...") {

            @Override
            public void onSuccess(WXPay wxPay, Call call, Response response) {
                if (wxPay != null) {
                    mSelectPayResponse.setMemberOrderNo(wxPay.getMemberOrderNo());
                    mTvOrderNum.setText(wxPay.getMemberOrderNo());
                    WXPayUtils.payByWX(wxPay);
                } else {
                    XToastUtils.showShortToast("服务器数据异常!");
                }
            }
        });
    }

    /**
     * 获取点击的支付项
     *
     * @param type 1二维码 2微信支付 3云支付 4口令支付
     * @return
     */
    @Nullable
    private SelectPayResponse.PaymentwaysBean getPaymentwaysBean(String type) {
        SelectPayResponse.PaymentwaysBean paymentwaysBean = null;
        List<SelectPayResponse.PaymentwaysBean> paymentways = mSelectPayResponse.getPaymentways();
        for (int i = 0; i < paymentways.size(); i++) {
            SelectPayResponse.PaymentwaysBean paymentwaysBean1 = paymentways.get(i);
            String paytype = paymentwaysBean1.getPaytype();
            if (CheckUtils.equalsString(paytype, type)) {
                paymentwaysBean = paymentwaysBean1;
            }
        }
        return paymentwaysBean;
    }

    /**
     * 云支付
     */
    private void payNow() {
        mPaymentwaysBean = getPaymentwaysBean("3");
        PayApiUtils.payNow(_mActivity, mSelectPayResponse.getMemberOrderNo(), mPaymentwaysBean.getPaymethodId(), mPaymentwaysBean.getPayclass(),mSelectPayResponse.getMemberAccount(),mSelectPayResponse.gethLabelNo(),
                mSelectPayResponse.gethPlateNo(), new DialogCallback<CloudPayResponse>(_mActivity, "获取支付信息...") {
            @Override
            public void onSuccess(CloudPayResponse cloudPayResponse, Call call, Response response) {
                if (cloudPayResponse != null) {
                    mSelectPayResponse.setMemberOrderNo(cloudPayResponse.getMemberOrderNo());
                    mTvOrderNum.setText(cloudPayResponse.getMemberOrderNo());
                    if (!CheckUtils.isEmpty(cloudPayResponse.getLink())) {
                        Intent intent = new Intent(_mActivity, WebXiAnActivity.class);
                        intent.putExtra("url", cloudPayResponse.getLink());
                        startActivity(intent);
                    } else {
                        XToastUtils.showShortToast("付款链接为空");
                    }
                } else {
                    XToastUtils.showShortToast("未获取到信息");
                }
            }
        });
    }

    /**
     * 获取支付二维码
     */
    private void getPayQrCode() {
        mPaymentwaysBean = getPaymentwaysBean("1");
        PayApiUtils.payNow(_mActivity, mSelectPayResponse.getMemberOrderNo(), mPaymentwaysBean.getPaymethodId(), mPaymentwaysBean.getPayclass(),mSelectPayResponse.getMemberAccount(),mSelectPayResponse.gethLabelNo(),
                mSelectPayResponse.gethPlateNo(), new DialogCallback<XCodeResponse>(_mActivity, "获取支付二维码...") {
            @Override
            public void onSuccess(XCodeResponse xCodeResponse, Call call, Response response) {
                if (xCodeResponse != null && xCodeResponse.getCode_img_url() != null) {
                    mSelectPayResponse.setMemberOrderNo(xCodeResponse.getMemberOrderNo());
                    mTvOrderNum.setText(xCodeResponse.getMemberOrderNo());
                    codePay(xCodeResponse.getCode_img_url());
                } else {
                    XToastUtils.showShortToast("未获取到信息");
                }
            }
        });
    }

    private void codePay(String s) {
        View view = View.inflate(_mActivity, R.layout.dialog_code_pay, null);
        mAlertDialog = Utils.showCornerDialog(_mActivity, view, 208, 382);
        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.setCancelable(false);
        ImageView ivPayCode = (ImageView) mAlertDialog.findViewById(R.id.iv_pay_code);
        TextView tvSurePay = (TextView) mAlertDialog.findViewById(R.id.tv_sure_pay);

        try {
            Bitmap bitmap = EncodingHandler.create2Code(s, Utils.dp2px(145));
            ImageUtil.loadBitmap(_mActivity, bitmap, ivPayCode);
        } catch (Exception e) {
            e.printStackTrace();
        }

        tvSurePay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePayState();
            }
        });
    }

    /**
     * 支付成功
     *
     * @param paySuccessResponse
     */
    private void paySuccess(PaySuccessResponse paySuccessResponse) {
        EventBus.getDefault().post(new EventManager(EventConstants.PAY_SUCCESS));
        Intent intent = new Intent(_mActivity, PaySuccessActivity.class);
        intent.putExtra("paySuccessResponse", paySuccessResponse);
        startActivity(intent);
        _mActivity.finish();
    }

    /**
     * 支付失败
     */
    private void payFailed() {
        pop();
        start(UnFinishPayFragment.getInstance());
    }

    /**
     * 查询支付状态
     */
    private void updatePayState() {
        PayApiUtils.checkPayStatus(_mActivity, mSelectPayResponse.getMemberOrderId(), mSelectPayResponse.getMemberOrderNo(), mPaymentwaysBean.getPaymethodId(), new DialogCallback<PaySuccessResponse>(_mActivity, "查询支付状态...") {
            @Override
            public void onSuccess(PaySuccessResponse paySuccessResponse, Call call, Response response) {
                if (payType == 1) {//二维码支付
                    mAlertDialog.dismiss();
                }
                if (paySuccessResponse != null) {//付款成功
                    paySuccess(paySuccessResponse);
                } else {
                    XToastUtils.showShortToast(msg);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (payType == 1) {//二维码支付
                    mAlertDialog.dismiss();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        if (mTimeCountUnPayOrder != null) {
            mTimeCountUnPayOrder.cancel();
        }
        super.onDestroy();
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.SURE_USE_FREE_PWD://使用口令支付成功
                _mActivity.finish();
                break;
            case EventConstants.TIME_COUNT_DOWN_CANCEL_ORDER://倒计时时间到,取消订单
                cancelFlag = 1;
                userCancelOrder();
                break;
            case EventConstants.WX_PAY_SUCCESS://微信支付成功
            case EventConstants.OUT_XIAN_PAY_ACTIVITY://退出西安支付页面
                updatePayState();
                break;
        }
    }

}
