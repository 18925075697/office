package com.dgzrdz.mobile.cocobee.adapter;


import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.response.SysPropertyOptionListBean;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by Administrator on 2017/5/5.
 */

public class CarBrandAdapter extends QuickRcvAdapter<SysPropertyOptionListBean> {

    private final List<SysPropertyOptionListBean> mData;
    private final Context mContext;

    public CarBrandAdapter(Context context, List<SysPropertyOptionListBean> data, int... layoutId) {
        super(context, data, R.layout.item_car_brand);
        mContext = context;
        mData = data;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, SysPropertyOptionListBean item) {
        TextView firstHeadWord = viewHolder.getView(R.id.tv_first_head_word);
        TextView carType = viewHolder.getView(R.id.tv_car_type);
        carType.setText(item.getSysPropertyOptionValue());
        carType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventBus.getDefault().post(new EventManager(EventConstants.SELECT_CAR_BRAND_SUCCESS, item));
                ((Activity) mContext).finish();
            }
        });
        firstHeadWord.setClickable(false);

        if (position == 0) {//第一条,显示首写字母
            firstHeadWord.setVisibility(View.VISIBLE);
            firstHeadWord.setText(item.getSysPropertyOptionChar());
        } else {
            //本条首写字母
            String firstHeadWordChar = item.getSysPropertyOptionChar();
            //前一条的首写字母
            String beforeHeadWordChar = mData.get(position - 1).getSysPropertyOptionChar();
            int i = firstHeadWordChar.compareTo(beforeHeadWordChar);
            if (i == 0) {//与前一条首写字母相同
                firstHeadWord.setVisibility(View.GONE);
            } else if (i > 0) {//比前一条大
                firstHeadWord.setVisibility(View.VISIBLE);
                firstHeadWord.setText(item.getSysPropertyOptionChar());
            }
        }

    }
}
