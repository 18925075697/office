package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  16:22
 */

public class TagServiceTaocanResponse implements Serializable{


    /**
     * year : 1年
     *desc: 1年年,宽带业务3
     * ids :1,4,7
     */

    private String year;
    private String desc;
    private String ids;//套餐的id集
    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
