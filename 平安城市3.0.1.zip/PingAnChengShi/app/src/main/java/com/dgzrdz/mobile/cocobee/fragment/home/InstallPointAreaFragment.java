package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.dgzrdz.mobile.cocobee.adapter.InstallPointAreaAdapter;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GetUserOrg;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import okhttp3.Response;

/**
 * 安装点区域
 * Created by Administrator on 2018/6/21.
 */

public class InstallPointAreaFragment extends RefreshAndLoadFragment<GetUserOrg> {
    private InstallPointAreaAdapter mInstallPointAreaAdapter;

    public static InstallPointAreaFragment getInstance() {
        InstallPointAreaFragment fragment = new InstallPointAreaFragment();
        return fragment;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        GetUserOrg getUserOrg = mList.get(position);
        start(InstallPointFragment.getInstance(getUserOrg.getSysAreaCode()));
    }

    @Override
    public QuickRcvAdapter<GetUserOrg> getAdapter() {
        return mInstallPointAreaAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        //固定查株洲市下级组织机构
        HomeApiUtils.getIndexOrgSelect(getContext(), userLoginInfo.getDataList().getAppMemberId(), new RefreshAndLoadCallback<List<GetUserOrg>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<GetUserOrg> getUserOrgs, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshListData(callback, getUserOrgs, null);
            }

        });
    }

    @Override
    public void onLoadMore() {

    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mInstallPointAreaAdapter = new InstallPointAreaAdapter(_mActivity, mList);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("安装点区域");
    }


}
