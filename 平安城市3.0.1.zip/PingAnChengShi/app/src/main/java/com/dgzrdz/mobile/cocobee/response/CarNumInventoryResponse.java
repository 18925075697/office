package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/6/29.
 */

public class CarNumInventoryResponse implements Serializable{

    /**
     * carTypeName : 电动三轮车
     * cno : 株洲A20180104
     * createtime : 2018-07-13 00:00:00
     * id : 0b6757aedb6041cfaf62223a84829adc
     * modifytime : 2018-07-13 00:00:00
     */

    private String carTypeName;
    private String cno;
    private String createtime;
    private String id;
    private String modifytime;
    private String packNumber;//盒号

    public String getCarTypeName() {
        return carTypeName;
    }

    public void setCarTypeName(String carTypeName) {
        this.carTypeName = carTypeName;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModifytime() {
        return modifytime;
    }

    public void setModifytime(String modifytime) {
        this.modifytime = modifytime;
    }

    public String getPackNumber() {
        return packNumber;
    }

    public void setPackNumber(String packNumber) {
        this.packNumber = packNumber;
    }
}
