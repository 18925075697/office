package com.dgzrdz.mobile.cocobee.activity.map;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ZoomControls;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.route.BikingRouteResult;
import com.baidu.mapapi.search.route.DrivingRouteResult;
import com.baidu.mapapi.search.route.IndoorRouteResult;
import com.baidu.mapapi.search.route.MassTransitRouteResult;
import com.baidu.mapapi.search.route.OnGetRoutePlanResultListener;
import com.baidu.mapapi.search.route.PlanNode;
import com.baidu.mapapi.search.route.RoutePlanSearch;
import com.baidu.mapapi.search.route.TransitRouteResult;
import com.baidu.mapapi.search.route.WalkingRouteLine;
import com.baidu.mapapi.search.route.WalkingRoutePlanOption;
import com.baidu.mapapi.search.route.WalkingRouteResult;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.common.TraceDataHolder;
import com.dgzrdz.mobile.cocobee.common.TraceJson;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.lzy.okgo.OkGo;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 轨迹页面：普通用户的车辆轨迹
 * Created by _H_JY on 16/10/28.
 */
public class TraceActivity extends BaseToolbarActivity implements OnGetRoutePlanResultListener {

    @BindView(R.id.mapView)
    MapView mMapView;
    @BindView(R.id.speed_sb)
    SeekBar mSpeedSb;
    @BindView(R.id.location_ivPlay)
    ImageView mLocationIvPlay;
    @BindView(R.id.replay_btn)
    Button mReplayBtn;
    @BindView(R.id.progressBar1)
    SeekBar mProgressBar1;
    @BindView(R.id.speed_btn)
    Button mSpeedBtn;
    @BindView(R.id.control_ll)
    LinearLayout mControlLl;

    //轨迹回放
    private List<LatLng> latLngPolygons = new ArrayList<>();
    private List<LatLng> planLatLngPolygons = new ArrayList<>();
    private List<TraceJson.DataBean.LocusBean> locationWithoutSames = new ArrayList<>();


    //路线记录标识
    private int routeIndex;
    private boolean routeFlag;
    private final int ROUTE = 0;
    private final int FIRST_ROUTE = 1;
    private Marker routeMarker;
    private int ROUTETIME = 300;

    private double latstart;
    private double lngstart;
    private double latend;
    private double lngend;

    private boolean loadFlag = true;

    private RoutePlanSearch routePlanSearch; //路线规划搜索接口
    // private int times = 0;

    private boolean isOneTimePlanFinish = true;

    private BaiduMap baiduMap;
    private final static int PROGRESS = 1234;
    private final static int PLAN_ROUTE_FINISH = 1235;
    private boolean isMoving = false;

    //定位
    private LocationClient locationClient;
    private double mLongitude;
    private double mLatitude;
    private boolean isFirst = true;
    private List<TraceJson.DataBean.LocusBean> userfulLocations;


    @Override
    protected int getContentViewLayoutID() {
        return R.layout.act_trace;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("车辆轨迹");
        initIntent();
        initView();
        initBaiduMap();
        initMap();
        getCurrentLocation();
        initListener();
        loadMapTrace();
    }

    private void initIntent() {
        userfulLocations = TraceDataHolder.getInstance().getData();
    }

    private void getCurrentLocation() {
        /*使用百度SDK获取经纬度*/
        locationClient = new LocationClient(getApplicationContext());
        LocationClientOption option = new LocationClientOption();
        option.setIsNeedAddress(true);
        option.setOpenGps(true);        //是否打开GPS
        option.setCoorType("bd09ll");       //设置返回值的坐标类型。
        option.setPriority(LocationClientOption.NetWorkFirst);  //设置定位优先级
        option.setProdName("Cocobee"); //设置产品线名称。强烈建议您使用自定义的产品线名称，方便我们以后为您提供更高效准确的定位服务。
        option.setScanSpan(30000);  //设置定时定位的时间间隔为20秒。单位毫秒
        locationClient.setLocOption(option);

        // 注册位置监听器
        locationClient.registerLocationListener(new BDLocationListener() {
            @Override
            public void onReceiveLocation(BDLocation location) {
                if (location == null) {
                    return;
                }

                mLongitude = location.getLongitude(); //获取经度
                mLatitude = location.getLatitude();
                if (isFirst) {
                    initMap();
                    isFirst = false;
                }
            }
        });
        locationClient.start();
        /*
         *当所设的整数值大于等于1000（ms）时，定位SDK内部使用定时定位模式。
         *调用requestLocation( )后，每隔设定的时间，定位SDK就会进行一次定位。
         *如果定位SDK根据定位依据发现位置没有发生变化，就不会发起网络请求，
         *返回上一次定位的结果；如果发现位置改变，就进行网络请求进行定位，得到新的定位结果。
         *定时定位时，调用一次requestLocation，会定时监听到定位结果。
         */
        locationClient.requestLocation();
    }


    private void initListener() {
        baiduMap.setOnMapStatusChangeListener(new BaiduMap.OnMapStatusChangeListener() {
            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus) {
                isMoving = true;
            }

            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus, int i) {

            }

            @Override
            public void onMapStatusChange(MapStatus mapStatus) {

            }

            @Override
            public void onMapStatusChangeFinish(MapStatus mapStatus) {
                isMoving = false;
            }
        });
    }

    private void initView() {
        mProgressBar1.setEnabled(false);
        mSpeedSb.setOnSeekBarChangeListener(onSeekBarChangeListener);
        routePlanSearch = RoutePlanSearch.newInstance(); //初始化路线规划检索对象
        routePlanSearch.setOnGetRoutePlanResultListener(this); //设置监听，接收规划结果

    }

    private void initBaiduMap() {
    /*隐藏百度地图logo*/
        View child = mMapView.getChildAt(1);
        if (child != null && (child instanceof ImageView || child instanceof ZoomControls)) {
            child.setVisibility(View.INVISIBLE);
        }
        baiduMap = mMapView.getMap(); //得到百度地图
        baiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL); //设置地图为正常模式
    }

    private void initMap() {
        //设定中心点坐标
        LatLng cenpt = new LatLng(mLatitude, mLongitude);
        //定义地图状态
        MapStatus mMapStatus = new MapStatus.Builder().target(cenpt).zoom(17).build();
        //定义MapStatusUpdate对象，以便描述地图状态将要发生的变化

        MapStatusUpdate mMapStatusUpdate = MapStatusUpdateFactory.newMapStatus(mMapStatus);
        //改变地图状态
        baiduMap.setMapStatus(mMapStatusUpdate);
    }


    SeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            stopTimer();
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            ROUTETIME = 500 - seekBar.getProgress();
        }
    };


    /**
     * 移动到指定位置 并缩放
     *
     * @param latlng
     */
    private void moveToLocation(LatLng latlng, boolean flag) {
        if (baiduMap == null || baiduMap.getMapStatus() == null) {
            return;
        }
        MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(latlng);// 设置新的中心点

        baiduMap.animateMapStatus(u);
        if (flag && baiduMap.getMapStatus().zoom < 12.0f) {
            // 加个延时播放的效果,就可以有先平移 ，再缩放的效果
            mTimer.start();
        }
    }

    private void stopTimer() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    private CountDownTimer mTimer = new CountDownTimer(2000, 2000) {
        @Override
        public void onTick(long millisUntilFinished) {
        }

        @Override
        public void onFinish() {
            if (baiduMap != null) {
                MapStatusUpdate u1 = MapStatusUpdateFactory.zoomTo(12.0f);
                baiduMap.animateMapStatus(u1);
            }
        }
    };

    private Handler handler = new Handler() {
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case ROUTE:
                    handler.sendEmptyMessage(PROGRESS);
                    if (routeIndex == planLatLngPolygons.size() - 1) {
                        routeFlag = false;
                        mLocationIvPlay.setImageResource(R.drawable.play1);
                        XToastUtils.showShortToast("播放完毕");
                        routeIndex = 0;
                        if (routeMarker != null) {
                            routeMarker.remove();
                            routeMarker = null;
                        }
                        addFinalPointIcon();

                        return;
                    }
                    if (routeIndex != 0) {
                        if (routeIndex == 1) { //起点
                            /**
                             * 创建自定义overlay
                             */
                            // 起点位置
                            LatLng geoPoint = new LatLng(latstart, lngstart);
                            // 构建Marker图标
                            BitmapDescriptor bitmap = BitmapDescriptorFactory.fromResource(R.drawable.ic_start);
                            // 构建MarkerOption，用于在地图上添加Marker
                            OverlayOptions option = new MarkerOptions().position(geoPoint).icon(bitmap).zIndex(8).draggable(true);

                            List<OverlayOptions> overlay = new ArrayList<OverlayOptions>();
                            overlay.add(option);
                            baiduMap.addOverlays(overlay);
                        } else {
                            OverlayOptions polyLine = new PolylineOptions().width(6).color(0xFF1694FF)
                                    .points(planLatLngPolygons.subList(routeIndex - 1, routeIndex + 1));

                            baiduMap.addOverlay(polyLine);
                        }

                    }
                    // 页面跟随移动,注掉这行就是在原图上绘制
                    if (routeIndex < planLatLngPolygons.size()) {
                        moveToLocation(planLatLngPolygons.get(routeIndex), false);

                        if (routeMarker == null) { //Marker在地图上移动
                            BitmapDescriptor currMarkerIcon = BitmapDescriptorFactory.fromResource(R.drawable.bike);

                            OverlayOptions cur = new MarkerOptions()
                                    .position(planLatLngPolygons.get(routeIndex++)).icon(currMarkerIcon)
                                    .perspective(false).anchor(0.5f, 0.5f).zIndex(10);
                            routeMarker = (Marker) baiduMap.addOverlay(cur);
                        } else {
                            routeMarker.setPosition(planLatLngPolygons.get(routeIndex++)); //不断地去改变marker的位置
                        }
                    }
                    handler.sendEmptyMessageDelayed(ROUTE, ROUTETIME);
                    break;

                case PROGRESS:
                    if (routeIndex == 0) {// 因为播放完毕时routeIndex被赋值成了0，不写进度条会直接跳到0的位置
                        mProgressBar1.setProgress(100);
                    } else {
                        mProgressBar1.setProgress((routeIndex + 1) * 100 / planLatLngPolygons.size());
                    }
                    break;

                case PLAN_ROUTE_FINISH:
                    mControlLl.setVisibility(View.VISIBLE);
                    routeFlag = false;
                    routeIndex = 0;
                    if (routeMarker != null) {
                        routeMarker.remove();
                        routeMarker = null;
                    }
                    if (planLatLngPolygons.size() >= 2) {
                        drawMyRoute(planLatLngPolygons);
                        XToastUtils.showShortToast("轨迹加载完毕");
                    } else {
                        XToastUtils.showShortToast("规划后坐标数少于2，无法加载路径");
                    }
                    break;

                case FIRST_ROUTE:

                    if (routeIndex == planLatLngPolygons.size() - 1) {
                        isOneTimePlanFinish = true;
                        return;
                    }

                    OverlayOptions polyLine = new PolylineOptions().width(6).color(0xFF1694FF).points(planLatLngPolygons.subList(routeIndex, routeIndex + 2));

                    baiduMap.addOverlay(polyLine);

                    // 页面跟随移动,注掉这行就是在原图上绘制
                    moveToLocation(planLatLngPolygons.get(routeIndex), false);

                    if (routeMarker == null) { //Marker在地图上移动
                        BitmapDescriptor currMarkerIcon = BitmapDescriptorFactory.fromResource(R.drawable.bike);
                        OverlayOptions cur = new MarkerOptions()
                                .position(planLatLngPolygons.get(routeIndex++)).icon(currMarkerIcon)
                                .perspective(false).anchor(0.5f, 0.5f).zIndex(10);
                        routeMarker = (Marker) baiduMap.addOverlay(cur);
                    } else {
                        routeMarker.setPosition(planLatLngPolygons.get(routeIndex++)); //不断地去改变marker的位置
                    }
                    handler.sendEmptyMessageDelayed(FIRST_ROUTE, 20);
                    break;
            }
        }
    };


    private void addFinalPointIcon() {
        if (planLatLngPolygons != null && planLatLngPolygons.size() > 0) {
            // 终点位置
            LatLng geoPoint1 = new LatLng(planLatLngPolygons.get(planLatLngPolygons.size() - 1).latitude, planLatLngPolygons.get(planLatLngPolygons.size() - 1).longitude);
            // 构建Marker图标
            BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromResource(R.drawable.ic_end);
            // 构建MarkerOption，用于在地图上添加Marker
            OverlayOptions option1 = new MarkerOptions().position(geoPoint1).icon(bitmap1).zIndex(8).draggable(true);
            baiduMap.addOverlay(option1);
        }
    }


    private void loadMapTrace() {
//        if (mTraceResponses != null && mTraceResponses.size() < 2) {
//            XToastUtils.showShortToast("当前坐标点数少于2，无法加载轨迹");
//            return;
//        }

//        //过滤掉空的经纬度
//        List<TraceJson.DataBean.LocusBean> userfulLocations = new ArrayList<>();
//
//        if (mTraceResponses != null && mTraceResponses.size() > 0) {
//            for (int i = 0; i < mTraceResponses.size(); i++) {
//                TraceJson.DataBean.LocusBean traceResponse = mTraceResponses.get(i);
//                if (!TextUtils.isEmpty(traceResponse.getEqLat()) && !TextUtils.isEmpty(traceResponse.getEqlng())) {
//                    userfulLocations.add(traceResponse);
//                }
//            }
//            for (int i = 0; i < userfulLocations.size(); i++) {
//                if (i != 0) {
//                    TraceJson.DataBean.LocusBean locusBean = userfulLocations.get(i);
//                    TraceJson.DataBean.LocusBean locusBean1 = userfulLocations.get(i - 1);
//                    if (CheckUtils.equalsString(locusBean.getEqLat(),locusBean1.getEqLat()) && CheckUtils.equalsString(locusBean.getEqlng(),locusBean1.getEqlng())){//与前一个经纬度相同
//                        userfulLocations.remove(i);
//                        i--;
//                    }
//                }
//            }
//        }


        if (userfulLocations != null && userfulLocations.size() < 2) {
            XToastUtils.showShortToast("当前坐标点数少于2，无法加载轨迹");
            return;
        }

        try {
            latstart = Double.parseDouble(userfulLocations.get(0).getEqLat());
            lngstart = Double.parseDouble(userfulLocations.get(0).getEqlng());
            latend = Double.parseDouble(userfulLocations.get(userfulLocations.size() - 1).getEqLat());
            lngend = Double.parseDouble(userfulLocations.get(userfulLocations.size() - 1).getEqlng());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        //创建自定义overlay
        // 起点位置
        LatLng geoPoint = new LatLng(latstart, lngstart);
        // 构建Marker图标
        BitmapDescriptor bitmap = BitmapDescriptorFactory.fromResource(R.drawable.ic_start);
        // 构建MarkerOption，用于在地图上添加Marker
        OverlayOptions option = new MarkerOptions().position(geoPoint).icon(bitmap).zIndex(8).draggable(true);

        // 终点位置
        LatLng geoPoint1 = new LatLng(latend, lngend);
        // 构建Marker图标
        BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromResource(R.drawable.ic_end);
        // 构建MarkerOption，用于在地图上添加Marker
        OverlayOptions option1 = new MarkerOptions().position(geoPoint1).icon(bitmap1).zIndex(8).draggable(true);
        // 在地图上添加Marker，并显示

        List<OverlayOptions> overlay = new ArrayList<OverlayOptions>();
        overlay.add(option);
        overlay.add(option1);
        baiduMap.addOverlays(overlay);

        locationWithoutSames.clear();
        for (TraceJson.DataBean.LocusBean l : userfulLocations) {
            if (!locationWithoutSames.contains(l)) {
                locationWithoutSames.add(l);
            }
        }

        //开启线程加载设备点
        setAllPoint();

        latLngPolygons.clear();
        double lat, lng;
        for (int k = 0; k < userfulLocations.size(); k++) {
            try {
                lat = Double.parseDouble(userfulLocations.get(k).getEqLat());
                lng = Double.parseDouble(userfulLocations.get(k).getEqlng());
                LatLng pt1 = new LatLng(lat, lng);
                latLngPolygons.add(pt1);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        // 百度最多支持10000个点连线
        if (latLngPolygons.size() > 10000) {
            latLngPolygons = latLngPolygons.subList(0, 10000);
        }

        loadFlag = true;

        if (latLngPolygons != null && latLngPolygons.size() > 1) {

            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (int i = 0; i < latLngPolygons.size() && loadFlag; i++) {
                        if (i != latLngPolygons.size() - 1) { //到达最后一个点时无需再做路径规划
                            PlanNode stNode = PlanNode.withLocation(latLngPolygons.get(i));
                            PlanNode enNode = PlanNode.withLocation(latLngPolygons.get(i + 1));
                            isOneTimePlanFinish = false;
                            routePlanSearch.walkingSearch(new WalkingRoutePlanOption().from(stNode).to(enNode)); //开始步行规划检索

                            while (!isOneTimePlanFinish) { //一次规划还没处理完，就不开始下次规划
                                System.out.println("##############");
                            }
                        }
                    }
                    handler.sendEmptyMessage(PLAN_ROUTE_FINISH);
                }
            }).start();
        }
    }


    /**
     * 根据数据绘制轨迹
     *
     * @param points2
     */
    protected void drawMyRoute(List<LatLng> points2) {
        if (points2 != null && points2.size() >= 2) {
            OverlayOptions options = new PolylineOptions().color(0xFF1694FF).width(6).points(points2);
            baiduMap.addOverlay(options);

            moveToLocation(points2.get(points2.size() / 2), true);
        }
    }

    @Override
    protected void onDestroy() {
        loadFlag = false;  //停止正在执行的线程
        handler.removeMessages(0);
        handler.removeMessages(1);
        stopTimer();

        if (routePlanSearch != null) { //销毁路径规划检索
            routePlanSearch.destroy();
            routePlanSearch = null;
        }


        if (baiduMap != null) { //关闭定位图层
            baiduMap.setMyLocationEnabled(false);
        }

        if (mMapView != null) {
            mMapView.onDestroy();
            mMapView = null;
        }

        //清掉轨迹数据
        TraceDataHolder.getInstance().setData(null);
        OkGo.getInstance().cancelTag(this);
        locationClient.stop();
//        AppManager.getAppManager().finishActivity(new WeakReference<Activity>(this));
        super.onDestroy();
    }

    //开始步行规划检索后，在此回调
    @Override
    public void onGetWalkingRouteResult(WalkingRouteResult walkingRouteResult) {
        if (walkingRouteResult == null || walkingRouteResult.error != SearchResult.ERRORNO.NO_ERROR) {
            isOneTimePlanFinish = true;
            return;  //未找到结果
        }

        if (walkingRouteResult.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
            // 起终点或途经点地址有岐义，通过以下接口获取建议查询信息
            // result.getSuggestAddrInfo()
            isOneTimePlanFinish = true;
            return;
        }

        if (walkingRouteResult.error == SearchResult.ERRORNO.NO_ERROR) {
            WalkingRouteLine routeLine = walkingRouteResult.getRouteLines().get(0); //如果有多种规划方案，直接获取第一种

            List<WalkingRouteLine.WalkingStep> walkingSteps = routeLine.getAllStep(); //获取所有路段信息
            for (int i = 0; i < walkingSteps.size(); i++) { //根据每个路段获取经纬度信息
                List<LatLng> latLngs = walkingSteps.get(i).getWayPoints();
                if (latLngs != null && latLngs.size() > 0) {
                    planLatLngPolygons.addAll(latLngs);
                }
            }
            handler.sendEmptyMessageDelayed(FIRST_ROUTE, 0);

        }

    }

    @Override
    public void onGetTransitRouteResult(TransitRouteResult transitRouteResult) {

    }

    @Override
    public void onGetMassTransitRouteResult(MassTransitRouteResult massTransitRouteResult) {

    }

    @Override
    public void onGetDrivingRouteResult(DrivingRouteResult drivingRouteResult) {

    }

    @Override
    public void onGetIndoorRouteResult(IndoorRouteResult indoorRouteResult) {

    }

    @Override
    public void onGetBikingRouteResult(BikingRouteResult bikingRouteResult) {

    }

    @OnClick({R.id.location_ivPlay, R.id.replay_btn, R.id.speed_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.location_ivPlay:
                if (latLngPolygons == null || latLngPolygons.size() <= 0) {
                    return;
                }
                routeFlag = !routeFlag;
                mLocationIvPlay.setImageResource(routeFlag ? R.drawable.pause1 : R.drawable.play1);

                if (routeFlag) {
                    if (routeIndex == 0) {
                        baiduMap.clear();
                        routeMarker = null;

                        //先把设备点标出来
                        //开启线程加载设备点
                        setAllPoint();
                    }
                    handler.sendEmptyMessageDelayed(ROUTE, 0);
                } else {
                    handler.removeMessages(0);
                }
                break;
            case R.id.replay_btn:
                if (latLngPolygons == null || latLngPolygons.size() <= 0) {
                    return;
                }
                handler.removeMessages(0);
                routeIndex = 0;
                routeFlag = true;
                baiduMap.clear();

                if (routeMarker != null) {
                    routeMarker.remove();
                    routeMarker = null;
                }
                mLocationIvPlay.setImageResource(R.drawable.pause1);
                loadFlag = true;
                //先把设备点标出来
                //开启线程加载设备点
                setAllPoint();

                handler.sendEmptyMessageDelayed(ROUTE, 0);
                break;
            case R.id.speed_btn:
                mSpeedSb.setVisibility(mSpeedSb.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
                break;
        }
    }

    /**
     * 加载设备点
     */
    private void setAllPoint() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                int i = 0;
                while (i < locationWithoutSames.size() && loadFlag) {

                    TraceJson.DataBean.LocusBean traceResponse = locationWithoutSames.get(i);
                    Double lat = null, lng = null;
                    if (!TextUtils.isEmpty(traceResponse.getEqLat())) {
                        lat = Double.valueOf(traceResponse.getEqLat());
                    }

                    if (!TextUtils.isEmpty(traceResponse.getEqlng())) {
                        lng = Double.valueOf(traceResponse.getEqlng());
                    }

                    BitmapDescriptor mCurrentMarker = BitmapDescriptorFactory.fromResource(R.drawable.online);

                    // 设置定位图层的配置（定位模式，是否允许方向信息，用户自定义定位图标）
                    LatLng geoPoint = new LatLng(lat, lng);

                    OverlayOptions option = new MarkerOptions().position(geoPoint).icon(mCurrentMarker).zIndex(8).draggable(true);
                    //options.add(option);
                    i++;
                    baiduMap.addOverlay(option);
                }
            }
        }).start();
    }
}
