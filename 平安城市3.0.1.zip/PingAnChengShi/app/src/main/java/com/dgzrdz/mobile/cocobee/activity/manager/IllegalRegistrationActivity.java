package com.dgzrdz.mobile.cocobee.activity.manager;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baoyz.actionsheet.ActionSheet;
import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.adapter.IdeaBackAdapter;
import com.dgzrdz.mobile.cocobee.adapter.ProblemSelectAdapter;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.StationProblemResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.GridItemDecoration;
import com.jzxiang.pickerview.TimePickerDialog;
import com.jzxiang.pickerview.data.Type;
import com.jzxiang.pickerview.listener.OnDateSetListener;
import com.lzy.okgo.OkGo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Administrator on 2018/1/18.
 */

public class IllegalRegistrationActivity extends BaseToolbarActivity implements OnDateSetListener {
    public static final int REQUEST_CODE_CAMERA = 1000;
    public static final int REQUEST_CODE_GALLERY = 1001;
    @BindView(R.id.tv_car_num)
    EditText mTvCarNum;
    @BindView(R.id.tv_reg_address)
    EditText mTvRegAddress;
    @BindView(R.id.tv_reg_time)
    EditText mTvRegTime;
    @BindView(R.id.tv_illegal_type)
    EditText mTvIllegalType;
    @BindView(R.id.tv_illegal_desc)
    EditText mTvIllegalDesc;
    @BindView(R.id.tv_text_num)
    TextView mTvTextNum;
    @BindView(R.id.recycle_view)
    RecyclerView mRecycleView;
    @BindView(R.id.iv_add_pic)
    ImageView mIvAddPic;
    @BindView(R.id.tv_illegal_upload)
    TextView mTvIllegalUpload;

    //定位
    private LocationClient locationClient;
    private String address;
    private boolean isFirst = true;


    private IllegalRegistrationActivity mContext;

    private TimePickerDialog mDialogAll;
    private TimePickerDialog.Builder timePickerBuilder;
    long tenYears = 10L * 365 * 1000 * 60 * 60 * 24L;
    private String mCno;

    private IdeaBackAdapter mAdapter;
    private ArrayList<PhotoInfo> mPhotoList = new ArrayList<>();
    private int camara_gallery = 0;// 1 拍照 2 相册
    private UserInfo mUserLoginInfo;
    private String mCid;

    private void initPickDialog() {
        timePickerBuilder = new TimePickerDialog.Builder()
                .setCallBack(this)
                .setCancelStringId("取消")
                .setSureStringId("确定")
                .setTitleStringId("请选择时间")
                .setYearText("年")
                .setMonthText("月")
                .setDayText("日")
                .setHourText("时")
                .setMinuteText("分")
                .setCyclic(false)
                .setMinMillseconds(System.currentTimeMillis() - 3 * tenYears)
                .setMaxMillseconds(System.currentTimeMillis())
                .setThemeColor(getResources().getColor(R.color.timepicker_dialog_bg))
                .setType(Type.ALL)
                .setWheelItemTextNormalColor(getResources().getColor(R.color.timetimepicker_default_text_color))
                .setWheelItemTextSelectorColor(getResources().getColor(R.color.timepicker_toolbar_bg))
                .setWheelItemTextSize(12);

        mDialogAll = timePickerBuilder.build();
    }

    private void initListener() {
        mTvIllegalDesc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String desc = mTvIllegalDesc.getText().toString().trim();
                mTvTextNum.setText(desc.length() + "/500");
                if (desc.length() > 500) {
                    XToastUtils.showShortToast("描述不能超过500字");
                    mTvIllegalDesc.setText(desc.substring(0, 501));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_illegal_registor;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("违章登记");
        mContext = this;
        mUserLoginInfo = Utils.getUserLoginInfo();
        // 默认软键盘不弹出
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        getCurrentLocation();
        initPickDialog();
        initIntent();
        initRecycleView();
        initListener();
    }

    /**
     * 初始化RecycleView
     */
    private void initRecycleView() {
        mAdapter = new IdeaBackAdapter(this, mPhotoList);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.HORIZONTAL);
        mRecycleView.setLayoutManager(layoutManager);
        mRecycleView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {

            }
        });
    }

    /**
     * 获取传过来的数据
     */
    private void initIntent() {
        Intent intent = getIntent();
        mCno = intent.getStringExtra("cno");
        mCid = intent.getStringExtra("cid");
        mTvCarNum.setText(mCno);
    }

    private void getCurrentLocation() {
        /*使用百度SDK获取经纬度*/
        locationClient = new LocationClient(mContext);
        LocationClientOption option = new LocationClientOption();
        option.setIsNeedAddress(true);
        //是否打开GPS
        option.setOpenGps(true);
        //设置返回值的坐标类型。
        option.setCoorType("bd09ll");
        //设置定位优先级
        option.setPriority(LocationClientOption.NetWorkFirst);
        //设置产品线名称。强烈建议您使用自定义的产品线名称，方便我们以后为您提供更高效准确的定位服务。
        option.setProdName("Cocobee");
        //设置定时定位的时间间隔为20秒。单位毫秒
        option.setScanSpan(30000);
        locationClient.setLocOption(option);

        // 注册位置监听器
        locationClient.registerLocationListener(new BDLocationListener() {
            @Override
            public void onReceiveLocation(BDLocation location) {
                if (location == null) {
                    return;
                }
                if (isFirst) {
                    //获取地址
                    address = location.getAddrStr();
                    mTvRegAddress.setText(address);
                    isFirst = false;
                }
            }
        });
        locationClient.start();
        /*
         *当所设的整数值大于等于1000（ms）时，定位SDK内部使用定时定位模式。
         *调用requestLocation( )后，每隔设定的时间，定位SDK就会进行一次定位。
         *如果定位SDK根据定位依据发现位置没有发生变化，就不会发起网络请求，
         *返回上一次定位的结果；如果发现位置改变，就进行网络请求进行定位，得到新的定位结果。
         *定时定位时，调用一次requestLocation，会定时监听到定位结果。
         */
        locationClient.requestLocation();
    }


    @OnClick({R.id.tv_reg_time, R.id.tv_illegal_type, R.id.iv_add_pic , R.id.tv_illegal_upload})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_reg_time:
                timePickerBuilder.setCurrentMillseconds(System.currentTimeMillis());
                timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());

                if (!mDialogAll.isAdded()) {
                    mDialogAll.show(getSupportFragmentManager(), "all");
                }
                break;
            case R.id.tv_illegal_type://违章类别
                getIllegalRegiType();
                break;
            case R.id.iv_add_pic://添加图片
                showOpen();
                break;
            case R.id.tv_illegal_upload://违章上传
                check();
                break;
        }
    }

    /**
     * 验证上传参数
     */
    private void check() {
        String address = mTvRegAddress.getText().toString().trim();
        String time = mTvRegTime.getText().toString().trim();
        String illegalType = mTvIllegalType.getText().toString().trim();
        String illegalDesc = mTvIllegalDesc.getText().toString().trim();
        if (CheckUtils.isEmpty(address)){
            XToastUtils.showShortToast("请输入违章地点");
        }else if (CheckUtils.isEmpty(time)){
            XToastUtils.showShortToast("请选择违章时间");
        }else if (CheckUtils.isEmpty(illegalType)){
            XToastUtils.showShortToast("请选择违章类型");
        }else if (CheckUtils.isEmpty(illegalDesc)){
            XToastUtils.showShortToast("请输入违章描述");
        }else {
            illegalUpload(address , time , illegalType , illegalDesc);
        }

    }

    /**
     * 上传违章信息
     * @param address
     * @param time
     * @param illegalType
     * @param illegalDesc
     */
    private void illegalUpload(String address, String time, String illegalType, String illegalDesc) {
        Map<String, String> params = new HashMap<>();
        params.put("cid", mCid);
        params.put("status",illegalType);
        params.put("remarks", illegalDesc);
        params.put("address", address);
        params.put("violationtime", time);
//        params.put("creator", mUserLoginInfo.getPid());
        if (mPhotoList.size() > 0) {
            String url = "";
            for (int i = 0; i < mPhotoList.size(); i++) {
                if (i == mPhotoList.size() - 1) {
                    url += Utils.base64Pic(this ,mPhotoList.get(i).getPhotoPath());
                } else {
                    url += Utils.base64Pic(this ,mPhotoList.get(i).getPhotoPath()) + ",";
                }
            }
            params.put("photourl" , url);
        }


        OkGo.post(Path.UPLOAD_ILLEGAL_INFO).params(params).execute(new DialogCallback<Object>(this, "违章信息上传中...") {

            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("登记成功");
                finish();
            }

        });
    }

    /**
     * 获取违章类型
     */
    private void getIllegalRegiType() {
        OkGo.post(Path.GET_ILLEGAL_TYPE).execute(new DialogCallback<List<StationProblemResponse>>(this, "违章类型获取中...") {

            @Override
            public void onSuccess(List<StationProblemResponse> stationProblemResponses, Call call, Response response) {
                if (stationProblemResponses != null && stationProblemResponses.size() > 0) {
                    showProblemSelectDialog(stationProblemResponses);
                }
            }

        });
    }

    /**
     * 显示违章类型选择框
     *
     * @param stationProblemResponses
     */
    private void showProblemSelectDialog(List<StationProblemResponse> stationProblemResponses) {
        View view1 = View.inflate(IllegalRegistrationActivity.this, R.layout.select_illegal_type, null);
        AlertDialog alertDialog = Utils.showCornerDialog(IllegalRegistrationActivity.this, view1, 270, 320);
        RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.recycle_view);
        TextView tvUploadNow = (TextView) alertDialog.findViewById(R.id.tv_upload_now);
        TextView tvCancel = (TextView) alertDialog.findViewById(R.id.tv_cancel);
        ProblemSelectAdapter adapter = new ProblemSelectAdapter(this, stationProblemResponses);
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new GridItemDecoration(this));
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        tvUploadNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = "";
                for (int i = 0; i < stationProblemResponses.size(); i++) {
                    StationProblemResponse stationProblemResponse = stationProblemResponses.get(i);
                    if (stationProblemResponse.getSelect()) {
                        if (CheckUtils.isEmpty(name)) {
                            name += stationProblemResponse.getName();
                        } else {
                            name += "," + stationProblemResponse.getName();
                        }
                    }
                }
                if (CheckUtils.isEmpty(name)) {
                    XToastUtils.showShortToast("请选择基站问题");
                    return;
                }
                mTvIllegalType.setText(name);
                alertDialog.dismiss();
            }
        });

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

    }


    /**
     * 显示拍照选项
     */
    private void showOpen() {
        ActionSheet.createBuilder(this, getSupportFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("打开相册(Open Gallery)", "拍照(Camera)")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                camara_gallery = 2;
                                if (requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_CODE_GALLERY, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openGalleryMuti(REQUEST_CODE_GALLERY, 3 - mPhotoList.size(), mOnHanlderResultCallback);
                                }
                                break;
                            case 1:
                                camara_gallery = 1;
                                String[] permissions = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                                if (requestPermission(permissions[0], REQUEST_CODE_CAMERA, "权限申请：\n我们需要您开启拍照权限") && requestPermission(permissions[1], REQUEST_CODE_GALLERY, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openCamera(REQUEST_CODE_CAMERA, mOnHanlderResultCallback);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }).show();

    }

    /**
     * 返回true表示已经有权限了
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    private boolean requestPermission(String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(this, permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(this)
                        .setMessage(info)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(IllegalRegistrationActivity.this, new String[]{permissions}, requestCode);
                            }
                        })
                        .show();
            } else {
                ActivityCompat.requestPermissions(IllegalRegistrationActivity.this, new String[]{permissions}, requestCode);
            }
            return false;
        }
        return true;
    }

    /**
     * 拍照,相册选择后回调
     */
    private GalleryFinal.OnHanlderResultCallback mOnHanlderResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
            if (resultList != null) {
                mPhotoList.addAll(resultList);
                mAdapter.notifyDataSetChanged();
                if (mPhotoList.size() > 2) {
                    mIvAddPic.setVisibility(View.GONE);
                } else {
                    mIvAddPic.setVisibility(View.VISIBLE);
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            XToastUtils.showShortToast(errorMsg);
        }
    };

    /**
     * 使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_CODE_GALLERY, "权限申请：\n我们需要您开启设备存储权限")) {
                        GalleryFinal.openCamera(REQUEST_CODE_GALLERY, mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启拍照权限,是否去设置?", "用户拒绝拍照授权");
                }
                break;
            case REQUEST_CODE_GALLERY:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (camara_gallery == 1) {
                        if (requestPermission(Manifest.permission.CAMERA, REQUEST_CODE_CAMERA, "权限申请：\n我们需要您开启拍照权限")) {
                            GalleryFinal.openCamera(REQUEST_CODE_CAMERA, mOnHanlderResultCallback);
                        }
                    } else if (camara_gallery == 2) {
                        GalleryFinal.openGalleryMuti(REQUEST_CODE_GALLERY, 3 - mPhotoList.size(), mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启设备存储权限,是否去设置?", "用户拒绝设备存储授权");
                }
                break;
            default:
                break;
        }
    }

    /**
     * 判断用户是否点击过不再提醒
     *
     * @param
     * @param permission
     */
    private void sureIfNotNotifiy(String permission, String msg, String toast) {
        //点击了不在提醒
        if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            new AlertDialog.Builder(this)
                    .setMessage(msg)
                    .setPositiveButton("设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .create()
                    .show();
        } else {
            XToastUtils.showShortToast(toast);
        }
    }

    @Override
    public void onDateSet(TimePickerDialog timePickerView, long millseconds) {
        mTvRegTime.setText(getDateToString(millseconds));
    }

    public String getDateToString(long time) {
        Date d = new Date(time);
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sf.format(d);
    }

    @Override
    protected void onDestroy() {
        mOnHanlderResultCallback = null;
        super.onDestroy();
    }
}
