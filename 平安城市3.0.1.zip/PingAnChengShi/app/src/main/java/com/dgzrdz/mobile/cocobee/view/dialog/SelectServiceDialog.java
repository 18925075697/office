package com.dgzrdz.mobile.cocobee.view.dialog;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.PolicyServiceAdapter;
import com.dgzrdz.mobile.cocobee.adapter.TagServiceAdapter1;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.ComputeResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;
import com.dgzrdz.mobile.cocobee.response.ServiceResponse;
import com.dgzrdz.mobile.cocobee.response.TagServiceResponse;
import com.dgzrdz.mobile.cocobee.response.TagServiceTaocanResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;
import com.dgzrdz.mobile.cocobee.view.MyLinearLayoutManager;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 选择服务弹框
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  15:15
 */
public class SelectServiceDialog extends DialogFragment {
    @BindView(R.id.tv_org_name)
    TextView mTvOrgName;
    @BindView(R.id.iv_close_dialog)
    ImageView mIvCloseDialog;
    @BindView(R.id.tv_car_type)
    TextView mTvCarType;
    @BindView(R.id.tv_phone)
    TextView mTvPhone;
    @BindView(R.id.recycle_view_tag)
    RecyclerView mRecycleViewTag;
    @BindView(R.id.recycle_view_policy)
    RecyclerView mRecycleViewPolicy;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.ll_sure_service)
    LinearLayout mLlSureService;
    private Unbinder mBind;
    private List<TagServiceResponse> tagListUI = new ArrayList<>();//标签服务集合(显示)
    private List<TagServiceTaocanResponse> mTagServiceTaocanResponses = new ArrayList<>();//标签服务套餐集合
    private List<PolicyServiceResponse> policyList = new ArrayList<>();//保险服务集合
    private List<Integer> selectPosition = new ArrayList<>();//选中位置的集合
    private TagServiceAdapter1 mTagAdapter;
    private PolicyServiceAdapter mPolicyServiceAdapter;
    private double taocanPrice;
    private double baoxianPrice;

    private String jsonUITag = "[{ \"serviceTypeList\": [{\"name\": \"1年\",\"id\":\"1\" },{\"name\": \"2年\",\"id\":\"2\"}," +
            "{\"name\": \"3年\",\"id\":\"3\" }],\"title\": \"年限\"},{\"serviceTypeList\": [{\"name\": \"无话费\", \"id\":\"4\"}," +
            "{\"name\": \"老卡套餐\", \"id\":\"5\"},{\"name\": \"新卡套餐\",\"id\":\"6\"}], \"title\": \"话费\"}," +
            "{\"serviceTypeList\": [{ \"name\": \"100M\", \"id\":\"7\" },{ \"name\": \"200M\",\"id\":\"8\"}],\"title\": \"宽带\"}]";

    private String jsonTaocanTag = "[{\"ids\": \"1,5,7\", \"kuandai\": \"100M\", \"taocan\": \"老卡套餐\", \"year\": \"1年\", \"price\": 100 }," +
            "{\"ids\": \"1,6,7\",\"kuandai\": \"100M\",\"taocan\": \"新卡套餐\", \"year\": \"1年\", \"price\": 200 }," +
            "{ \"ids\": \"1,5,8\",\"kuandai\": \"200M\",\"taocan\": \"老卡套餐\",\"year\": \"1年\" , \"price\": 300 }," +
            "{\"ids\": \"2,4,7\",\"kuandai\": \"100M\", \"taocan\": \"无话费\",\"year\": \"2年\", \"price\": 400 }," +
            "{\"ids\": \"2,4,8\",\"kuandai\": \"200M\",\"taocan\": \"无话费\", \"year\": \"2年\", \"price\": 500 }," +
            "{ \"ids\": \"2,5,7\",\"kuandai\": \"100M\", \"taocan\": \"老卡套餐\",\"year\": \"2年\", \"price\": 600 }," +
            "{\"ids\": \"3,4,7\",\"kuandai\": \"100M\",\"taocan\": \"无话费\", \"year\": \"3年\" , \"price\": 700 }," +
            "{ \"ids\": \"3,6,7\", \"kuandai\": \"100M\",\"taocan\": \"新卡套餐\",\"year\": \"3年\", \"price\": 800  }]";

    private TagServiceTaocanResponse selectTaocanResponse;
    private UserInfo mUserLoginInfo;
    private UserBeanResponse mUserBeanResponse;
    private GuardianObjectResponse mGuardianObjectResponse;
    private ComputeResponse mComputeResponse;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.MyDialog);
    }

    /**
     * 设置选中的车主信息
     *
     * @param userBeanResponse
     */
    public void setUserBeanResponse(UserBeanResponse userBeanResponse) {
        mUserBeanResponse = userBeanResponse;
    }

    /**
     * 设置选中的监护对象信息
     *
     * @param guardianObjectResponse
     */
    public void setGuardianObjectResponse(GuardianObjectResponse guardianObjectResponse) {
        mGuardianObjectResponse = guardianObjectResponse;
    }

    /**
     * 设置集团信息
     *
     * @param computeResponse
     */
    public void setGroupResponse(ComputeResponse computeResponse) {
        mComputeResponse = computeResponse;
    }

    /**
     * 设置服务套餐信息
     *
     * @param tagServiceTaocanResponses
     * @param selectPositions
     * @param policyLists
     * @param tagList
     * @param selectTaocanResponse1
     */
    public void setServiceInfo(List<TagServiceTaocanResponse> tagServiceTaocanResponses, List<Integer> selectPositions, List<PolicyServiceResponse> policyLists, List<TagServiceResponse> tagList, TagServiceTaocanResponse selectTaocanResponse1) {
        mTagServiceTaocanResponses.clear();
        mTagServiceTaocanResponses.addAll(tagServiceTaocanResponses);

        selectPosition.clear();
        selectPosition.addAll(selectPositions);

        policyList.clear();
        policyList.addAll(policyLists);

        tagListUI.clear();
        tagListUI.addAll(tagList);

        selectTaocanResponse = selectTaocanResponse1;
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = Utils.getScreenWidth();
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.windowAnimations = R.style.DialogAnimation;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_select_service, container);
        mBind = ButterKnife.bind(this, view);
        mUserLoginInfo = Utils.getUserLoginInfo();
        setView();
        initTagRecycleView();
        initPolicyRecycleView();
        if (selectTaocanResponse != null) {//已经选过了,这次回显
            mTagAdapter.notifyDataSetChanged();
            mPolicyServiceAdapter.notifyDataSetChanged();
            getSelectTaocan();
            getSelectPolicy();
        } else {
            getData();
        }
        return view;
    }

    /**
     * 设置选中服务弹框的组织机构,电话等
     */
    private void setView() {
        mTvOrgName.setText("当前机构:" + mUserLoginInfo.getDataList().getSysAreaName());
        mTvCarType.setText(mGuardianObjectResponse.getSysServiceTypeName());
        if (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) && CheckUtils.isEmpty(mUserBeanResponse.getSysProName())
                && CheckUtils.isEmpty(mUserBeanResponse.getSysCityName())) {//运营商,省市均为空
            mTvPhone.setText(mUserBeanResponse.getMemberAccount());
        } else {
            mTvPhone.setText(mUserBeanResponse.getMemberAccount() + "("
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) ? "" : mUserBeanResponse.getSysMobileName())
                    + " " + (CheckUtils.isEmpty(mUserBeanResponse.getSysProName()) ? "" : mUserBeanResponse.getSysProName())
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysCityName()) ? "" : mUserBeanResponse.getSysCityName())
                    + ")");
        }
    }

    /**
     * 获取服务
     */
    private void getData() {
        String groupId = "";
        if (mComputeResponse != null) {
            groupId = mComputeResponse.getSysGroupId();
        }
        PayApiUtils.getService(getContext(), mUserLoginInfo.getDataList().getAppMemberId(), mUserBeanResponse.getMemberId(), mGuardianObjectResponse.getSysServiceTypeId(), mUserLoginInfo.getDataList().getSysAreaId(), groupId, new JsonCallback<ServiceResponse>(getContext()) {
            @Override
            public void onSuccess(ServiceResponse serviceResponse, Call call, Response response) {
                if (serviceResponse != null) {
                    List<TagServiceResponse> tagServiceResponses = serviceResponse.getSetsShowList();
                    List<PolicyServiceResponse> insShowList = serviceResponse.getInsShowList();
                    List<TagServiceTaocanResponse> valueList = serviceResponse.getValueList();
                    tagListUI.clear();
                    mTagServiceTaocanResponses.clear();
                    policyList.clear();
                    if (tagServiceResponses != null && tagServiceResponses.size() > 0) {
                        tagListUI.addAll(tagServiceResponses);
                    } else {
                        XToastUtils.showShortToast("暂未配置标签服务套餐");
                        dismiss();
                    }
                    if (valueList != null) {
                        mTagServiceTaocanResponses.addAll(valueList);
                    }
                    if (insShowList != null) {
                        //保险价格为0,默认选中第一个为0的
                        for (int i = 0; i < insShowList.size(); i++) {
                            PolicyServiceResponse policyServiceResponse = insShowList.get(i);
                            if (policyServiceResponse != null) {
                                List<PolicyServiceResponse.PolicyServiceTypeListBean> serviceTypeList = policyServiceResponse.getServiceTypeList();
                                if (serviceTypeList == null)
                                    break;
                                for (int j = 0; j < serviceTypeList.size(); j++) {
                                    PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = serviceTypeList.get(j);
                                    if (policyServiceTypeListBean.getSysInsurancePrice() == 0) {
                                        policyServiceResponse.setPosition(j);//第i层选中第j条
                                        policyServiceTypeListBean.setSelect(j);
                                        break;
                                    }
                                }
                            }
                        }

                        policyList.addAll(insShowList);
                    }

                    initData();
                }
            }
        });
    }

    private void initData() {
        for (int i = 0; i < tagListUI.size(); i++) {
            selectPosition.add(-1);
        }
        mTagAdapter.notifyDataSetChanged();
        mPolicyServiceAdapter.notifyDataSetChanged();
    }

    /**
     * 初始化RecycleView
     */
    private void initTagRecycleView() {
        mRecycleViewTag.setLayoutManager(new MyLinearLayoutManager(getContext()));
        mTagAdapter = new TagServiceAdapter1(getContext(), tagListUI);
        mRecycleViewTag.setAdapter(mTagAdapter);
        mTagAdapter.setTagItemOnClickListener(new TagServiceAdapter1.TagItemOnClick() {
            @Override
            public void onItemClick(int position, int positions) {
                TagServiceResponse tagServiceResponse = tagListUI.get(position);
                tagServiceResponse.setPosition(positions);

                List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = tagServiceResponse.getServiceTypeList();
                TagServiceResponse.ServiceTypeListBean serviceTypeListBean1 = serviceTypeList.get(positions);
                if (!serviceTypeListBean1.isEnable()) {
                    return;
                }

                for (int j = 0; j < serviceTypeList.size(); j++) {
                    TagServiceResponse.ServiceTypeListBean serviceTypeListBean = serviceTypeList.get(j);
                    if (j == positions && serviceTypeListBean.getSelect() == positions) {//点击的条目原来是选中的,取消选中
                        tagServiceResponse.setPosition(-1);
                    }
                }

                //sku选择逻辑
                checkEnable(position, positions);

                for (int j = 0; j < serviceTypeList.size(); j++) {
                    TagServiceResponse.ServiceTypeListBean serviceTypeListBean = serviceTypeList.get(j);
                    if (j == positions && serviceTypeListBean.getSelect() == positions) {//点击的条目原来是选中的,取消选中
                        serviceTypeListBean.setSelect(-1);
                        selectPosition.set(position, -1);
                        tagServiceResponse.setPosition(-1);
                    } else if (j == positions) {
                        serviceTypeListBean.setSelect(positions);
                        selectPosition.set(position, positions);
                    } else {
                        serviceTypeListBean.setSelect(-1);
                    }
                }
                mTagAdapter.notifyDataSetChanged();
                //得到选择的套餐
                String selectTaocan = getSelectTaocan();
            }
        });
    }

    private void initPolicyRecycleView() {
        //保险服务列表
        mRecycleViewPolicy.setLayoutManager(new MyLinearLayoutManager(getContext()));
        mPolicyServiceAdapter = new PolicyServiceAdapter(getContext(), policyList);
        mRecycleViewPolicy.setAdapter(mPolicyServiceAdapter);
        mPolicyServiceAdapter.setPolicyItemOnClickListener(new PolicyServiceAdapter.PolicyItemOnClick() {
            @Override
            public void onItemClick(int position, int positions) {
                PolicyServiceResponse policyServiceResponse = policyList.get(position);
                policyServiceResponse.setPosition(positions);
                List<PolicyServiceResponse.PolicyServiceTypeListBean> policyServiceTypeList = policyServiceResponse.getServiceTypeList();
                for (int i = 0; i < policyServiceTypeList.size(); i++) {
                    PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceTypeList.get(i);
                    if (i == positions && policyServiceTypeListBean.getSelect() == positions) {//点击的条目原来是选中的,取消选中
                        policyServiceTypeListBean.setSelect(-1);
                        policyServiceResponse.setPosition(-1);
                    } else if (i == positions) {
                        policyServiceTypeListBean.setSelect(positions);
                    } else {
                        policyServiceTypeListBean.setSelect(-1);
                    }
                }

                mPolicyServiceAdapter.notifyDataSetChanged();

                //得到选中的保险
                getSelectPolicy();
            }
        });
    }

    /**
     * 获取选中的保险
     */
    private void getSelectPolicy() {
        String selectId = "";
        double price = 0;
        for (int i = 0; i < policyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = policyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                //                selectId = selectId + policyServiceTypeListBean.get() + ",";
                price = price + policyServiceTypeListBean.getSysInsurancePrice();
            }
        }
        if (!CheckUtils.isEmpty(selectId)) {
            selectId = selectId.substring(0, selectId.length() - 1);
        }
        baoxianPrice = price;
        mMtvPayNum.setAmount(taocanPrice + baoxianPrice);
    }

    /**
     * 获取选中的套餐
     */
    private String getSelectTaocan() {
        String selectId = "";
        for (int i = 0; i < tagListUI.size(); i++) {
            TagServiceResponse tagServiceResponse = tagListUI.get(i);
            if (tagServiceResponse.getPosition() != -1) {//有选中的
                String id = tagServiceResponse.getServiceTypeList().get(tagServiceResponse.getPosition()).getId();
                selectId = selectId + id + ",";
            }
        }
        if (!CheckUtils.isEmpty(selectId)) {
            selectId = selectId.substring(0, selectId.length() - 1);
        }
        boolean isTaocanOk = false;
        for (int i = 0; i < mTagServiceTaocanResponses.size(); i++) {
            TagServiceTaocanResponse tagServiceTaocanResponse = mTagServiceTaocanResponses.get(i);
            if (CheckUtils.equalsString(tagServiceTaocanResponse.getIds(), selectId)) {
                taocanPrice = tagServiceTaocanResponse.getPrice();
                isTaocanOk = true;
                selectTaocanResponse = tagServiceTaocanResponse;
            }
        }
        //没有对应的套餐,价格清零
        if (!isTaocanOk) {
            taocanPrice = 0;
            selectTaocanResponse = null;
        }

        mMtvPayNum.setAmount(taocanPrice + baoxianPrice);
        return selectId;
    }


    /**
     * 检查是否可用
     *
     * @param position  外层position
     * @param positions 内层position
     */
    private void checkEnable(int position, int positions) {
        List<String> notSelectList = new ArrayList<>();//不可选集合

        //点击的条目是原来没有点击过的,如果点击过就是取消选中,不需要获取不可选集合
        if (selectPosition.get(position) != positions) {
            //获取不可选id集合
            String selectId = tagListUI.get(position).getServiceTypeList().get(positions).getId();//点击的id
            List<String> notSelectList1 = getNotSelectList(selectId, position);
            notSelectList.addAll(notSelectList1);
        }

        //获取除点击行外其他行的不可选id
        for (int i = 0; i < tagListUI.size(); i++) {
            if (i != position) {//除点击那行外其他行
                TagServiceResponse tagServiceResponse = tagListUI.get(i);
                int position1 = tagServiceResponse.getPosition();
                if (position1 != -1) {//有选中的条目
                    //获取不可选id集合
                    String selectId = tagServiceResponse.getServiceTypeList().get(position1).getId();//点击的id
                    List<String> notSelectList1 = getNotSelectList(selectId, i);
                    notSelectList.addAll(notSelectList1);
                }
            }
        }


        List<String> idNoSelectList = getMoreNotSelect();

        for (int i = 0; i < idNoSelectList.size(); i++) {
            if (!notSelectList.contains(idNoSelectList.get(i))) {
                notSelectList.add(idNoSelectList.get(i));
            }
        }

        //设置UI可选或不可选
        for (int i = 0; i < tagListUI.size(); i++) {
            if (i != position) {//点击的这行不用比
                List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = tagListUI.get(i).getServiceTypeList();
                for (int j = 0; j < serviceTypeList.size(); j++) {
                    TagServiceResponse.ServiceTypeListBean serviceTypeListBean = serviceTypeList.get(j);
                    if (notSelectList.contains(serviceTypeListBean.getId())) {//集合中不包含就可选,包含就不可选
                        serviceTypeListBean.setEnable(false);
                    } else {
                        serviceTypeListBean.setEnable(true);
                    }
                }

            }
        }
        mTagAdapter.notifyDataSetChanged();
    }

    @NonNull
    private List<String> getMoreNotSelect() {


        List<String> idSelectList = new ArrayList<>();//选中id的集合
        List<String> idNoSelectList = new ArrayList<>();//未选中层的所有id的集合
        for (int i = 0; i < tagListUI.size(); i++) {
            TagServiceResponse tagServiceResponse = tagListUI.get(i);
            if (tagServiceResponse.getPosition() != -1) {
                TagServiceResponse.ServiceTypeListBean serviceTypeListBean = tagServiceResponse.getServiceTypeList().get(tagServiceResponse.getPosition());
                idSelectList.add(serviceTypeListBean.getId());
            } else {
                List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = tagServiceResponse.getServiceTypeList();
                for (int j = 0; j < serviceTypeList.size(); j++) {
                    idNoSelectList.add(serviceTypeList.get(j).getId());
                }
            }
        }

        //获取所有选中的不可选
        for (int i = 0; i < mTagServiceTaocanResponses.size(); i++) {
            TagServiceTaocanResponse tagServiceTaocanResponse = mTagServiceTaocanResponses.get(i);
            String ids = tagServiceTaocanResponse.getIds();
            String[] idArr = ids.split(",");
            List<String> idList = new ArrayList<>();//套餐id的集合
            for (int j = 0; j < idArr.length; j++) {
                idList.add(idArr[j]);
            }

            //获取选中id集合
            if (idList.containsAll(idSelectList)) {//套餐里面包含有选中id的情况下
                idList.removeAll(idSelectList);
                for (int j = 0; j < idList.size(); j++) {
                    String s = idList.get(j);
                    if (idNoSelectList.contains(s)) {
                        idNoSelectList.remove(s);
                    }
                }
            }
        }
        return idNoSelectList;
    }

    /**
     * 获取指定id的不可选集合
     *
     * @param selectId 选中的id
     * @param position 外层位置
     * @return
     */
    private List<String> getNotSelectList(String selectId, int position) {
        List<String> canSelectList = new ArrayList<>();//可选集合
        //点击id的其它层全部id集合
        List<String> idAllList = getAllIdList(position);

        //得到可选id集合
        for (int i = 0; i < mTagServiceTaocanResponses.size(); i++) {
            TagServiceTaocanResponse tagServiceTaocanResponse = mTagServiceTaocanResponses.get(i);
            String ids = tagServiceTaocanResponse.getIds();
            String[] idArr = ids.split(",");
            List<String> idList = new ArrayList<>();//套餐id的集合
            for (int j = 0; j < idArr.length; j++) {
                idList.add(idArr[j]);
            }

            if (idList.contains(selectId)) {//套餐里面包含有选中id的情况下
                idList.remove(selectId);
                for (int j = 0; j < idList.size(); j++) {
                    String s = idList.get(j);
                    if (!canSelectList.contains(s)) {
                        canSelectList.add(s);
                    }
                }
            }
        }
        //所有id集合移除可选id集合剩余不可选id集合
        idAllList.removeAll(canSelectList);
        return idAllList;
    }

    /**
     * 获取除指定外层的其他层所有id集合
     *
     * @param position
     * @return
     */
    @NonNull
    private List<String> getAllIdList(int position) {
        List<String> idAllList = new ArrayList<>();//点击id的其它层全部id集合
        for (int i = 0; i < tagListUI.size(); i++) {
            if (i != position) {
                TagServiceResponse tagServiceResponse = tagListUI.get(i);
                List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = tagServiceResponse.getServiceTypeList();
                for (int j = 0; j < serviceTypeList.size(); j++) {
                    idAllList.add(serviceTypeList.get(j).getId());
                }
            }
        }
        return idAllList;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        OkGo.getInstance().cancelTag(this);
        mBind.unbind();
    }

    @OnClick({R.id.iv_close_dialog, R.id.ll_sure_service})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_close_dialog:
                dismiss();
                break;
            case R.id.ll_sure_service:
                sure();
                break;
        }
    }

    /**
     * 确定
     */
    private void sure() {
        for (int i = 0; i < tagListUI.size(); i++) {
            TagServiceResponse tagServiceResponse = tagListUI.get(i);
            if (tagServiceResponse.getPosition() == -1) {
                XToastUtils.showShortToast("请选择服务");
                return;
            }
        }


        Intent intent = new Intent();
        intent.putExtra("selectTaocanResponse", selectTaocanResponse);
        intent.putExtra("policyList", (Serializable) policyList);
        intent.putExtra("tagListUI", (Serializable) tagListUI);
        intent.putExtra("tagServiceTaocanResponses", (Serializable) mTagServiceTaocanResponses);//套餐的集合
        intent.putExtra("selectPosition", (Serializable) selectPosition);//选中位置的集合

        EventBus.getDefault().post(new EventManager(EventConstants.SERVICE_SELECT_SUCCESS, intent));
        dismiss();

    }
}
