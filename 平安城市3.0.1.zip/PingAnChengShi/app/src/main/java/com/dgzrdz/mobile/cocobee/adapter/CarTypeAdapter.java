package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.CarTypeResponse;

import java.util.List;

/**
 * Created by Administrator on 2017/5/5.
 */

public class CarTypeAdapter extends QuickRcvAdapter<CarTypeResponse> {

    public CarTypeAdapter(Context context, List data, int... layoutId) {
        super(context, data, R.layout.item_car_type);
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, CarTypeResponse item) {
        viewHolder.setText(R.id.tv_car_type,item.getSysServiceTypeName());
    }
}
