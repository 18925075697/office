package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.CarBrandAdapter;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.PinyinComparator;
import com.dgzrdz.mobile.cocobee.response.SysPropertyOptionListBean;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Description: 车辆品牌
 * Author: Liubingren
 * Data:  2018/6/28
 * Time:  17:50
 */

public class CarBrandFragment extends RefreshAndLoadFragment<SysPropertyOptionListBean> {

    private static String title;
    @BindView(R.id.search_et_input)
    EditText mSearchEtInput;
    @BindView(R.id.search_iv_delete)
    ImageView mSearchIvDelete;

    private static List<SysPropertyOptionListBean> sysPropertyOptionList;
    private CarBrandAdapter mAdapter;

    public static CarBrandFragment getInstance(List<SysPropertyOptionListBean> sysPropertyOptionList, String title) {
        CarBrandFragment.sysPropertyOptionList = sysPropertyOptionList;
        CarBrandFragment.title = title;
        return new CarBrandFragment();
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_car_brand;
    }

    @Override
    public QuickRcvAdapter<SysPropertyOptionListBean> getAdapter() {
        return mAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public boolean canRefresh() {
        return false;
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        mList.clear();
        String value = mSearchEtInput.getText().toString().trim();
        if (CheckUtils.isEmpty(value)) {
            mList.addAll(sysPropertyOptionList);
        } else {
            for (int i = 0; i < sysPropertyOptionList.size(); i++) {
                SysPropertyOptionListBean sysPropertyOptionListBean = sysPropertyOptionList.get(i);
                if (sysPropertyOptionListBean.getSysPropertyOptionValue().contains(value)
                        || CheckUtils.equalsString(sysPropertyOptionListBean.getSysPropertyOptionChar().toUpperCase(),value.toUpperCase())) {//包含就添加
                    mList.add(sysPropertyOptionListBean);
                }
            }
        }
        PinyinComparator comparator = new PinyinComparator();
        Collections.sort(mList, comparator);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoadMore() {

    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mAdapter = new CarBrandAdapter(_mActivity, mList);
        initEditText();
    }


    @Override
    protected void initToolbarHere() {
        initToolbar(title);
    }

    @OnClick({R.id.search_iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.search_iv_delete:
                mSearchEtInput.setText("");
                mSearchIvDelete.setVisibility(View.GONE);
                break;
        }
    }

    private void initEditText() {
        mSearchEtInput.setHint("输入拼音首字母或汉字搜索");
        mSearchEtInput.addTextChangedListener(new EditChangedListener());

        //响应回车键
        mSearchEtInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    notifyStartSearching();
                }
                return true;
            }
        });
    }

    private class EditChangedListener implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (!"".equals(charSequence.toString())) {
                mSearchIvDelete.setVisibility(View.VISIBLE);
            } else {
                mSearchIvDelete.setVisibility(View.GONE);
                notifyStartSearching();
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    }

    /**
     * 通知监听者 进行搜索操作
     */
    private void notifyStartSearching() {
        //隐藏软键盘
        InputMethodManager imm = (InputMethodManager) _mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        loadDataList(1, true);

    }

}
