package com.dgzrdz.mobile.cocobee.activity.data;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.adapter.PicDetailAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 监护对象详情  锁定中/已激活/已过期
 * Created by admin on 2018/4/19.
 */

public class JianHuObjectDetailActivity extends BaseToolbarActivity {
    @BindView(R.id.ll_info)
    LinearLayout mLlInfo;
    @BindView(R.id.tv_car_type)
    TextView mTvCarType;
    @BindView(R.id.tv_change_tag)
    TextView mChangeTag;
    @BindView(R.id.tv_change_object)
    TextView mTvChangeObject;
    @BindView(R.id.ll_car_num)
    LinearLayout mLlCarNum;
    @BindView(R.id.tv_car_num)
    TextView mTvCarNum;
    @BindView(R.id.tv_tag_num)
    TextView mTvTagNum;

    private GuardianObjectResponse mGuardianObjectResponse;
    private List<GuardianObjectDetailResponse.CustomizeBean> picList = new ArrayList<>();
    private PicDetailAdapter mPicAdapter;
    private GuardianObjectDetailResponse mGuardianObjectDetailResponse;
    private UserInfo mUserLoginInfo;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_jian_hu_object_detail;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initIntent();
        mUserLoginInfo = Utils.getUserLoginInfo();
        getJianhuDetail();
    }

    /**
     * 获取监护对象详情
     */
    private void getJianhuDetail() {
        DatasApiUtils.getJianhuDetail(this, mGuardianObjectResponse.getMemberServiceObjId(), new DialogCallback<GuardianObjectDetailResponse>(this, "获取监护对象详情...") {
            @Override
            public void onSuccess(GuardianObjectDetailResponse guardianObjectDetailResponse, Call call, Response response) {
                mLlInfo.removeAllViews();
                if (guardianObjectDetailResponse != null) {
                    mGuardianObjectDetailResponse = guardianObjectDetailResponse;
                    mTvCarType.setText(guardianObjectDetailResponse.getSysServiceTypeName());
                    mTvTagNum.setText(guardianObjectDetailResponse.getHLabelNo());
                    String sysServiceTypeSpecialType = guardianObjectDetailResponse.getSysServiceTypeSpecialType();
                    String sysAreaCarNumEnabled = guardianObjectDetailResponse.getSysAreaCarNumEnabled();
                    String sysServiceTypeEnabled = guardianObjectDetailResponse.getSysServiceTypeEnabled();
                    if (CheckUtils.equalsString(sysServiceTypeSpecialType, "1") && CheckUtils.equalsString(sysAreaCarNumEnabled, "1")
                            && CheckUtils.equalsString(sysServiceTypeEnabled, "1")) {//需要车牌服务
                        mLlCarNum.setVisibility(View.VISIBLE);
                        mTvCarNum.setText(guardianObjectDetailResponse.getMemberServiceObjNumber());
                    } else {//不需要车牌服务
                        mLlCarNum.setVisibility(View.GONE);
                    }

                    picList.clear();
                    setValue(guardianObjectDetailResponse.getCustomize());
                } else {
                    XToastUtils.showShortToast("暂未配置监护对象类型");
                }
            }
        });
    }

    /**
     * 添加文本输入模式控件
     *
     * @param customizeBean
     * @param position      子控件的位置
     */
    private void addTextView(GuardianObjectDetailResponse.CustomizeBean customizeBean, int position) {
        View view = View.inflate(this, R.layout.text_view, null);
        TextView tvMustText = (TextView) view.findViewById(R.id.tv_must_text);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        EditText etText = (EditText) view.findViewById(R.id.et_text);
        etText.setFocusable(false);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);

        tvTextTitle.setText(customizeBean.getSysPropertyName());
        etText.setText(customizeBean.getSysPropertyValue());
        if (CheckUtils.equalsString(customizeBean.getSysPropertyRequired(), "1")) {//必填
            tvMustText.setVisibility(View.VISIBLE);
        } else {
            tvMustText.setVisibility(View.GONE);
        }
    }

    /**
     * 添加图片列表模式控件
     */
    private void addPicView() {
        View view = View.inflate(this, R.layout.pic_list_view, null);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycle_view);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        mPicAdapter = new PicDetailAdapter(this, picList);
        recyclerView.setAdapter(mPicAdapter);
        mPicAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH bh, int i) {
                Intent intent = new Intent(JianHuObjectDetailActivity.this, BigPicActivity.class);
                if (CheckUtils.isWebUrl(picList.get(i).getSysPropertyValue())) {//是全路径
                    intent.putExtra("picUrl", picList.get(i).getSysPropertyValue());
                } else {
                    intent.putExtra("picUrl", mUserLoginInfo.getDataList().getPicture_prefix_url() + picList.get(i).getSysPropertyValue());
                }
                startActivity(intent);
            }
        });

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);
    }


    private void initIntent() {
        Intent intent = getIntent();
        mGuardianObjectResponse = (GuardianObjectResponse) intent.getSerializableExtra("guardianObjectResponse");
        int memberServiceObjActiveFlag = mGuardianObjectResponse.getMemberServiceObjActiveFlag();
        switch (memberServiceObjActiveFlag) {
            case 2://锁定中
                initToolbar(Html.fromHtml("状态:<font color=#FF0000>锁定中</font>"));
                break;
            case 3://已激活
                initToolbar(Html.fromHtml("状态:<font color=#12bc00>已激活</font>"));
                break;
            case 4://已过期
                initToolbar(Html.fromHtml("状态:<font color=#999999>已过期</font>"));
                mChangeTag.setVisibility(View.GONE);
                mTvChangeObject.setVisibility(View.GONE);
                break;
            case 5://已删除
                initToolbar(Html.fromHtml("状态:<font color=#999999>已删除</font>"));
                mChangeTag.setVisibility(View.GONE);
                mTvChangeObject.setVisibility(View.GONE);
                break;
            default:
                break;
        }
    }

    @OnClick({R.id.tv_change_tag, R.id.tv_change_object})
    public void onViewClicked(View view) {
        //防止一秒内点击多次
        if (!Utils.isFastClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_change_tag://修改标签信息
                Intent intent = new Intent(this, UpdateCarInfoActivity.class);
                intent.putExtra("guardianObjectDetailResponse", mGuardianObjectDetailResponse);
                startActivity(intent);
                break;
            case R.id.tv_change_object://修改对象信息
                Intent intent1 = new Intent(this, UpdateJianHuObjectInfoActivity.class);
                intent1.putExtra("guardianObjectDetailResponse", mGuardianObjectDetailResponse);
                startActivity(intent1);
                break;
        }

    }

    /**
     * 设置属性
     *
     * @param customizeBeans
     */
    private void setValue(List<GuardianObjectDetailResponse.CustomizeBean> customizeBeans) {
        for (int i = 0; i < customizeBeans.size(); i++) {
            GuardianObjectDetailResponse.CustomizeBean customizeBean = customizeBeans.get(i);
            int sysPropertyInputType = customizeBean.getSysPropertyInputType();
            if (sysPropertyInputType == 4) {//图片格式
                picList.add(customizeBean);
            } else {//文本样式
                addTextView(customizeBean, i);
            }
        }

        if (picList.size() > 0) {
            addPicView();
        }
    }

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.UPDATE_CAR_INFO_SUCCESS://车辆信息修改成功
            case EventConstants.UPDATE_TAG_INFO_SUCCESS://标签信息修改成功
                getJianhuDetail();
                break;
        }
    }
}
