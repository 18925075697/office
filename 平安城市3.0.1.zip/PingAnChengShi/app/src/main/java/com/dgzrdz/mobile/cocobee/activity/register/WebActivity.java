package com.dgzrdz.mobile.cocobee.activity.register;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;

/**
 * Description: 云支付页面
 * Author: Liubingren
 * Data:  2018/5/18
 * Time:  17:15
 */

public class WebActivity extends BaseActivity {
    @BindView(R.id.webview)
    WebView mWebview;
    private String mUrl;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_test_web;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUrl = getIntent().getStringExtra("url");
        initWebView();
    }

    @Override
    protected boolean isStatusDarkMode() {
        return false;
    }

    private void initWebView() {
        WebViewClient client = new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 获取上下文, H5PayDemoActivity为当前页面
                final Activity context = WebActivity.this;
                // ------ 对alipays:相关的scheme处理 -------
                if (url.startsWith("alipays:") || url.startsWith("alipay")) {
                    try {
                        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                    } catch (Exception e) {
                        new AlertDialog.Builder(context)
                                .setMessage("未检测到支付宝客户端，请安装后重试。")
                                .setPositiveButton("立即安装", new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Uri alipayUrl = Uri.parse("https://d.alipay.com");
                                                context.startActivity(new Intent("android.intent.action.VIEW", alipayUrl));
                                            }
                                        }).setNegativeButton("取消", null).show();
                    }
                    return true;
                } else if (url.startsWith("weixin://wap/pay?")) {//打开微信进行支付
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    context.startActivity(intent);
                    return true;
                } else {
                    Map<String, String> extraHeaders = new HashMap<String, String>();
                    //如果是调起微信支付，需要在webview中手动设置referer
                    //extraHeaders.put("Referer", "https://yaoyaotest.cebbank.com"); //测试环境
//                    extraHeaders.put("Referer", "https://yaoyao.cebbank.com");//生产环境
                    view.loadUrl(url, extraHeaders);
                    return true;
                }

            }

            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // handler.cancel(); // Android默认的处理方式
                handler.proceed(); // 接受所有网站的证书
                // handleMessage(Message msg); // 进行其他处理
            }

        };

        String dir = this.getApplicationContext().getDir("database", Context.MODE_PRIVATE).getPath();
        WebSettings settings = mWebview.getSettings();
        settings.setDomStorageEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setGeolocationDatabasePath(dir);
        /**
         *   android webview 从Lollipop(5.0)开始webview默认不允许混合模式，https当中不能加载http资源，需要设置开启。以下三行代码设置开启.
         */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }


        mWebview.setWebViewClient(client);
        mWebview.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
                super.onGeolocationPermissionsShowPrompt(origin, callback);
            }
        });

        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        mWebview.loadUrl(mUrl);

    }

}
