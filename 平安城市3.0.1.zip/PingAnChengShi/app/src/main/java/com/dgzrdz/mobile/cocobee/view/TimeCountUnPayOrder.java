package com.dgzrdz.mobile.cocobee.view;

import android.content.Context;
import android.os.CountDownTimer;
import android.widget.TextView;

import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.common.EventConstants;

import org.greenrobot.eventbus.EventBus;

public class TimeCountUnPayOrder extends CountDownTimer {

    private final TextView mTextView;
    private final Context mContext;

    public TimeCountUnPayOrder(Context context, long millisInFuture, long countDownInterval, TextView textView) {
        super(millisInFuture, countDownInterval);
        mContext = context;
        mTextView = textView;
    }


    @Override
    public void onTick(long millisUntilFinished) {
        long h = millisUntilFinished / 1000 / 60 / 60;
        long h1 = millisUntilFinished / 1000 % 60;//丢失的秒数
        long m = millisUntilFinished / 1000 / 60;
        System.out.println( );
        mTextView.setText(m + "分" + h1 + "秒后自动取消");
    }

    @Override
    public void onFinish() {
        mTextView.setText("取消中");
        EventBus.getDefault().post(new EventManager(EventConstants.TIME_COUNT_DOWN_CANCEL_ORDER));
    }

}