package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.ImageView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.HomeIndexResponse;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 查询的recycleView的adapter
 */

public class HomeAdapter extends QuickRcvAdapter<HomeIndexResponse.PermissionMenuMapBean> {


    private final Context mContext;
    private final UserInfo mUserLoginInfo;

    public HomeAdapter(Context context, List<HomeIndexResponse.PermissionMenuMapBean> data, int... layoutId) {
        super(context, data, R.layout.home_rec_item);
        mContext = context;
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, HomeIndexResponse.PermissionMenuMapBean item) {
        ImageView view = viewHolder.getView(R.id.iv_home_pic);
        if (CheckUtils.isWebUrl(item.getAppModuleIcon())) {//是全路径
            ImageUtil.loadHomeSmallIcon(mContext, item.getAppModuleIcon(), view);
        } else {
            ImageUtil.loadHomeSmallIcon(mContext, mUserLoginInfo.getDataList().getPicture_prefix_url() + item.getAppModuleIcon(), view);
        }
        viewHolder.setText(R.id.tv_home_title, item.getAppModuleName());
    }
}
