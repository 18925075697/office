package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.SelectBindingCarAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.fragment.me.RealNameInfoFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 保险补办选择监护对象
 * Author: Liubingren
 * Data:  2018/4/25
 * Time:  16:00
 */

public class SelectBindingCarPolicyFragment extends BaseFragment implements QuickRcvAdapter.OnRecyclerViewItemClickListener {
    private static UserBeanResponse userBeanResponse;
    @BindView(R.id.recycle_view)
    RecyclerView mRecycleView;
    @BindView(R.id.userNameTxt)
    TextView mUserNameTxt;
    @BindView(R.id.tv_user_name)
    TextView mTvUserName;
    @BindView(R.id.telTxt)
    TextView mTelTxt;
    @BindView(R.id.ieTxt)
    TextView mIeTxt;
    @BindView(R.id.ll_car_owner_info)
    LinearLayout mLlCarOwnerInfo;
    @BindView(R.id.userHeadImg)
    ImageView mUserHeadImg;
    private List<GuardianObjectResponse> mList = new ArrayList<>();
    private SelectBindingCarAdapter adapter;
    private int selectPosition = -1;
    private UserInfo mUserLoginInfo;


    public static SelectBindingCarPolicyFragment getInstance(UserBeanResponse userBeanResponse) {
        SelectBindingCarPolicyFragment.userBeanResponse = userBeanResponse;
        SelectBindingCarPolicyFragment fragment = new SelectBindingCarPolicyFragment();
        return fragment;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_select_bind_policy;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        setCarOwner();
        initRecycleView();
        initData();
    }

    /**
     * 设置车主信息
     */
    private void setCarOwner() {
        if (userBeanResponse == null) {
            return;
        }
        mTvUserName.setText(userBeanResponse.getMemberName());
        mUserNameTxt.setText("性别:" + (CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? "男" : "女"));
        mTelTxt.setText("电话:" + userBeanResponse.getMemberAccount());
        mIeTxt.setText("身份证:" + userBeanResponse.getMemberCardId());
        mUserHeadImg.setImageResource(CheckUtils.equalsString(userBeanResponse.getMemberSix(), "1") ? R.drawable.male_portrait : R.drawable.women);
    }

    private void initData() {
        DatasApiUtils.getUnbindCarInfo(_mActivity, userBeanResponse.getMemberId(), mUserLoginInfo.getDataList().getSysAreaId(), new DialogCallback<List<GuardianObjectResponse>>(_mActivity, "获取监护对象...") {

            @Override
            public void onSuccess(List<GuardianObjectResponse> guardianObjectResponses, Call call, Response response) {
                mList.clear();
                if (guardianObjectResponses != null && guardianObjectResponses.size() > 0) {
                    mList.addAll(guardianObjectResponses);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void initRecycleView() {
        adapter = new SelectBindingCarAdapter(_mActivity, userBeanResponse, mList);
        mRecycleView.setLayoutManager(new LinearLayoutManager(_mActivity));
        mRecycleView.addItemDecoration(new ListLineDecoration());
        mRecycleView.setAdapter(adapter);
        adapter.setOnItemClickListener(this);
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithRightText("选择监护对象", "确定");
    }

    @Override
    public void onItemClick(BH bh, int position) {
        GuardianObjectResponse guardianObjectResponse = mList.get(position);
        //组织机构模块相同,且为已激活才能选中
        if (/*CheckUtils.equalsString(guardianObjectResponse.getChecksysArea(), "1") &&*/
                guardianObjectResponse.getMemberServiceObjActiveFlag() == 3) {
            selectPosition = position;
            //把点击的项设置为选中状态
            for (int i = 0; i < mList.size(); i++) {
                if (i != position) {
                    mList.get(i).setCheck(false);
                } else {
                    mList.get(i).setCheck(true);
                }
            }
            adapter.notifyDataSetChanged();
        } else {
            XToastUtils.showShortToast("该对象不支持选中");
        }

    }

    @OnClick({R.id.ll_car_owner_info})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_car_owner_info:
                start(RealNameInfoFragment.getInstance(userBeanResponse));
                break;
        }
    }

    @Override
    public void btnRightTextClick() {
        if (selectPosition >= 0) {
            GuardianObjectResponse guardianObjectResponse = mList.get(selectPosition);
            Intent intent = new Intent();
            intent.putExtra("guardianObjectResponse", guardianObjectResponse);
            intent.putExtra("userBean", userBeanResponse);
            EventBus.getDefault().post(new EventManager(EventConstants.CAR_SELECT_SUCCESS, intent));
            _mActivity.finish();
        } else {
            XToastUtils.showShortToast("请选择监护对象");
        }
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.UPDATE_CAR_INFO_SUCCESS://车辆信息修改成功
                selectPosition = -1;
                initData();
                break;
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                userBeanResponse = (UserBeanResponse) eventManager.getData();
                setCarOwner();
                break;
        }
    }
}
