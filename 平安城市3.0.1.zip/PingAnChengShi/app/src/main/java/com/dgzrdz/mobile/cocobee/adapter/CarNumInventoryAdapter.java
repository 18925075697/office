package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.CarNumInventoryResponse;

import java.util.List;

/**
 * Created by Administrator on 2018/6/29.
 */

public class CarNumInventoryAdapter extends QuickRcvAdapter<CarNumInventoryResponse> {

    private final Context mContext;

    public CarNumInventoryAdapter(Context context, List<CarNumInventoryResponse> data, int... layoutId) {
        super(context, data, R.layout.item_car_num_inventory);
        mContext = context;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, CarNumInventoryResponse carNumInventoryResponse) {
        quickRcvHolder.setText(R.id.tv_label, carNumInventoryResponse.getCno());
        quickRcvHolder.setText(R.id.tv_type, carNumInventoryResponse.getCarTypeName());
        quickRcvHolder.setText(R.id.tv_pakage_num, carNumInventoryResponse.getPackNumber());
        quickRcvHolder.setText(R.id.tv_time, carNumInventoryResponse.getModifytime());
    }
}
