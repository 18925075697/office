package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.response.OrderDetailResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/29
 * Time:  14:28
 */

public class TaocanAdapter extends QuickRcvAdapter<OrderDetailResponse.LabelServicePackageListBean> {

    private final List<OrderDetailResponse.LabelServicePackageListBean> mData;
    private final Context mContext;
    private final OrderDetailResponse mOrderDetailResponse;

    public TaocanAdapter(Context context, List<OrderDetailResponse.LabelServicePackageListBean> data, OrderDetailResponse orderDetailResponse) {
        super(context, data, R.layout.item_taocan_view);
        mContext = context;
        mData = data;
        mOrderDetailResponse = orderDetailResponse;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, OrderDetailResponse.LabelServicePackageListBean item) {
        viewHolder.setText(R.id.tv_taocan, item.getSysServiceSetPropName() + ":  " + item.getSysServiceSetPropOptionName());
        TextView tvPhone = viewHolder.getView(R.id.tv_phone);
        TextView tvChangePhone = viewHolder.getView(R.id.tv_change_phone);
        if (CheckUtils.equalsString(item.getSysServiceSetPropOptionInput(), "1")) {//需要显示
            tvPhone.setVisibility(View.VISIBLE);
            if (CheckUtils.equalsString(item.getSysServiceSetPropOptionSpecial(), "1")) {//1：校验手机号码 ，2：校验身份证号码，3：校验纯数字，4：其他

                tvPhone.setText(item.getSysServiceSetPropOptionInputName() + ":  " + item.getSysServiceSetPropExValueStr() + "(" + item.getSysMobileName()
                        + " " + item.getSysProName() + item.getSysCityName() + ")");
                //是手机号且状态为待付款或已激活
                if ((CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "1")
                        || CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "2"))) {

                    tvChangePhone.setVisibility(View.VISIBLE);
                    tvChangePhone.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showPhoneInputDialog(item);
                        }
                    });
                } else {
                    tvChangePhone.setVisibility(View.GONE);
                }
            } else {
                tvPhone.setText(item.getSysServiceSetPropOptionInputName() + ":  " + item.getSysServiceSetPropExValueStr());
                tvChangePhone.setVisibility(View.GONE);
            }

        } else {
            tvPhone.setVisibility(View.GONE);
            tvChangePhone.setVisibility(View.GONE);
        }
    }

    /**
     * 展示手机号输入弹框
     *
     * @param labelServicePackageListBean
     */
    private void showPhoneInputDialog(OrderDetailResponse.LabelServicePackageListBean labelServicePackageListBean) {
        View view = View.inflate(mContext, R.layout.view_input_phone, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(mContext, view, 270, 174);
        EditText newPhone = (EditText) alertDialog.findViewById(R.id.et_new_phone);
        TextView sure = (TextView) alertDialog.findViewById(R.id.tv_sure);
        TextView cancel = (TextView) alertDialog.findViewById(R.id.tv_cancel);

        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = newPhone.getText().toString().trim();
                if (CheckUtils.isEmpty(phone)) {
                    XToastUtils.showShortToast("请输入手机号码");
                } else if (!CheckUtils.isMobilePhone(phone)) {
                    XToastUtils.showShortToast("手机号格式错误");
                } else {
                    changePhone(labelServicePackageListBean, phone, alertDialog);
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    /**
     * 修改手机号码
     *
     * @param labelServicePackageListBean
     * @param phone
     * @param alertDialog
     */
    private void changePhone(OrderDetailResponse.LabelServicePackageListBean labelServicePackageListBean, String phone, AlertDialog alertDialog) {
        PayApiUtils.changePhone(mContext, labelServicePackageListBean.getSysServiceSetPropValueId(), phone, mOrderDetailResponse.getPaymentTime(), new DialogCallback<Object>(mContext, "修改中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("修改成功");
                EventBus.getDefault().post(new EventManager(EventConstants.PHONE_CHANGE_SUCCESS));
                alertDialog.dismiss();
            }
        });
    }
}
