package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description: 监护对象response
 * Author: Liubingren
 * Data:  2018/11/14
 * Time:  14:40
 */

public class GuardianObjectResponse implements Serializable {

    /**
     * memberServiceObjId : 27
     * memberServiceObjActiveFlag : 1
     * sysPropertyValueStr :
     * sysServiceTypeName : 摩托车
     */

    private String memberServiceObjId;
    private int memberServiceObjActiveFlag;//1 未激活2 锁定中3 已激活、有效中4 已过期5 删除了
    private String sysPropertyValueStr;
    private String sysServiceTypeName;
    private String sysServiceTypeId;
    private String sysServiceTypeIcon;
    private String checksysArea;//是否属于该管理员模块下的：0不是1是
    private String sysAreaCarNumEnabled;//是否启用车牌，1启用，2禁用
    private String sysAreaCarNumPrefix;//车牌前缀+字母
    private String sysAreaCode;
    private String sysServiceTypeSpecialType;//特定服务\n0：无额外服务\n1：需要车牌服务
    private String hLabelId;//标签id
    private String hLabelNo;//标签号
    private String hPlateId;//车牌id
    private String hPlateNo;//车牌号
    private String sysGroupName;//集团单位
    private String sysGroupId;//集团单位id
    private String sysConfType;//订单类型，1 个人业务，2集团业务
    boolean isCheck;//是否选中

    public String getSysGroupName() {
        return sysGroupName;
    }

    public void setSysGroupName(String sysGroupName) {
        this.sysGroupName = sysGroupName;
    }

    public String getSysGroupId() {
        return sysGroupId;
    }

    public void setSysGroupId(String sysGroupId) {
        this.sysGroupId = sysGroupId;
    }

    public String getSysConfType() {
        return sysConfType;
    }

    public void setSysConfType(String sysConfType) {
        this.sysConfType = sysConfType;
    }

    public String gethLabelId() {
        return hLabelId;
    }

    public void sethLabelId(String hLabelId) {
        this.hLabelId = hLabelId;
    }

    public String gethLabelNo() {
        return hLabelNo;
    }

    public void sethLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }

    public String gethPlateId() {
        return hPlateId;
    }

    public void sethPlateId(String hPlateId) {
        this.hPlateId = hPlateId;
    }

    public String gethPlateNo() {
        return hPlateNo;
    }

    public void sethPlateNo(String hPlateNo) {
        this.hPlateNo = hPlateNo;
    }

    public String getSysAreaCarNumEnabled() {
        return sysAreaCarNumEnabled;
    }

    public void setSysAreaCarNumEnabled(String sysAreaCarNumEnabled) {
        this.sysAreaCarNumEnabled = sysAreaCarNumEnabled;
    }

    public String getSysAreaCarNumPrefix() {
        return sysAreaCarNumPrefix;
    }

    public void setSysAreaCarNumPrefix(String sysAreaCarNumPrefix) {
        this.sysAreaCarNumPrefix = sysAreaCarNumPrefix;
    }

    public String getSysAreaCode() {
        return sysAreaCode;
    }

    public void setSysAreaCode(String sysAreaCode) {
        this.sysAreaCode = sysAreaCode;
    }

    public String getSysServiceTypeSpecialType() {
        return sysServiceTypeSpecialType;
    }

    public void setSysServiceTypeSpecialType(String sysServiceTypeSpecialType) {
        this.sysServiceTypeSpecialType = sysServiceTypeSpecialType;
    }

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }

    public String getSysServiceTypeId() {
        return sysServiceTypeId;
    }

    public void setSysServiceTypeId(String sysServiceTypeId) {
        this.sysServiceTypeId = sysServiceTypeId;
    }

    public String getSysServiceTypeIcon() {
        return sysServiceTypeIcon;
    }

    public void setSysServiceTypeIcon(String sysServiceTypeIcon) {
        this.sysServiceTypeIcon = sysServiceTypeIcon;
    }

    public String getChecksysArea() {
        return checksysArea;
    }

    public void setChecksysArea(String checksysArea) {
        this.checksysArea = checksysArea;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public int getMemberServiceObjActiveFlag() {
        return memberServiceObjActiveFlag;
    }

    public void setMemberServiceObjActiveFlag(int memberServiceObjActiveFlag) {
        this.memberServiceObjActiveFlag = memberServiceObjActiveFlag;
    }

    public String getSysPropertyValueStr() {
        return sysPropertyValueStr;
    }

    public void setSysPropertyValueStr(String sysPropertyValueStr) {
        this.sysPropertyValueStr = sysPropertyValueStr;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }
}
