package com.dgzrdz.mobile.cocobee.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.DeviceUtils;
import com.bql.utils.NetworkUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.register.LoginActivity;
import com.dgzrdz.mobile.cocobee.common.AppConstants;
import com.dgzrdz.mobile.cocobee.common.AppManager;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.ElectricVehicleApp;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.kernal.passportreader.sdk.utils.DefaultPicSavePath;
import com.lzy.okgo.OkGo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import Decoder.BASE64Encoder;
import cn.pedant.SweetAlert.SweetAlertDialog;
import id.zelory.compressor.Compressor;
import kernal.idcard.camera.CardOcrRecogConfigure;

/**
 * Created by Administrator on 2017/4/1.
 */
public class Utils {

    /**
     * 保存用户登录信息
     *
     * @param userInfo
     */
    public static void putUserLoginInfo(UserInfo userInfo) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.USER_LOGIN_INFO, userInfo);
    }

    /**
     * 获得用户登录信息
     *
     * @return
     */
    public static UserInfo getUserLoginInfo() {
        return (UserInfo) ElectricVehicleApp.getDataKeeper().get(AppConstants.USER_LOGIN_INFO);
    }

    /**
     * 保存版本升级信息
     *
     * @param versionInfo
     */
    public static void putUpdateVersionInfo(VersionInfo versionInfo) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.VERSION_UPDATE_INFO, versionInfo);
    }

    /**
     * 获得版本升级信息
     *
     * @return
     */
    public static VersionInfo getUpdateVersionInfo() {
        return (VersionInfo) ElectricVehicleApp.getDataKeeper().get(AppConstants.VERSION_UPDATE_INFO);
    }

    /**
     * 保存用户登录账号
     */
    public static void putUserLoginNum(String num) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.USER_LOGIN_NUM, num);
    }

    /**
     * 获得用户登录账号
     */
    public static String getUserLoginNum() {
        return ElectricVehicleApp.getDataKeeper().get(AppConstants.USER_LOGIN_NUM, "");
    }

    /**
     * 保存测试模式标签号
     */
    public static void putTestModeTag(String tag) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.TEST_MODE_TAG, tag);
    }

    /**
     * 获得测试模式标签号
     */
    public static String getTestModeTag() {
        return ElectricVehicleApp.getDataKeeper().get(AppConstants.TEST_MODE_TAG, "");
    }

    /**
     * 保存测试模式主天线门限
     */
    public static void putTestModeP(String p) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.TEST_MODE_P, p);
    }

    /**
     * 获得测试模式主天线门限
     */
    public static String getTestModeP() {
        return ElectricVehicleApp.getDataKeeper().get(AppConstants.TEST_MODE_P, "");
    }

    /**
     * 保存测试模式从天线门限
     */
    public static void putTestModeS(String s) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.TEST_MODE_S, s);
    }

    /**
     * 获得测试模式从天线门限
     */
    public static String getTestModeS() {
        return ElectricVehicleApp.getDataKeeper().get(AppConstants.TEST_MODE_S, "");
    }

    /**
     * 保存搜索记录信息
     *
     * @param list
     */
    public static void putSearchList(List<String> list) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.SEARCH_HISTORY_INFO, list);
    }

    /**
     * 获得搜索记录信息
     *
     * @return
     */
    public static List<String> getSearchList() {
        return (List<String>) ElectricVehicleApp.getDataKeeper().get(AppConstants.SEARCH_HISTORY_INFO);
    }

    /**
     * 保存用户是否第一次进入应用
     *
     * @param b
     */
    public static void putUserIsFirst(boolean b) {
        ElectricVehicleApp.getDataKeeper().put(AppConstants.IS_USER_FIRST, b);
    }

    /**
     * 获取用户是否第一次进入应用
     */
    public static boolean getUserIsFirst() {
        return ElectricVehicleApp.getDataKeeper().get(AppConstants.IS_USER_FIRST, true);
    }

    /**
     * 保存用户选择的语言
     *
     * @param i
     */
    public static void putUserLuanguage(int i) {
        ElectricVehicleApp.getDataKeeper().putInt(AppConstants.LANGUAGE_ID, i);
    }

    /**
     * 获取用户设置的语言
     */
    public static int getUserLuanguage() {
        return ElectricVehicleApp.getDataKeeper().getInt(AppConstants.LANGUAGE_ID, 0);
    }

    public static void setLanguageConfig(Context context, int languageId) {
        Resources resources = context.getResources();//获得res资源对象
        Configuration config = resources.getConfiguration();//获得设置对象
        DisplayMetrics dm = resources.getDisplayMetrics();//获得屏幕参数：主要是分辨率，像素等。
        switch (languageId) {
            case 0:
                config.locale = Locale.getDefault();
                break;
            case 1: //简体中文
                config.locale = Locale.SIMPLIFIED_CHINESE;
                break;
            case 2: //英文
                config.locale = Locale.ENGLISH;
                break;
            default:
                config.locale = Locale.getDefault();
                break;
        }

        resources.updateConfiguration(config, dm);

        Utils.putUserLuanguage(languageId);
    }


    //上传base64图片
    public static String base64Pic(Context context, String pic) {
        //压缩
        String picUrl = getCompressPicUrl(context, pic);

        String base64Pic = "";
        if (!TextUtils.isEmpty(picUrl)) { //照片

            try {
                FileInputStream is = new FileInputStream(picUrl);
                byte[] picData = new byte[is.available()];
                is.read(picData);
                is.close();
                BASE64Encoder encoder = new BASE64Encoder();
                base64Pic = encoder.encode(picData);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return base64Pic;
    }

    /**
     * 压缩图片
     *
     * @return
     */
    public static String getCompressPicUrl(Context context, String plate_str) {
        try {
            File fileName = new File(plate_str);
            if (FileOperateUtils.getFileSize(fileName) > Constant.PIC_SIZE_LIMIT) {
                File compressedImage = new Compressor(context)
                        .setMaxWidth(640)
                        .setMaxHeight(480)
                        .setQuality(75)
                        .setCompressFormat(Bitmap.CompressFormat.JPEG)//压缩格式
                        .setDestinationDirectoryPath(Path.IMAGE_TEMP_FILE_PATH)//压缩后图片保存地址
                        .compressToFile(fileName);//压缩文件

                plate_str = compressedImage.getAbsolutePath();
            }
        } catch (IOException e) {
            e.printStackTrace();
            plate_str = getPicUrl(plate_str);
        }
        return plate_str;
    }

    //压缩图片
    public static String getPicUrl(String picStr) {
        try {
            File fileName = new File(picStr);
            if (FileOperateUtils.getFileSize(fileName) > Constant.PIC_SIZE_LIMIT) {
                Bitmap newBitmap = ImageUtils.compressImageFromFile(picStr);//获取压缩后的bitmap
                if (newBitmap != null) {
                    if (fileName.exists()) {
                        fileName.delete(); //删掉原文件
                    }
                    //创建新文件
                    ImageUtils.compressBmpToFile(newBitmap, new File(picStr));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return picStr;
    }

    /**
     * 清除用户相关数据
     *
     * @return
     */
    public static void clear() {
        ElectricVehicleApp.getDataKeeper().remove(AppConstants.USER_LOGIN_INFO);
        ElectricVehicleApp.getDataKeeper().remove(AppConstants.TEST_MODE_TAG);
        ElectricVehicleApp.getDataKeeper().remove(AppConstants.TEST_MODE_P);
        ElectricVehicleApp.getDataKeeper().remove(AppConstants.TEST_MODE_S);
    }

    //进入登录界面
    public static void gotoLogin() {
        Utils.clear();
        Intent intent = new Intent(ElectricVehicleApp.getApp(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        ElectricVehicleApp.getApp().startActivity(intent);
        OkGo.getInstance().cancelAll();
        AppManager.getAppManager().finishAllActivity();
    }

    /**
     * 高亮字体
     *
     * @param view    TextView
     * @param oriStr  源字符画
     * @param keyword 关键字符串
     * @param color   颜色
     */
    public static void highlightStr(TextView view, String oriStr, String keyword, int color) {
        int start = oriStr.indexOf(keyword);
        SpannableStringBuilder style = new SpannableStringBuilder(oriStr);
        style.setSpan(new ForegroundColorSpan(color), start, keyword.length() + start, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        view.setText(style);
    }

    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    public static int dp2px(float dpValue) {
        return DeviceUtils.dp2px(ElectricVehicleApp.getApp(), dpValue);
    }

    /**
     * 获取屏幕宽度
     *
     * @return
     */
    public static int getScreenWidth() {
        return ElectricVehicleApp.getApp().getResources().getDisplayMetrics().widthPixels;
    }

    /**
     * 获取屏幕高度
     *
     * @return
     */
    public static int getScreenHeight() {
        return ElectricVehicleApp.getApp().getResources().getDisplayMetrics().heightPixels;
    }

    /**
     * 居中显示圆角dialog
     */
    public static AlertDialog showCornerDialog(Context context, View view, float width, float height) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.MyDialog);
        builder.setView(view);
        AlertDialog ad = builder.create();  //创建对话框
        ad.show();
        Window dialogWindow = ad.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);
        dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        lp.width = dp2px(width); // 宽度
        lp.height = dp2px(height); // 高度
        dialogWindow.setAttributes(lp);
        return ad;
    }

    /**
     * 居中显示圆角dialog
     * 大小屏幕宽高比例
     */
    public static AlertDialog showCornersDialog(Context context, View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.MyDialog);
        builder.setView(view);
        AlertDialog ad = builder.create();  //创建对话框
        ad.show();
        Window dialogWindow = ad.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);
        lp.width = (int) (getScreenWidth() * 0.8); // 宽度
        lp.height = (int) (getScreenHeight() * 0.8); // 高度
        dialogWindow.setAttributes(lp);
        return ad;
    }

    /**
     * 判断应用是否处于前台
     *
     * @param context
     * @return
     */
    public static boolean isBackground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(context.getPackageName())) {
                if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                    Log.i("后台", appProcess.processName);
                    return true;
                } else {
                    Log.i("前台", appProcess.processName);
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 网络是否连接
     *
     * @return
     */
    public static boolean isNetConnected() {
        return NetworkUtils.isConnected(ElectricVehicleApp.getApp());
    }

    /**
     * activity跳转
     *
     * @param nowActivity    当前的activity
     * @param targetActivity 目标的activity
     */
    public static void startActivity(Activity nowActivity, Class<?> targetActivity) {
        Intent intent = new Intent(nowActivity, targetActivity);
        nowActivity.startActivity(intent);
    }

    /**
     * 拷贝assets文件到指定目录
     *
     * @param context
     * @param strOutFileName
     * @param files
     * @throws IOException
     */
    public static void copyBigDataToSD(Context context, String strOutFileName, String files) throws IOException {
        InputStream myInput;
        OutputStream myOutput = new FileOutputStream(strOutFileName);
        myInput = context.getAssets().open("vmp.zip");
        byte[] buffer = new byte[1024];
        int length = myInput.read(buffer);
        while (length > 0) {
            myOutput.write(buffer, 0, length);
            length = myInput.read(buffer);
        }

        myOutput.flush();
        myInput.close();
        myOutput.close();
        unzipFile(files, strOutFileName);

    }

    /**
     * 解压文件
     */
    public static void unzipFile(String targetPath, String zipFilePath) {

        try {
            File zipFile = new File(zipFilePath);
            InputStream is = new FileInputStream(zipFile);
            ZipInputStream zis = new ZipInputStream(is);
            ZipEntry entry = null;
            System.out.println("开始解压:" + zipFile.getName() + "...");
            while ((entry = zis.getNextEntry()) != null) {
                String zipPath = entry.getName();
                try {

                    if (entry.isDirectory()) {
                        File zipFolder = new File(targetPath + File.separator
                                + zipPath);
                        if (!zipFolder.exists()) {
                            zipFolder.mkdirs();
                        }
                    } else {
                        File file = new File(targetPath + File.separator
                                + zipPath);
                        if (!file.exists()) {
                            File pathDir = file.getParentFile();
                            pathDir.mkdirs();
                            file.createNewFile();
                        }

                        FileOutputStream fos = new FileOutputStream(file);
                        int bread;
                        while ((bread = zis.read()) != -1) {
                            fos.write(bread);
                        }
                        fos.close();

                    }
                    System.out.println("成功解压:" + zipPath);

                } catch (Exception e) {
                    System.out.println("解压" + zipPath + "失败");
                    continue;
                }
            }
            zis.close();
            is.close();
            System.out.println("解压结束");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // 两次点击按钮之间的点击间隔不能少于1000毫秒
    private static final int MIN_CLICK_DELAY_TIME = 1000;
    private static long lastClickTime;

    public static boolean isFastClick() {
        boolean flag = false;
        long curClickTime = System.currentTimeMillis();
        if ((curClickTime - lastClickTime) >= MIN_CLICK_DELAY_TIME) {
            flag = true;
        }
        lastClickTime = curClickTime;
        return flag;
    }

    /**
     * 获取进程名字
     *
     * @param cxt
     * @param pid
     * @return
     */
    public static String getProcessName(Context cxt, int pid) {
        ActivityManager am = (ActivityManager) cxt.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        if (runningApps == null) {
            return null;
        }
        for (ActivityManager.RunningAppProcessInfo procInfo : runningApps) {
            if (procInfo.pid == pid) {
                return procInfo.processName;
            }
        }
        return null;
    }


    /**
     * 隐藏手机号中间4位
     *
     * @param mobile
     * @return
     */
    public static String getPhoneFirstAndEnd(String mobile) {
        if (CheckUtils.isEmpty(mobile) || mobile.length() < 11) {
            return mobile;
        }
        String mobileFirst = mobile.substring(0, 3);
        String mobileEnd = mobile.substring(mobile.length() - 4, mobile.length());
        return mobileFirst + "****" + mobileEnd;
    }

    /**
     * 隐藏身份证中间8位
     *
     * @param idCard
     * @return
     */
    public static String getIdCardFirstAndEnd(String idCard) {
        if (CheckUtils.isEmpty(idCard) || idCard.length() < 15) {
            return idCard;
        }
        String idCardFirst = idCard.substring(0, 6);
        String idCardEnd = idCard.substring(idCard.length() - 4, idCard.length());
        return idCardFirst + "***********" + idCardEnd;
    }

    /**
     * 比较两个集合是否相同
     *
     * @param list1
     * @param list2
     * @return
     */
    public static boolean equalList(List list1, List list2) {
        if (list1.size() != list2.size())
            return false;
        for (Object object : list1) {
            if (!list2.contains(object))
                return false;
        }
        return true;

    }

    /**
     * 判断GPS是否开启，GPS或者AGPS开启一个就认为是开启的
     *
     * @param context
     * @return true 表示开启
     */
    public static final boolean isOPen(final Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        // 通过GPS卫星定位，定位级别可以精确到街（通过24颗卫星定位，在室外和空旷的地方定位准确、速度快）
        boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        // 通过WLAN或移动网络(3G/2G)确定的位置（也称作AGPS，辅助GPS定位。主要用于在室内或遮盖物（建筑群或茂密的深林等）密集的地方定位）
        boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (gps || network) {
            return true;
        }

        return false;
    }

    /**
     * 强制帮用户打开GPS
     *
     * @param context
     */
    public static final void openGPS(Context context) {
        Intent GPSIntent = new Intent();
        GPSIntent.setClassName("com.android.settings",
                "com.android.settings.widget.SettingsAppWidgetProvider");
        GPSIntent.addCategory("android.intent.category.ALTERNATIVE");
        GPSIntent.setData(Uri.parse("custom:3"));
        try {
            PendingIntent.getBroadcast(context, 0, GPSIntent, 0).send();
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }
    }

    /**
     * 隐藏虚拟按键，并且全屏
     */
    public static void hideBottomUIMenu(Activity activity) {
        //隐藏虚拟按键
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            //for new api versions.
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    /**
     * 跳转百度地图导航
     *
     * @param context
     * @param lng
     * @param lat
     * @param eqaddr
     */
    public static void gotoBaiduMap(Context context, String lng, String lat, String eqaddr) {
        if (isAvilible(context, "com.baidu.BaiduMap")) {//传入指定应用包名
            Intent i1 = new Intent();
            i1.setData(Uri.parse("baidumap://map/direction?destination=latlng:" + lat + "," + lng + "|name:" + eqaddr + "&mode=driving"));
            context.startActivity(i1);
        } else {//未安装
            //market为路径，id为包名
            //显示手机上所有的market商店
            XToastUtils.showShortToast("您尚未安装百度地图");
            Uri uri = Uri.parse("market://details?id=com.baidu.BaiduMap");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(intent);
        }
    }

    /**
     * 跳转高德地图导航
     *
     * @param context
     * @param lng
     * @param lat
     * @param eqaddr
     */
    public static void gotoGaodeMap(Context context, String lng, String lat, String eqaddr) {

        Double[] doubles = bd_decrypt(Double.parseDouble(lat), Double.parseDouble(lng));
        if (isAvilible(context, "com.autonavi.minimap")) {
            try {
                Intent intent = Intent.getIntent("amapuri://route/plan/?did=BGVIS2&dlat=" + doubles[1] + "&dlon=" + doubles[0] + "&dname=" + eqaddr + "&dev=0&t=0");
                context.startActivity(intent);
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            XToastUtils.showShortToast("您尚未安装高德地图");
            Uri uri = Uri.parse("market://details?id=com.autonavi.minimap");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(intent);
        }
    }

    /**
     * 检查手机上是否安装了指定的软件
     *
     * @param context
     * @param packageName：应用包名
     * @return
     */

    public static boolean isAvilible(Context context, String packageName) {
        //获取packagemanager
        final PackageManager packageManager = context.getPackageManager();
        //获取所有已安装程序的包信息
        List<PackageInfo> packageInfos = packageManager.getInstalledPackages(0);
        //用于存储所有已安装程序的包名
        List<String> packageNames = new ArrayList<String>();
        //从pinfo中将包名字逐一取出，压入pName list中
        if (packageInfos != null) {
            for (int i = 0; i < packageInfos.size(); i++) {
                String packName = packageInfos.get(i).packageName;
                packageNames.add(packName);
            }
        }
        //判断packageNames中是否有目标程序的包名，有TRUE，没有FALSE
        return packageNames.contains(packageName);
    }

    /**
     * 高德转百度
     */
    public static Double[] bd_encrypt(double gg_lat, double gg_lon) {
        double x = gg_lon, y = gg_lat;
        double z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * Math.PI);
        double theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * Math.PI);
        double bd_lon = z * Math.cos(theta) + 0.0065;
        double bd_lat = z * Math.sin(theta) + 0.006;
        Double[] list = new Double[2];
        list[0] = bd_lon;
        list[1] = bd_lat;
        return list;
    }

    /**
     * 百度转高德
     */
    public static Double[] bd_decrypt(double bd_lat, double bd_lon) {
        double x = bd_lon - 0.0065, y = bd_lat - 0.006;
        double z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * Math.PI);
        double theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * Math.PI);
        double gg_lon = z * Math.cos(theta);
        double gg_lat = z * Math.sin(theta);
        Double[] list = new Double[2];
        list[0] = gg_lon;
        list[1] = gg_lat;
        return list;
    }

    /**
     * 根据标识值跳转相应的页面
     * 返回值 0没有匹配的 1集团业务 2保险补办 3预登记 4业务统计
     */
    public static int getNaviValue(String string) {
        if (CheckUtils.equalsString(string, "1")) {//集团业务
            return 1;
        } else if (CheckUtils.equalsString(string, "2")) {//保险补办
            return 2;
        } else if (CheckUtils.equalsString(string, "3")) {//预登记
            return 3;
        } else if (CheckUtils.equalsString(string, "4")) {//业务统计
            return 4;
        } else if (CheckUtils.equalsString(string, "Linkingdevice")) {//连接设备
            return 5;
        } else if (CheckUtils.equalsString(string, "BatteryPower")) {//电池电量
            return 6;
        } else if (CheckUtils.equalsString(string, "TagSearch")) {//标签搜索
            return 7;
        } else if (CheckUtils.equalsString(string, "ManuallyCheckPoints")) {//手动踩点
            return 8;
        } else if (CheckUtils.equalsString(string, "InstallationDebugging")) {//安装调试
            return 9;
        } else if (CheckUtils.equalsString(string, "PointManagement")) {//点位管理
            return 10;
        } else if (CheckUtils.equalsString(string, "TagReading")) {//标签读取
            return 11;
        } else if (CheckUtils.equalsString(string, "EquipmentInformation")) {//基站信息
            return 12;
        } else if (CheckUtils.equalsString(string, "BluetoothUpgrade")) {//蓝牙升级
            return 13;
        } else if (CheckUtils.equalsString(string, "ConvenienceServices")) {//便民服务
            return 14;
        } else if (CheckUtils.equalsString(string, "BandingRdcords")) {//车辆绑定记录
            return 15;
        } else if (CheckUtils.equalsString(string, "DateBase")) {//车主资料库
            return 16;
        } else if (CheckUtils.equalsString(string, "InventoryView")) {//库存查看
            return 17;
        } else if (CheckUtils.equalsString(string, "InstallationRecords")) {//安装记录
            return 18;
        } else if (CheckUtils.equalsString(string, "CarNumReader")) {//车牌读取
            return 19;
        }
        return 0;
    }

    //获取报警状态(报警状态：0：待确认，1：已确认，2：待审核，3：审核通过，4：退回)
    public static String getAlarmStatus(String status) {
        if (TextUtils.equals("0", status)) {
            return "待确认";
        } else if (TextUtils.equals("1", status)) {
            return "已确认";
        } else if (TextUtils.equals("2", status)) {
            return "待审核";
        } else if (TextUtils.equals("3", status)) {
            return "审核通过";
        } else if (TextUtils.equals("4", status)) {
            return "退回";
        }
        return "";
    }

    /**
     * 将数据保留两位小数
     */
    public static double getTwoDecimal(double num) {
        DecimalFormat dFormat = new DecimalFormat("#.00");
        String yearString = dFormat.format(num);
        Double temp = Double.valueOf(yearString);
        return temp;
    }

    //获取付款方式(二维码类型 1- 龙支付（暂不支持）2- 微信 3- 支付宝 4- 银联（暂不支持）)
    public static String getPayType(String payType) {
        if (TextUtils.equals("1", payType)) {
            return "建行龙支付";
        } else if (TextUtils.equals("2", payType)) {
            return "微信支付";
        } else if (TextUtils.equals("3", payType)) {
            return "支付宝支付";
        } else if (TextUtils.equals("4", payType)) {
            return "银联支付";
        }
        return "";
    }

    public static String getDateToString(long time) {
        Date d = new Date(time);
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        return sf.format(d);
    }

    /**
     * 退出登录
     *
     * @param context
     */
    public static void exitLogin(Context context) {
        UserInfo userLoginInfo = getUserLoginInfo();
        if (userLoginInfo != null) {
            SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(context, SweetAlertDialog.CUSTOM_IMAGE_TYPE);
            sweetAlertDialog.setCustomImage(R.drawable.exit_tip);
            sweetAlertDialog.setTitleText("退出当前用户？");
            sweetAlertDialog.setConfirmText("确定");
            sweetAlertDialog.showCancelButton(true);
            sweetAlertDialog.setCancelText("取消");
            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog) {
                    sweetAlertDialog.dismiss();
                    Utils.gotoLogin();
                }
            });

            sweetAlertDialog.show();
        } else {
            context.startActivity(new Intent(context, LoginActivity.class));
        }
    }

    /**
     * 高亮字体
     *
     * @param color   高亮颜色
     * @param text    源字符串
     * @param keyword 需要高亮的字符串
     * @return
     */
    public static SpannableString matcherSearchText(int color, String text, String keyword) {
        SpannableString ss = new SpannableString(text);
        //把字符串转成普通字符串，不在被当做正则表达式
        String patten = Pattern.quote(keyword);
        Pattern pattern = Pattern.compile(patten);
        Matcher matcher = pattern.matcher(ss);

        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            ss.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return ss;
    }

    /**
     * 字符串过滤,限制只允许字母、数字和汉字
     *
     * @param str
     * @return
     * @throws PatternSyntaxException
     */
    public static String stringFilter(String str) throws PatternSyntaxException {
        String regEx = "[^a-zA-Z\u4E00-\u9FA5]";//正则表达式
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }

    public static void setOcrValue(Context context){
        CardOcrRecogConfigure.getInstance()
                .initLanguage(context)
                .setSaveCut(true)
                .setnMainId(2)
                .setnSubID( 0)
                .setFlag(0)
                .setnCropType(0)
                .setSavePath(new DefaultPicSavePath());
    }
}
