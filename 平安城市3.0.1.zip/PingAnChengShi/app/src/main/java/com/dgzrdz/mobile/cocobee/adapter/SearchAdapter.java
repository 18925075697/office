package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;

import java.util.List;

/**
 * 查询的recycleView的adapter
 */

public class SearchAdapter extends QuickRcvAdapter<String> {

    public SearchAdapter(Context context, List<String> data, int... layoutId) {
        super(context, data, layoutId);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, String item) {
        viewHolder.setText(R.id.tv_name, item);
    }

}
