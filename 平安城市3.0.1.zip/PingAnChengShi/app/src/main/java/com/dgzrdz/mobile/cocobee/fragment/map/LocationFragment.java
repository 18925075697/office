package com.dgzrdz.mobile.cocobee.fragment.map;

import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ZoomControls;

import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.model.LatLng;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.common.LocationJson;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Description:标签位置
 * Author: Liubingren
 * Data:  2018/5/14
 * Time:  10:44
 */

public class LocationFragment extends BaseFragment {

    @BindView(R.id.mapview)
    MapView mMapview;
    @BindView(R.id.iv_location)
    ImageView mIvLocation;

    private static LocationJson.DataBean positionResponse;
    private BaiduMap baiduMap;
    private double mLatitude;
    private double mLongitude;
    public boolean isMoving = false;

    public static LocationFragment getInstance(LocationJson.DataBean positionResponse) {
        LocationFragment.positionResponse = positionResponse;
        LocationFragment fragment = new LocationFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        immersiveStatusBar(mMapview);
        initBaiduMap();
        initListener();
        mLatitude = Double.parseDouble(positionResponse.getEqlat());
        mLongitude = Double.parseDouble(positionResponse.getEqLng());
        initLocation();
    }

    /**
     * 初始化百度地图
     */
    private void initBaiduMap() {
        // 隐藏百度的LOGO
        View child = mMapview.getChildAt(1);
        if (child != null && (child instanceof ImageView || child instanceof ZoomControls)) {
            child.setVisibility(View.INVISIBLE);
        }
        // 不显示地图缩放控件（按钮控制栏）
        mMapview.showZoomControls(false);

        //得到百度地图
        baiduMap = mMapview.getMap();
        //设置地图为正常模式
        baiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
        //开启图层定位
        baiduMap.setMyLocationEnabled(true);
        //设定中心点坐标
        mLatitude = 22.555331 /*Double.parseDouble(searchRecResponse.getLat())*/;
        mLongitude = 113.951446 /*Double.parseDouble(searchRecResponse.getLng())*/;
        LatLng cenpt = new LatLng(mLatitude, mLongitude);
        //定义地图状态
        MapStatus mMapStatus = new MapStatus.Builder().target(cenpt).zoom(17).build();
        //定义MapStatusUpdate对象，以便描述地图状态将要发生的变化
        MapStatusUpdate mMapStatusUpdate = MapStatusUpdateFactory.newMapStatus(mMapStatus);
        //改变地图状态
        baiduMap.setMapStatus(mMapStatusUpdate);
    }

    private void initLocation() {
        baiduMap.setMyLocationEnabled(true);
        // 设置定位图层的配置（定位模式，是否允许方向信息，用户自定义定位图标）
        MyLocationData locData = new MyLocationData.Builder()
                .accuracy(0)  //如果不需要精度圈，将radius设为0即可
                // 此处设置开发者获取到的方向信息，顺时针0-360
                .direction(0).latitude(mLatitude)
                .longitude(mLongitude).build();
        // 设置定位数据
        baiduMap.setMyLocationData(locData);

        LatLng ll = new LatLng(mLatitude, mLongitude);
        MapStatusUpdate mapStatusUpdate = MapStatusUpdateFactory.newLatLngZoom(ll, 17f);
        baiduMap.animateMapStatus(mapStatusUpdate);
        isMoving = false;

    }

    /**
     * 事件监听
     */
    private void initListener() {

        //监听百度地图滑动动画是否完成,只有完成后才能允许跳转,否则地图卡死
        baiduMap.setOnMapStatusChangeListener(new BaiduMap.OnMapStatusChangeListener() {
            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus) {
                isMoving = true;
            }

            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus, int i) {

            }

            @Override
            public void onMapStatusChange(MapStatus mapStatus) {

            }

            @Override
            public void onMapStatusChangeFinish(MapStatus mapStatus) {
                isMoving = false;
            }
        });
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("标签位置");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_location;
    }


    @OnClick({R.id.iv_location})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_location:
                initLocation();
                showDeviceInfo();
                break;
        }
    }

    /**
     * 显示设备信息
     */
    private void showDeviceInfo() {
        View view1 = View.inflate(_mActivity, R.layout.label_last_info, null);
        AlertDialog alertDialog = Utils.showCornerDialog(_mActivity, view1, 270, 270);
        TextView stationNum = (TextView) alertDialog.findViewById(R.id.tv_station_num);
        TextView lastAddress = (TextView) alertDialog.findViewById(R.id.tv_last_address);
        TextView lastLat = (TextView) alertDialog.findViewById(R.id.tv_last_lat);
        TextView lastLng = (TextView) alertDialog.findViewById(R.id.tv_last_lng);
        TextView lastTime = (TextView) alertDialog.findViewById(R.id.tv_last_time);
        stationNum.setText(positionResponse.getDeviceId());
        lastAddress.setText(positionResponse.getEqaddr());
        lastLat.setText(positionResponse.getEqlat());
        lastLng.setText(positionResponse.getEqLng());
        lastTime.setText(positionResponse.getTagTime());
    }

    @Override
    public void onStop() {
        super.onStop();
        //关闭定位
        if (baiduMap != null) {
            baiduMap.setMyLocationEnabled(false);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mMapview != null) {
            mMapview.onResume();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mMapview != null) {
            mMapview.onPause();
        }
    }

    @Override
    public void onDestroy() {
        //关闭定位图层
        if (baiduMap != null) {
            baiduMap.setMyLocationEnabled(false);
        }

        if (mMapview != null) {
            mMapview.onDestroy();
            mMapview = null;
        }
        super.onDestroy();
    }
}
