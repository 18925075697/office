package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseTabFragment;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by Administrator on 2018/6/27.
 */

public class InventoryCheckFragment extends BaseTabFragment {
    @BindView(R.id.iv_back)
    ImageView mIvBack;
    @BindView(R.id.ll_top)
    LinearLayout mLlTop;
    @BindView(R.id.view)
    View mView;
    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private String[] titles = new String[]{"标签库存", "车牌库存"};

    public static InventoryCheckFragment getInstance() {
        InventoryCheckFragment fragment = new InventoryCheckFragment();
        return fragment;
    }

    @Override
    public String[] getTabTitles() {
        return titles;
    }

    @Override
    public ArrayList<Fragment> getFragments() {
        mFragments.add(LabelFragment.getInstance());
        mFragments.add(CarNumFragment.getInstance());
        return mFragments;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        immersiveStatusBar(mView);
    }

    @Override
    public boolean canScroll() {
        return false;
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_inventory_check;
    }

    @Override
    public int getInitPageNum() {
        return 2;
    }


    @OnClick({R.id.iv_back, R.id.ll_top})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                _mActivity.finish();
                break;
        }
    }
}
