package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.StationProblemResponse;

import java.util.List;

/**
 * Created by Administrator on 2017/5/5.
 */

public class ProblemSelectAdapter extends QuickRcvAdapter<StationProblemResponse> {

    public ProblemSelectAdapter(Context context, List data, int... layoutId) {
        super(context, data, R.layout.item_problem_select);
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, StationProblemResponse item) {
        TextView tvLabel = viewHolder.getView(R.id.tv_label);
        viewHolder.setText(R.id.tv_label, item.getName());
        tvLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (item.getSelect()) {//选中
                    item.setSelect(false);
                    tvLabel.setBackgroundResource(R.drawable.btn_style_blue_click);
                } else {
                    tvLabel.setBackgroundResource(R.drawable.btn_style_blue);
                    item.setSelect(true);
                }

            }
        });

    }
}
