package com.dgzrdz.mobile.cocobee.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.service.DownloadService;

import java.util.Date;

public class UpdateManager {

    private Context mContext;
    private final VersionInfo mVersionInfo;
    private AlertDialog mAlertDialog;
    private TextView mTitle;
    private TextView mTip;
    private ProgressBar mProgressBar;

    public UpdateManager(Context context) {
        this.mContext = context;
        mVersionInfo = Utils.getUpdateVersionInfo();
        //注册广播接收器
        ShowDialogReceiver receiver = new ShowDialogReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.dgzrdz.mobile.cocobee.utils.UpdateManager.ShowDialogReceiver");
        mContext.registerReceiver(receiver, filter);
    }

    // 显示更新程序对话框，供主程序调用
    public void showNoticeDialog() {
        View view = View.inflate(mContext, R.layout.dialog_update, null);
        AlertDialog mAlertDialog = Utils.showCornerDialog(mContext, view, 208, 240);
        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.setCancelable(false);
        TextView content = (TextView) mAlertDialog.findViewById(R.id.tv_content);
        CheckBox cbNotNotice = (CheckBox) mAlertDialog.findViewById(R.id.cb_not_notice);
        TextView updateLater = (TextView) mAlertDialog.findViewById(R.id.tv_update_late);
        TextView updateNow = (TextView) mAlertDialog.findViewById(R.id.tv_update_now);

        cbNotNotice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { //不再提醒
                    mVersionInfo.setDate(new Date(System.currentTimeMillis()));
                    mVersionInfo.setUnRemind(true);
                    Utils.putUpdateVersionInfo(mVersionInfo);
                }
            }
        });
        if (CheckUtils.equalsString(mVersionInfo.getAndroidUpdate(), "1")) {//强制更新
            mAlertDialog.setCancelable(false);
            mAlertDialog.setCanceledOnTouchOutside(false);
            content.setText("发现新版本的软件包，为避免影响您正常使用本软件，请立即更新！");
            cbNotNotice.setVisibility(View.INVISIBLE);//不提供不再提醒功能
            updateLater.setVisibility(View.GONE);//不提供取消功能
        } else {
            mAlertDialog.setCancelable(true);
            mAlertDialog.setCanceledOnTouchOutside(true);
            content.setText("发现新版本的软件包，为避免影响您正常使用本软件，建议更新！");
            cbNotNotice.setVisibility(View.VISIBLE);
            updateLater.setVisibility(View.VISIBLE);
        }

        updateLater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAlertDialog.dismiss();
            }
        });

        updateNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAlertDialog.dismiss();
                if (mVersionInfo.isDownload() == true) {
                    XToastUtils.showShortToast("新版本已经在下载中");
                    showDialog();
                } else {
                    Intent intent = new Intent(mContext, DownloadService.class);
                    mContext.startService(intent);// 开启服务，下载新版本
                }
            }
        });
    }

    /**
     * 显示升级框
     */
    private void showDialog() {
        View view = View.inflate(mContext, R.layout.download_view_dialog, null);
        mAlertDialog = Utils.showCornerDialog(mContext, view, 270, 100);

        if (CheckUtils.equalsString(mVersionInfo.getAndroidUpdate(), "1")) {//强制更新
            mAlertDialog.setCanceledOnTouchOutside(false);
            mAlertDialog.setCancelable(false);
        } else {
            mAlertDialog.setCanceledOnTouchOutside(true);
            mAlertDialog.setCancelable(true);
        }
        mTitle = (TextView) mAlertDialog.findViewById(R.id.tvTitle);
        mTip = (TextView) mAlertDialog.findViewById(R.id.tvTip);
        mProgressBar = (ProgressBar) mAlertDialog.findViewById(R.id.pbNotification);
        mProgressBar.setMax(100);
    }

    public class ShowDialogReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            int count = bundle.getInt("count");
            switch (count) {
                case 0://开始
                    showDialog();
                    break;
                case 1://1下载中
                    if (mAlertDialog != null && mAlertDialog.isShowing()) {
                        int i = bundle.getInt("i");
                        mTip.setText("正在下载(" + i + "%)");
                        mProgressBar.setProgress(i);
                    }
                    break;
                case 2://2下载完成
                    if (mAlertDialog != null && mAlertDialog.isShowing()) {
                        mAlertDialog.dismiss();
                    }
                    break;
                case 3:// 3下载失败
                    if (mAlertDialog != null && mAlertDialog.isShowing()) {
                        mAlertDialog.dismiss();
                    }
                    break;
            }
        }
    }

}
