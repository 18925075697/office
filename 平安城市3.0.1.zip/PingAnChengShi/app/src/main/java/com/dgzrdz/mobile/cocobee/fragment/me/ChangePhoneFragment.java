package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.api.LoginApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.TimeCount;

import java.text.ParseException;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:修改手机号
 * Author: Liubingren
 * Data:  2018/11/26
 * Time:  11:27
 */

public class ChangePhoneFragment extends BaseFragment {

    @BindView(R.id.et_id_card)
    EditText mEtIdCard;
    @BindView(R.id.et_new_phone)
    EditText mEtNewPhone;
    @BindView(R.id.et_ckeck_code)
    EditText mEtCkeckCode;
    @BindView(R.id.tv_get_check_code)
    TextView mTvGetCheckCode;
    @BindView(R.id.tv_upload)
    TextView mTvUpload;

    private UserInfo mUserLoginInfo;
    private TimeCount timeCount;

    public static ChangePhoneFragment getInstance() {
        ChangePhoneFragment fragment = new ChangePhoneFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("更改手机号");
        timeCount = new TimeCount(_mActivity, 60000, 1000, mTvGetCheckCode);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_change_manager_phone;
    }

    @OnClick({R.id.tv_get_check_code, R.id.tv_upload})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_get_check_code://获取验证码
                getCheckCode();
                break;
            case R.id.tv_upload://提交
                String idCard = mEtIdCard.getText().toString().trim();
                String phone = mEtNewPhone.getText().toString().trim();
                String checkCode = mEtCkeckCode.getText().toString().trim();

                String idCArdNum = "";

                try {
                    idCArdNum = CheckUtils.IDCardValidate(idCard);
                } catch (ParseException e) {
                    e.printStackTrace();
                    XToastUtils.showLongToast("身份证无效");
                } catch (Exception e) {
                    idCArdNum = "身份证格式错误";
                    e.printStackTrace();
                    XToastUtils.showLongToast("身份证无效");
                }

                if (CheckUtils.isEmpty(idCard)) {
                    XToastUtils.showShortToast("请输入身份证号码");
                } else if (!CheckUtils.equalsString(idCArdNum, "")) {
                    XToastUtils.showLongToast("身份证无效");
                } else if (CheckUtils.isEmpty(phone)) {
                    XToastUtils.showShortToast("请输入新手机号码");
                } else if (!CheckUtils.isMobilePhone(phone)) {
                    XToastUtils.showShortToast("手机号格式错误");
                } else if (CheckUtils.isEmpty(checkCode)) {
                    XToastUtils.showShortToast("请输入验证码");
                } else {
                    upload(idCard, phone, checkCode);
                }
                break;
        }
    }

    /**
     * 上传
     *
     * @param idCard
     * @param phone
     * @param checkCode
     */
    private void upload(String idCard, String phone, String checkCode) {
        DatasApiUtils.changePhone(_mActivity,mUserLoginInfo.getDataList().getAppMemberId() ,phone, idCard, checkCode, new DialogCallback<Object>(_mActivity, "修改中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                Utils.putUserLoginNum(phone);
                XToastUtils.showShortToast("修改成功");
                Utils.gotoLogin();
            }
        });
    }


    /**
     * 获取验证码
     */
    private void getCheckCode() {
        String phone = mEtNewPhone.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            XToastUtils.showShortToast("请填写手机号码");
            return;
        }

        if (!CheckUtils.isMobilePhone(phone)) {
            XToastUtils.showShortToast("手机号码格式不正确");
            return;
        }

        LoginApiUtils.sendCheckCode(_mActivity, phone, new DialogCallback<Object>(_mActivity, "获取验证码...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                timeCount.start();
            }
        });
    }

    /**
     * 停止计时器
     */
    private void stopCountTimer() {
        if (timeCount != null) {
            timeCount.cancel();
            timeCount = null;
        }
    }

    @Override
    public void onDestroy() {
        stopCountTimer();
        super.onDestroy();
    }
}
