package com.dgzrdz.mobile.cocobee.fragment.home;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.BarCodeScanAct;
import com.dgzrdz.mobile.cocobee.activity.data.CarOwnerInfoActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectDetailActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectUnArcActivity;
import com.dgzrdz.mobile.cocobee.activity.data.SelectBindingCarActivity;
import com.dgzrdz.mobile.cocobee.activity.pay.SelectPayTypeActivity;
import com.dgzrdz.mobile.cocobee.adapter.ComputeAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.AddOrderResponse;
import com.dgzrdz.mobile.cocobee.response.BaoxianUploadResponse;
import com.dgzrdz.mobile.cocobee.response.ComputeResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;
import com.dgzrdz.mobile.cocobee.response.TagServiceResponse;
import com.dgzrdz.mobile.cocobee.response.TagServiceTaocanResponse;
import com.dgzrdz.mobile.cocobee.response.TaocanUploadResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;
import com.dgzrdz.mobile.cocobee.view.dialog.SelectServiceDialog;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:信息录入界面
 * Author: Liubingren
 * Data:  2018/6/25
 * Time:  10:44
 */

public class InfoInputFragment extends BaseFragment {
    private static final int REQUEST_TIAOXINMA_CODE = 555;
    private static String sysConfType;
    @BindView(R.id.tv_add_car_owner)
    TextView mTvAddCarOwner;
    @BindView(R.id.tv_car_owner_phone)
    TextView mTvCarOwnerPhone;
    @BindView(R.id.ll_car_owner_info)
    LinearLayout mLlCarOwnerInfo;
    @BindView(R.id.iv_car_owner_more)
    ImageView mIvCarOwnerMore;
    @BindView(R.id.tv_car_brand_model)
    TextView mTvCarBrandModel;
    @BindView(R.id.iv_car_info_more)
    ImageView mIvCarInfoMore;
    @BindView(R.id.et_tag)
    EditText mEtTag;
    @BindView(R.id.iv_scan_img)
    ImageView mIvScanImg;
    @BindView(R.id.tv_car_num_prefix)
    TextView mTvCarNumPrefix;
    @BindView(R.id.et_car_num)
    EditText mEtCarNum;
    @BindView(R.id.tv_select_service)
    TextView mTvSelectService;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.tv_upload)
    TextView mTvUpload;
    @BindView(R.id.tv_select_title)
    TextView mTvSelectTitle;
    @BindView(R.id.tv_select_baoxian)
    TextView mTvSelectBaoxian;
    @BindView(R.id.ll_select_service)
    LinearLayout mLlSelectService;
    @BindView(R.id.ll_car_num_info)
    LinearLayout mLlCarNumInfo;
    @BindView(R.id.ll_other_add)
    LinearLayout mLlOtherAdd;
    @BindView(R.id.tv_group_compute)
    TextView mTvGroupCompute;
    @BindView(R.id.ll_group_compute)
    LinearLayout mLlGroupCompute;

    private UserInfo mUserLoginInfo;
    private UserBeanResponse mUserBeanResponse;
    private GuardianObjectResponse mGuardianObjectResponse;
    private List<TagServiceResponse.ServiceTypeListBean> mServiceTypeListBeans = new ArrayList<>();//选中服务后,存储额外输入的集合
    private List<PolicyServiceResponse.PolicyServiceTypeListBean> mPolicyServiceTypeListBeans = new ArrayList<>();//选中保险后,存储额外输入的集合

    private double totalPayNum;
    private List<PolicyServiceResponse> mPolicyList = new ArrayList<>();
    private List<TagServiceResponse> mTagList = new ArrayList<>();
    private ComputeResponse mComputeResponse;
    private List<TagServiceTaocanResponse> serviceTaocanResponses = new ArrayList<>();
    private List<Integer> selectPositions = new ArrayList<>();
    private TagServiceTaocanResponse mSelectTaocanResponse;

    public static InfoInputFragment getInstance(String sysConfType) {
        InfoInputFragment.sysConfType = sysConfType;
        InfoInputFragment fragment = new InfoInputFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mTvTitle.setCompoundDrawables(null, null, null, null);
        mUserLoginInfo = Utils.getUserLoginInfo();
        if (CheckUtils.equalsString(sysConfType, "2")) {//集团业务
            mLlGroupCompute.setVisibility(View.VISIBLE);
        } else {
            mLlGroupCompute.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("信息录入");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_info_input;
    }


    @OnClick({R.id.ll_car_owner_info, R.id.iv_scan_img, R.id.tv_car_brand_model, R.id.ll_select_service, R.id.tv_upload, R.id.tv_group_compute})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_car_owner_info:
                Intent intent = new Intent(_mActivity, CarOwnerInfoActivity.class);
                intent.putExtra("isSelect", true);

                if (mUserBeanResponse != null) {
                    intent.putExtra("userBean", mUserBeanResponse);
                }
                startActivity(intent);
                break;
            case R.id.tv_car_brand_model://监护对象
                if (mUserBeanResponse == null) {//没选车主信息
                    XToastUtils.showShortToast("请先添加车主");
                } else {//选了车主后直接跳转选择对象
                    Intent intent2 = new Intent(_mActivity, SelectBindingCarActivity.class);
                    intent2.putExtra("userBean", mUserBeanResponse);
                    startActivity(intent2);
                }
                break;
            case R.id.iv_scan_img:
                if (PermissionUtils.requestPermission(this, Manifest.permission.CAMERA, REQUEST_TIAOXINMA_CODE, "权限申请：\n我们需要您开启相机权限")) {
                    tiaoXinMa();
                }
                break;
            case R.id.ll_select_service:
                if (mUserBeanResponse == null) {
                    XToastUtils.showShortToast("请先选择用户");
                } else if (mGuardianObjectResponse == null) {
                    XToastUtils.showShortToast("请先选择监护对象");
                } else if (CheckUtils.equalsString(sysConfType, "2") && mComputeResponse == null) {//集团单位
                    XToastUtils.showShortToast("请先选择集团单位");
                } else {
                    showSelectServiceDialog();
                }

                break;
            case R.id.tv_upload:
                checkInput();
                break;
            case R.id.tv_group_compute://集团单位
                getComputes();
                break;
        }
    }

    /**
     * 获取集团单位
     */
    private void getComputes() {
        DatasApiUtils.getComputeList(_mActivity, mUserLoginInfo.getDataList().getSysAreaId(), new DialogCallback<List<ComputeResponse>>(_mActivity, "获取集团单位...") {
            @Override
            public void onSuccess(List<ComputeResponse> computeResponses, Call call, Response response) {
                if (computeResponses != null && computeResponses.size() > 0) {
                    showComputeDialog(computeResponses);
                } else {
                    XToastUtils.showShortToast("暂无集团单位");
                }
            }
        });
    }

    /**
     * 显示集团单位选择弹框
     *
     * @param computeResponses 集团单位列表
     */
    private void showComputeDialog(List<ComputeResponse> computeResponses) {
        View view = View.inflate(_mActivity, R.layout.label_list, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(_mActivity, view, 270, 218);
        RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.listView);
        TextView tvTitleCarLabel = (TextView) alertDialog.findViewById(R.id.tv_title_car_label);
        tvTitleCarLabel.setText("请选择集团单位");
        ComputeAdapter adapter = new ComputeAdapter(_mActivity, computeResponses);
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new ListLineDecoration());
        recyclerView.setLayoutManager(new LinearLayoutManager(_mActivity));
        adapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {
                alertDialog.dismiss();
                //服务信息会根据集团单位变化,选中集团单位时,清除已选中的服务信息
                clearService();
                mComputeResponse = computeResponses.get(position);
                mTvGroupCompute.setText(mComputeResponse.getSysGroupName());
            }
        });
    }

    /**
     * 提交前检查必填的是否都填了
     */
    private void checkInput() {
        String tag = mEtTag.getText().toString().trim();
        String carNum = mEtCarNum.getText().toString().trim();
        String selectService = mTvSelectService.getText().toString().trim();
        if (mUserBeanResponse == null) {
            XToastUtils.showShortToast("请添加用户");
            return;
        } else if (mGuardianObjectResponse == null) {
            XToastUtils.showShortToast("请选择监护对象");
            return;
        } else if (CheckUtils.isEmpty(selectService)) {
            XToastUtils.showShortToast("请选择服务");
            return;
        } else if (CheckUtils.isEmpty(tag)) {
            XToastUtils.showShortToast("请输入标签号");
            return;
        } else if (CheckUtils.equalsString(mGuardianObjectResponse.getSysServiceTypeSpecialType(), "1")
                && CheckUtils.equalsString(mGuardianObjectResponse.getSysAreaCarNumEnabled(), "1")
                && CheckUtils.isEmpty(carNum)) {//启用了车牌且车牌为空
            XToastUtils.showShortToast("请输入车牌号");
            return;
        }


        //检查套餐额外添加的属性是否都填了
        for (int i = 0; i < mServiceTypeListBeans.size(); i++) {
            TagServiceResponse.ServiceTypeListBean serviceTypeListBean = mServiceTypeListBeans.get(i);
            String inputInfo = getInputInfo(i);
            if (CheckUtils.isEmpty(inputInfo)) {
                XToastUtils.showShortToast(serviceTypeListBean.getSysServiceSetPropOptionInputName() + "不能为空");
                return;
            } else if (CheckUtils.equalsString(serviceTypeListBean.getSysServiceSetPropOptionSpecial(), "1") && !CheckUtils.isMobilePhone(inputInfo)) {//手机号
                XToastUtils.showShortToast(serviceTypeListBean.getSysServiceSetPropOptionInputName() + "格式不正确");
                return;
            } else if (CheckUtils.equalsString(serviceTypeListBean.getSysServiceSetPropOptionSpecial(), "2")) {//身份证号码
                String idCArdNum = "";

                try {
                    idCArdNum = CheckUtils.IDCardValidate(inputInfo);
                } catch (Exception e) {
                    idCArdNum = "身份证格式错误";
                    e.printStackTrace();
                    XToastUtils.showLongToast("身份证无效");
                }
                if (!CheckUtils.equalsString(idCArdNum, "")) {
                    XToastUtils.showShortToast(serviceTypeListBean.getSysServiceSetPropOptionInputName() + "格式不正确");
                    return;
                }
            }
        }

        //检查保险额外添加的属性是否都填了
        for (int i = 0; i < mPolicyServiceTypeListBeans.size(); i++) {
            PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = mPolicyServiceTypeListBeans.get(i);
            String inputInfo = getInputInfo(i + mServiceTypeListBeans.size());
            if (CheckUtils.isEmpty(inputInfo)) {
                XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "不能为空");
                return;
            } else if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeSpecial(), "1") && !CheckUtils.isMobilePhone(inputInfo)) {//手机号
                XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "格式不正确");
                return;
            } else if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeSpecial(), "2")) {//身份证
                String idCArdNum = "";

                try {
                    idCArdNum = CheckUtils.IDCardValidate(inputInfo);
                } catch (Exception e) {
                    idCArdNum = "身份证格式错误";
                    e.printStackTrace();
                    XToastUtils.showLongToast("身份证无效");
                }
                if (!CheckUtils.equalsString(idCArdNum, "")) {
                    XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "格式不正确");
                    return;
                }
            }
        }

        getObjectDetail();
    }

    /**
     * 获取选中监护对象的详情
     */
    private void getObjectDetail() {
        DatasApiUtils.getJianhuDetail(_mActivity, mGuardianObjectResponse.getMemberServiceObjId(), new DialogCallback<GuardianObjectDetailResponse>(_mActivity, "获取监护对象详情...") {
            @Override
            public void onSuccess(GuardianObjectDetailResponse guardianObjectDetailResponse, Call call, Response response) {
                if (guardianObjectDetailResponse != null) {
                    checkObject(guardianObjectDetailResponse);
                }
            }
        });
    }

    /**
     * 检查监护对象必填项是否都填了
     *
     * @param guardianObjectDetailResponse
     */
    private void checkObject(GuardianObjectDetailResponse guardianObjectDetailResponse) {
        List<GuardianObjectDetailResponse.CustomizeBean> customize = guardianObjectDetailResponse.getCustomize();
        if (customize != null && customize.size() > 0) {
            for (int i = 0; i < customize.size(); i++) {
                GuardianObjectDetailResponse.CustomizeBean customizeBean = customize.get(i);
                if (CheckUtils.equalsString(customizeBean.getSysPropertyRequired(), "1") && CheckUtils.isEmpty(customizeBean.getSysPropertyValue())) {//必填的,没值
                    XToastUtils.showShortToast(customizeBean.getSysPropertyName() + "不能为空");
                    Intent intent;
                    if (mGuardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {//未激活
                        intent = new Intent(_mActivity, JianHuObjectUnArcActivity.class);
                        intent.putExtra("userBean", mUserBeanResponse);
                    } else {
                        intent = new Intent(_mActivity, JianHuObjectDetailActivity.class);
                    }
                    intent.putExtra("guardianObjectResponse", mGuardianObjectResponse);
                    startActivity(intent);
                    return;
                }
            }
        }

        creatOrder();
    }

    /**
     * 生成订单
     */
    private void creatOrder() {
        String tag = mEtTag.getText().toString().trim();
        String carNum = mEtCarNum.getText().toString().trim();

        String sysServiceTypeId = mGuardianObjectResponse.getSysServiceTypeId();
        String memberServiceObjId = mGuardianObjectResponse.getMemberServiceObjId();
        String memberServiceObjActiveFlag = mGuardianObjectResponse.getMemberServiceObjActiveFlag() + "";
        String appMemberId = mUserLoginInfo.getDataList().getAppMemberId();
        String sysAreaId = mUserLoginInfo.getDataList().getSysAreaId();
        String sysInstallPlaceId = mUserLoginInfo.getDataList().getSysInstallPlaceId();
        String memberOrderTotalPay = totalPayNum + "";
        String hLabelNo = tag;
        String hPlateNo = carNum;

        List<TaocanUploadResponse> exvalueJson = getUploadTaocan();
        List<BaoxianUploadResponse> porpertyJson = getUploadBaoxian();

        PayApiUtils.creatOrder(_mActivity, sysConfType, sysServiceTypeId, memberServiceObjId, memberServiceObjActiveFlag, appMemberId, sysAreaId, memberOrderTotalPay,
                porpertyJson, exvalueJson, hLabelNo, hPlateNo, mGuardianObjectResponse.getSysAreaCarNumPrefix() + carNum, "0",
                sysInstallPlaceId, new DialogCallback<AddOrderResponse>(_mActivity, "订单生成中...") {
                    @Override
                    public void onSuccess(AddOrderResponse addOrderResponse, Call call, Response response) {
                        if (addOrderResponse != null) {
                            addOrderResponse.setPayPrice(totalPayNum);
                            gotoPay(addOrderResponse);
                        } else {
                            XToastUtils.showShortToast("生成订单出错");
                        }
                    }

                });
    }

    /**
     * 获取上传的保险json
     */
    private List<BaoxianUploadResponse> getUploadBaoxian() {
        List<BaoxianUploadResponse> baoxianUploadResponses = new ArrayList<>();
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {//该行有被选中的保险
                //被选中的保险
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                BaoxianUploadResponse baoxianUploadResponse = new BaoxianUploadResponse();
                baoxianUploadResponse.setSysInsuranceConfPriceId(policyServiceTypeListBean.getSysInsuranceConfPriceId());
                baoxianUploadResponse.setSysInsuranceId(policyServiceTypeListBean.getSysInsuranceId());
                baoxianUploadResponse.setSysInsuranceTypeId(policyServiceTypeListBean.getSysInsuranceTypeId());
                baoxianUploadResponse.setSysInsuranceTypeName(policyServiceTypeListBean.getSysInsuranceTypeName());
                baoxianUploadResponse.setSysInsuranceConfYears(policyServiceTypeListBean.getSysInsuranceConfYears());
                baoxianUploadResponse.setSysInsurancePrice(policyServiceTypeListBean.getSysInsurancePrice() + "");
                if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeInput(), "1")) {//有额外输入
                    for (int j = 0; j < mPolicyServiceTypeListBeans.size(); j++) {//额外保险输入集合
                        if (CheckUtils.equalsString(mPolicyServiceTypeListBeans.get(j).getSysInsuranceConfId(), policyServiceTypeListBean.getSysInsuranceConfId())) {//id相同,说明是同一个
                            String inputInfo = getInputInfo(j + mServiceTypeListBeans.size());
                            baoxianUploadResponse.setSysInsuranceExValueStr(inputInfo);
                        }
                    }
                }
                baoxianUploadResponses.add(baoxianUploadResponse);
            }
        }
        return baoxianUploadResponses;
    }

    /**
     * 获取上传的套餐json
     */
    private List<TaocanUploadResponse> getUploadTaocan() {
        String realid = "";
        List<TaocanUploadResponse> taocanUploadResponses = new ArrayList<>();

        //获取年限的Realid
        for (int i = 0; i < mTagList.size(); i++) {
            TagServiceResponse tagServiceResponse = mTagList.get(i);
            if (tagServiceResponse.getPosition() != -1) {//该行有选中的服务
                TagServiceResponse.ServiceTypeListBean serviceTypeListBean = tagServiceResponse.getServiceTypeList().get(tagServiceResponse.getPosition());
                if (!CheckUtils.isEmpty(serviceTypeListBean.getRealid())) {//为选中的年限
                    realid = serviceTypeListBean.getRealid();
                }
            }
        }

        //获取套餐集合
        for (int i = 0; i < mTagList.size(); i++) {
            TagServiceResponse tagServiceResponse = mTagList.get(i);
            if (tagServiceResponse.getPosition() != -1) {//该行有选中的服务
                TagServiceResponse.ServiceTypeListBean serviceTypeListBean = tagServiceResponse.getServiceTypeList().get(tagServiceResponse.getPosition());
                if (CheckUtils.isEmpty(serviceTypeListBean.getRealid())) {//为选中的除年限外的套餐
                    TaocanUploadResponse taocanUploadResponse = new TaocanUploadResponse();
                    taocanUploadResponse.setRealid(realid);
                    taocanUploadResponse.setSysServiceSetPropId(serviceTypeListBean.getSysServiceSetPropId());
                    taocanUploadResponse.setSysServiceSetPropOptionId(serviceTypeListBean.getId());
                    if (CheckUtils.equalsString(serviceTypeListBean.getSysServiceSetPropOptionInput(), "1")) {//有额外输入
                        for (int j = 0; j < mServiceTypeListBeans.size(); j++) {//额外套餐输入集合
                            if (CheckUtils.equalsString(mServiceTypeListBeans.get(j).getId(), serviceTypeListBean.getId())) {//id相同,说明是同一个
                                String inputInfo = getInputInfo(j);
                                taocanUploadResponse.setSysServiceSetPropExValueStr(inputInfo);
                            }
                        }
                    }
                    taocanUploadResponses.add(taocanUploadResponse);
                }
            }
        }
        return taocanUploadResponses;
    }

    /**
     * 获取用户输入选择的值
     *
     * @param position 子view的位置
     * @return
     */
    private String getInputInfo(int position) {
        RelativeLayout relativeLayout = (RelativeLayout) mLlOtherAdd.getChildAt(position);

        EditText editText = (EditText) relativeLayout.getChildAt(1);
        String string = editText.getText().toString().trim();

        return string;
    }

    /**
     * 去支付
     *
     * @param addOrderResponse
     */
    private void gotoPay(AddOrderResponse addOrderResponse) {
        EventBus.getDefault().post(new EventManager(EventConstants.ORDER_CREATER_SUCCESS));
        Intent intent = new Intent(_mActivity, SelectPayTypeActivity.class);
        intent.putExtra("memberOrderId", addOrderResponse.getMemberOrderId());
        startActivity(intent);
    }

    /**
     * 显示选择服务dialog
     */
    private void showSelectServiceDialog() {
        SelectServiceDialog dialog = new SelectServiceDialog();
        dialog.setGuardianObjectResponse(mGuardianObjectResponse);
        dialog.setUserBeanResponse(mUserBeanResponse);
        if (CheckUtils.equalsString(sysConfType, "2")) {
            dialog.setGroupResponse(mComputeResponse);
        }

        dialog.setServiceInfo(serviceTaocanResponses, selectPositions, mPolicyList, mTagList, mSelectTaocanResponse);
        dialog.show(getFragmentManager(), "selectService");
    }

    /**
     * 条形码扫描
     */
    private void tiaoXinMa() {
        startActivityForResult(new Intent(_mActivity, BarCodeScanAct.class), 1666);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1666 && resultCode == 1667) {
            String scanResult = data.getStringExtra("scanResult");
            if (!CheckUtils.isEmpty(scanResult)) {
                mEtTag.setText(scanResult);
            }
            return;
        }
    }

    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_TIAOXINMA_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    tiaoXinMa();
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(_mActivity, Manifest.permission.ACCESS_FINE_LOCATION, "app需要开启相机权限,是否去设置?", "用户拒绝相机授权");
                }
                break;
        }
    }


    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.CAR_SELECT_SUCCESS://车辆选择成功
                //服务信息会根据监护对象变化,选中监护对象时,清除已选中的服务信息
                clearService();
                Intent data = (Intent) eventManager.getData();
                mGuardianObjectResponse = (GuardianObjectResponse) data.getSerializableExtra("guardianObjectResponse");
                mUserBeanResponse = (UserBeanResponse) data.getSerializableExtra("userBean");
                setCarOwnerSelectSuccess();
                setCarInfo();
                break;
            case EventConstants.SERVICE_SELECT_SUCCESS://服务选择成功
                Intent intent = (Intent) eventManager.getData();
                setServiceSelect(intent);
                break;
            case EventConstants.ORDER_CANCEL_SUCCESS://订单取消成功
                _mActivity.finish();
                break;
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
                _mActivity.finish();
                break;
        }
    }

    /**
     * 清清除已选的服务信息
     */
    private void clearService() {
        //清除UI
        mTvSelectTitle.setText("选中服务");
        mTvSelectService.setVisibility(View.VISIBLE);
        mTvSelectService.setText("");
        mTvSelectBaoxian.setVisibility(View.GONE);
        mTvSelectBaoxian.setText("");
        //清除数据
        serviceTaocanResponses.clear();
        selectPositions.clear();
        mPolicyList.clear();
        mTagList.clear();
        mSelectTaocanResponse = null;
        totalPayNum = 0;
        mMtvPayNum.setAmount(totalPayNum);
        mLlOtherAdd.removeAllViews();
    }

    /**
     * 服务选择成功,设置
     *
     * @param intent
     */
    private void setServiceSelect(Intent intent) {
        //套餐的集合
        List<TagServiceTaocanResponse> tagServiceTaocanResponses1 = (List<TagServiceTaocanResponse>) intent.getSerializableExtra("tagServiceTaocanResponses");
        serviceTaocanResponses.clear();
        serviceTaocanResponses.addAll(tagServiceTaocanResponses1);
        //选中位置的集合
        List<Integer> selectPosition = (List<Integer>) intent.getSerializableExtra("selectPosition");
        selectPositions.clear();
        selectPositions.addAll(selectPosition);


        List<PolicyServiceResponse> policyList = (List<PolicyServiceResponse>) intent.getSerializableExtra("policyList");
        mPolicyList.clear();
        mPolicyList.addAll(policyList);

        mSelectTaocanResponse = (TagServiceTaocanResponse) intent.getSerializableExtra("selectTaocanResponse");

        List<TagServiceResponse> tagListUI = (List<TagServiceResponse>) intent.getSerializableExtra("tagListUI");
        mTagList.clear();
        mTagList.addAll(tagListUI);

        mTvSelectTitle.setText("已选");
        totalPayNum = 0;
        if (mSelectTaocanResponse != null) {
            //设置选中套餐
            mTvSelectService.setText(mSelectTaocanResponse.getDesc());
            totalPayNum = totalPayNum + mSelectTaocanResponse.getPrice();//支付金额 = 套餐金额 + 保险金额
        } else {
            mTvSelectService.setVisibility(View.GONE);
        }

        //设置选中保险
        String text = "";
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                totalPayNum = totalPayNum + policyServiceTypeListBean.getSysInsurancePrice();
                if (policyServiceTypeListBean.getSysInsurancePrice() == 0) {
                    text = text + policyServiceResponse.getTitle() + ":" + policyServiceTypeListBean.getSysInsuranceConfYearsShow() + (i == mPolicyList.size() - 1 ? " 赠送" : "赠送\n");
                } else {
                    text = text + policyServiceResponse.getTitle() + ":" + policyServiceTypeListBean.getSysInsuranceConfYearsShow() + " ¥" + policyServiceTypeListBean.getSysInsurancePrice() + (i == mPolicyList.size() - 1 ? "" : "\n");
                }
            }
        }
        if (!CheckUtils.isEmpty(text)) {
            mTvSelectBaoxian.setVisibility(View.VISIBLE);
            mTvSelectBaoxian.setText(text);
        } else {
            mTvSelectBaoxian.setVisibility(View.GONE);
            mTvSelectBaoxian.setText(text);
        }

        mLlOtherAdd.removeAllViews();
        mServiceTypeListBeans.clear();
        //设置套餐是否有额外添加的属性
        for (int i = 0; i < mTagList.size(); i++) {
            TagServiceResponse tagServiceResponse = mTagList.get(i);
            if (tagServiceResponse.getPosition() != -1) {//该行有被选中的服务
                TagServiceResponse.ServiceTypeListBean serviceTypeListBean = tagServiceResponse.getServiceTypeList().get(tagServiceResponse.getPosition());//被选中的具体服务
                if (CheckUtils.equalsString(serviceTypeListBean.getSysServiceSetPropOptionInput(), "1")) {//有额外输入
                    mServiceTypeListBeans.add(serviceTypeListBean);
                    addTextView(serviceTypeListBean);
                }
            }
        }

        mPolicyServiceTypeListBeans.clear();
        //设置保险是否有额外添加属性
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {//该行有被选中的保险
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());//被选中的具体服务
                if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeInput(), "1")) {//有额外输入
                    mPolicyServiceTypeListBeans.add(policyServiceTypeListBean);
                    addPolicyTextView(policyServiceTypeListBean);
                }
            }
        }

        mMtvPayNum.setAmount(totalPayNum);
    }

    /**
     * 添加保险文本输入模式控件
     *
     * @param policyServiceTypeListBean
     */
    private void addPolicyTextView(PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean) {
        View view = View.inflate(_mActivity, R.layout.service_text_view, null);
        TextView tvNoticeContent = (TextView) view.findViewById(R.id.tv_notice_content);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        EditText etText = (EditText) view.findViewById(R.id.et_text);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlOtherAdd.addView(view, layoutParams);

        tvTextTitle.setText(policyServiceTypeListBean.getSysInsuranceTypeInputName());
        etText.setHint(policyServiceTypeListBean.getSysInsuranceTypeInputName());
        tvNoticeContent.setText(policyServiceTypeListBean.getSysInsuranceTypeInputInfo());
    }

    /**
     * 添加套餐文本输入模式控件
     *
     * @param serviceTypeListBean
     */
    private void addTextView(TagServiceResponse.ServiceTypeListBean serviceTypeListBean) {
        View view = View.inflate(_mActivity, R.layout.service_text_view, null);
        TextView tvNoticeContent = (TextView) view.findViewById(R.id.tv_notice_content);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        EditText etText = (EditText) view.findViewById(R.id.et_text);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlOtherAdd.addView(view, layoutParams);

        tvTextTitle.setText(serviceTypeListBean.getSysServiceSetPropOptionInputName());
        etText.setHint(serviceTypeListBean.getSysServiceSetPropOptionInputName());
        tvNoticeContent.setText(serviceTypeListBean.getSysServiceSetPropOptionInputInfo());
    }

    /**
     * 车主选择成功
     */
    private void setCarOwnerSelectSuccess() {
        mTvAddCarOwner.setText(mUserBeanResponse.getMemberName());
        mTvAddCarOwner.setCompoundDrawables(null, null, null, null);
        mTvAddCarOwner.setTextColor(_mActivity.getResources().getColor(R.color.color_666666));
        mIvCarOwnerMore.setVisibility(View.VISIBLE);

        mTvCarBrandModel.setText("添加对象");
        mTvCarBrandModel.setTextColor(_mActivity.getResources().getColor(R.color.color_008cff));
        Drawable drawable = _mActivity.getResources().getDrawable(R.drawable.list_add);
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        mTvCarBrandModel.setCompoundDrawablePadding(10);//设置图片和text之间的间距
        mTvCarBrandModel.setCompoundDrawables(drawable, null, null, null);

        mTvCarOwnerPhone.setVisibility(View.VISIBLE);
        if (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) && CheckUtils.isEmpty(mUserBeanResponse.getSysProName())
                && CheckUtils.isEmpty(mUserBeanResponse.getSysCityName())) {//运营商,省市均为空
            mTvCarOwnerPhone.setText(mUserBeanResponse.getMemberAccount());
        } else {
            mTvCarOwnerPhone.setText(mUserBeanResponse.getMemberAccount() + "("
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) ? "" : mUserBeanResponse.getSysMobileName())
                    + " " + (CheckUtils.isEmpty(mUserBeanResponse.getSysProName()) ? "" : mUserBeanResponse.getSysProName())
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysCityName()) ? "" : mUserBeanResponse.getSysCityName())
                    + ")");
        }
    }

    /**
     * 车辆选择成功
     */
    private void setCarInfo() {
        mTvCarBrandModel.setText(mGuardianObjectResponse.getSysPropertyValueStr());
        mTvCarBrandModel.setTextColor(_mActivity.getResources().getColor(R.color.color_666666));
        mTvCarBrandModel.setCompoundDrawables(null, null, null, null);
        mIvCarInfoMore.setVisibility(View.VISIBLE);

        //启用车牌
        if (CheckUtils.equalsString(mGuardianObjectResponse.getSysServiceTypeSpecialType(), "1")
                && CheckUtils.equalsString(mGuardianObjectResponse.getSysAreaCarNumEnabled(), "1")) {
            mLlCarNumInfo.setVisibility(View.VISIBLE);
            mEtCarNum.setText(mGuardianObjectResponse.gethPlateNo());
            mTvCarNumPrefix.setText(mGuardianObjectResponse.getSysAreaCarNumPrefix());
        } else {
            mLlCarNumInfo.setVisibility(View.GONE);
        }

        mEtTag.setText(mGuardianObjectResponse.gethLabelNo());

        if (mGuardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {//未激活
            mEtTag.setFocusable(true);
            mEtCarNum.setFocusable(true);

            mEtCarNum.setFocusableInTouchMode(true);
            mEtTag.setFocusableInTouchMode(true);

            mEtCarNum.requestFocus();
            mEtTag.requestFocus();
        } else {
            mEtTag.setFocusable(false);
            mEtCarNum.setFocusable(false);
        }
    }
}
