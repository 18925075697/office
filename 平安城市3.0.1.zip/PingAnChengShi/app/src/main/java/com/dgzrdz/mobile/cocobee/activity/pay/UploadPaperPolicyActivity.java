package com.dgzrdz.mobile.cocobee.activity.pay;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.pay.UploadPaperPolicyFragment;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * 支付成功/绑定成功
 * Created by _H_JY on 2017/1/19.
 */
public class UploadPaperPolicyActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            String cid = getIntent().getStringExtra("cid");
            loadRootFragment(R.id.fl_container, UploadPaperPolicyFragment.getInstance(cid));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }

    @Override
    protected boolean isApplyStatusBarTranslucent() {
        return true;
    }

}