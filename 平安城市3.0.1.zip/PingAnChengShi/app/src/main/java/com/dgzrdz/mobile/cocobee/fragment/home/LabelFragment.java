package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.LabelInventoryAdapter;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.LabelInventoryResponse;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

/**
 * 标签库存
 * Created by Administrator on 2018/6/26.
 */

public class LabelFragment extends RefreshAndLoadFragment<LabelInventoryResponse> {
    private LabelInventoryAdapter mLabelInventoryAdapter;

    public static LabelFragment getInstance() {
        LabelFragment fragment = new LabelFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mLabelInventoryAdapter = new LabelInventoryAdapter(_mActivity, mList);
    }

    @Override
    protected boolean isAddHeaderView() {
        return true;
    }

    @Override
    protected View getHeaderView() {
        View view = View.inflate(_mActivity,R.layout.view_label_head,null);
        return view;
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {

    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.view_ptr_load;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public QuickRcvAdapter getAdapter() {
        return mLabelInventoryAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {

    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        for (int i = 0; i < 5; i++) {
            LabelInventoryResponse response = new LabelInventoryResponse();
            mList.add(response);
        }
        mLabelInventoryAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoadMore() {

    }
}
