package com.dgzrdz.mobile.cocobee.activity.register;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AlertDialog;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.bql.convenientlog.CLog;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.utils.WXPayUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;

/**
 * 加载西安支付页面
 * Created by Administrator on 2018/5/18.
 */

public class WebXiAnActivity extends BaseToolbarActivity {
    @BindView(R.id.webview)
    WebView mWebview;
    @BindView(R.id.webview_progressbar)
    ProgressBar mWebviewProgressbar;
    private String mUrl;
    private WebSettings mSettings;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_xi_an_web;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbarWithRightText("支付", "完成");
        getMTvRight().setVisibility(View.GONE);
        String url = getIntent().getStringExtra("url");
        mUrl = url.replaceAll("\\\\", "");
        CLog.e("LogInterceptor", "#############" + mUrl);
        initWebView();
    }

    private void initWebView() {
        String dir = this.getApplicationContext().getDir("database", Context.MODE_PRIVATE).getPath();
        mSettings = mWebview.getSettings();
        mSettings.setDomStorageEnabled(true);//设置适应html5
        mSettings.setJavaScriptEnabled(true);
        mSettings.setGeolocationEnabled(true);
        mSettings.setGeolocationDatabasePath(dir);
        /**
         *   android webview 从Lollipop(5.0)开始webview默认不允许混合模式，https当中不能加载http资源，需要设置开启。以下三行代码设置开启.
         */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        mSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        mSettings.setAppCacheEnabled(false);

        WebViewClient client = new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 获取上下文, H5PayDemoActivity为当前页面
                final Activity context = WebXiAnActivity.this;
                // ------ 对alipays:相关的scheme处理 -------
                if (url.startsWith("alipays:") || url.startsWith("alipay")) {
                    try {
                        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                    } catch (Exception e) {
                        new AlertDialog.Builder(context)
                                .setMessage("未检测到支付宝客户端，请安装后重试。")
                                .setPositiveButton("立即安装", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Uri alipayUrl = Uri.parse("https://d.alipay.com");
                                        context.startActivity(new Intent("android.intent.action.VIEW", alipayUrl));
                                    }
                                }).setNegativeButton("取消", null).show();
                    }
                } else if (url.startsWith("weixin://wap/pay?")) {//打开微信进行支付
                    //判断手机是否安装微信客户端
                    if (WXPayUtils.checkIsSupportWXPay(WebXiAnActivity.this)) {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        context.startActivity(intent);
                    }
                } else {
                    Map<String, String> extraHeaders = new HashMap<String, String>();
                    //如果是调起微信支付，需要在webview中手动设置referer
                    //extraHeaders.put("Referer", "https://yaoyaotest.cebbank.com"); //测试环境
                    extraHeaders.put("Referer", "https://yaoyao.cebbank.com");//生产环境
                    view.loadUrl(url, extraHeaders);
                }
                return true;

            }

            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // handler.cancel(); // Android默认的处理方式
                handler.proceed(); // 接受所有网站的证书
                // handleMessage(Message msg); // 进行其他处理
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mWebviewProgressbar.setVisibility(View.VISIBLE);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mWebviewProgressbar.setVisibility(View.GONE);
                super.onPageFinished(view, url);
                CLog.e("LogInterceptor", "#############网页加载完了" + url);
                if (url.contains("ordersearch")) {
                    getMTvRight().setVisibility(View.VISIBLE);
                }
            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                CLog.e("LogInterceptor", "#############网页加载失败" + request.getUrl().getPath());
            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                //主页面虽然加载成功，但由于网站没有favicon.ico文件导致返回404错误
                //重写WebViewClient的shouldInterceptRequest方法禁用favicon.ico请求
                if (!request.isForMainFrame() && request.getUrl().getPath().endsWith("/favicon.ico")) {
                    try {
                        return new WebResourceResponse("image/png", "UTF-8", null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return null;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                //主页面虽然加载成功，但由于网站没有favicon.ico文件导致返回404错误
                //重写WebViewClient的shouldInterceptRequest方法禁用favicon.ico请求
                if (url.toLowerCase().contains("/favicon.ico")) {
                    try {
                        return new WebResourceResponse("image/png", "UTF-8", null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return null;
            }
        };

        mWebview.setWebViewClient(client);
        mWebview.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
                super.onGeolocationPermissionsShowPrompt(origin, callback);
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mWebviewProgressbar.setProgress(newProgress);
                super.onProgressChanged(view, newProgress);
            }
        });

        mWebview.loadUrl(mUrl);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mSettings.setJavaScriptEnabled(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mSettings.setJavaScriptEnabled(false);
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().post(new EventManager(EventConstants.OUT_XIAN_PAY_ACTIVITY));
        mWebview.clearHistory();
        mWebview.destroy();
        super.onDestroy();
    }

    @Override
    public void btnRightTextClick() {
        finish();
    }

    @Override
    public void leftContainerClick() {
        if (mWebview.canGoBack()) {
            mWebview.goBack();
        } else {
            finish();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //其中webView.canGoBack()在webView含有一个可后退的浏览记录时返回true
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebview.canGoBack()) {
            mWebview.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
