package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.ManifestUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.me.ChangePwdOrgActivity;
import com.dgzrdz.mobile.cocobee.activity.register.LoginActivity;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.model.VersionInfo;
import com.dgzrdz.mobile.cocobee.utils.UpdateManager;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;

/**
 * 设置
 * Created by Administrator on 2017/6/3.
 */

public class SettingFragment extends BaseFragment {
    @BindView(R.id.tv_cur_version)
    TextView tvCurVersion;
    @BindView(R.id.out_login)
    TextView outLogin;
    @BindView(R.id.ll_chang_pwd)
    LinearLayout mLlChangPwd;
    @BindView(R.id.ll_check_version)
    LinearLayout mLlCheckVersion;
    private UserInfo mUserLoginInfo;
    private VersionInfo mVersionInfo;

    public static SettingFragment getInstance() {
        SettingFragment fragment = new SettingFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mVersionInfo = Utils.getUpdateVersionInfo();
        initView();
    }

    private void initView() {
        String versionName = ManifestUtils.getVersionName(_mActivity);
        tvCurVersion.setText(versionName);
    }

    @Override
    protected void initToolbarHere() {
        initToolbarWithLeftText("设置", "我的");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_setting;
    }


    @OnClick({R.id.out_login, R.id.ll_chang_pwd, R.id.ll_check_version})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.out_login:
                if (mUserLoginInfo != null) {
                    SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.CUSTOM_IMAGE_TYPE);
                    sweetAlertDialog.setCustomImage(R.drawable.exit_tip);
                    sweetAlertDialog.setTitleText("退出当前用户？");
                    sweetAlertDialog.setConfirmText("确定");
                    sweetAlertDialog.showCancelButton(true);
                    sweetAlertDialog.setCancelText("取消");
                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            sweetAlertDialog.dismiss();
                            Utils.gotoLogin();
                        }
                    });

                    sweetAlertDialog.show();
                } else {
                    startActivity(new Intent(_mActivity, LoginActivity.class));
                }
                break;
            case R.id.ll_chang_pwd:
                Intent i = new Intent(_mActivity, ChangePwdOrgActivity.class);
                startActivity(i);
                break;
            case R.id.ll_check_version:
                if (mVersionInfo != null && mVersionInfo.isNeedUpdate()) { //有最新版本,需要更新
                    UpdateManager updateManager = new UpdateManager(_mActivity);
                    updateManager.showNoticeDialog();
                } else {
                    XToastUtils.showShortToast("已是最新版本");
                }
                break;
            default:
                break;
        }
    }
}
