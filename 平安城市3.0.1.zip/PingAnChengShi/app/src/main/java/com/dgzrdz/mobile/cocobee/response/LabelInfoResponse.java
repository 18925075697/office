package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/6/20.
 */

public class LabelInfoResponse implements Serializable {

    /**
     * birthday : 2028-12-27
     * unit :
     * address : 你以为
     * regiaddr : 最便宜
     * pname : 以我
     * sex : 1
     * idcard : 444444444444442222
     * mobile : 17765286643
     * JD : 113.950619
     * WD : 22.556489
     */

    private String birthday;
    private String unit;
    private String address;
    private String regiaddr;
    private String pname;
    private String sex;
    private String idcard;
    private String mobile;
    private String JD;
    private String WD;
    private String cid;
    private String cno;

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRegiaddr() {
        return regiaddr;
    }

    public void setRegiaddr(String regiaddr) {
        this.regiaddr = regiaddr;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getJD() {
        return JD;
    }

    public void setJD(String JD) {
        this.JD = JD;
    }

    public String getWD() {
        return WD;
    }

    public void setWD(String WD) {
        this.WD = WD;
    }
}
