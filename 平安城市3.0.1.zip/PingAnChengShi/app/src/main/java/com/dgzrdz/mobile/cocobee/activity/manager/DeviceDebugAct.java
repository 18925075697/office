package com.dgzrdz.mobile.cocobee.activity.manager;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.model.LatLng;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.btreader.BlueToothHelper;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.CarOwnerInfo;
import com.dgzrdz.mobile.cocobee.model.Point;
import com.dgzrdz.mobile.cocobee.model.Transponder;
import com.dgzrdz.mobile.cocobee.utils.Tools;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.dialog.AddressSelectToolDialog;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;


/**
 * 设备安装调试页面
 *
 * @author _H_JY
 * @date 2017/3/17
 */
public class DeviceDebugAct extends BaseToolbarActivity implements BlueToothHelper.ScanListener {

    protected static final int CMD_STOP = 112;

    private EditText device_id_et, device_ip_et, device_port_et, device_address_et, device_imei_et, device_num_et;
    private TextView collector_info_tv;

    private Context context;

    private TextView coordinates_tv; //经纬度
    private ImageView deviceid_clear_iv, deviceip_clear_iv, deviceport_clear_iv, code_clear_iv, addr_clear_iv;
    private ImageView lanip_clear_iv, lanfwport_clear_iv, lanfwip_clear_iv, lanwg_clear_iv, lanzwym_clear_iv, lanport_clear_iv, mac_clear_iv;

    // button
    private TextView read_device_btn; //读设备信息
    private TextView set_params_btn; //设置参数
    private TextView read_systime_tv;
    private TextView set_systime_tv;
    private TextView systime_tv;
    private TextView net_state_tv;
    private EditText gprs_num_et;
    private TextView read_gprs_tv;


    private TextView upload_info_btn;
    private TextView read_imei, read_factorynum, read_cache_tagnum_tv;
    private TextView read_gprs_connect_tv, read_lan_connect_tv;
    private EditText tx_one_zy_et, tx_one_rssi_et, tx_two_zy_et, tx_two_rssi_et, tx_three_zy_et, tx_three_rssi_et, tx_four_zy_et, tx_four_rssi_et;
    private EditText lan_ip_et, lan_port_et, lan_zwym_et, lan_wg_et, lan_fwip_et, lan_fwport_et, lan_mac_et;
    private EditText gprs_connect_et, lan_connect_et; //gprs连接状态，lan连接状态
    private EditText filter_et, wx_tagnum_et, yx_tagnum_et, gl_tagnum_et, stopTime_et, directionTime_et; //去重过滤
    private CheckBox beep_cb, dhcp_cb, drct_cb;

    private boolean mScanning = false;
    private boolean mSetting = false;


    private BlueToothHelper reader;// Blue Tooth reader
    SharedPreferences sharedPreferences = null;
    private MediaPlayer mp;

    private SweetAlertDialog sDialog;
    private LocationClient locationClient;
    private double longitude; //经度值
    private double latitude; //纬度值
    private float radius; //精度圈半径
    private float direction; //方向信息
    private String address, orgid;
    private EditText police_station_et;
    private byte[] SET_PARAMS_COMMAND = null;


    private EditText police_num_et;
    private final int DEVICE_ID_LENGTH = 15;
    private byte beepSwitch = 0x00; //默认是关
    private byte dhcpSwitch = 0x00; //默认是关
    private byte drctSwitch = 0x00; //默认是关
    private byte[] filterWindowByte = new byte[]{(byte) 0x78, 0x00}; //去重窗口过滤默认值120秒
    private byte[] stopTimeWindowByte = new byte[]{(byte) 0xB3, 0x00}; //停留时间默认值180秒
    private byte[] drctTimeWindowByte; //停留时间默认值180秒
    private Point mPoint;


    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_device_debug;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbarWithRightText("安装调试", "调试天线");
        initView();
    }

    @Override
    public void btnRightTextClick() {
        startActivity(new Intent(context, AntennaDebugAct.class));
    }


    private void initView() {
        context = this;

        // Init the reader
        reader = BlueToothHelper.getInstance(handler);

        mp = MediaPlayer.create(DeviceDebugAct.this, R.raw.beep);

        // Init share Preference
        sharedPreferences = null;
        sharedPreferences = getSharedPreferences("bluetooth", Context.MODE_PRIVATE); //存放蓝牙连接状态的文件


        device_id_et = (EditText) findViewById(R.id.device_id_et);
        device_ip_et = (EditText) findViewById(R.id.device_ip_et);
        device_port_et = (EditText) findViewById(R.id.device_port_et);
        device_address_et = (EditText) findViewById(R.id.device_address_et);
        device_imei_et = (EditText) findViewById(R.id.device_imei_et);
        device_num_et = (EditText) findViewById(R.id.device_num_et);
        police_num_et = (EditText) findViewById(R.id.police_num_et);
        collector_info_tv = (TextView) findViewById(R.id.collector_info_tv);
        read_imei = (TextView) findViewById(R.id.read_imei_btn);
        read_factorynum = (TextView) findViewById(R.id.read_factorynum_btn);
        tx_one_rssi_et = (EditText) findViewById(R.id.tx_one_rssi_et);
        tx_one_zy_et = (EditText) findViewById(R.id.tx_one_zy_et);
        tx_two_rssi_et = (EditText) findViewById(R.id.tx_two_rssi_et);
        tx_two_zy_et = (EditText) findViewById(R.id.tx_two_zy_et);
        tx_three_rssi_et = (EditText) findViewById(R.id.tx_three_rssi_et);
        tx_three_zy_et = (EditText) findViewById(R.id.tx_three_zy_et);
        tx_four_rssi_et = (EditText) findViewById(R.id.tx_four_rssi_et);
        tx_four_zy_et = (EditText) findViewById(R.id.tx_four_zy_et);
        filter_et = (EditText) findViewById(R.id.filter_et);
        stopTime_et = (EditText) findViewById(R.id.stop_time_et);
        beep_cb = (CheckBox) findViewById(R.id.beep_cb);
        systime_tv = (TextView) findViewById(R.id.system_time_tv);
        read_systime_tv = (TextView) findViewById(R.id.read_systime_btn);
        set_systime_tv = (TextView) findViewById(R.id.set_systime_btn);
        net_state_tv = (TextView) findViewById(R.id.net_state_tv);
        police_station_et = (EditText) findViewById(R.id.police_station_et);
        gprs_num_et = (EditText) findViewById(R.id.gprs_num_et);
        read_gprs_tv = (TextView) findViewById(R.id.read_gprs_tv);
        lan_ip_et = (EditText) findViewById(R.id.lan_ip_et);
        lan_port_et = (EditText) findViewById(R.id.lan_port_et);
        lan_zwym_et = (EditText) findViewById(R.id.lan_zwym_et);
        lan_wg_et = (EditText) findViewById(R.id.lan_wg_et);
        lan_fwip_et = (EditText) findViewById(R.id.lan_fwip_et);
        lan_fwport_et = (EditText) findViewById(R.id.lan_fwport_et);
        lan_mac_et = (EditText) findViewById(R.id.lan_mac_et);
        gprs_connect_et = (EditText) findViewById(R.id.gprs_connect_et);
        lan_connect_et = (EditText) findViewById(R.id.lan_connect_et);
        read_gprs_connect_tv = (TextView) findViewById(R.id.read_gprs_connect_tv);
        read_lan_connect_tv = (TextView) findViewById(R.id.read_lan_connect_tv);
        read_cache_tagnum_tv = (TextView) findViewById(R.id.read_cache_tagnum_tv);
        wx_tagnum_et = (EditText) findViewById(R.id.wx_tagnum_et);
        yx_tagnum_et = (EditText) findViewById(R.id.yx_tagnum_et);
        gl_tagnum_et = (EditText) findViewById(R.id.gl_tagnum_et);
        dhcp_cb = (CheckBox) findViewById(R.id.dhcp_cb);
        directionTime_et = (EditText) findViewById(R.id.direction_time_et);
        drct_cb = (CheckBox) findViewById(R.id.drct_cb);

        //用于清除输入的图标
        deviceid_clear_iv = (ImageView) findViewById(R.id.deviceid_clear_iv);
        deviceip_clear_iv = (ImageView) findViewById(R.id.deviceip_clear_iv);
        deviceport_clear_iv = (ImageView) findViewById(R.id.deviceport_clear_iv);
        code_clear_iv = (ImageView) findViewById(R.id.code_clear_iv);
        addr_clear_iv = (ImageView) findViewById(R.id.addr_clear_iv);
        lanip_clear_iv = (ImageView) findViewById(R.id.lanip_clear_iv);
        lanport_clear_iv = (ImageView) findViewById(R.id.lanport_clear_iv);
        mac_clear_iv = (ImageView) findViewById(R.id.mac_clear_iv);
        lanzwym_clear_iv = (ImageView) findViewById(R.id.lanzwym_clear_iv);
        lanwg_clear_iv = (ImageView) findViewById(R.id.lanwg_clear_iv);
        lanfwip_clear_iv = (ImageView) findViewById(R.id.lanfwip_clear_iv);
        lanfwport_clear_iv = (ImageView) findViewById(R.id.lanfwport_clear_iv);

        coordinates_tv = (TextView) findViewById(R.id.device_coordinates_tv); //显示经纬度

        read_device_btn = (TextView) findViewById(R.id.input_read_tag); //读取标签按钮
        set_params_btn = (TextView) findViewById(R.id.input_save_data); //保存信息按钮

        upload_info_btn = (TextView) findViewById(R.id.input_uplo_dasta);


        initIntent();

        police_station_et.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrgSelectDialog();
            }
        });


        beep_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) { //开
                    beepSwitch = 0x01;
                } else { //关
                    beepSwitch = 0x00;
                }
            }
        });

        dhcp_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) { //开
                    dhcpSwitch = 0x01;
                } else { //关
                    dhcpSwitch = 0x00;
                }
            }
        });

        drct_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) { //开
                    drctSwitch = 0x01;
                } else { //关
                    drctSwitch = 0x00;
                }
            }
        });

        lan_ip_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanip_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanip_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        lan_port_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanport_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanport_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        lan_zwym_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanzwym_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanzwym_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        lan_wg_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanwg_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanwg_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        lan_fwip_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanfwip_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanfwip_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        lan_fwport_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    lanfwport_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    lanfwport_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        lan_mac_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    mac_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    mac_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        read_cache_tagnum_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readCacheTagNum();
                    } else { //BLE
                        reader.bleSendCmd(Constant.BLE_READ_CACHE_TAG_NUM, BlueToothHelper.READ_CACHE_TAG_NUM_COMMAND, false);
                    }

                }
            }
        });


        read_gprs_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readGPRSNum();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_GPRS_NUM, BlueToothHelper.READ_GPRS_NUM_COMMAND, false);
                    }

                }


            }
        });


        read_imei.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();

                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readImei();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_IMEI, BlueToothHelper.READ_IMEI_COMMAND, true);
                    }
                }
            }
        });


        read_factorynum.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readFactoryNum();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_FACTORY_NUM, BlueToothHelper.READ_FACNUM_COMMAND, true);
                    }

                }


            }
        });


        read_systime_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readSysTime();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_SYS_TIME, BlueToothHelper.READ_SYS_TIME_COMMAND, false);
                    }

                }
            }
        });


        read_gprs_connect_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readGPRSCntState();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_GPRS_CONNECT_STATE, BlueToothHelper.READ_GPRS_CONNECT_STATE_COMMAND, true);
                    }

                }
            }
        });


        read_lan_connect_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.readLANCntState();
                    } else {
                        reader.bleSendCmd(Constant.BLE_READ_LAN_CONNECT_STATE, BlueToothHelper.READ_LAN_CONNECT_STATE_COMMAND, true);
                    }

                }
            }
        });


        set_systime_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!mSetting) {
                    mSetting = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                        reader.setSysTime();
                    } else {
                        reader.bleSendCmd(Constant.BLE_SET_SYS_TIME, reader.getSysTimeBytes(), true);
                    }

                }


            }
        });


        device_id_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence text, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence text, int i, int i1, int i2) {
                if (!TextUtils.isEmpty(text)) {
                    deviceid_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    deviceid_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        device_ip_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence text, int i, int i1, int i2) {
                if (!TextUtils.isEmpty(text)) {
                    deviceip_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    deviceip_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        device_port_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence text, int i, int i1, int i2) {
                if (!TextUtils.isEmpty(text)) {
                    deviceport_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    deviceport_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        police_num_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence text, int i, int i1, int i2) {
                if (!TextUtils.isEmpty(text)) {
                    code_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    code_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        device_address_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence text, int i, int i1, int i2) {
                if (!TextUtils.isEmpty(text)) {
                    addr_clear_iv.setVisibility(View.VISIBLE);
                } else {
                    addr_clear_iv.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        deviceid_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                device_id_et.setText("");
            }
        });
        deviceip_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                device_ip_et.setText("");
            }
        });
        deviceport_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                device_port_et.setText("");
            }
        });

        code_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                police_num_et.setText("");
            }
        });

        addr_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                device_address_et.setText("");
            }
        });

        lanip_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_ip_et.setText("");
            }
        });

        lanport_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_port_et.setText("");
            }
        });

        mac_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_mac_et.setText("");
            }
        });

        lanzwym_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_zwym_et.setText("");
            }
        });


        lanwg_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_wg_et.setText("");
            }
        });


        lanfwip_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_fwip_et.setText("");
            }
        });


        lanfwport_clear_iv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lan_fwport_et.setText("");
            }
        });


        coordinates_tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    //进入到这里代表没有获取权限
                    if (ActivityCompat.shouldShowRequestPermissionRationale(DeviceDebugAct.this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                        //已经禁止提示了
                        Toast.makeText(context, "您已禁止该权限，需要重新开启", Toast.LENGTH_SHORT).show();
                    } else {
                        ActivityCompat.requestPermissions(DeviceDebugAct.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 3333);

                    }
                }


                startActivityForResult(new Intent(DeviceDebugAct.this, ShowMapAct.class).putExtra(Constant.LONGITUDE, longitude)
                        .putExtra(Constant.LATITUDE, latitude).putExtra(Constant.RADIUS, radius)
                        .putExtra(Constant.DIRECTION, direction).putExtra("addr", address).putExtra("flag", Constant.AZTS), 1002);


            }
        });

        if (mPoint == null) {
            //        getLoc(); //获取经纬度
            getBaiduAddress();
        }


        read_device_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!mScanning) {
                    mScanning = true;
                    sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                    sDialog.setTitleText("正在读取...");
                    sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
                    sDialog.setCancelable(true);
                    sDialog.setCanceledOnTouchOutside(true);
                    sDialog.show();
                    if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) { //蓝牙2.0
                        reader.readDeviceInfo();
                    } else if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_LE) { //蓝牙4.0
                        reader.bleSendCmd(Constant.BLE_READ_DEVICE_INFO, BlueToothHelper.SCAN_DEVICE_COMMANDS, true);
                    }
                }
            }
        });
        // Button save information.
        set_params_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected()) {
                    Toast.makeText(context, "未连接设备，无法读取", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (TextUtils.isEmpty(device_id_et.getText().toString().trim())) {
                    Toast.makeText(context, "请输入设备ID", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (device_id_et.getText().toString().trim().length() < DEVICE_ID_LENGTH) {
                    Toast.makeText(context, "设备ID长度不足", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (TextUtils.isEmpty(device_ip_et.getText().toString().trim())) {
                    Toast.makeText(context, "ip地址不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(device_port_et.getText().toString().trim())) {
                    Toast.makeText(context, "端口号不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (Integer.valueOf(device_port_et.getText().toString().trim()) < 0 || Integer.valueOf(device_port_et.getText().toString().trim()) > 65535) {
                    Toast.makeText(context, "端口号输入范围为0～65535", Toast.LENGTH_SHORT).show();
                    return;
                }

                String tx_one_zy_str = tx_one_zy_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_one_zy_str)) {
                    if (Integer.valueOf(tx_one_zy_str) < 0 || Integer.valueOf(tx_one_zy_str) > 31) {
                        Toast.makeText(context, "增益值为0～31", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String tx_two_zy_str = tx_two_zy_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_two_zy_str)) {
                    if (Integer.valueOf(tx_two_zy_str) < 0 || Integer.valueOf(tx_two_zy_str) > 31) {
                        Toast.makeText(context, "增益值为0～31", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String tx_three_zy_str = tx_three_zy_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_three_zy_str)) {
                    if (Integer.valueOf(tx_three_zy_str) < 0 || Integer.valueOf(tx_three_zy_str) > 31) {
                        Toast.makeText(context, "增益值为0～31", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String tx_four_zy_str = tx_four_zy_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_four_zy_str)) {
                    if (Integer.valueOf(tx_four_zy_str) < 0 || Integer.valueOf(tx_four_zy_str) > 31) {
                        Toast.makeText(context, "增益值为0～31", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String tx_one_rssi_str = tx_one_rssi_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_one_rssi_str)) {
                    if (Integer.valueOf(tx_one_rssi_str) < -128 || Integer.valueOf(tx_one_rssi_str) > 0) {
                        Toast.makeText(context, "rssi值为-128～0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                String tx_two_rssi_str = tx_two_rssi_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_two_rssi_str)) {
                    if (Integer.valueOf(tx_two_rssi_str) < -128 || Integer.valueOf(tx_two_rssi_str) > 0) {
                        Toast.makeText(context, "rssi值为-128～0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                String tx_three_rssi_str = tx_three_rssi_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_three_rssi_str)) {
                    if (Integer.valueOf(tx_three_rssi_str) < -128 || Integer.valueOf(tx_three_rssi_str) > 0) {
                        Toast.makeText(context, "rssi值为-128～0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                String tx_four_rssi_str = tx_four_rssi_et.getText().toString().trim();
                if (!TextUtils.isEmpty(tx_four_rssi_str)) {
                    if (Integer.valueOf(tx_four_rssi_str) < -128 || Integer.valueOf(tx_four_rssi_str) > 0) {
                        Toast.makeText(context, "rssi值为-128～0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                String filterStr = filter_et.getText().toString().trim();
                if (!TextUtils.isEmpty(filterStr)) {
                    if (Integer.valueOf(filterStr) < 0 || Integer.valueOf(filterStr) > 65526) {
                        Toast.makeText(context, "去重过滤值为0～65526", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String stopTimeStr = stopTime_et.getText().toString().trim();
                if (!TextUtils.isEmpty(stopTimeStr)) {
                    if (Integer.valueOf(stopTimeStr) < 0 || (Integer.valueOf(stopTimeStr) > 0 && Integer.valueOf(stopTimeStr) < 5) || Integer.valueOf(stopTimeStr) > 65535) {
                        Toast.makeText(context, "停留时间值为0,5~65535", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String drctTimeStr = directionTime_et.getText().toString().trim();
                if (!TextUtils.isEmpty(drctTimeStr)) {
                    if (Integer.valueOf(drctTimeStr) < 0 || (Integer.valueOf(drctTimeStr) > 255)) {
                        Toast.makeText(context, "方向过滤时间值为0-255", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String lanIp = lan_ip_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanIp)) {
                    Toast.makeText(context, "lan ip地址不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                String lanPort = lan_port_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanPort)) {
                    Toast.makeText(context, "lan 端口号不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!TextUtils.isEmpty(lanPort)) {
                    if (Integer.valueOf(lanPort) < 0 || Integer.valueOf(lanPort) > 65536) {
                        Toast.makeText(context, "lan端口号为0～65536", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                String lanZwym = lan_zwym_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanZwym)) {
                    Toast.makeText(context, "lan 子网掩码不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                String lanWg = lan_wg_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanWg)) {
                    Toast.makeText(context, "lan 网关不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                String lanFwIp = lan_fwip_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanFwIp)) {
                    Toast.makeText(context, "lan 服务器ip不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                String lanFwPort = lan_fwport_et.getText().toString().trim();
                if (TextUtils.isEmpty(lanFwPort)) {
                    Toast.makeText(context, "lan 服务器端口不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!TextUtils.isEmpty(lanFwPort)) {
                    if (Integer.valueOf(lanFwPort) < 0 || Integer.valueOf(lanFwPort) > 65536) {
                        Toast.makeText(context, "lan服务器端口号为0～65536", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                String lanMac = lan_mac_et.getText().toString().trim();
                if (!CheckUtils.isEmpty(lanMac) && !Tools.isValidMac(lanMac)) {
                    XToastUtils.showShortToast("Mac地址格式错误");
                    return;
                }

                setParams();
            }
        });
        // --上传数据---------------------------------------------------------

        upload_info_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                /**
                 * 上传数据，先从本地数据库中的表查询所有数据添加到一个集合中,
                 * 然后把集合中的数据转换成json格式数据再提交到后台
                 */
                uploadCheck(); //上传方法
            }
        });

        reader.setScanListener(this);
        //        reader.setScanListener(new BlueToothHelper.ScanListener() {
        //
        //                                   @Override
        //                                   public void scanned(final Transponder trp) {
        //                                       runOnUiThread(new Runnable() {
        //                                           @Override
        //                                           public void run() {
        //                                               if (sDialog != null && sDialog.isShowing()) {
        //                                                   sDialog.dismiss();
        //                                               }
        //                                               if (trp != null) {
        //                                                   device_id_et.setText(trp.getDevice_id().trim());
        //                                                   device_ip_et.setText(trp.getIp().trim());
        //                                                   device_port_et.setText(trp.getPort());
        //                                                   SET_PARAMS_COMMAND = trp.getData();
        //                                                   tx_one_zy_et.setText(trp.getDeviceGrains()[0]);
        //                                                   tx_two_zy_et.setText(trp.getDeviceGrains()[1]);
        //                                                   tx_three_zy_et.setText(trp.getDeviceGrains()[2]);
        //                                                   tx_four_zy_et.setText(trp.getDeviceGrains()[3]);
        //
        //
        //                                                   tx_one_rssi_et.setText(trp.getDeviceRssis()[0] + "");
        //                                                   tx_two_rssi_et.setText(trp.getDeviceRssis()[1] + "");
        //                                                   tx_three_rssi_et.setText(trp.getDeviceRssis()[2] + "");
        //                                                   tx_four_rssi_et.setText(trp.getDeviceRssis()[3] + "");
        //
        //                                                   filter_et.setText(trp.getFilterNum() + "");
        //                                                   stopTime_et.setText(trp.getStopTimeNum() + "");
        //                                                   directionTime_et.setText(trp.getDrctTimeNum() + "");
        //
        //                                                   lan_ip_et.setText(trp.getLanIp().trim());
        //                                                   lan_port_et.setText(trp.getLanPort());
        //                                                   lan_zwym_et.setText(trp.getLanZwym());
        //                                                   lan_wg_et.setText(trp.getLanWg());
        //                                                   lan_fwip_et.setText(trp.getLanFwIp().trim());
        //                                                   lan_fwport_et.setText(trp.getLanFwPort());
        //                                                   lan_mac_et.setText(trp.getMac());
        //
        //
        //                                                   if (trp.getBeepFlag() == 0) { //关闭状态
        //                                                       beep_cb.setChecked(false);
        //                                                       beepSwitch = 0x00;
        //                                                   } else {
        //                                                       beep_cb.setChecked(true);
        //                                                       beepSwitch = 0x01;
        //                                                   }
        //
        //                                                   if (trp.getDhcpFlag() == 0) { //关闭状态
        //                                                       dhcp_cb.setChecked(false);
        //                                                       dhcpSwitch = 0x00;
        //                                                   } else {
        //                                                       dhcp_cb.setChecked(true);
        //                                                       dhcpSwitch = 0x01;
        //                                                   }
        //
        //                                                   if (trp.getDrctFlag() == 0) { //关闭状态
        //                                                       drct_cb.setChecked(false);
        //                                                       drctSwitch = 0x00;
        //                                                   } else {
        //                                                       drct_cb.setChecked(true);
        //                                                       drctSwitch = 0x01;
        //                                                   }
        //
        //                                                   //网络连接状态
        //                                                   if (trp.getNetState() == 0xA1) {
        //                                                       net_state_tv.setText("无线已连接");
        //                                                   } else if (trp.getNetState() == 0xA0) {
        //                                                       net_state_tv.setText("无连接");
        //                                                   } else if (trp.getNetState() == 0xA2) {
        //                                                       net_state_tv.setText("有线已连接");
        //                                                   } else if (trp.getNetState() == 0xA3) {
        //                                                       net_state_tv.setText("无线/有线 已连接");
        //                                                   } else {
        //                                                       net_state_tv.setText("不支持");
        //                                                   }
        //
        //
        //                                                   if (!TextUtils.isEmpty(trp.getVersion()) && !TextUtils.isEmpty(trp.getTime())) {
        //                                                       collector_info_tv.setText("采集器信息（ V " + trp.getVersion() + "      " + trp.getTime() + " )");
        //                                                   } else if (!TextUtils.isEmpty(trp.getVersion())) {
        //                                                       collector_info_tv.setText("采集器信息（ V " + trp.getVersion() + " ）");
        //                                                   } else if (!TextUtils.isEmpty(trp.getTime())) {
        //                                                       collector_info_tv.setText("采集器信息（ " + trp.getTime() + " ）");
        //                                                   } else {
        //                                                       collector_info_tv.setText("采集器信息");
        //                                                   }
        //
        //                                                   if (mp != null) {
        //                                                       mp.start();
        //                                                   }
        //
        //                                               } else {
        //                                                   Toast.makeText(context, "读取设备信息失败", Toast.LENGTH_SHORT).show();
        //                                               }
        //                                               mSetting = false;
        //                                               mScanning = false;
        //                                           }
        //                                       });
        //                                   }
        //
        //                                   @Override
        //                                   public void begin() {
        //                                       runOnUiThread(new Runnable() {
        //                                           @Override
        //                                           public void run() {
        //                                               mScanning = true;
        //                                               sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
        //                                               sDialog.setTitleText("正在读取...");
        //                                               sDialog.getProgressHelper().setBarColor(Color.parseColor("#266351"));
        //                                               sDialog.setCancelable(true);
        //                                               sDialog.setCanceledOnTouchOutside(true);
        //                                               sDialog.show();
        //                                           }
        //                                       });
        //                                   }
        //                               }
        //
        //        );
    }

    /**
     * 设置参数
     */
    private void setParams() {
        String tx_one_zy_str = tx_one_zy_et.getText().toString().trim();
        String tx_two_zy_str = tx_two_zy_et.getText().toString().trim();
        String tx_three_zy_str = tx_three_zy_et.getText().toString().trim();
        String tx_four_zy_str = tx_four_zy_et.getText().toString().trim();
        String tx_one_rssi_str = tx_one_rssi_et.getText().toString().trim();
        String tx_two_rssi_str = tx_two_rssi_et.getText().toString().trim();
        String tx_three_rssi_str = tx_three_rssi_et.getText().toString().trim();
        String tx_four_rssi_str = tx_four_rssi_et.getText().toString().trim();
        String filterStr = filter_et.getText().toString().trim();
        String stopTimeStr = stopTime_et.getText().toString().trim();
        String drctTimeStr = directionTime_et.getText().toString().trim();
        String lanIp = lan_ip_et.getText().toString().trim();
        String lanPort = lan_port_et.getText().toString().trim();
        String lanZwym = lan_zwym_et.getText().toString().trim();
        String lanWg = lan_wg_et.getText().toString().trim();
        String lanFwIp = lan_fwip_et.getText().toString().trim();
        String lanFwPort = lan_fwport_et.getText().toString().trim();
        String mac = lan_mac_et.getText().toString().trim();
        if (!mSetting) {
            mSetting = true;
            sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
            sDialog.setTitleText("正在设置参数...");
            sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
            sDialog.setCancelable(true);
            sDialog.setCanceledOnTouchOutside(true);
            sDialog.show();

            byte[] ip = new byte[32];
            byte[] realIp = device_ip_et.getText().toString().trim().getBytes();


            //lan信息
            String[] lanIpNumStr = lanIp.split("\\."); //"."需要加转义字符
            byte[] lanIpB = new byte[4];
            for (int i = 0; i < 4; i++) {
                lanIpB[i] = (byte) Integer.parseInt(lanIpNumStr[i]);
            }

            //lan信息
            String[] lanZwymNumStr = lanZwym.split("\\.");
            byte[] lanZwymB = new byte[4];
            for (int i = 0; i < 4; i++) {
                lanZwymB[i] = (byte) Integer.parseInt(lanZwymNumStr[i]);
            }

            //lan信息
            String[] lanWgNumStr = lanWg.split("\\.");
            byte[] lanWgB = new byte[4];
            for (int i = 0; i < 4; i++) {
                lanWgB[i] = (byte) Integer.parseInt(lanWgNumStr[i]);
            }

            //lan信息
            byte[] lanFwIpB = lanFwIp.getBytes();


            byte[] lanPortB = Tools.int2byte(Integer.valueOf(lanPort));
            byte[] lanFwPortB = Tools.int2byte(Integer.valueOf(lanFwPort));


            byte[] macB = new byte[6];
            if (!CheckUtils.isEmpty(mac)) {
                String s = mac.replaceAll("-", "");
                String s1 = s.replaceAll(":", "");
                String s2 = s1.toUpperCase();
                byte[] bytes = Tools.hexStringToByte(s2);
                for (int i = 0; i < 6; i++) {
                    macB[i] = bytes[i];
                }
            }

            //获取增益
            byte[] grain1 = new byte[4];
            if (TextUtils.isEmpty(tx_one_zy_str)) {
                grain1[0] = 0x1F;
            } else {
                grain1 = Tools.int2byte(Integer.valueOf(tx_one_zy_str));
            }

            byte[] grain2 = new byte[4];
            if (TextUtils.isEmpty(tx_two_zy_str)) {
                grain2[0] = 0x1F;
            } else {
                grain2 = Tools.int2byte(Integer.valueOf(tx_two_zy_str));
            }

            byte[] grain3 = new byte[4];
            if (TextUtils.isEmpty(tx_three_zy_str)) {
                grain3[0] = 0x1F;
            } else {
                grain3 = Tools.int2byte(Integer.valueOf(tx_three_zy_str));
            }


            byte[] grain4 = new byte[4];
            if (TextUtils.isEmpty(tx_four_zy_str)) {
                grain4[0] = 0x1F;
            } else {
                grain4 = Tools.int2byte(Integer.valueOf(tx_four_zy_str));
            }


            byte[] grain = new byte[4];
            grain[0] = grain1[0];
            grain[1] = grain2[0];
            grain[2] = grain3[0];
            grain[3] = grain4[0];


            //获取rssi
            byte[] rssi1 = new byte[4];
            if (TextUtils.isEmpty(tx_one_rssi_str)) {
                rssi1[0] = (byte) 0x80;
            } else {
                rssi1 = Tools.int2byte(Integer.valueOf(tx_one_rssi_str));
            }


            byte[] rssi2 = new byte[4];
            if (TextUtils.isEmpty(tx_two_rssi_str)) {
                rssi2[0] = (byte) 0x80;
            } else {
                rssi2 = Tools.int2byte(Integer.valueOf(tx_two_rssi_str));
            }

            byte[] rssi3 = new byte[4];
            if (TextUtils.isEmpty(tx_three_rssi_str)) {
                rssi3[0] = (byte) 0x80;
            } else {
                rssi3 = Tools.int2byte(Integer.valueOf(tx_three_rssi_str));
            }


            byte[] rssi4 = new byte[4];
            if (TextUtils.isEmpty(tx_four_rssi_str)) {
                rssi4[0] = (byte) 0x80;
            } else {
                rssi4 = Tools.int2byte(Integer.valueOf(tx_four_rssi_str));
            }


            if (!TextUtils.isEmpty(filterStr)) {
                filterWindowByte = Tools.int2byte(Integer.valueOf(filterStr));
            }
            if (!TextUtils.isEmpty(stopTimeStr)) {
                stopTimeWindowByte = Tools.int2byte(Integer.valueOf(stopTimeStr));
            }

            if (!TextUtils.isEmpty(drctTimeStr)) {
                drctTimeWindowByte = Tools.int2byte(Integer.valueOf(drctTimeStr));
            }

            byte[] rssi = new byte[4];
            rssi[0] = rssi1[0];
            rssi[1] = rssi2[0];
            rssi[2] = rssi3[0];
            rssi[3] = rssi4[0];


            for (int i = 0; i < 32; i++) {
                if (i < realIp.length) {
                    ip[i] = realIp[i];
                } else {
                    ip[i] = 0x00;
                }
            }

            byte[] realFwIpB = new byte[32];
            for (int i = 0; i < 32; i++) {
                if (i < lanFwIpB.length) {
                    realFwIpB[i] = lanFwIpB[i];
                } else {
                    realFwIpB[i] = 0x00;
                }

            }

            byte[] device_id = device_id_et.getText().toString().trim().getBytes(); //把字符中转换为字符数组
            byte[] port = Tools.int2byte(Integer.valueOf(device_port_et.getText().toString().trim()));


            if (SET_PARAMS_COMMAND != null) {
                if (SET_PARAMS_COMMAND.length == 187) {
                    SET_PARAMS_COMMAND[0] = 0x0A;
                    SET_PARAMS_COMMAND[2] = (byte) 0xB8;
                    SET_PARAMS_COMMAND[3] = 0x13;
                    SET_PARAMS_COMMAND[4] = 0x55;
                    SET_PARAMS_COMMAND[8] = beepSwitch;
                    SET_PARAMS_COMMAND[10] = filterWindowByte[0];
                    SET_PARAMS_COMMAND[11] = filterWindowByte[1];
                    SET_PARAMS_COMMAND[30] = dhcpSwitch;

                    int start = 12;//设备id
                    for (int i = 0; i < device_id.length; i++) {
                        SET_PARAMS_COMMAND[start++] = device_id[i];
                    }

                    SET_PARAMS_COMMAND[start] = 0x00;
                    SET_PARAMS_COMMAND[start + 1] = stopTimeWindowByte[0];
                    SET_PARAMS_COMMAND[start + 2] = stopTimeWindowByte[1];


                    //lan ip信息
                    start = 31;
                    for (int i = 0; i < lanIpB.length; i++) {
                        SET_PARAMS_COMMAND[start++] = lanIpB[i];
                    }


                    //lan子网掩码
                    start = 35;
                    for (int i = 0; i < lanZwymB.length; i++) {
                        SET_PARAMS_COMMAND[start++] = lanZwymB[i];
                    }

                    //lan网关
                    start = 39;
                    for (int i = 0; i < lanWgB.length; i++) {
                        SET_PARAMS_COMMAND[start++] = lanWgB[i];
                    }

                    //lan 端口号
                    SET_PARAMS_COMMAND[43] = lanPortB[0];
                    SET_PARAMS_COMMAND[44] = lanPortB[1];


                    start = 45; //ip地址
                    for (int i = 0; i < ip.length; i++) {
                        SET_PARAMS_COMMAND[start++] = ip[i];
                    }

                    SET_PARAMS_COMMAND[start++] = port[0];
                    SET_PARAMS_COMMAND[start] = port[1];


                    //lan服务器ip
                    start = 79;
                    for (int i = 0; i < realFwIpB.length; i++) {
                        SET_PARAMS_COMMAND[start++] = realFwIpB[i];
                    }

                    //lan服务器端口
                    SET_PARAMS_COMMAND[111] = lanFwPortB[0];
                    SET_PARAMS_COMMAND[112] = lanFwPortB[1];

                    start = 113;
                    for (int i = 0; i < macB.length; i++) {
                        SET_PARAMS_COMMAND[start++] = macB[i];
                    }


                    start = 172; //插入rssi
                    for (int i = 0; i < rssi.length; i++) {
                        SET_PARAMS_COMMAND[start++] = rssi[i];
                    }

                    //插入增益
                    for (int i = 0; i < grain.length; i++) {
                        SET_PARAMS_COMMAND[start++] = grain[i];
                    }

                    SET_PARAMS_COMMAND[182] = drctSwitch;
                    if (drctTimeWindowByte != null) {
                        SET_PARAMS_COMMAND[183] = drctTimeWindowByte[0];
                    }

                    byte[] a = new byte[1];
                    for (int i = 0; i < SET_PARAMS_COMMAND.length - 1; i++) {
                        a[0] += SET_PARAMS_COMMAND[i];
                    }
                    a[0] = (byte) ((~a[0]) + 1);
                    SET_PARAMS_COMMAND[186] = a[0];

                } else {
                    linkCommand(device_id, ip, port, rssi, grain, lanIpB, lanPortB, lanZwymB, lanWgB, realFwIpB, lanFwPortB);
                }


            } else {

                linkCommand(device_id, ip, port, rssi, grain, lanIpB, lanPortB, lanZwymB, lanWgB, realFwIpB, lanFwPortB);

            }


            //拼接数据包
            if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) { //蓝牙2.0
                reader.setParams(SET_PARAMS_COMMAND);
            } else { //蓝牙4.0
                reader.bleSetParams(SET_PARAMS_COMMAND);
            }

        }
    }

    private void initIntent() {
        Intent intent = getIntent();
        mPoint = (Point) intent.getSerializableExtra("point");
        if (mPoint != null) {
            police_num_et.setText(mPoint.getIdentity());
            longitude = Double.parseDouble(mPoint.getEqlng());
            latitude = Double.parseDouble(mPoint.getEqlat());
            address = mPoint.getEqaddr();
            coordinates_tv.setText(" ( " + longitude + " , " + latitude + " )");
            device_address_et.setText(address);
        }
    }

    /**
     * 显示设置组织机构的dialog
     */
    private void showOrgSelectDialog() {
        AddressSelectToolDialog dialog = new AddressSelectToolDialog();
        dialog.show(getSupportFragmentManager(), "address");
    }

    private LocationManager locationManager;


    public void getLoc() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            //gps已打开
            getLocation();
        } else {
            XToastUtils.showShortToast("请打开gps定位");
        }
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        if (location != null) {
            latitude = location.getLatitude();
            longitude = location.getLongitude();

            String locationStr = " ( " + location.getLongitude() + " , " + location.getLatitude() + " )";
            coordinates_tv.setText(locationStr);
            LatLng latLng = new LatLng(latitude, longitude);
            latlngToAddress(latLng);
        } else {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, locationListener);
        }
    }

    LocationListener locationListener = new LocationListener() {
        // Provider的状态在可用、暂时不可用和无服务三个状态直接切换时触发此函数
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        // Provider被enable时触发此函数，比如GPS被打开
        @Override
        public void onProviderEnabled(String provider) {
            XToastUtils.showShortToast("Gps被打开");
            getLocation();
        }

        // Provider被disable时触发此函数，比如GPS被关闭
        @Override
        public void onProviderDisabled(String provider) {
            XToastUtils.showShortToast("Gps被关闭");
        }

        // 当坐标改变时触发此函数，如果Provider传进相同的坐标，它就不会被触发
        @Override
        public void onLocationChanged(Location location) {
            if (location != null) {
                Log.e("Map", "Location changed : Lat: " + location.getLatitude() + " Lng: " + location.getLongitude());
                latitude = location.getLatitude(); // 纬度
                longitude = location.getLongitude(); // 经度
                LatLng latLng = new LatLng(latitude, longitude);
                String locationStr = " ( " + location.getLongitude() + " , " + location.getLatitude() + " )";
                latlngToAddress(latLng);
                coordinates_tv.setText(locationStr);
            }
        }
    };

    /**
     * 经纬度或地址相互转换
     *
     * @param latlng
     */
    private void latlngToAddress(LatLng latlng) {
        Geocoder geocoder = new Geocoder(DeviceDebugAct.this);
        try {
            List<Address> address1 = geocoder.getFromLocation(latlng.latitude, latlng.longitude, 1);
            if (address1.size() > 0) {
                address = address1.get(0).getCountryName() + /*address1.get(0).getAdminArea() + address1.get(0).getLocality() + */address1.get(0).getAddressLine(1) + address1.get(0).getAddressLine(2);
                device_address_et.setText(address);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void getBaiduAddress() {
    /*使用百度SDK获取经纬度*/
        locationClient = new LocationClient(this);
        LocationClientOption option = new LocationClientOption();
        option.setIsNeedAddress(true);
        option.setOpenGps(true);        //是否打开GPS
        option.setCoorType("bd09ll");       //设置返回值的坐标类型。
        option.setPriority(LocationClientOption.NetWorkFirst);  //设置定位优先级
        option.setProdName("Cocobee"); //设置产品线名称。强烈建议您使用自定义的产品线名称，方便我们以后为您提供更高效准确的定位服务。
        option.setScanSpan(600000);  //设置定时定位的时间间隔为10分钟。单位毫秒
        locationClient.setLocOption(option);

        // 注册位置监听器
        locationClient.registerLocationListener(new BDLocationListener() {
            @Override
            public void onReceiveLocation(BDLocation location) {
                if (location == null) {
                    return;
                }
                longitude = location.getLongitude(); //获取经度
                latitude = location.getLatitude();
                radius = location.getRadius(); //获取精度圈半径
                direction = location.getDirection(); //获取方向信息


                String locationStr = " ( " + location.getLongitude() + " , " + location.getLatitude() + " )";

                address = location.getAddrStr();
                coordinates_tv.setText(locationStr);
                device_address_et.setText(address);


            }
        });
        locationClient.start();
                    /*
                     *当所设的整数值大于等于1000（ms）时，定位SDK内部使用定时定位模式。
                     *调用requestLocation( )后，每隔设定的时间，定位SDK就会进行一次定位。
                     *如果定位SDK根据定位依据发现位置没有发生变化，就不会发起网络请求，
                     *返回上一次定位的结果；如果发现位置改变，就进行网络请求进行定位，得到新的定位结果。
                     *定时定位时，调用一次requestLocation，会定时监听到定位结果。
                     */
        locationClient.requestLocation();
    }


    private void linkCommand(byte[] device_id, byte[] ip, byte[] port, byte[] rssi, byte[] grain, byte[] lanIpB, byte[] lanPortB,
                             byte[] lanZwymB, byte[] lanWgB, byte[] lanFwIpB, byte[] lanFwPortB) {
        byte[] SET_PARAMS_COMMAND_PART1 = new byte[]{0x0A, 0x00, (byte) 0xB8, 0x13,
                0x55,
                0x03,
                0x00, 0x00,
                0x01,
                0x01,
                0x0A, 0x00,
                device_id[0], device_id[1], device_id[2], device_id[3], device_id[4], device_id[5], device_id[6], device_id[7],
                device_id[8], device_id[9], device_id[10], device_id[11], device_id[12], device_id[13], device_id[14],
                0x00, 0x00, 0x00,
                0x01,
                lanIpB[0], lanIpB[1], lanIpB[2], lanIpB[3],
                lanZwymB[0], lanZwymB[1], lanZwymB[2], lanZwymB[3],
                lanWgB[0], lanWgB[1], lanWgB[2], lanWgB[3],
                lanPortB[0], lanPortB[1]
        };


        byte[] SET_PARAMS_COMMAND_PART2 = new byte[SET_PARAMS_COMMAND_PART1.length + ip.length];
        System.arraycopy(SET_PARAMS_COMMAND_PART1, 0, SET_PARAMS_COMMAND_PART2, 0, SET_PARAMS_COMMAND_PART1.length);
        System.arraycopy(ip, 0, SET_PARAMS_COMMAND_PART2, SET_PARAMS_COMMAND_PART1.length, ip.length);


        byte[] other_byte = new byte[109];
        other_byte[0] = port[0];
        other_byte[1] = port[1];
        for (int i = 2; i < other_byte.length - 1; i++) {
            other_byte[i] = 0x00;
        }

        //lan服务器ip  32个字节
        for (int i = 0; i < lanFwIpB.length; i++) {
            other_byte[i + 2] = lanFwIpB[i];
        }


        //lan服务器端口
        other_byte[34] = lanFwPortB[0];
        other_byte[35] = lanFwPortB[1];


        //赋值rssi
        other_byte[95] = rssi[0];
        other_byte[96] = rssi[1];
        other_byte[97] = rssi[2];
        other_byte[98] = rssi[3];

        //赋值增益
        other_byte[99] = grain[0];
        other_byte[100] = grain[1];
        other_byte[101] = grain[2];
        other_byte[102] = grain[3];

        //拼接命令
        SET_PARAMS_COMMAND = new byte[SET_PARAMS_COMMAND_PART2.length + other_byte.length + 1]; //加一个校验位

        System.arraycopy(SET_PARAMS_COMMAND_PART2, 0, SET_PARAMS_COMMAND, 0, SET_PARAMS_COMMAND_PART2.length);
        System.arraycopy(other_byte, 0, SET_PARAMS_COMMAND, SET_PARAMS_COMMAND_PART2.length, other_byte.length);


        byte[] a = new byte[1];
        for (int i = 0; i < SET_PARAMS_COMMAND.length - 1; i++) {
            a[0] += SET_PARAMS_COMMAND[i];
        }

        a[0] = (byte) ((~a[0]) + 1);

        SET_PARAMS_COMMAND[SET_PARAMS_COMMAND.length - 1] = a[0];
    }

    public void uploadCheck() {
        if (user == null) {
            Toast.makeText(context, "请先登录，再上传数据", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(device_id_et.getText().toString().trim())) { //标签为空
            Toast.makeText(context, "请输入设备ID", Toast.LENGTH_SHORT).show();
            return;
        }

        if (device_id_et.getText().toString().trim().length() < DEVICE_ID_LENGTH) {
            Toast.makeText(context, "设备ID长度不足", Toast.LENGTH_SHORT).show();
            return;
        }

        if (CheckUtils.isEmpty(coordinates_tv.getText().toString().trim())) {
            XToastUtils.showLongToast("经纬度为空");
            return;
        }

        if (CheckUtils.isEmpty(device_address_et.getText().toString().trim())) {
            XToastUtils.showShortToast("请先输入地址");
            return;
        }

        if (TextUtils.isEmpty(device_ip_et.getText().toString().trim())) {
            Toast.makeText(context, "平台1 IP地址不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(device_port_et.getText().toString().trim())) {
            Toast.makeText(context, "平台1端口号不能为空", Toast.LENGTH_SHORT).show();
            return;
        }


        if (Integer.valueOf(device_port_et.getText().toString().trim()) < 0 || Integer.valueOf(device_port_et.getText().toString().trim()) > 65535) {
            Toast.makeText(context, "平台1端口号输入范围为0～65535", Toast.LENGTH_SHORT).show();
            return;
        }


        if (TextUtils.isEmpty(police_station_et.getText().toString().trim())) {
            Toast.makeText(context, "组织机构不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!CheckUtils.isEmpty(lan_fwport_et.getText().toString().trim()) && (Integer.valueOf(lan_fwport_et.getText().toString().trim()) < 0 || Integer.valueOf(lan_fwport_et.getText().toString().trim()) > 65535)) {
            Toast.makeText(context, "平台2端口号输入范围为0～65535", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(lan_ip_et.getText().toString().trim())) {
            Toast.makeText(context, "本地ip不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(lan_port_et.getText().toString().trim())) {
            Toast.makeText(context, "本地端口号不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!CheckUtils.isEmpty(lan_port_et.getText().toString().trim()) && (Integer.valueOf(lan_port_et.getText().toString().trim()) < 0 || Integer.valueOf(lan_port_et.getText().toString().trim()) > 65535)) {
            Toast.makeText(context, "本地端口号输入范围为0～65535", Toast.LENGTH_SHORT).show();
            return;
        }

        String filterStr = filter_et.getText().toString().trim();
        if (CheckUtils.isEmpty(filterStr)) {
            XToastUtils.showShortToast("去重过滤不能为空");
            return;
        } else if (!TextUtils.isEmpty(filterStr) && Integer.valueOf(filterStr) < 0 || Integer.valueOf(filterStr) > 65526) {
            Toast.makeText(context, "去重过滤值为0～65526", Toast.LENGTH_SHORT).show();
            return;
        }

        upload();
    }

    /**
     * 上传数据
     * 基站是否存在 1存在0不存在
     */
    private void upload() {
        String deviceId = device_id_et.getText().toString().trim();//设备编号
        String deviceIp = device_ip_et.getText().toString().trim();//平台1 IP地址
        String devicePort = device_port_et.getText().toString().trim();//平台1端口号
        String policeNum = police_num_et.getText().toString().trim();//110识别码
        String deviceAddress = device_address_et.getText().toString().trim();//所在地
        String deviceImei = device_imei_et.getText().toString().trim();//无线模块imei
        String deviceNum = device_num_et.getText().toString().trim();//出厂编号
        String lanFwip = lan_fwip_et.getText().toString().trim();//平台2 IP
        String lanFwport = lan_fwport_et.getText().toString().trim();//平台2端口
        String lanLocalip = lan_ip_et.getText().toString().trim();//本地 IP
        String lanLocalport = lan_port_et.getText().toString().trim();//本地端口
        String filterTime = filter_et.getText().toString().trim();//去重时间
        String stopTime = stopTime_et.getText().toString().trim();//停留时间
        String creator = "";
        if (user != null) {
            creator = user.getDataList().getAppMemberId();
        }

        ManagerApiUtils.uploadStationInfo(this, deviceId, deviceIp, devicePort, String.valueOf(longitude), String.valueOf(latitude), policeNum, deviceAddress, deviceImei,
                deviceNum, lanLocalip, lanLocalport,lanFwip, lanFwport, orgid, filterTime, stopTime, creator, new DialogCallback<Object>(this, "正在上报...") {
                    @Override
                    public void onSuccess(Object o, Call call, Response response) {
                        XToastUtils.showShortToast("上报成功");
                        EventBus.getDefault().post(new EventManager(EventConstants.DEVICE_UPLOAD_SUCCESS));
                        startActivity(new Intent(context, EquipPosLookAct.class).putExtra("collectorId", deviceId).putExtra("flag", Constant.AFTER_UPLOAD_DEVICE_INFO_SUCCESS));
                    }
                });
    }

    private Handler handler = new MyHandler(DeviceDebugAct.this);

    /**
     * 处理收到handler后的事情
     *
     * @param msg
     */
    private void handleSuccess(Message msg) {
        if (sDialog != null && sDialog.isShowing()) {
            sDialog.dismiss();
        }
        switch (msg.what) {

            case BlueToothHelper.MSG_SET_PARAMS_OK:
                Toast.makeText(context, "参数设置成功", Toast.LENGTH_SHORT).show();
                mSetting = false;
                if (mp != null) {
                    mp.start();
                }
                break;

            case BlueToothHelper.MSG_SET_PARAMS_FAIL:
                mSetting = false;
                Toast.makeText(context, "参数设置失败", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_READ_IMEI_OK:
                if (mp != null) {
                    mp.start();
                }
                mScanning = false;
                String imei = msg.obj.toString();
                device_imei_et.setText(imei);
                break;

            case BlueToothHelper.MSG_READ_IMEI_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_READ_FACNUM_OK:
                if (mp != null) {
                    mp.start();
                }
                mScanning = false;
                String factory_num = msg.obj.toString();
                device_num_et.setText(factory_num);
                break;

            case BlueToothHelper.MSG_READ_FACUNM_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;


            case BlueToothHelper.MSG_READ_GPRS_OK:
                if (mp != null) {
                    mp.start();
                }
                mScanning = false;
                int gprsNum = (int) msg.obj;
                gprs_num_et.setText("" + gprsNum);
                break;

            case BlueToothHelper.MSG_READ_GPRS_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_READ_SYSTIME_OK:
                if (mp != null) {
                    mp.start();
                }
                mScanning = false;
                String time = msg.obj.toString();
                systime_tv.setText(time);
                break;


            case BlueToothHelper.MSG_READ_SYSTIME_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_SET_SYSTIME_OK:
                if (mp != null) {
                    mp.start();
                }
                mSetting = false;
                Toast.makeText(context, "设置成功", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_SET_SYSTIME_FAIL:
                mSetting = false;
                Toast.makeText(context, "设置失败", Toast.LENGTH_SHORT).show();
                break;

            case BlueToothHelper.MSG_NO_BLUETOOTH_SOCKET:
                Toast.makeText(context, "蓝牙Socket已丢失，请重新连接设备", Toast.LENGTH_SHORT).show();
                break;


            case BlueToothHelper.MSG_READ_GPRS_CONNECT_STATE_OK:
                mScanning = false;
                if (mp != null) {
                    mp.start();
                }
                Map<String, Object> result = (Map<String, Object>) msg.obj;
                String ip = (String) result.get("gprsCntIp");
                String port = (String) result.get("gprsCntPort");
                int state = (int) result.get("gprsCntState");

                if (state == 1) { //已经建立连接
                    gprs_connect_et.setText(ip + ":" + port + " 已连接");
                } else { //0表示未连接
                    gprs_connect_et.setText(ip + ":" + port + " 无连接");
                }

                break;


            case BlueToothHelper.MSG_READ_GPRS_CONNECT_STATE_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;


            case BlueToothHelper.MSG_READ_LAN_CONNECT_STATE_OK:
                mScanning = false;
                if (mp != null) {
                    mp.start();
                }
                result = (Map<String, Object>) msg.obj;
                ip = (String) result.get("lanCntIp");
                port = (String) result.get("lanCntPort");
                state = (int) result.get("lanCntState");

                if (state == 1) { //已经建立连接
                    lan_connect_et.setText(ip + ":" + port + " 已连接");
                } else { //0表示未连接
                    lan_connect_et.setText(ip + ":" + port + " 无连接");
                }
                break;

            case BlueToothHelper.MSG_DEVICE_UNSUPPORT_LAN:
                mScanning = false;
                lan_connect_et.setText("          :   不支持");
                break;

            case BlueToothHelper.MSG_READ_LAN_CONNECT_STATE_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;


            case BlueToothHelper.MSG_READ_CACHE_TAG_NUM_OK:
                mScanning = false;
                if (mp != null) {
                    mp.start();
                }
                if (msg.arg1 == 200) { //只有无线
                    int tagCacheNum = (int) msg.obj;
                    wx_tagnum_et.setText("" + tagCacheNum);
                    yx_tagnum_et.setText("无");
                    gl_tagnum_et.setText("无");
                } else if (msg.arg1 == 500) {
                    int[] tagCacheNum = (int[]) msg.obj;
                    wx_tagnum_et.setText("" + tagCacheNum[0]);
                    yx_tagnum_et.setText("" + tagCacheNum[1]);
                    gl_tagnum_et.setText("" + tagCacheNum[2]);
                }
                break;

            case BlueToothHelper.MSG_READ_CACHE_TAG_NUM_FAIL:
                mScanning = false;
                Toast.makeText(context, "读取失败", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;

        }
    }

    static class MyHandler extends Handler {

        private final DeviceDebugAct mDeviceDebugAct;

        public MyHandler(DeviceDebugAct deviceDebugAct) {
            mDeviceDebugAct = deviceDebugAct;
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mDeviceDebugAct.handleSuccess(msg);
        }

    }

    @Override
    public void scanned(Transponder trp) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (sDialog != null && sDialog.isShowing()) {
                    sDialog.dismiss();
                }
                if (trp != null) {
                    device_id_et.setText(trp.getDevice_id().trim());
                    device_ip_et.setText(trp.getIp().trim());
                    device_port_et.setText(trp.getPort());
                    SET_PARAMS_COMMAND = trp.getData();
                    tx_one_zy_et.setText(trp.getDeviceGrains()[0]);
                    tx_two_zy_et.setText(trp.getDeviceGrains()[1]);
                    tx_three_zy_et.setText(trp.getDeviceGrains()[2]);
                    tx_four_zy_et.setText(trp.getDeviceGrains()[3]);


                    tx_one_rssi_et.setText(trp.getDeviceRssis()[0] + "");
                    tx_two_rssi_et.setText(trp.getDeviceRssis()[1] + "");
                    tx_three_rssi_et.setText(trp.getDeviceRssis()[2] + "");
                    tx_four_rssi_et.setText(trp.getDeviceRssis()[3] + "");

                    filter_et.setText(trp.getFilterNum() + "");
                    stopTime_et.setText(trp.getStopTimeNum() + "");
                    directionTime_et.setText(trp.getDrctTimeNum() + "");

                    lan_ip_et.setText(trp.getLanIp().trim());
                    lan_port_et.setText(trp.getLanPort());
                    lan_zwym_et.setText(trp.getLanZwym());
                    lan_wg_et.setText(trp.getLanWg());
                    lan_fwip_et.setText(trp.getLanFwIp().trim());
                    lan_fwport_et.setText(trp.getLanFwPort());
                    lan_mac_et.setText(trp.getMac());


                    if (trp.getBeepFlag() == 0) { //关闭状态
                        beep_cb.setChecked(false);
                        beepSwitch = 0x00;
                    } else {
                        beep_cb.setChecked(true);
                        beepSwitch = 0x01;
                    }

                    if (trp.getDhcpFlag() == 0) { //关闭状态
                        dhcp_cb.setChecked(false);
                        dhcpSwitch = 0x00;
                    } else {
                        dhcp_cb.setChecked(true);
                        dhcpSwitch = 0x01;
                    }

                    if (trp.getDrctFlag() == 0) { //关闭状态
                        drct_cb.setChecked(false);
                        drctSwitch = 0x00;
                    } else {
                        drct_cb.setChecked(true);
                        drctSwitch = 0x01;
                    }

                    //网络连接状态
                    if (trp.getNetState() == 0xA1) {
                        net_state_tv.setText("无线已连接");
                    } else if (trp.getNetState() == 0xA0) {
                        net_state_tv.setText("无连接");
                    } else if (trp.getNetState() == 0xA2) {
                        net_state_tv.setText("有线已连接");
                    } else if (trp.getNetState() == 0xA3) {
                        net_state_tv.setText("无线/有线 已连接");
                    } else {
                        net_state_tv.setText("不支持");
                    }


                    if (!TextUtils.isEmpty(trp.getVersion()) && !TextUtils.isEmpty(trp.getTime())) {
                        collector_info_tv.setText("采集器信息（ V " + trp.getVersion() + "      " + trp.getTime() + " )");
                    } else if (!TextUtils.isEmpty(trp.getVersion())) {
                        collector_info_tv.setText("采集器信息（ V " + trp.getVersion() + " ）");
                    } else if (!TextUtils.isEmpty(trp.getTime())) {
                        collector_info_tv.setText("采集器信息（ " + trp.getTime() + " ）");
                    } else {
                        collector_info_tv.setText("采集器信息");
                    }

                    if (mp != null) {
                        mp.start();
                    }

                } else {
                    XToastUtils.showShortToast("读取设备信息失败");
                }
                mSetting = false;
                mScanning = false;
            }
        });
    }

    @Override
    public void begin() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mScanning = true;
                sDialog = new SweetAlertDialog(DeviceDebugAct.this, SweetAlertDialog.PROGRESS_TYPE);
                sDialog.setTitleText("正在读取...");
                sDialog.getProgressHelper().setBarColor(Color.parseColor("#266351"));
                sDialog.setCancelable(true);
                sDialog.setCanceledOnTouchOutside(true);
                sDialog.show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(mReceiver, filter);

        reader = BlueToothHelper.getInstance(handler);
    }


    @Override
    protected void onStop() {
        try {
            this.unregisterReceiver(mReceiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onStop();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1002 && resultCode == 2001) {
            latitude = data.getDoubleExtra("lat", 0.0);
            longitude = data.getDoubleExtra("lng", 0.0);
            address = data.getStringExtra("address");

            String locationStr = " ( " + longitude + " , " + latitude + " )";

            coordinates_tv.setText(locationStr);

            if (!TextUtils.isEmpty(address)) {
                device_address_et.setText(address);
            }
        }


    }


    private boolean isConnected() {

        SharedPreferences sp = getSharedPreferences(Constant.SP_CONNECT_STATUS, Context.MODE_PRIVATE);
        boolean status = sp.getBoolean(Constant.CONNECT_STATUS, false);

        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC && status && (reader.getSocket() == null || !reader.getSocket().isConnected())) { //如果当前标记已连接，但是socket连接实际已经断了
            Editor editor = sp.edit();
            editor.putBoolean(Constant.CONNECT_STATUS, false);
            editor.commit();
            status = false;
        }


        return status;
    }

    @Override
    protected void onDestroy() {
        // setReadyStatus();
        if (locationClient != null && locationClient.isStarted()) {
            locationClient.stop();
            locationClient = null;
        }

        if (mp != null) {
            mp.release();
            mp = null;
        }


        if (sDialog != null && sDialog.isShowing()) {
            sDialog.dismiss();
        }

        OkGo.getInstance().cancelTag(this);

        handler.removeCallbacksAndMessages(null);
        super.onDestroy();


    }


    // The BroadcastReceiver that listens for discovered devices and
    // changes the title when discovery is finished
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) { //蓝牙连接丢失监听广播，若丢失读标签按钮不可按
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                Toast.makeText(context, "连接丢失", Toast.LENGTH_SHORT).show();
                read_device_btn.setEnabled(false);

                Message msg = handler.obtainMessage();
                msg.what = CMD_STOP;
                handler.sendMessage(msg);

                setReadyStatus();
            }
        }
    };

    /**
     * Set the Connection of BlueTooth with READY
     */
    private void setReadyStatus() {
        // save the READY status into config file.
        Editor editor = sharedPreferences.edit();
        editor.putBoolean("status", false);
        editor.commit();

        // Stop the Blue tooth helper.
        if (reader != null) {
            reader.close();
        }
    }

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.ORGENIZE_SELECT_CAR_OWNER_SUCCESS://组织机构选择成功
                CarOwnerInfo carOwnerInfo = (CarOwnerInfo) eventManager.getData();
                orgid = carOwnerInfo.getOrgid();
                String orgname = carOwnerInfo.getOrgname();
                if (!TextUtils.isEmpty(orgname)) {
                    police_station_et.setText(orgname);
                }
                break;
        }
    }
}
