package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.DeviceUpdateResponse;

import java.util.List;

/**
 * Created by Administrator on 2017/5/5.
 */

public class DeviceUpdatePathAdapter extends QuickRcvAdapter<DeviceUpdateResponse> {

    public DeviceUpdatePathAdapter(Context context, List data, int... layoutId) {
        super(context, data, R.layout.item_download_path_list);
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, DeviceUpdateResponse item) {
        viewHolder.setText(R.id.tv_file_name,item.getName());
        viewHolder.setText(R.id.tv_version_num,item.getVersion());
    }
}
