package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.recyclerview.swipe.SwipeMenuAdapter;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/4/25
 * Time:  10:45
 */

public class BindingCarAdapter extends SwipeMenuAdapter<BindingCarAdapter.BindingCarAdapterViewHolder> {
    private List<GuardianObjectResponse> mList;
    private Context mContext;
    private final UserInfo mUserLoginInfo;

    public BindingCarAdapter(Context context, List<GuardianObjectResponse> list) {
        this.mList = list;
        this.mContext = context;
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    public View onCreateContentView(ViewGroup viewGroup, int i) {
        return LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_car_binding, viewGroup, false);

    }

    @Override
    public BindingCarAdapterViewHolder onCompatCreateViewHolder(View view, int i) {
        return new BindingCarAdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BindingCarAdapterViewHolder holder, int position) {
        holder.setData(mList.get(position));
    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }

    class BindingCarAdapterViewHolder extends RecyclerView.ViewHolder {

        private final ImageView bikeImg;
        private final TextView carNumberTxt;
        private final TextView mTvEdit;
        private final TextView mStatusTxt;

        public BindingCarAdapterViewHolder(View itemView) {
            super(itemView);
            bikeImg = (ImageView) itemView.findViewById(R.id.bikeImg);
            mTvEdit = (TextView) itemView.findViewById(R.id.tv_edit);
            mStatusTxt = (TextView) itemView.findViewById(R.id.statusTxt);
            carNumberTxt = (TextView) itemView.findViewById(R.id.carNumberTxt);
        }

        public void setData(GuardianObjectResponse guardianObjectResponse) {
            carNumberTxt.setText(guardianObjectResponse.getSysServiceTypeName());
            mTvEdit.setText(guardianObjectResponse.getSysPropertyValueStr());
            //1 未激活2 锁定中3 已激活、有效中4 已过期5 删除了
            if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 2) {
                mStatusTxt.setText("锁定中");
                mStatusTxt.setTextColor(mContext.getResources().getColor(R.color.color_ff0000));
            } else if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 3) {
                mStatusTxt.setText("已激活");
                mStatusTxt.setTextColor(mContext.getResources().getColor(R.color.color_12bc00));
            } else if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 4) {
                mStatusTxt.setText("已过期");
                mStatusTxt.setTextColor(mContext.getResources().getColor(R.color.color_999999));
            } else {
                mStatusTxt.setText("未激活");
                mStatusTxt.setTextColor(mContext.getResources().getColor(R.color.color_333333));
            }

            ImageUtil.loadJianhuObjectPic(mContext, guardianObjectResponse.getSysServiceTypeIcon(), bikeImg);
        }
    }

}
