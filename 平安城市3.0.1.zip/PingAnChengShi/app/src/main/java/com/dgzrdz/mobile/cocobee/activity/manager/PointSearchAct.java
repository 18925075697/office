package com.dgzrdz.mobile.cocobee.activity.manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseAct;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.model.Point;
import com.dgzrdz.mobile.cocobee.view.PointSearchView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 点位搜索页面
 * Created by _H_JY on 2016/11/14.
 */
public class PointSearchAct extends BaseAct implements View.OnClickListener/*, AdapterView.OnItemClickListener */{

    private Context context;
    private List<Point> points = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_point_search);
        context = this;

        Intent intent = getIntent();
        List<Point> pointList = (List<Point>) intent.getSerializableExtra("points");

        points.addAll(pointList);


        initView();
    }

    private void initView() {

        ImageButton back_ib = (ImageButton) findViewById(R.id.back_ib);
        ListView listView = (ListView) findViewById(R.id.listView);
        PointSearchView<Point> pointSearchView = (PointSearchView) findViewById(R.id.searchView);



        pointSearchView.setHintString("识别码、状态、地址关键词");



        back_ib.setOnClickListener(this);

        SearchPointAdapter adapter = new SearchPointAdapter(this, points);
        listView.setAdapter(adapter);

        listView.addHeaderView(new ViewStub(this));
        listView.addFooterView(new ViewStub(this));

        //设置数据源
        pointSearchView.setDatas(points);

        //设置适配器
        pointSearchView.setAdapter(adapter);

        pointSearchView.setSearchDataListener(new PointSearchView.SearchDatas<Point>() {
            @Override
            public List<Point> filterDatas(List<Point> datas, List<Point> filterdatas, String inputstr) {
                for (int i = 0; i < datas.size(); i++) {
                    Point point = datas.get(i);
                    String installStateStr = "";
                    String onlineStateStr = "";
                    if (point.getInstall_flag() != null && point.getInstall_flag().equals("2")) {
                        installStateStr = "已安装";
                    } else {
                        installStateStr = "未安装";
                    }
                    if (point.getEqversion() != null && point.getEqversion().equals("1")) {
                        onlineStateStr = "在线";
                    } else {
                        onlineStateStr = "不在线";
                    }

                    if (point.getIdentity().contains(inputstr) || point.getEqaddr().contains(inputstr) || installStateStr.contains(inputstr) || onlineStateStr.startsWith(inputstr)) {
                        filterdatas.add(datas.get(i));
                    }
                }
                return filterdatas;
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_ib:
                finish();
                break;

        }
    }

    private void updatePointData(int position) {

        Intent i = new Intent(context, PointMapManageAct.class);
        i.putExtra("flag", Constant.DWGL);
        i.putExtra("currentPosition", position);
        i.putExtra("points", (Serializable) points);
        startActivity(i);

    }


    private class ViewHolder {

        private TextView mInstall_debug;
        private TextView mChangePosition;
        private TextView recogcode_tv;
        private TextView address_tv;
        private TextView coordinates_tv;
        private TextView install_status_tv;
        private TextView online_status_tv;


        public ViewHolder(View view) {
            recogcode_tv = (TextView) view.findViewById(R.id.recogcode_tv);
            address_tv = (TextView) view.findViewById(R.id.address_tv);
            coordinates_tv = (TextView) view.findViewById(R.id.coordinates_tv);
            install_status_tv = (TextView) view.findViewById(R.id.install_status_tv);
            online_status_tv = (TextView) view.findViewById(R.id.online_status_tv);
            mInstall_debug = (TextView) view.findViewById(R.id.install_debug);
            mChangePosition = (TextView) view.findViewById(R.id.change_position);
        }


    }


    public class SearchPointAdapter extends BaseAdapter {

        private Context context;
        private List<Point> searchResPoints = new ArrayList<>();
        private LayoutInflater layoutInflater;

        public SearchPointAdapter(Context context, List<Point> searchResPoints) {
            this.context = context;
            this.searchResPoints = searchResPoints;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return searchResPoints.size();
        }

        @Override
        public Object getItem(int position) {
            return searchResPoints.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            Point point = searchResPoints.get(position);
            ViewHolder viewHolder;
            if (view == null) {
                view = layoutInflater.inflate(R.layout.pos_info_lv_item, null);
                viewHolder = new ViewHolder(view);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }


            viewHolder.recogcode_tv.setText(Html.fromHtml("110识别码：<font color='blue'>" + point.getIdentity() + "</font>"));
            viewHolder.address_tv.setText("地址：" + point.getEqaddr());
            viewHolder.coordinates_tv.setText("经纬度： ( " + point.getEqlng() + " , " + point.getEqlat() + " )");

            String pointInstallStatus = point.getInstall_flag();
            if (pointInstallStatus != null && pointInstallStatus.equals("2")) {
                viewHolder.install_status_tv.setText(Html.fromHtml("安装状态：<font color='#136006'>已安装</font>"));

            } else {
                viewHolder.install_status_tv.setText(Html.fromHtml("安装状态：<font color='red'>未安装</font>"));
            }
            viewHolder.mInstall_debug.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, DeviceDebugAct.class);
                    intent.putExtra("point",point);
                    startActivity(intent);
                }
            });

            viewHolder.mChangePosition.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updatePointData(position);
                }
            });
            return view;
        }
    }

}
