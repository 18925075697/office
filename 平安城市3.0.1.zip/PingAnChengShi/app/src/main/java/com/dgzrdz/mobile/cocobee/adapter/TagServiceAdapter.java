package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.TagServiceResponse;

import java.util.List;

/**
 * Description: 选择服务弹框的标签服务adapter
 * Author: Liubingren
 * Data:  2017/5/5
 * Time:  16:21
 */

public class TagServiceAdapter extends QuickRcvAdapter<TagServiceResponse> {

    private final List<TagServiceResponse> mData;
    private final Context mContext;

    public TagServiceAdapter(Context context, List<TagServiceResponse> data, int... layoutId) {
        super(context, data, R.layout.item_tag_service);
        mContext = context;
        mData = data;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, TagServiceResponse item) {
        RecyclerView recyclerView = viewHolder.getView(R.id.recycle_view);
        TextView title = viewHolder.getView(R.id.tv_title);
        title.setText(item.getTitle());

        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 3));
        List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = item.getServiceTypeList();
        ItemYearAdapter adapter = new ItemYearAdapter(mContext,serviceTypeList );
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH bh, int i) {
                tagItemOnClick.onItemClick(position,i);
            }
        });
    }

    private TagItemOnClick tagItemOnClick;

    public interface TagItemOnClick {
        /**
         *
         * @param position 外层条目
         * @param positions 内层条目
         */
        void onItemClick( int position, int positions);
    }
    public void setTagItemOnClickListener(TagItemOnClick listener) {
        tagItemOnClick = listener;
    }
}
