package com.dgzrdz.mobile.cocobee.activity.manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseAct;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.Point;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * 点位管理页面
 * Created by _H_JY on 16/11/9.
 */
public class PointManageListAct extends BaseAct implements View.OnClickListener {

    private ImageView back_ib;
    private TextView top_map;
    private ListView mListView;
    private View headerView;
    private TextView size_tv;  //展示标签记录数
    private List<Point> infos = new ArrayList<>();
    private PosInfoAdapter adapter;
    private Context context;
    private int refresh_flag;
    private TextView search_point_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_posmanage);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        context = this;
        initView();
    }

    private void initView() {

        back_ib = (ImageView) findViewById(R.id.back_ib);
        mListView = (ListView) findViewById(R.id.listView);
        top_map = (TextView) findViewById(R.id.top_map);

        headerView = LayoutInflater.from(context).inflate(R.layout.lv_header, null);
        mListView.addHeaderView(headerView);
        size_tv = (TextView) headerView.findViewById(R.id.record_num_tv);
        search_point_btn = (TextView) headerView.findViewById(R.id.search_point_btn);

        top_map.setOnClickListener(this);
        back_ib.setOnClickListener(this);
        search_point_btn.setOnClickListener(this);


        loadData();
    }


    @Subscribe
    public void onEventMainThread(EventManager eventMsg) {
        if (eventMsg != null) {
            switch (eventMsg.getEventCode()) {
                case EventConstants.NEED_REFRESH_POINTLIST:
                case EventConstants.DEVICE_UPLOAD_SUCCESS:
                    refresh_flag = 2;
                    loadData();
                    break;

            }
        }
    }

    private void loadData() {

        String title = "";
        if (refresh_flag == 2) {
            title = "正在更新点位数据...";
        } else {
            title = "正在加载点位数据...";
        }
        ManagerApiUtils.getPointsInfo(this, user.getDataList().getSysAreaId(), new DialogCallback<List<Point>>(this, title) {
            @Override
            public void onSuccess(List<Point> points, Call call, Response response) {
                infos.clear();
                if (points != null && points.size() > 0) {
                    infos.addAll(points);
                    adapter = new PosInfoAdapter(context, infos);
                    mListView.setAdapter(adapter);

                    size_tv.setText("点位总数: " + infos.size());

                    top_map.setVisibility(View.VISIBLE);

                } else {
                    top_map.setVisibility(View.GONE);
                    XToastUtils.showShortToast("暂无相关数据");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                top_map.setVisibility(View.GONE);
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.back_ib:
                finish();
                break;

            case R.id.search_point_btn:
                gotoActivity(new Intent(context, PointSearchAct.class));
                break;

            case R.id.top_map://地图视角
                gotoActivity(new Intent(this, PointMapActivity.class));
                break;

        }

    }

    /**
     * 跳转进入下一个页面
     *
     * @param intent
     */
    private void gotoActivity(Intent intent) {
        intent.putExtra("points", (Serializable) infos);
        startActivity(intent);
    }

    private void updatePointData(int position) {
        Intent i = new Intent(context, PointMapManageAct.class);
        i.putExtra("flag", Constant.DWGL);
        i.putExtra("currentPosition", position);
        i.putExtra("points", (Serializable) infos);
        startActivity(i);

    }


    private class ViewHolder {

        private TextView recogcode_tv;
        private TextView address_tv;
        private TextView coordinates_tv;
        private TextView install_status_tv;
        private TextView online_status_tv;
        private TextView mInstall_debug;
        private TextView mChangePosition;


        public ViewHolder(View view) {
            recogcode_tv = (TextView) view.findViewById(R.id.recogcode_tv);
            address_tv = (TextView) view.findViewById(R.id.address_tv);
            coordinates_tv = (TextView) view.findViewById(R.id.coordinates_tv);
            install_status_tv = (TextView) view.findViewById(R.id.install_status_tv);
            online_status_tv = (TextView) view.findViewById(R.id.online_status_tv);
            mInstall_debug = (TextView) view.findViewById(R.id.install_debug);
            mChangePosition = (TextView) view.findViewById(R.id.change_position);
        }


    }


    public class PosInfoAdapter extends BaseAdapter {

        private Context context;
        private List<Point> points = new ArrayList<>();
        private LayoutInflater layoutInflater;

        public PosInfoAdapter(Context context, List<Point> alarmInfos) {
            this.context = context;
            this.points = alarmInfos;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return points.size();
        }

        @Override
        public Object getItem(int position) {
            return points.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            Point point = points.get(position);
            ViewHolder viewHolder;
            if (view == null) {
                view = layoutInflater.inflate(R.layout.pos_info_lv_item, null);
                viewHolder = new ViewHolder(view);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }


            viewHolder.recogcode_tv.setText(Html.fromHtml("110识别码：<font color='blue'>" + point.getIdentity() + "</font>"));
            viewHolder.address_tv.setText("地址：" + point.getEqaddr());
            viewHolder.coordinates_tv.setText("经纬度： ( " + point.getEqlng() + " , " + point.getEqlat() + " )");

            String pointInstallStatus = point.getInstall_flag();
            if (pointInstallStatus != null && pointInstallStatus.equals("2")) {
                viewHolder.install_status_tv.setText(Html.fromHtml("安装状态：<font color='#136006'>已安装</font>"));
                String isOnlineStr = point.getEqupversion();
            } else {
                viewHolder.install_status_tv.setText(Html.fromHtml("安装状态：<font color='red'>未安装</font>"));
            }

            viewHolder.mInstall_debug.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, DeviceDebugAct.class);
                    intent.putExtra("point",point);
                    startActivity(intent);
                }
            });

            viewHolder.mChangePosition.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updatePointData(position);
                }
            });
            return view;
        }
    }


    @Override
    protected void onDestroy() {
        OkGo.getInstance().cancelTag(this);
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        super.onDestroy();
    }
}
