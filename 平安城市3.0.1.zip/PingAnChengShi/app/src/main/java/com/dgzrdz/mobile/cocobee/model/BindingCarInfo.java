package com.dgzrdz.mobile.cocobee.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Created by admin on 2018/4/25.
 * 绑定服务  item的实体类
 */

public class BindingCarInfo implements Serializable {
    /**
     * buyPrice : 665
     * buyTime : 2018-05-03 15:56:00
     * buyType :
     * cno : 呢加QQ
     * frame :
     * id : c0c2217c4ea711e89a8900ffe2fce803
     * people_car_labelId : c0c3cc744ea711e89a8900ffe2fce803
     * picture : [{"id":"0953d33f1dbe408c87c1cab827fea99b","picId":"0953d33f1dbe408c87c1cab827fea99b","property":"3","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/2/9j/4A.jpg"},{"id":"511aaf815fa4439683893c2fd7e769ed","picId":"511aaf815fa4439683893c2fd7e769ed","property":"5","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/4/9j/4A.jpg"},{"id":"28e25e6e9d384d8eb9ffd94abacfa435","picId":"28e25e6e9d384d8eb9ffd94abacfa435","property":"6","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/5/9j/4A.jpg"},{"id":"4839de5be83e4e7c8f43674a57f21ea1","picId":"4839de5be83e4e7c8f43674a57f21ea1","property":"2","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/1/9j/4A.jpg"},{"id":"450b18f232614984b85d98ec469df85a","picId":"450b18f232614984b85d98ec469df85a","property":"4","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/3/9j/4A.jpg"},{"id":"908e56202e01429e82c198b47cca55d0","picId":"908e56202e01429e82c198b47cca55d0","property":"1","thirdId":"c0c2217c4ea711e89a8900ffe2fce803","url":"/upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/0/9j/4A.jpg"}]
     */

    private int buyPrice;
    private String buyTime;
    private String buyType;
    private String cno;
    private String frame;
    private String id;
    private String device;
    private String color;
    private String people_car_labelId;
    private List<PictureBean> picture;
    boolean isCheck;//是否选中
    boolean isSelect;//是否选择车辆
    boolean isMissPic;//是否上传时缺少图片
    private int status;//状态 0未激活 1 锁定中 2已激活 3已失效

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }

    public int getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(int buyPrice) {
        this.buyPrice = buyPrice;
    }

    public String getBuyTime() {
        return buyTime;
    }

    public void setBuyTime(String buyTime) {
        this.buyTime = buyTime;
    }

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getFrame() {
        return frame;
    }

    public void setFrame(String frame) {
        this.frame = frame;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isMissPic() {
        return isMissPic;
    }

    public void setMissPic(boolean missPic) {
        isMissPic = missPic;
    }

    public String getPeople_car_labelId() {
        return people_car_labelId;
    }

    public void setPeople_car_labelId(String people_car_labelId) {
        this.people_car_labelId = people_car_labelId;
    }

    public List<PictureBean> getPicture() {
        return picture;
    }

    public void setPicture(List<PictureBean> picture) {
        this.picture = picture;
    }


    public static class PictureBean implements Serializable{
        /**
         * id : 0953d33f1dbe408c87c1cab827fea99b
         * picId : 0953d33f1dbe408c87c1cab827fea99b
         * property : 3                                     15:身份证正面+标签照片,13：身份证反面+车辆合格证，14：登记表+新卡照片，12：车辆全身照+车牌，16：车架号
         * thirdId : c0c2217c4ea711e89a8900ffe2fce803
         * url : /upload/c0c2217c4ea711e89a8900ffe2fce803/2018-05-03/2/9j/4A.jpg
         */

        private String id;
        private String picId;
        private String property;
        private String thirdId;
        @SerializedName("url")
        private String urlX;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPicId() {
            return picId;
        }

        public void setPicId(String picId) {
            this.picId = picId;
        }

        public String getProperty() {
            return property;
        }

        public void setProperty(String property) {
            this.property = property;
        }

        public String getThirdId() {
            return thirdId;
        }

        public void setThirdId(String thirdId) {
            this.thirdId = thirdId;
        }

        public String getUrlX() {
            return urlX;
        }

        public void setUrlX(String urlX) {
            this.urlX = urlX;
        }
    }
}
