package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.SearchRecResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * 查询的recycleView的adapter
 */

public class SearchOrderResultAdapter extends QuickRcvAdapter<SearchRecResponse> {

    private String mSearchString;
    private Context mContext;

    public SearchOrderResultAdapter(Context context, List<SearchRecResponse> data, int... layoutId) {
        super(context, data, layoutId);
    }

    public SearchOrderResultAdapter(Context context, List<SearchRecResponse> data, String searchString, int... layoutId) {
        super(context, data, layoutId);
        mContext = context;
        mSearchString = searchString;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, final int position, SearchRecResponse item) {

        TextView tvName = viewHolder.getView(R.id.tv_name);
        TextView tvMobile = viewHolder.getView(R.id.tv_phone);
        TextView tvLabelNum = viewHolder.getView(R.id.tv_label_num);
        TextView tvCarNum = viewHolder.getView(R.id.tv_car_num);
        TextView tvOrgName = viewHolder.getView(R.id.tv_org_name);

        String name = item.getName();
        String mobile = item.getMobile();
        String lno = item.getLno();
        String personName = item.getPersonName();

        tvName.setText(name);
        tvMobile.setText(mobile);
        tvLabelNum.setText(lno);
        tvCarNum.setText(personName);
        tvOrgName.setText("组织机构: " + item.getOrgname());


        //设置高亮字体
        if (!CheckUtils.isEmpty(name) && name.contains(mSearchString)) {
            Utils.highlightStr(tvName, name, mSearchString, mContext.getResources().getColor(R.color.color_008cff));
        }
        if (!CheckUtils.isEmpty(mobile) && mobile.contains(mSearchString)) {
            Utils.highlightStr(tvMobile, mobile, mSearchString, mContext.getResources().getColor(R.color.color_008cff));
        }

        if (!CheckUtils.isEmpty(lno) && lno.contains(mSearchString)) {
            Utils.highlightStr(tvLabelNum, lno, mSearchString, mContext.getResources().getColor(R.color.color_008cff));
        }

        if (!CheckUtils.isEmpty(personName) && personName.contains(mSearchString)) {
            Utils.highlightStr(tvCarNum, personName, mSearchString, mContext.getResources().getColor(R.color.color_008cff));
        }

    }

}
