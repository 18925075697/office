package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.AlarmInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

/**
 * Created by liu on 2016/10/29.
 * 报警记录adapter
 */
public class AlarmInfoAdapter extends QuickRcvAdapter<AlarmInfoResponse> {
    private List<AlarmInfoResponse> mList;
    private Context mContext;

    public AlarmInfoAdapter(Context context, List<AlarmInfoResponse> list, int... layoutId) {
        super(context, list, R.layout.item_alarm_info);
        this.mList = list;
        this.mContext = context;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, AlarmInfoResponse alarmInfoResponse) {
        quickRcvHolder.setText(R.id.tv_alarm_car, alarmInfoResponse.getBuyType() + "(" + alarmInfoResponse.getCno() + ")");
        quickRcvHolder.setText(R.id.tv_alarm_time, alarmInfoResponse.getTime());
        TextView policeBack = quickRcvHolder.getView(R.id.tv_police_back);
        if (CheckUtils.equalsString(alarmInfoResponse.getStatus(), "1")) {
            policeBack.setTextColor(mContext.getResources().getColor(R.color.color_008cff));
        } else {
            policeBack.setTextColor(mContext.getResources().getColor(R.color.color_f06537));
        }
        policeBack.setText(Utils.getAlarmStatus(alarmInfoResponse.getStatus()));
    }

}