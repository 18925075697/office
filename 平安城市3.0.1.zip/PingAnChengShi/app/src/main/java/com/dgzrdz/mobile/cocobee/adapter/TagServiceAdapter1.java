package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.TagServiceResponse;
import com.zhy.view.flowlayout.FlowLayout;
import com.zhy.view.flowlayout.TagAdapter;
import com.zhy.view.flowlayout.TagFlowLayout;

import java.util.List;

/**
 * Description: 选择服务弹框的标签服务adapter
 * Author: Liubingren
 * Data:  2017/5/5
 * Time:  16:21
 */

public class TagServiceAdapter1 extends QuickRcvAdapter<TagServiceResponse> {

    private final List<TagServiceResponse> mData;
    private final Context mContext;

    public TagServiceAdapter1(Context context, List<TagServiceResponse> data, int... layoutId) {
        super(context, data, R.layout.item_tag_service1);
        mContext = context;
        mData = data;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, TagServiceResponse item) {
        TagFlowLayout tagFlowLayout = viewHolder.getView(R.id.tag_flow_layout);
        TextView title = viewHolder.getView(R.id.tv_title);
        title.setText(item.getTitle());

        List<TagServiceResponse.ServiceTypeListBean> serviceTypeList = item.getServiceTypeList();
        tagFlowLayout.setAdapter(new TagAdapter<TagServiceResponse.ServiceTypeListBean>(serviceTypeList) {
            @Override
            public View getView(FlowLayout parent, int position, TagServiceResponse.ServiceTypeListBean serviceTypeListBean) {
                View view = LayoutInflater.from(mContext).inflate(R.layout.item_year_view, tagFlowLayout, false);
                TextView serviceType = (TextView) view.findViewById(R.id.service_type);
                serviceType.setText(serviceTypeListBean.getName());
                if (!serviceTypeListBean.isEnable()) {
                    serviceType.setPaintFlags(serviceType.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);//添加删除线
                    serviceType.setBackgroundResource(R.drawable.tag_service_normal);
                    serviceType.setTextColor(mContext.getResources().getColor(R.color.color_dddddd));
                    return view;
                }

                if (serviceTypeListBean.getSelect() == position) {//选中的条目
                    serviceType.setPaintFlags(serviceType.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));//取消删除线
                    serviceType.setBackgroundResource(R.drawable.tag_service_select);
                    serviceType.setTextColor(mContext.getResources().getColor(R.color.color_008cff));
                } else {
                    serviceType.setPaintFlags(serviceType.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));//取消删除线
                    serviceType.setBackgroundResource(R.drawable.tag_service_normal);
                    serviceType.setTextColor(mContext.getResources().getColor(R.color.color_333333));
                }
                return view;
            }
        });

        tagFlowLayout.setOnTagClickListener(new TagFlowLayout.OnTagClickListener() {
            @Override
            public boolean onTagClick(View view, int i, FlowLayout parent) {
                tagItemOnClick.onItemClick(position, i);
                return true;
            }
        });

        //        adapter.setOnItemClickListener(new OnRecyclerViewItemClickListener() {
        //            @Override
        //            public void onItemClick(BH bh, int i) {
        //                tagItemOnClick.onItemClick(position, i);
        //            }
        //        });
    }

    private TagItemOnClick tagItemOnClick;

    public interface TagItemOnClick {
        /**
         * @param position  外层条目
         * @param positions 内层条目
         */
        void onItemClick(int position, int positions);
    }

    public void setTagItemOnClickListener(TagItemOnClick listener) {
        tagItemOnClick = listener;
    }
}
