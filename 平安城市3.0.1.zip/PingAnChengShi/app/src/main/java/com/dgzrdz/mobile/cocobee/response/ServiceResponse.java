package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  16:22
 */

public class ServiceResponse implements Serializable{


    private List<PolicyServiceResponse> insShowList;//保险服务显示列表
    private List<TagServiceResponse> setsShowList;//标签服务显示列表
    private List<TagServiceTaocanResponse> valueList;//套餐列表

    public List<TagServiceTaocanResponse> getValueList() {
        return valueList;
    }

    public void setValueList(List<TagServiceTaocanResponse> valueList) {
        this.valueList = valueList;
    }

    public List<PolicyServiceResponse> getInsShowList() {
        return insShowList;
    }

    public void setInsShowList(List<PolicyServiceResponse> insShowList) {
        this.insShowList = insShowList;
    }

    public List<TagServiceResponse> getSetsShowList() {
        return setsShowList;
    }

    public void setSetsShowList(List<TagServiceResponse> setsShowList) {
        this.setsShowList = setsShowList;
    }
}
