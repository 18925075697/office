package com.dgzrdz.mobile.cocobee.common;

import android.os.Environment;


import java.io.File;

/**
 * @author _H_JY
 * 2016-5-26下午2:53:04
 */
public class Path {

    /*项目总文件夹路径*/
    public static final String PROJECT_FILE_PATH = Environment.getExternalStorageDirectory() + File.separator + "com.hsjc.electricar" + File.separator;

    /*存放记录信息的文件夹路径*/
    public static final String RECORD_FILE_PATH = PROJECT_FILE_PATH + "record" + File.separator;

    /*用于存放临时图片的文件夹路径*/
    public static final String IMAGE_TEMP_FILE_PATH = PROJECT_FILE_PATH + "temp_image" + File.separator;

    /***********************************
     * 接口路径
     **************************************************/

    //    public static final String SERVER_BASIC_PATH = "http://192.168.1.107:8080/hs-ebike-app-service/"; //徐勇勇调试地址
    //    public static final String SERVER_BASIC_PATH = "http://192.168.1.2:8083/hs-ebike-app-service/"; //陈康调试地址
    //    public static final String SERVER_BASIC_PATH = "http://192.168.1.220:8099/hs-ebike-app-service/"; //廖健服务器地址
//        public static final String SERVER_BASIC_PATH = "http://172.168.1.122:8082/hs-ebike-app-service/"; //内网正式服务器地址
//    public static final String SERVER_BASIC_PATH = "http://218.17.157.214:8082/hs-ebike-app-service/"; //外网正式服务器地址
    public static final String SERVER_BASIC_PATH = "http://e.intrace.cn:8082/hs-ebike-app-service/"; //正式服务器地址
    //    public static final String SERVER_BASIC_PATH = "http://192.168.1.35:8080/hs-ebike-app-service/"; //大军服务器地址
//        public static final String SERVER_BASIC_PATH = "http://172.168.1.110:8082/hs-ebike-app-service/"; //测试服务器地址
    //    public static final String SERVER_BASIC_PATH = "http://172.168.1.101:8082/hs-ebike-app-service/"; //开发服务器地址
//        public static final String SERVER_BASIC_PATH = "http://192.168.1.175:8113/hs-ebike-app-service/"; //金春丽服务器地址
//        public static final String SERVER_BASIC_PATH = "http://192.168.1.184:8082/hs-ebike-app-service/"; //服务器地址
    //    public static final String SERVER_BASIC_PATH = "http://192.168.1.174:8088/appapi/"; //雷学武服务器地址
//    public static final String SERVER_BASIC_PATH = "http://192.168.1.3:8091/hs-ebike-app-service/"; //杨守坤服务器地址

    public static final String LOCATION_TRACE_BASIC_PATH = "http://120.55.18.211:4307/"; //公网轨迹位置地址
//    public static final String LOCATION_TRACE_BASIC_PATH = "http://218.17.157.214:4307/"; //公网轨迹位置地址
//        public static final String LOCATION_TRACE_BASIC_PATH = "http://172.168.1.101:8186/"; //局域网轨迹位置地址

    /**
     * apk下载地址
     */
    public static final String APK_DOWNLOAD_URL = SERVER_BASIC_PATH + "APK/base.apk";

    // 违章查车获取标签信息
    public static final String SEARCH_CAR_DOWNLOAD = SERVER_BASIC_PATH + "servlet/showpage?eventID=32&&app_res=App_Marktrace";

    //上传违章信息
    public static final String UPLOAD_ILLEGAL_INFO = SERVER_BASIC_PATH + "servlet/showpage?eventID=35&&app_res=App_Marktrace";

    //获取违章类型
    public static final String GET_ILLEGAL_TYPE = SERVER_BASIC_PATH + "servlet/showpage?eventID=34&&app_res=App_Marktrace";


    /**
     * 登录接口
     */
    public static final String LOGIIN_PATH = SERVER_BASIC_PATH + "api/opt/appmember/login";//新接口

    /**
     * 忘记密码获取验证码
     */
    public static final String GET_CHECK_CODE_PATH = SERVER_BASIC_PATH + "api/auth/authcode/send_sms_code";


    /**
     * 忘记密码 验证验证码
     */
    public static final String CHECK_CHECK_CODE_PATH = SERVER_BASIC_PATH + "api/opt/appmember/reset_pass";
    /**
     * 忘记密码
     */
    public static final String FORGET_PWD_PATH = SERVER_BASIC_PATH + "forgetPwd";

    /**
     * 注册获取验证码
     */
    public static final String GET_CHECK_CODE_REG_PATH = SERVER_BASIC_PATH + "registerCode";

    /**
     * 注册验证验证码
     */
    public static final String CHECK_CHECK_CODE_REG_PATH = SERVER_BASIC_PATH + "registerCheckCode";

    /**
     * 注册
     */
    public static final String REGISTER_PATH = SERVER_BASIC_PATH + "register";

    /**
     * 加载首页信息
     */
    public static final String GET_INDEX_MORE_INFO_PATH = SERVER_BASIC_PATH + "web/opt/indexmember/findindex";

    /**
     * 业务统计
     */
    public static final String GET_BUSSINESS_INFO_PATH = SERVER_BASIC_PATH + "web/report/reportmember/findbusinessstatistics";

    /**
     * 首页获取组织机构选择信息
     */
    public static final String GET_INDEX_ORG_SELECT_PATH = SERVER_BASIC_PATH + "web/opt/indexmember/findsysareasubordinate";

    /**
     * 首页获取组织机构选择信息
     */
    public static final String SAVE_INDEX_ORG_SELECT_PATH = SERVER_BASIC_PATH + "index/saveIndexOrgSelect";

    /**
     * 预登记注册
     */
    public static final String PRE_REGISTRATION_PATH = SERVER_BASIC_PATH + "web/reserved/registrationmember/findindex";

    /**
     * 修改用户信息
     */
    public static final String UPDATE_USER_INFO_PATH = SERVER_BASIC_PATH + "web/reserved/registrationmember/updatememberid";

    /**
     * 预登记上传监护对象信息
     */
    public static final String PRE_UPLOAD_CAR_INFO_PATH = SERVER_BASIC_PATH + "web/reserved/registrationmember/savememberserviceobj";

    /**
     * 修改监护对象信息
     */
    public static final String UPDATE_CAR_INFO_PATH = SERVER_BASIC_PATH + "web/reserved/registrationmember/updatememberserviceobj";

    /**
     * 修改标签信息
     */
    public static final String UPDATE_TAG_INFO_PATH = SERVER_BASIC_PATH + "web/database/databasemember/updateobjecthardware";

    /**
     * 删除监护对象
     */
    public static final String DELETE_CAR_INFO_PATH = SERVER_BASIC_PATH + "web/database/databasemember/deletememberserviceobj";

    /**
     * 资料库车主搜索
     */
    public static final String DATA_CAR_HOST_SEARCH_PATH = SERVER_BASIC_PATH + "web/database/databasemember/finddatabasemember";

    /**
     * 查看车主下面的对象
     */
    public static final String GET_UNBIND_CAR_INFO = SERVER_BASIC_PATH + "web/database/databasemember/findappidmemberserviceobj";

    /**
     * 修改车主信息
     */
    public static final String UPDATE_CAR_OWNER_INFO = SERVER_BASIC_PATH + "web/reserved/registrationmember/updatememberid";

    /**
     * 上传纸质保单
     */
    public static final String UPLOAD_PAPER_POLICY = SERVER_BASIC_PATH + "cms/PayOrderform/addPaperWarranty";

    /**
     * 查看电子保单
     */
    public static final String SEE_E_POLICY = SERVER_BASIC_PATH + "cms/PayOrderform/findElectronicWarranty";


    /**
     * 生成未支付订单
     */
    public static final String CREATE_UNPAYED_ORDER = SERVER_BASIC_PATH + "web/order/memberorder/savememberorder";

    /**
     * 验证是否支付成功
     */
    public static final String CHECK_PAY_OK = SERVER_BASIC_PATH + "web/pay/payment/checkispay";

    /**
     * 0元支付通知服务器支付成功
     */
    public static final String NOTIFY_PAY_SUCCESS = SERVER_BASIC_PATH + "web/pay/payment/zeropaynotice";

    /**
     * 管理搜索车主手机号和姓名
     */
    public static final String SEARCH_CAR_OWNER_NAME = SERVER_BASIC_PATH + "root/findSearchFor";

    /**
     * 意见反馈
     */
    public static final String IDEA_BACK = SERVER_BASIC_PATH + "personal/Feedback";

    /**
     * 修改密码
     */
    public static final String CHENGE_PASSWORD = SERVER_BASIC_PATH + "web/mine/minemember/findbusinessstatistics";

    /**
     * 查询车辆详情信息
     */
    public static final String GET_CAR_DETAIL_INFO = SERVER_BASIC_PATH + "findCarDetails";

    /**
     * 获取黑名单
     */
    public static final String GET_ALARM_TAG_INFOS = SERVER_BASIC_PATH + "web/tool/toolmember/findtagsearch";

    /**
     * 手动踩点上传数据
     */
    public static final String UPLOAD_POINT_INFOS = SERVER_BASIC_PATH + "web/tool/toolmember/savebusinessstatistics";

    /**
     * 上传便民服务点
     */
    public static final String UPLOAD_CONVINIENCE_POINT = SERVER_BASIC_PATH + "toolbox/Servicepoints";

    /**
     * 修改便民服务点
     */
    public static final String UPDATE_CONVINIENCE_POINT = SERVER_BASIC_PATH + "toolbox/UpdateServicepoints";

    /**
     * 获取便民服务点
     */
    public static final String GET_CONVINIENCE = SERVER_BASIC_PATH + "toolbox/findServicepoints";

    /**
     * 获取点位数据
     */
    public static final String GET_POINTS_INFO = SERVER_BASIC_PATH + "web/tool/toolmember/findbusinessstatistics";

    /**
     * 更新点位数据
     */
    public static final String UPDATE_POINTS_INFO = SERVER_BASIC_PATH + "web/tool/toolmember/updatebusinessstatistics";

    /**
     * 查询采集器是否存在
     */
    public static final String CHECK_STATION_HAS = SERVER_BASIC_PATH + "web/tool/toolmember/findeqnolocationbelief";

    /**
     * 安装调试上报数据
     */
    public static final String UPLOAD_STATION_INFO = SERVER_BASIC_PATH + "web/tool/toolmember/findindex";

    /**
     * 获取基站位置信息
     */
    public static final String GET_STATION_LOCATION = SERVER_BASIC_PATH + "web/tool/toolmember/findeqnolocationbelief";

    /**
     * 获取设备升级包下载地址
     */
    public static final String DEVICE_UPDATE_PATH = SERVER_BASIC_PATH + "web/tool/toolmember/findsysfiledownload";

    /**
     * 获取版本信息
     */
    public static final String GET_VERSION_INFO = SERVER_BASIC_PATH + "api/opt/appmember/findsysversion";

    /**
     * 报警信息
     */
    public static final String GET_ALARM_INFO = SERVER_BASIC_PATH + "personal/findAlarmCar";

    /**
     * 验证手机号
     */
    public static final String CHECK_PHONE = SERVER_BASIC_PATH + "web/database/databasemember/finphonegetmember";

    /**
     * 获取监护对象类型(三轮车,两轮车)
     */
    public static final String GET_CAR_TYPE = SERVER_BASIC_PATH + "web/reserved/registrationmember/findsysservicetype";

    /**
     * 获取监护对象详情
     */
    public static final String GET_JIAN_HU_DETAIL = SERVER_BASIC_PATH + "web/reserved/registrationmember/findmemberserviceobjidobjectattributeinformation";

    /**
     * 获取监护对象属性
     */
    public static final String GET_OBJECT_VALUE = SERVER_BASIC_PATH + "web/reserved/registrationmember/basisfindserviceobjectattributes";

    /**
     * 获取车辆最后位置
     */
    public static final String GET_CAR_LAST_POSITION = LOCATION_TRACE_BASIC_PATH + "api/v1/agent/data/singleLocation";

    /**
     * 获取车辆轨迹
     */
    public static final String GET_CAR_TRACE = LOCATION_TRACE_BASIC_PATH + "api/v1/agent/data/singleLocus";

    /**
     * 用户取消订单
     */
    public static final String USER_CANCEL_ORDER = SERVER_BASIC_PATH + "web/mine/minemember/manual_cancellation_object";

    /**
     * 获取选择支付页面信息
     */
    public static final String GET_SELECT_PAY = SERVER_BASIC_PATH + "web/report/reportmember/find_payment_center";

    /**
     * 获取标签库存
     */
    public static final String GET_LABEL_STOCK = SERVER_BASIC_PATH + "personal/findGetLabel";

    /**
     * 获取车牌库存
     */
    public static final String GET_CNO_STOCK = SERVER_BASIC_PATH + "personal/findGetCno";

    /**
     * 获取安装点
     */
    public static final String GET_INSTALL_POINT = SERVER_BASIC_PATH + "personal/findMountingPoint";

    /**
     * 获取服务
     */
    public static final String GET_SERVICE_PATH = SERVER_BASIC_PATH + "web/order/memberorder/getmemberorder";

    /**
     * 保险补办获取保险
     */
    public static final String GET_POLICY_PATH = SERVER_BASIC_PATH + "web/order/memberorder/selectins";

    /**
     * 获取消息列表
     */
    public static final String GET_MESSAGE_LIST_PATH = SERVER_BASIC_PATH + "web/mine/minemember/findsysmessage";

    /**
     * 修改手机号码
     */
    public static final String CHANGE_PHONE_NUM = SERVER_BASIC_PATH + "web/mine/minemember/reset_account_number";

    /**
     * 获取订单列表信息
     */
    public static final String GET_ORDER_LIST_INFO = SERVER_BASIC_PATH + "web/mine/minemember/find_order_information";

    /**
     * 获取订单详情信息
     */
    public static final String GET_ORDER_DETAIL_INFO = SERVER_BASIC_PATH + "web/mine/minemember/findobjectmemberorder_details";

    /**
     * 修改套餐手机号码
     */
    public static final String CHANGE_TAOCAN_PHONE = SERVER_BASIC_PATH + "web/mine/minemember/updatelabelpackagecallfeepackagenumber";

    /**
     * 修改保险手机号码
     */
    public static final String CHANGE_POLICY_PHONE = SERVER_BASIC_PATH + "web/mine/minemember/updatesysinsurancevalue_sysinsuranceexvaluestr";

    /**
     * 获取订单统计数
     */
    public static final String GET_ORDER_TOTAL_NUM = SERVER_BASIC_PATH + "web/mine/minemember/findmemberorderappmemberidtotal";

    /**
     * 获取口令短信验证码
     */
    public static final String GET_KOULIN_MSG = SERVER_BASIC_PATH + "web/report/reportmember/password_verification";

    /**
     * 口令码验证
     */
    public static final String CHECK_KOULIN_CODE = SERVER_BASIC_PATH + "web/report/reportmember/pay_password_code";

    /**
     * 获取集团单位列表
     */
    public static final String GET_COMPUTE_LIST = SERVER_BASIC_PATH + "web/mine/minemember/find_sysgroup";

    /**
     * 立即支付
     */
    public static final String PAY_NOW_PATH = SERVER_BASIC_PATH + "web/pay/payment/choosepayment";

    /**
     * 获取车辆信息
     */
    public static final String GET_CAR_INFO_BY_CNO = SERVER_BASIC_PATH + "web/tool/toolmember/getplateinfo";
}
