package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;

public class Point implements Serializable {
    /**
     * orderno : 0
     * ipaddr2 :
     * ipaddr1 :
     * port1 : 0
     * port2 :
     * reportType : 2
     * hearttime : 2018
     * antenna_rssi4 :
     * antenna_rssi3 :
     * line_local_port2 :
     * sysAreaName : 火车站街道
     * eqaddr : 中国浙江省衢州市常山县柚香路28
     * eqisconn : 0
     * antenna_gain1 :
     * antenna_gain2 :
     * factoryno : MR7901-004C0049
     * antenna_gain3 :
     * resetUpflag :
     * antenna_gain4 :
     * line_subnet_mask :
     * orgid : 12
     * eqlat : 28.906802
     * antenna_version :
     * eqlng : 118.523693
     * status : 0
     * eqno : 123456
     * line_local_ip2 :
     * battery_voltage : 6
     * eq_status : 1
     * librepeat : 180
     * remark :
     * devversion :
     * antenna_buzzer :
     * imeino : 1
     * upFlag : 0
     * equpversion : 0
     * identity : 0
     * install_flag : 2
     * simno :
     * antenna_upversion :
     * createtime : 2018-11-06 15:47:16.0
     * eqid : 4
     * eqport : 4600
     * createuser : 1
     * antenna_rssi2 :
     * antenna_rssi1 :
     * power_state :
     * line_gateway :
     * gprs_csq :
     * eqname :
     * eqversion :
     * line_local_ip : 218.17.157.214
     * add_admin_type : 2
     * eqip : 120.55.18.211
     * line_local_port : 4600
     * line_mac_address :
     */

    private String orderno;
    private String ipaddr2;
    private String ipaddr1;
    private String port1;
    private String port2;
    private String reportType;
    private String hearttime;
    private String antenna_rssi4;
    private String antenna_rssi3;
    private String line_local_port2;
    private String sysAreaName;
    private String eqaddr;
    private String eqisconn;
    private String antenna_gain1;
    private String antenna_gain2;
    private String factoryno;
    private String antenna_gain3;
    private String resetUpflag;
    private String antenna_gain4;
    private String line_subnet_mask;
    private String orgid;
    private String eqlat;
    private String antenna_version;
    private String eqlng;
    private String status;
    private String eqno;
    private String line_local_ip2;
    private String battery_voltage;
    private String eq_status;
    private String librepeat;
    private String remark;
    private String devversion;
    private String antenna_buzzer;
    private String imeino;
    private String upFlag;
    private String equpversion;//设备是否正在通信：1：在线，0：离线
    private String identity;
    private String install_flag;//是否安装 1 未安装，2 已安装
    private String simno;
    private String antenna_upversion;
    private String createtime;
    private String eqid;
    private String eqport;
    private String createuser;
    private String antenna_rssi2;
    private String antenna_rssi1;
    private String power_state;
    private String line_gateway;
    private String gprs_csq;
    private String eqname;
    private String eqversion;
    private String line_local_ip;
    private String add_admin_type;
    private String eqip;
    private String line_local_port;
    private String line_mac_address;

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getIpaddr2() {
        return ipaddr2;
    }

    public void setIpaddr2(String ipaddr2) {
        this.ipaddr2 = ipaddr2;
    }

    public String getIpaddr1() {
        return ipaddr1;
    }

    public void setIpaddr1(String ipaddr1) {
        this.ipaddr1 = ipaddr1;
    }

    public String getPort1() {
        return port1;
    }

    public void setPort1(String port1) {
        this.port1 = port1;
    }

    public String getPort2() {
        return port2;
    }

    public void setPort2(String port2) {
        this.port2 = port2;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getHearttime() {
        return hearttime;
    }

    public void setHearttime(String hearttime) {
        this.hearttime = hearttime;
    }

    public String getAntenna_rssi4() {
        return antenna_rssi4;
    }

    public void setAntenna_rssi4(String antenna_rssi4) {
        this.antenna_rssi4 = antenna_rssi4;
    }

    public String getAntenna_rssi3() {
        return antenna_rssi3;
    }

    public void setAntenna_rssi3(String antenna_rssi3) {
        this.antenna_rssi3 = antenna_rssi3;
    }

    public String getLine_local_port2() {
        return line_local_port2;
    }

    public void setLine_local_port2(String line_local_port2) {
        this.line_local_port2 = line_local_port2;
    }

    public String getSysAreaName() {
        return sysAreaName;
    }

    public void setSysAreaName(String sysAreaName) {
        this.sysAreaName = sysAreaName;
    }

    public String getEqaddr() {
        return eqaddr;
    }

    public void setEqaddr(String eqaddr) {
        this.eqaddr = eqaddr;
    }

    public String getEqisconn() {
        return eqisconn;
    }

    public void setEqisconn(String eqisconn) {
        this.eqisconn = eqisconn;
    }

    public String getAntenna_gain1() {
        return antenna_gain1;
    }

    public void setAntenna_gain1(String antenna_gain1) {
        this.antenna_gain1 = antenna_gain1;
    }

    public String getAntenna_gain2() {
        return antenna_gain2;
    }

    public void setAntenna_gain2(String antenna_gain2) {
        this.antenna_gain2 = antenna_gain2;
    }

    public String getFactoryno() {
        return factoryno;
    }

    public void setFactoryno(String factoryno) {
        this.factoryno = factoryno;
    }

    public String getAntenna_gain3() {
        return antenna_gain3;
    }

    public void setAntenna_gain3(String antenna_gain3) {
        this.antenna_gain3 = antenna_gain3;
    }

    public String getResetUpflag() {
        return resetUpflag;
    }

    public void setResetUpflag(String resetUpflag) {
        this.resetUpflag = resetUpflag;
    }

    public String getAntenna_gain4() {
        return antenna_gain4;
    }

    public void setAntenna_gain4(String antenna_gain4) {
        this.antenna_gain4 = antenna_gain4;
    }

    public String getLine_subnet_mask() {
        return line_subnet_mask;
    }

    public void setLine_subnet_mask(String line_subnet_mask) {
        this.line_subnet_mask = line_subnet_mask;
    }

    public String getOrgid() {
        return orgid;
    }

    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    public String getEqlat() {
        return eqlat;
    }

    public void setEqlat(String eqlat) {
        this.eqlat = eqlat;
    }

    public String getAntenna_version() {
        return antenna_version;
    }

    public void setAntenna_version(String antenna_version) {
        this.antenna_version = antenna_version;
    }

    public String getEqlng() {
        return eqlng;
    }

    public void setEqlng(String eqlng) {
        this.eqlng = eqlng;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEqno() {
        return eqno;
    }

    public void setEqno(String eqno) {
        this.eqno = eqno;
    }

    public String getLine_local_ip2() {
        return line_local_ip2;
    }

    public void setLine_local_ip2(String line_local_ip2) {
        this.line_local_ip2 = line_local_ip2;
    }

    public String getBattery_voltage() {
        return battery_voltage;
    }

    public void setBattery_voltage(String battery_voltage) {
        this.battery_voltage = battery_voltage;
    }

    public String getEq_status() {
        return eq_status;
    }

    public void setEq_status(String eq_status) {
        this.eq_status = eq_status;
    }

    public String getLibrepeat() {
        return librepeat;
    }

    public void setLibrepeat(String librepeat) {
        this.librepeat = librepeat;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDevversion() {
        return devversion;
    }

    public void setDevversion(String devversion) {
        this.devversion = devversion;
    }

    public String getAntenna_buzzer() {
        return antenna_buzzer;
    }

    public void setAntenna_buzzer(String antenna_buzzer) {
        this.antenna_buzzer = antenna_buzzer;
    }

    public String getImeino() {
        return imeino;
    }

    public void setImeino(String imeino) {
        this.imeino = imeino;
    }

    public String getUpFlag() {
        return upFlag;
    }

    public void setUpFlag(String upFlag) {
        this.upFlag = upFlag;
    }

    public String getEqupversion() {
        return equpversion;
    }

    public void setEqupversion(String equpversion) {
        this.equpversion = equpversion;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getInstall_flag() {
        return install_flag;
    }

    public void setInstall_flag(String install_flag) {
        this.install_flag = install_flag;
    }

    public String getSimno() {
        return simno;
    }

    public void setSimno(String simno) {
        this.simno = simno;
    }

    public String getAntenna_upversion() {
        return antenna_upversion;
    }

    public void setAntenna_upversion(String antenna_upversion) {
        this.antenna_upversion = antenna_upversion;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getEqid() {
        return eqid;
    }

    public void setEqid(String eqid) {
        this.eqid = eqid;
    }

    public String getEqport() {
        return eqport;
    }

    public void setEqport(String eqport) {
        this.eqport = eqport;
    }

    public String getCreateuser() {
        return createuser;
    }

    public void setCreateuser(String createuser) {
        this.createuser = createuser;
    }

    public String getAntenna_rssi2() {
        return antenna_rssi2;
    }

    public void setAntenna_rssi2(String antenna_rssi2) {
        this.antenna_rssi2 = antenna_rssi2;
    }

    public String getAntenna_rssi1() {
        return antenna_rssi1;
    }

    public void setAntenna_rssi1(String antenna_rssi1) {
        this.antenna_rssi1 = antenna_rssi1;
    }

    public String getPower_state() {
        return power_state;
    }

    public void setPower_state(String power_state) {
        this.power_state = power_state;
    }

    public String getLine_gateway() {
        return line_gateway;
    }

    public void setLine_gateway(String line_gateway) {
        this.line_gateway = line_gateway;
    }

    public String getGprs_csq() {
        return gprs_csq;
    }

    public void setGprs_csq(String gprs_csq) {
        this.gprs_csq = gprs_csq;
    }

    public String getEqname() {
        return eqname;
    }

    public void setEqname(String eqname) {
        this.eqname = eqname;
    }

    public String getEqversion() {
        return eqversion;
    }

    public void setEqversion(String eqversion) {
        this.eqversion = eqversion;
    }

    public String getLine_local_ip() {
        return line_local_ip;
    }

    public void setLine_local_ip(String line_local_ip) {
        this.line_local_ip = line_local_ip;
    }

    public String getAdd_admin_type() {
        return add_admin_type;
    }

    public void setAdd_admin_type(String add_admin_type) {
        this.add_admin_type = add_admin_type;
    }

    public String getEqip() {
        return eqip;
    }

    public void setEqip(String eqip) {
        this.eqip = eqip;
    }

    public String getLine_local_port() {
        return line_local_port;
    }

    public void setLine_local_port(String line_local_port) {
        this.line_local_port = line_local_port;
    }

    public String getLine_mac_address() {
        return line_mac_address;
    }

    public void setLine_mac_address(String line_mac_address) {
        this.line_mac_address = line_mac_address;
    }


    //    /**
//     * address : arrcccd
//     * createtime : 2018-05-22 13:52:07
//     * creator : null
//     * dentityid : code
//     * id : 42b0a5cd5d8411e8b036005056a645a8
//     * isinstall : 0
//     * lat : 11.1113333
//     * lng : 22.21333
//     * modifier : null
//     * modifytime : null
//     * orgid : 448c07743d8311e8b77300ff02317479
//     * remark : null
//     */
//
//    private String address;         //地址
//    private String createtime;      //创建时间
//    private String creator;         //创建人
//    private String dentityid;       //110快速识别编码
//    private String id;              //表id
//    private String isinstall;       //是否安装 0：未安装，1已安装
//    private String lat;             //经度
//    private String lng;             //纬度
//    private String modifier;        //修改人
//    private String modifytime;      //修改时间
//    private String orgid;           //组织机构id
//    private String remark;          //备注
//    private String isconn ;//0代表不在线，1代表在线
//
//    public String getIsconn() {
//        return isconn;
//    }
//
//    public void setIsconn(String isconn) {
//        this.isconn = isconn;
//    }
//
//    public String getAddress() {
//        return address;
//    }
//
//    public void setAddress(String address) {
//        this.address = address;
//    }
//
//    public String getCreatetime() {
//        return createtime;
//    }
//
//    public void setCreatetime(String createtime) {
//        this.createtime = createtime;
//    }
//
//    public String getDentityid() {
//        return dentityid;
//    }
//
//    public void setDentityid(String dentityid) {
//        this.dentityid = dentityid;
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public String getIsinstall() {
//        return isinstall;
//    }
//
//    public void setIsinstall(String isinstall) {
//        this.isinstall = isinstall;
//    }
//
//    public String getLat() {
//        return lat;
//    }
//
//    public void setLat(String lat) {
//        this.lat = lat;
//    }
//
//    public String getLng() {
//        return lng;
//    }
//
//    public void setLng(String lng) {
//        this.lng = lng;
//    }
//
//    public String getOrgid() {
//        return orgid;
//    }
//
//    public void setOrgid(String orgid) {
//        this.orgid = orgid;
//    }
//
//    public String getCreator() {
//        return creator;
//    }
//
//    public void setCreator(String creator) {
//        this.creator = creator;
//    }
//
//    public String getModifier() {
//        return modifier;
//    }
//
//    public void setModifier(String modifier) {
//        this.modifier = modifier;
//    }
//
//    public String getModifytime() {
//        return modifytime;
//    }
//
//    public void setModifytime(String modifytime) {
//        this.modifytime = modifytime;
//    }
//
//    public String getRemark() {
//        return remark;
//    }
//
//    public void setRemark(String remark) {
//        this.remark = remark;
//    }

}
