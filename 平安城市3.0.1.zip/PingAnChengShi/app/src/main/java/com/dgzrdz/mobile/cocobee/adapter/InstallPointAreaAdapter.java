package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.GetUserOrg;

import java.util.List;

/**
 * Created by Administrator on 2018/6/21.
 * 安装点adapter
 */

public class InstallPointAreaAdapter extends QuickRcvAdapter<GetUserOrg> {


    public InstallPointAreaAdapter(Context context, List<GetUserOrg> data, int... layoutId) {
        super(context, data, R.layout.item_install_point);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int position, GetUserOrg getUserOrg) {
        quickRcvHolder.setText(R.id.tv_area_name, getUserOrg.getSysAreaName());
    }
}
