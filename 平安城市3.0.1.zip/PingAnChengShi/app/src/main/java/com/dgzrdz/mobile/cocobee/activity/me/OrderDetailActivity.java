package com.dgzrdz.mobile.cocobee.activity.me;

import android.os.Bundle;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.me.OrderDetailFragment;
import com.dgzrdz.mobile.cocobee.fragment.me.OrderDetailUnPayFragment;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/28
 * Time:  15:14
 */

public class OrderDetailActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            OrderStatusResponse orderStatusResponse = (OrderStatusResponse) getIntent().getSerializableExtra("orderStatusResponse");
            if (CheckUtils.equalsString(orderStatusResponse.getMemberOrderProcess(), "1")) {
                loadRootFragment(R.id.fl_container, OrderDetailUnPayFragment.getInstance(orderStatusResponse));
            } else {
                loadRootFragment(R.id.fl_container, OrderDetailFragment.getInstance(orderStatusResponse));
            }
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}