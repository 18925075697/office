package com.dgzrdz.mobile.cocobee.activity.data;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.databank.BindingCarFragment;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/4/25
 * Time:  10:45
 */

public class BindingCarActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
          if (savedInstanceState == null) {
              UserBeanResponse userBean = (UserBeanResponse) getIntent().getSerializableExtra("userBean");
              loadRootFragment(R.id.fl_container, BindingCarFragment.getInstance(userBean));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}
