package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.AlarmInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import butterknife.BindView;

/**
 * Created by Administrator on 2018/6/14.
 */

public class AlarmInfoDetailFragment extends BaseFragment {

    private static AlarmInfoResponse alarmInfoResponse;
    @BindView(R.id.tv_alarm_name)
    TextView mTvAlarmName;
    @BindView(R.id.tv_alarm_idcard)
    TextView mTvAlarmIdcard;
    @BindView(R.id.tv_alarm_car_num)
    TextView mTvAlarmCarNum;
    @BindView(R.id.tv_alarn_car_type)
    TextView mTvAlarnCarType;
    @BindView(R.id.tv_alarm_phone)
    TextView mTvAlarmPhone;
    @BindView(R.id.tv_alarm_address)
    TextView mTvAlarmAddress;
    @BindView(R.id.tv_alarm_desc)
    TextView mTvAlarmDesc;
    @BindView(R.id.tv_alarm_time)
    TextView mTvAlarmTime;
    @BindView(R.id.alarm_status)
    TextView mAlarmStatus;

    public static AlarmInfoDetailFragment getInstance(AlarmInfoResponse alarmInfoResponse) {
        AlarmInfoDetailFragment.alarmInfoResponse = alarmInfoResponse;
        AlarmInfoDetailFragment fragment = new AlarmInfoDetailFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setView();
    }

    private void setView() {
        mTvAlarmName.setText(alarmInfoResponse.getName());
        mTvAlarmIdcard.setText(alarmInfoResponse.getIdcard());
        mTvAlarmCarNum.setText(alarmInfoResponse.getCno());
        mTvAlarnCarType.setText(alarmInfoResponse.getBuyType());
        mTvAlarmPhone.setText(alarmInfoResponse.getMobile());
        mTvAlarmAddress.setText(alarmInfoResponse.getAddress());
        mTvAlarmDesc.setText(alarmInfoResponse.getDesc());
        mTvAlarmTime.setText(alarmInfoResponse.getTime());
        mAlarmStatus.setText(Utils.getAlarmStatus(alarmInfoResponse.getStatus()));
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("报警详情");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_alarm_info_detail;
    }
}
