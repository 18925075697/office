package com.dgzrdz.mobile.cocobee.common;

public class EventConstants {

    /**
     * 组织机构上传成功
     */
    public static final int ORGENIZE_SELECT_SUCCESS = 55000 * 1;

    /**
     * 集团标签绑定/购买服务 车辆选择成功
     */
    public static final int CAR_SELECT_SUCCESS = 55000 * 2;

    /**
     * 未完成支付3s后返回首页
     */
    public static final int UNFINISH_PAY_BACK_HOME = 55000 * 3;

    /**
     * 支付完成页回首页
     */
    public static final int PAY_FINISH_BACK_HOME = 55000 * 4;

    /**
     * 预登记完成
     */
    public static final int PRE_REGIST_SUCCESS = 55000 * 5;

    /**
     * 预登记车主录入成功
     */
    public static final int PRE_REGIST_CAR_OWNER_UP_SUCCESS = 55000 * 6;

    /**
     * 修改车主组织机构选择成功
     */
    public static final int ORGENIZE_SELECT_CAR_OWNER_SUCCESS = 55000 * 7;

    /**
     * 车主信息修改成功
     */
    public static final int UPDATE_CAR_OWNER_INFO_SUCCESS = 55000 * 8;

    /**
     * 车辆信息修改成功
     */
    public static final int UPDATE_CAR_INFO_SUCCESS = 55000 * 9;

    /**
     * 注册成功
     */
    public final static int REGISTER_SUCCESS = 55000 * 10;

    /**
     * 忘记密码成功
     */
    public final static int FORGETPWD_SUCCESS = 55000 * 11;

    /**
     * 微信支付成功
     */
    public static final int WX_PAY_SUCCESS = 55000 * 12;

    /**
     * 微信支付取消
     */
    public static final int WX_PAY_CANCEL = 55000 * 13;

    /**
     * 车辆信息删除成功
     */
    public static final int DELETE_CAR_INFO_SUCCESS = 55000 * 14;

    /**
     * 当前组织机构没有子组织机构
     */
    public static final int CURRENT_ORG_HAS_NO_CHILD = 55000 * 15;

    /**
     * 车辆删除成功
     */
    public static final int CARINFO_DELETE_SUCCESS = 55000 * 16;

    /**
     * 车辆绑定成功
     */
    public static final int CAR_BIND_SUCCESS = 55000 * 17;

    /**
     * 更新便民服务点
     */
    public static final int NEED_REFRESH_CONVENIENCE_LIST = 55000 * 18;

    /**
     * 选择车辆品牌成功
     */
    public static final int SELECT_CAR_BRAND_SUCCESS = 55000 * 21;

    /**
     * 信息录入完成,缺少图片直接进入上传完成
     */
    public static final int INPUT_INFO_PIC_SUCCESS = 55000 * 23;

    /**
     * 车辆信息录入成功,保存并使用
     */
    public static final int CAR_INFO_INPUT_SUCCESS = 55000 * 24;

    /**
     * 订单取消成功
     */
    public static final int ORDER_CANCEL_SUCCESS = 55000 * 25;

    /**
     * OCR扫描成功
     */
    public static final int OCR_SCAN_SUCCESS = 55000 * 26;

    /**
     * 确认使用免密口令
     */
    public static final int SURE_USE_FREE_PWD = 55000 * 27;

    /**
     * 导航地图选择弹框消失
     */
    public static final int MAP_SELECT_DIALOG_DISMISS = 55000 * 28;

    /**
     * 需要更新点位数据
     */
    public static final int NEED_REFRESH_POINTLIST = 55000 * 29;

    /**
     * 设备上报成功
     */
    public static final int DEVICE_UPLOAD_SUCCESS = 55000 * 30;

    /**
     * 服务选择成功
     */
    public static final int SERVICE_SELECT_SUCCESS = 55000 * 31;

    /**
     * 保险选择成功
     */
    public static final int POLICY_SELECT_SUCCESS = 55000 * 32;

    /**
     * 标签信息修改成功
     */
    public static final int UPDATE_TAG_INFO_SUCCESS = 55000 * 33;

    /**
     * 手机号码修改成功
     */
    public static final int PHONE_CHANGE_SUCCESS = 55000 * 34;

    /**
     * 倒计时时间到,取消订单
     */
    public static final int TIME_COUNT_DOWN_CANCEL_ORDER = 55000 * 35;

    /**
     * 待付款页面定时器自动取消订单成功
     */
    public static final int ORDER_CANCEL_AUTO_SUCCESS = 55000 * 36;

    /**
     * 全部页面定时器自动取消成功
     */
    public static final int TOTAL_ORDER_CANCEL_AUTO_SUCCESS = 55000 * 37;

    /**
     * 详情页取消订单
     */
    public static final int DETAIL_ORDER_CANCEL_AUTO_SUCCESS = 55000 * 38;

    /**
     * 支付成功
     */
    public static final int PAY_SUCCESS = 55000 * 39;

    /**
     *  退出西安支付页面
     */
    public static final int OUT_XIAN_PAY_ACTIVITY = 55000 * 40;

    /**
     * 订单生成成功
     */
    public static final int ORDER_CREATER_SUCCESS = 55000 * 41;

    /**
     * 蓝牙连接成功
     */
    public static final int BLE_CONNECT_SUCCESS = 55000 * 42;

    /**
     * 品牌选择成功
     */
    public static final int BRAND_SELECT_SUCCESS = 55000 * 43;

}
