package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/4/17.
 */

public class GetUserOrg implements Serializable {

    /**
     * sysAreaCarNumEnabled : 2
     * sysAreaCarNumPrefix :
     * sysAreaSort : 0
     * sysAreaCode : 00010002
     * sysAreaPId : 1
     * sysCityId : 43
     * sysAreaStatus : 1
     * sysAreaId : 2
     * sysAreaName : 湖南省
     * sysAreaCarNumApplyFlag : 1
     */

    private String sysAreaCarNumEnabled;
    private String sysAreaCarNumPrefix;
    private String sysAreaSort;
    private String sysAreaCode;
    private String sysAreaPId;
    private String sysCityId;
    private String sysAreaStatus;
    private String sysAreaId;
    private String sysAreaName;
    private String sysAreaCarNumApplyFlag;
    private String selectPosition;

    public String getSelectPosition() {
        return selectPosition;
    }

    public void setSelectPosition(String selectPosition) {
        this.selectPosition = selectPosition;
    }

    public String getSysAreaCarNumEnabled() {
        return sysAreaCarNumEnabled;
    }

    public void setSysAreaCarNumEnabled(String sysAreaCarNumEnabled) {
        this.sysAreaCarNumEnabled = sysAreaCarNumEnabled;
    }

    public String getSysAreaCarNumPrefix() {
        return sysAreaCarNumPrefix;
    }

    public void setSysAreaCarNumPrefix(String sysAreaCarNumPrefix) {
        this.sysAreaCarNumPrefix = sysAreaCarNumPrefix;
    }

    public String getSysAreaSort() {
        return sysAreaSort;
    }

    public void setSysAreaSort(String sysAreaSort) {
        this.sysAreaSort = sysAreaSort;
    }

    public String getSysAreaCode() {
        return sysAreaCode;
    }

    public void setSysAreaCode(String sysAreaCode) {
        this.sysAreaCode = sysAreaCode;
    }

    public String getSysAreaPId() {
        return sysAreaPId;
    }

    public void setSysAreaPId(String sysAreaPId) {
        this.sysAreaPId = sysAreaPId;
    }

    public String getSysCityId() {
        return sysCityId;
    }

    public void setSysCityId(String sysCityId) {
        this.sysCityId = sysCityId;
    }

    public String getSysAreaStatus() {
        return sysAreaStatus;
    }

    public void setSysAreaStatus(String sysAreaStatus) {
        this.sysAreaStatus = sysAreaStatus;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getSysAreaName() {
        return sysAreaName;
    }

    public void setSysAreaName(String sysAreaName) {
        this.sysAreaName = sysAreaName;
    }

    public String getSysAreaCarNumApplyFlag() {
        return sysAreaCarNumApplyFlag;
    }

    public void setSysAreaCarNumApplyFlag(String sysAreaCarNumApplyFlag) {
        this.sysAreaCarNumApplyFlag = sysAreaCarNumApplyFlag;
    }
}
