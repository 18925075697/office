package com.dgzrdz.mobile.cocobee.fragment.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.pulltorefreshandloadmore.loadmoreview.DefaultLeLoadMoreView;
import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.loadmoreview.OnLoadMoreListener;
import com.bql.pulltorefreshandloadmore.ultraptr.PtrFrameLayout;
import com.bql.pulltorefreshandloadmore.ultraptr.indicator.PtrIndicator;
import com.cjj.MaterialRefreshLayout;
import com.cjj.MaterialRefreshListener;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.base.QuickRcvfeRreshAdapter;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.view.animator.NoAlphaItemAnimator;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;


/**
 * ClassName: RefreshAndLoadFragment_new <br>
 * Description: 下拉刷新 加载更多的Fragment<br>
 * Author: Cyarie <br>
 * Created: 2016/7/18 15:46 <br>
 * Update Time：<br>
 * Update Description：<br>
 */
public abstract class RefreshAndLoadFragment_new<T extends Object> extends BaseFragment implements OnLoadMoreListener {

    //数据集合
    public List<T> mList = new ArrayList<>();

    @BindView(R.id.rcv_load_more)
    public LoadMoreRecyclerView mRcvLoadMore;

    //下拉刷新 上拉加载 风格
    @BindView(R.id.prt_layout)
    public MaterialRefreshLayout mPrtLayout;

    //当前页数
    public int mCurPage = 1;

    //每页大小
    public int pageSize = 20;


    @Override
    protected void initLazyViewsAndEvents(@Nullable Bundle savedInstanceState) {
        super.initLazyViewsAndEvents(savedInstanceState);
        initLazyViews(savedInstanceState);
        initView();

    }

    /**
     * 懒加载 如果继承该类 要实现懒加载效果 重写该方法进行初始化
     *
     * @param savedInstanceState
     */
    protected void initLazyViews(@Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onEnterAnimationEnd(Bundle savedInstanceState) {
        super.onEnterAnimationEnd(savedInstanceState);
        if (!lazyLoadMode()) {
            initView();
        }
    }


    /**
     * 初始化View
     */
    private void initView() {
        if (getLayoutManager() == null) {
            throw new NullPointerException("The getLayoutManager() method must not be null");
        }
        mRcvLoadMore.setLayoutManager(getLayoutManager());
        if (getAdapter() == null) {
            throw new NullPointerException("The getAdapter() method must not be null");
        }
        // 设置自定义的animator，解决闪烁问题
        mRcvLoadMore.setItemAnimator(new NoAlphaItemAnimator());

        mRcvLoadMore.setAdapter(getAdapter());

        // 设置headerView
        if (isAddHeaderView()) {
            mRcvLoadMore.addHeaderView(getHeaderView());
        }

        if (getItemDecoration() != null)
            mRcvLoadMore.addItemDecoration(getItemDecoration());
        mRcvLoadMore.setOnLoadMoreListener(this);
        mRcvLoadMore.setHideLoadingView(hideLoadMoreView());
        if (mPrtLayout != null) {
            mPrtLayout.setIsOverLay(true);
            mPrtLayout.setWaveShow(false);
            mPrtLayout.setCanRefresh(canRefresh());
            mPrtLayout.setMaterialRefreshListener(new MaterialRefreshListener() {
                @Override
                public void onRefresh(final MaterialRefreshLayout materialRefreshLayout) {
                    //refreshing...
                    RefreshAndLoadFragment_new.this.onRefresh();
                }

                @Override
                public void onRefreshLoadMore(MaterialRefreshLayout materialRefreshLayout) {
                    //load more refreshing...
                    mPrtLayout.finishRefreshLoadMore();
                }


            });


        }
        mRcvLoadMore.setOnItemClickListener((holder, position) -> onRcvItemClick(holder, position));
        loadDataList(1, false);
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_ptr_load_new;
    }


    public abstract void onRcvItemClick(RecyclerView.ViewHolder holder, int position);

    /**
     * 适配器 继承自{@link QuickRcvAdapter}
     *
     * @return
     */
    public abstract QuickRcvfeRreshAdapter<T> getAdapter();

    /**
     * 添加分割线 {@link RecyclerView.ItemDecoration}
     *
     * @return
     */
    public abstract RecyclerView.ItemDecoration getItemDecoration();

    /**
     * 布局管理器 {@link RecyclerView.LayoutManager}
     *
     * @return
     */
    public abstract RecyclerView.LayoutManager getLayoutManager();


    @Override
    public void onDestroyView() {
        if (mRcvLoadMore != null && mRcvLoadMore.getLoadMoreView() instanceof DefaultLeLoadMoreView) {
            ((DefaultLeLoadMoreView) mRcvLoadMore.getLoadMoreView()).stop();
            mRcvLoadMore = null;
        }
        super.onDestroyView();
    }


    /**
     * 是否需要添加HeaderView
     *
     * @return
     */
    protected boolean isAddHeaderView() {
        return false;
    }

    /**
     * 获取HeaderView控件
     *
     * @return
     */
    protected View getHeaderView() {
        return null;
    }

    /**
     * 刷新数据
     */
    public abstract void onRefresh();

    /**
     * 滑动监听
     */
    public void onUIScrollChange(PtrFrameLayout frame, boolean isUnderTouch, byte status, PtrIndicator ptrIndicator) {

    }


    /**
     * 是否可以下拉刷新 默认 true
     */
    public boolean canRefresh() {
        return true;
    }


    /**
     * 加载数据列表
     *
     * @param curPage         当前页
     * @param isPullToRefresh 是否下拉刷新
     */
    public abstract void loadDataList(int curPage, boolean isPullToRefresh);


    public int getCurPage() {
        return mCurPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setCurPage(int curPage) {
        mCurPage = curPage;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * 结束刷新和加载
     */
    public void completeRefreshAndLoad() {
        if (mPrtLayout != null) {
            mPrtLayout.finishRefresh();
        }

        if (mRcvLoadMore != null) {
            mRcvLoadMore.onLoadMoreComplete();
        }

    }

    /**
     * 处理刷新加载得到的数据
     *
     * @param curPage             当前页
     * @param loadingViewCallback 加载视图
     * @param list                数据集合
     */
    public void handleRefreshListData(int curPage, LoadingViewCallback loadingViewCallback, List<T> list) {
        mCurPage = curPage;
        if (list.size() == 0 && mCurPage == 1) {
            loadingViewCallback.showEmpty();
        } else {
            if (mCurPage == 1) {
                getAdapter().clear();
            }
            mCurPage = mCurPage + 1;
            getAdapter().addToLast(list);
            if (mRcvLoadMore != null) {
                mRcvLoadMore.setCanLoadMore(false);
            }
        }
    }


    /**
     * 处理刷新加载得到的数据
     *
     * @param curPage             当前页
     * @param loadingViewCallback 加载视图
     * @param list                数据集合
     */
    public void handleRefreshAndLoadListData(int curPage, LoadingViewCallback loadingViewCallback, List<T> list) {
        mCurPage = curPage;
        if (list == null || (list.size() == 0 && mCurPage == 1)) {
            loadingViewCallback.showEmpty();
        } else {
            if (mCurPage == 1) {
                getAdapter().clear();
            }
            mCurPage = mCurPage + 1;
            getAdapter().addToLast(list);
            if (mRcvLoadMore != null) {
                if (list.size() < pageSize || list.size() == 0) {
                    mRcvLoadMore.setCanLoadMore(false);
                } else {
                    mRcvLoadMore.setCanLoadMore(true);
                }
            }
        }
    }


    /**
     * 刷新加载回调
     *
     * @param <T>
     */
    public abstract class RefreshAndLoadCallback<T> extends LoadingViewCallback<T> {

        public RefreshAndLoadCallback(boolean isPullToRefresh) {
            super(_mActivity, getView(), isPullToRefresh);
        }


        @Override
        public void onAfter(T t, Exception e) {
            super.onAfter(t, e);
            if (isPullToRefresh)
                completeRefreshAndLoad();
        }
    }

    public boolean hideLoadMoreView() {
        return true;
    }
}
