package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2019/3/15
 * Time:  11:38
 */

public class CarInfoResponse implements Serializable{


    /**
     * param : {"memberSix":"1","memberName":"鞍朱山明","memberServiceObjNumber":"东莞市M15700001","memberAccount":"15915705085"}
     * pics : ["http://electrocar.oss-cn-hangzhou.aliyuncs.com/20190311100532.jpg?x-oss-process=image/resize,w_896,h_569","http://electrocar.oss-cn-hangzhou.aliyuncs.com/20190311100536.jpg?x-oss-process=image/resize,w_896,h_569","http://electrocar.oss-cn-hangzhou.aliyuncs.com/20190311100555.jpg?x-oss-process=image/resize,w_896,h_569"]
     */

    private ParamBean param;
    private List<String> pics;

    public ParamBean getParam() {
        return param;
    }

    public void setParam(ParamBean param) {
        this.param = param;
    }

    public List<String> getPics() {
        return pics;
    }

    public void setPics(List<String> pics) {
        this.pics = pics;
    }

    public static class ParamBean implements Serializable{
        /**
         * memberSix : 1
         * memberName : 鞍朱山明
         * memberServiceObjNumber : 东莞市M15700001
         * memberAccount : 15915705085
         */

        private String memberSix;
        private String memberName;
        private String memberServiceObjNumber;
        private String memberAccount;

        public String getMemberSix() {
            return memberSix;
        }

        public void setMemberSix(String memberSix) {
            this.memberSix = memberSix;
        }

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getMemberServiceObjNumber() {
            return memberServiceObjNumber;
        }

        public void setMemberServiceObjNumber(String memberServiceObjNumber) {
            this.memberServiceObjNumber = memberServiceObjNumber;
        }

        public String getMemberAccount() {
            return memberAccount;
        }

        public void setMemberAccount(String memberAccount) {
            this.memberAccount = memberAccount;
        }
    }
}
