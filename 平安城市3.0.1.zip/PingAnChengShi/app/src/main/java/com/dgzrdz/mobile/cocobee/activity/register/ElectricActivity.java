package com.dgzrdz.mobile.cocobee.activity.register;

import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.bql.convenientlog.CLog;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;

import butterknife.BindView;

/**
 * 电子保单页面
 * Created by Administrator on 2018/5/18.
 */

public class ElectricActivity extends BaseToolbarActivity {
    @BindView(R.id.webview)
    WebView mWebview;
    @BindView(R.id.webview_progressbar)
    ProgressBar mWebviewProgressbar;
    private String mUrl;
    private WebSettings mSettings;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_xi_an_web;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("电子凭证");
        String url = getIntent().getStringExtra("url");
        if (!CheckUtils.isEmpty(url)) {
            mUrl = url.replaceAll("\\\\", "");
        }
        initWebView();
    }

    private void initWebView() {
        mSettings = mWebview.getSettings();
        mSettings.setDomStorageEnabled(true);//设置适应html5
        mSettings.setJavaScriptEnabled(true);
        /**
         *   android webview 从Lollipop(5.0)开始webview默认不允许混合模式，https当中不能加载http资源，需要设置开启。以下三行代码设置开启.
         */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        mSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        mSettings.setAppCacheEnabled(false);

        WebViewClient client = new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return true;
            }

            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // handler.cancel(); // Android默认的处理方式
                handler.proceed(); // 接受所有网站的证书
                // handleMessage(Message msg); // 进行其他处理
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mWebviewProgressbar.setVisibility(View.VISIBLE);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mWebviewProgressbar.setVisibility(View.GONE);
                super.onPageFinished(view, url);
                CLog.e("LogInterceptor", "#############网页加载完了" + url);
            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                CLog.e("LogInterceptor", "#############网页加载失败" + request.getUrl().getPath());
            }
        };

        mWebview.setWebViewClient(client);
        mWebview.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
                super.onGeolocationPermissionsShowPrompt(origin, callback);
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mWebviewProgressbar.setProgress(newProgress);
                super.onProgressChanged(view, newProgress);
            }
        });

        mWebview.loadUrl(mUrl);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mSettings.setJavaScriptEnabled(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mSettings.setJavaScriptEnabled(false);
    }

    @Override
    protected void onDestroy() {
        mWebview.clearHistory();
        mWebview.destroy();
        super.onDestroy();
    }

    @Override
    public void leftContainerClick() {
        if (mWebview.canGoBack()) {
            mWebview.goBack();
        } else {
            finish();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //其中webView.canGoBack()在webView含有一个可后退的浏览记录时返回true
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebview.canGoBack()) {
            mWebview.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
