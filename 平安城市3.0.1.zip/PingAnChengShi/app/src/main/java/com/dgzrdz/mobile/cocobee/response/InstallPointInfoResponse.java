package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2018/8/3.
 */

public class InstallPointInfoResponse implements Serializable{

    /**
     * Installer : [{"id":null,"mobile":null,"name":null}]
     * orgId : 021d1abe85b711e8b662525400a4ed52
     * orgName : 均楚派出所值班室
     */

    private String orgId;
    private String orgName;
    private List<InstallerBean> Installer;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public List<InstallerBean> getInstaller() {
        return Installer;
    }

    public void setInstaller(List<InstallerBean> Installer) {
        this.Installer = Installer;
    }

    public static class InstallerBean {
        /**
         * id : null
         * mobile : null
         * name : null
         */

        private String id;
        private String mobile;
        private String name;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
