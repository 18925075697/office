package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/6/27
 * Time:  17:26
 */

public class ObjectValueResponse implements Serializable {

    /**
     * sysPropertyInputTypeName : 下拉框选择输入
     * sysPropertyOptionList : [{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"5","sysPropertyOptionValue":"宝马","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"b"},{"sysPropertyOptionTop":"0","sysPropertyId":"1","sysPropertyOptionId":"6","sysPropertyOptionValue":"玛莎拉蒂","sysPropertyOptionEnabled":"1","sysPropertyOptionStatus":"1","sysPropertyOptionChar":"m"}]
     * sysPropertyId : 1
     * sysPropertyShowStyle : 2
     * sysPropertyInputType : 5
     * sysPropertyRequired : 1
     * sysPropertyName : 车辆品牌
     */

    private String sysPropertyInputTypeName;
    private String sysPropertyId;
    private String sysPropertyShowStyle;
    private int sysPropertyInputType;
    private String sysPropertyRequired;
    private String sysPropertyName;
    private String sysPropertySort;
    private String sysOptionId;//下拉字段id
    private String sysPropertyOptionId;//属性值(下拉选择对应的id,输入框对应的值)
    private String localUrl;//本地图片选择地址
    private String sysPropertyValue;
    private List<SysPropertyOptionListBean> sysPropertyOptionList;

    public String getSysPropertyValue() {
        return sysPropertyValue;
    }

    public void setSysPropertyValue(String sysPropertyValue) {
        this.sysPropertyValue = sysPropertyValue;
    }

    public String getSysOptionId() {
        return sysOptionId;
    }

    public void setSysOptionId(String sysOptionId) {
        this.sysOptionId = sysOptionId;
    }

    public String getSysPropertySort() {
        return sysPropertySort;
    }

    public void setSysPropertySort(String sysPropertySort) {
        this.sysPropertySort = sysPropertySort;
    }

    public String getLocalUrl() {
        return localUrl;
    }

    public void setLocalUrl(String localUrl) {
        this.localUrl = localUrl;
    }

    public String getSysPropertyOptionId() {
        return sysPropertyOptionId;
    }

    public void setSysPropertyOptionId(String sysPropertyOptionId) {
        this.sysPropertyOptionId = sysPropertyOptionId;
    }

    public String getSysPropertyInputTypeName() {
        return sysPropertyInputTypeName;
    }

    public void setSysPropertyInputTypeName(String sysPropertyInputTypeName) {
        this.sysPropertyInputTypeName = sysPropertyInputTypeName;
    }

    public String getSysPropertyId() {
        return sysPropertyId;
    }

    public void setSysPropertyId(String sysPropertyId) {
        this.sysPropertyId = sysPropertyId;
    }

    public String getSysPropertyShowStyle() {
        return sysPropertyShowStyle;
    }

    public void setSysPropertyShowStyle(String sysPropertyShowStyle) {
        this.sysPropertyShowStyle = sysPropertyShowStyle;
    }

    public int getSysPropertyInputType() {
        return sysPropertyInputType;
    }

    public void setSysPropertyInputType(int sysPropertyInputType) {
        this.sysPropertyInputType = sysPropertyInputType;
    }

    public String getSysPropertyRequired() {
        return sysPropertyRequired;
    }

    public void setSysPropertyRequired(String sysPropertyRequired) {
        this.sysPropertyRequired = sysPropertyRequired;
    }

    public String getSysPropertyName() {
        return sysPropertyName;
    }

    public void setSysPropertyName(String sysPropertyName) {
        this.sysPropertyName = sysPropertyName;
    }

    public List<SysPropertyOptionListBean> getSysPropertyOptionList() {
        return sysPropertyOptionList;
    }

    public void setSysPropertyOptionList(List<SysPropertyOptionListBean> sysPropertyOptionList) {
        this.sysPropertyOptionList = sysPropertyOptionList;
    }

//    public static class SysPropertyOptionListBean implements Serializable{
//        /**
//         * sysPropertyOptionTop : 0
//         * sysPropertyId : 1
//         * sysPropertyOptionId : 5
//         * sysPropertyOptionValue : 宝马
//         * sysPropertyOptionEnabled : 1
//         * sysPropertyOptionStatus : 1
//         * sysPropertyOptionChar : b
//         */
//
//        private String sysPropertyOptionTop;
//        private String sysPropertyId;
//        private int sysPropertyOptionId;
//        private String sysPropertyOptionValue;
//        private String sysPropertyOptionEnabled;
//        private String sysPropertyOptionStatus;
//        private String sysPropertyOptionChar;
//
//        public String getSysPropertyOptionTop() {
//            return sysPropertyOptionTop;
//        }
//
//        public void setSysPropertyOptionTop(String sysPropertyOptionTop) {
//            this.sysPropertyOptionTop = sysPropertyOptionTop;
//        }
//
//        public String getSysPropertyId() {
//            return sysPropertyId;
//        }
//
//        public void setSysPropertyId(String sysPropertyId) {
//            this.sysPropertyId = sysPropertyId;
//        }
//
//        public int getSysPropertyOptionId() {
//            return sysPropertyOptionId;
//        }
//
//        public void setSysPropertyOptionId(int sysPropertyOptionId) {
//            this.sysPropertyOptionId = sysPropertyOptionId;
//        }
//
//        public String getSysPropertyOptionValue() {
//            return sysPropertyOptionValue;
//        }
//
//        public void setSysPropertyOptionValue(String sysPropertyOptionValue) {
//            this.sysPropertyOptionValue = sysPropertyOptionValue;
//        }
//
//        public String getSysPropertyOptionEnabled() {
//            return sysPropertyOptionEnabled;
//        }
//
//        public void setSysPropertyOptionEnabled(String sysPropertyOptionEnabled) {
//            this.sysPropertyOptionEnabled = sysPropertyOptionEnabled;
//        }
//
//        public String getSysPropertyOptionStatus() {
//            return sysPropertyOptionStatus;
//        }
//
//        public void setSysPropertyOptionStatus(String sysPropertyOptionStatus) {
//            this.sysPropertyOptionStatus = sysPropertyOptionStatus;
//        }
//
//        public String getSysPropertyOptionChar() {
//            return sysPropertyOptionChar;
//        }
//
//        public void setSysPropertyOptionChar(String sysPropertyOptionChar) {
//            this.sysPropertyOptionChar = sysPropertyOptionChar;
//        }
//    }
}
