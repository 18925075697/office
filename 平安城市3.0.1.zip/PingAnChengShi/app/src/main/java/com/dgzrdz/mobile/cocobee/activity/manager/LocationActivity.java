package com.dgzrdz.mobile.cocobee.activity.manager;


import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.CoordinateConverter;
import com.baoyz.actionsheet.ActionSheet;
import com.bql.utils.CheckUtils;
import com.bql.utils.ThreadPool;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.model.BaseStation;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.CustPopupwindow;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * 基站位置:
 * 1、进来先初始化地图，默认加载上一次的定位信息、没有定位信息默认加载一个坐标
 * 2、定位、把定位信息保存缓存
 * 3、定位完成之后、加载屏幕可视区域的基站信息（此时输入框的值为空）
 * 4、点击搜索、如果输入框的值为空，把屏幕可视区域的经纬度上传服务器查询基站信息
 * 5、点击搜索、瑞格输入框的值不为空、把输入框的值上传服务器查询基站信息、得到服务器的基站数据之后
 * 把地图上的基站点清空、并且把第一个基站设置到屏幕中心
 * 6、点击基站、显示基站明细、3秒后消失
 * 7、设置在线、离线、总数数据
 */
public class LocationActivity extends BaseActivity implements BaiduMap.OnMapLoadedCallback, CustPopupwindow.ViewInterface {

    @BindView(R.id.mapView)
    MapView mMapView;

    @BindView(R.id.inputEqunEdt)
    EditText inputEqunEdt;

    @BindView(R.id.allBaseSizeTxt)
    TextView allBaseSizeTxt;

    @BindView(R.id.onLineSizeTxt)
    TextView onLineSizeTxt;

    @BindView(R.id.offlineSizeTxt)
    TextView offlineSizeTxt;


    @BindView(R.id.back_ib)
    ImageButton back_ib;

    @BindView(R.id.searchBtn)
    Button searchBtn;

    @BindView(R.id.detailLayout)
    RelativeLayout detailLayout;

    @BindView(R.id.nameTxt)
    TextView nameTxt;


    @BindView(R.id.lngTxt)
    TextView lngTxt;

    @BindView(R.id.latTxt)
    TextView latTxt;

    @BindView(R.id.addressTxt)
    TextView addressTxt;

    @BindView(R.id.onLineTxt)
    TextView onLineTxt;


   private BaiduMap mBaiduMap;
   private MapStatus ms;


    private String firstLng1 = "";
    private String firstLat1 = "";
    private String firstLng2 = "";
    private String firstLat2 = "";
    int width = 0;
    int height = 0;


    public MyLocationListener1 myListener1 = new MyLocationListener1();
    //定位
    private LocationClient locationClient;
    private double mLongitude = 106.662893;
    private double mLatitude = 26.616185;
    boolean isFirstLoad = true;

    MarkerOptions markerOptions;
    //获取添加的 marker 这样便于后续的操作
    Marker marker;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_carlocation;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        //不能滑动返回
        setSwipeBackEnable(false);
        getCurrentLocation();
        initMap();
    }

    @Override
    protected boolean isStatusDarkMode() {
        return false;
    }

    private void getCurrentLocation() {
        /*使用百度SDK获取经纬度*/
        locationClient = new LocationClient(getApplicationContext());
        locationClient.registerLocationListener(myListener1);
        LocationClientOption option = new LocationClientOption();
        option.setIsNeedAddress(true);
        option.setOpenGps(true);        //是否打开GPS
        option.setCoorType("bd09ll");       //设置返回值的坐标类型。
        option.setPriority(LocationClientOption.NetWorkFirst);  //设置定位优先级
        option.setProdName("Cocobee"); //设置产品线名称。强烈建议您使用自定义的产品线名称，方便我们以后为您提供更高效准确的定位服务。
        option.setScanSpan(600000);  //设置定时定位的时间间隔为10分钟。单位毫秒
        locationClient.setLocOption(option);
        locationClient.start();
        /*
         *当所设的整数值大于等于1000（ms）时，定位SDK内部使用定时定位模式。
         *调用requestLocation( )后，每隔设定的时间，定位SDK就会进行一次定位。
         *如果定位SDK根据定位依据发现位置没有发生变化，就不会发起网络请求，
         *返回上一次定位的结果；如果发现位置改变，就进行网络请求进行定位，得到新的定位结果。
         *定时定位时，调用一次requestLocation，会定时监听到定位结果。
         */
        locationClient.requestLocation();
    }

    //初始化地图
    private void initMap() {
        //定义地图状态
        ms = new MapStatus.Builder().target(new LatLng(mLatitude, mLongitude)).zoom(17).build();
        mBaiduMap = mMapView.getMap();

        //禁止旋转
        UiSettings uiSettings = mBaiduMap.getUiSettings();
        uiSettings.setRotateGesturesEnabled(false);

        mBaiduMap.setOnMapLoadedCallback(this);
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));

    }

    //获取标注信息：这一步是在定位成功之后调用
    private void getMarkData(String type, String eqno) {
        WindowManager wm = this.getWindowManager();
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        width = outMetrics.widthPixels;
        height = outMetrics.heightPixels;


        Point pt = new Point();
        pt.x = 0;
        pt.y = 0;
        LatLng ll = mBaiduMap.getProjection().fromScreenLocation(pt);
        Point ptr = new Point();
        ptr.x = width;
        ptr.y = height;
        LatLng llr = mBaiduMap.getProjection().fromScreenLocation(ptr);

        loadBaseStation(ll.latitude, ll.longitude, llr.latitude, llr.longitude, type, eqno);
    }

    private void loadBaseStation(double lat1, double lng1, double lat2, double lng2, String type, String eqno) {
        CoordinateConverter converter = new CoordinateConverter();
        converter.from(CoordinateConverter.CoordType.GPS);
        // sourceLatLng待转换坐标
        String repeat = "", long1 = "", lati1 = "", long2 = "", lati2 = "", jzxlh = "";

        if ("1".equals(type)) {//输入框没值
            long1 = lng1 + "";
            lati1 = lat1 + "";
            long2 = lng2 + "";
            lati2 = lat2 + "";
            if (!"".equals(firstLng1) && null != firstLng1) {
                repeat = firstLng1 + "," + firstLat1 + "," + firstLng2 + "," + firstLat2;
                firstLng1 = lng1 + "";
                firstLat1 = lat1 + "";
                firstLng2 = lng2 + "";
                firstLat2 = lat2 + "";
            } else {
                repeat = "";
            }
        } else {
            repeat = "";
            long1 = "";
            lati1 = "";
            long2 = "";
            lati2 = "";
            jzxlh = eqno;
        }

        ManagerApiUtils.getStationLocation(this, repeat, long1, lati1, long2, lati2, jzxlh, new DialogCallback<BaseStation>(this, "正在获取基站信息....") {
            @Override
            public void onSuccess(BaseStation baseStation, Call call, Response response) {
                if (baseStation != null) {
                    List<BaseStation.ListBean> listBeans = baseStation.getList();
                    BaseStation.TotalBean total = baseStation.getTotal();
                    if (total != null) {
                        setTotalSize(total);
                    }
                    if (listBeans != null && listBeans.size() > 0) {
                        ThreadPool.runOnWorker(new Runnable() {
                            @Override
                            public void run() {
                                addBaseStationMarkers(listBeans, type);
                            }
                        });
                    } else {
                        XToastUtils.showShortToast("没有更多数据");
                    }
                } else {
                    XToastUtils.showShortToast("没有更多数据");
                }
            }
        });
    }

    /**
     * 添加markers
     */
    private void addBaseStationMarkers(List<BaseStation.ListBean> listBeans, String type) {
        double lat;
        double lng;
        BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromResource(R.drawable.location_marker_gray);
        BitmapDescriptor bitmap2 = BitmapDescriptorFactory.fromResource(R.drawable.location_marker_blue);
        //type：1   查询输入框内搜索到的基站
        // type：   其他 ：根据基站编号查询基站信息、需要清除界面上的基站信息
        if (!"1".equals(type)) {
            mBaiduMap.clear();
            if (listBeans.size() > 0) {
                lat = Double.parseDouble(listBeans.get(0).getEqlat());
                lng = Double.parseDouble(listBeans.get(0).getEqlng());
                LatLng latLng = new LatLng(lat, lng);
                ms = new MapStatus.Builder().target(latLng).zoom(17).build();
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));
            }

        }
        for (int i = 0; i < listBeans.size(); i++) {
            if (CheckUtils.isEmpty(listBeans.get(i).getEqlat())) {
                continue;
            }
            lat = Double.parseDouble(listBeans.get(i).getEqlat());
            lng = Double.parseDouble(listBeans.get(i).getEqlng());
            LatLng latLng = new LatLng(lat, lng);
            //准备 marker option 添加 marker 使用
            Bundle bundle = new Bundle();
            bundle.putSerializable("info", listBeans.get(i));
            //1是在线
            if ("1".equals(listBeans.get(i).getEqisconn())) {
                markerOptions = new MarkerOptions().icon(bitmap2).position(latLng).zIndex(5);
            } else {
                //离线
                markerOptions = new MarkerOptions().icon(bitmap1).position(latLng).zIndex(5);
            }

            marker = (Marker) mBaiduMap.addOverlay(markerOptions);
            marker.setExtraInfo(bundle);
        }
        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (detailLayout.getVisibility() == View.VISIBLE) {
                    detailLayout.setVisibility(View.GONE);
                }
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {
                return false;
            }
        });

        mBaiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                BaseStation.ListBean info = (BaseStation.ListBean) marker.getExtraInfo().get("info");
                if ("1".equals(info.getEqisconn())) {
                    onLineTxt.setText("是");
                } else {
                    onLineTxt.setText("否");
                }
                nameTxt.setText(info.getEqno());
                lngTxt.setText(info.getEqlng());
                latTxt.setText(info.getEqlat());
                addressTxt.setText(info.getEqaddr());
                //展示
                showDetail(info);
                return true;
            }
        });
    }

    private void setTotalSize(BaseStation.TotalBean totalBean) {
        //总数、在线、离线
        String jztotal = totalBean.getTotaol() + "";
        String noLine = totalBean.getOnline() + "";
        String Offline = totalBean.getOffline() + "";
        allBaseSizeTxt.setText("总数:" + jztotal);
        onLineSizeTxt.setText("在线数:" + noLine);
        offlineSizeTxt.setText("离线数:" + Offline);

    }

    @Override
    protected void onPause() {
        if (mMapView != null) {
            mMapView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (mMapView != null) {
            mMapView.onResume();
        }
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        if (locationClient != null) {
            locationClient.stop();
        }

//        if (mMapView != null) {
//            mMapView.onDestroy();
//            mMapView = null;
//        }
        super.onDestroy();
    }

    @Override
    public void getChildView(View view, int layoutResId) {
    }

    @Override
    public void onMapLoaded() {
        ms = new MapStatus.Builder().zoom(17).build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));
    }

    public class MyLocationListener1 implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            // TODO Auto-generated method stub
            if (location == null || mMapView == null)
                return;
            mLongitude = location.getLongitude(); //获取经度
            mLatitude = location.getLatitude();

            if (isFirstLoad) {
                //定位成功之后设置地图更新
                MyLocationData locData = new MyLocationData.Builder()
                        .accuracy(0).direction(0).latitude(mLatitude).longitude(mLongitude).build();
                mBaiduMap.setMyLocationData(locData);
                ms = new MapStatus.Builder().target(new LatLng(mLatitude, mLongitude)).zoom(17).build();
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(ms));

                mBaiduMap.setOnMapStatusChangeListener(new BaiduMap.OnMapStatusChangeListener() {
                    @Override
                    public void onMapStatusChangeStart(MapStatus mapStatus) {

                    }

                    @Override
                    public void onMapStatusChangeStart(MapStatus mapStatus, int i) {

                    }

                    @Override
                    public void onMapStatusChange(MapStatus mapStatus) {

                    }

                    @Override
                    public void onMapStatusChangeFinish(MapStatus mapStatus) {
                        if (isFirstLoad) {
                            getMarkData("1", "");
                        }
                        isFirstLoad = false;
                    }
                });

            }
        }


    }


    @OnClick({R.id.back_ib, R.id.searchBtn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.back_ib:
                finish();

                break;
            case R.id.searchBtn:
                String eqno = inputEqunEdt.getText().toString().trim();
                String type = "1";
                if (!CheckUtils.isEmpty(eqno)) {
                    type = "2";
                }
                getMarkData(type, eqno);
                break;
        }
    }

    //展示明细
    private void showDetail(BaseStation.ListBean info) {
        detailLayout.setVisibility(View.VISIBLE);
        detailLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailLayout.setVisibility(View.GONE);
                showGotoMap(info);
            }
        });
    }

    private void showGotoMap(BaseStation.ListBean info) {
        ActionSheet.createBuilder(this, getSupportFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("百度地图导航", "高德地图导航")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                Utils.gotoBaiduMap(LocationActivity.this, info.getEqlng(), info.getEqlat(), info.getEqaddr());
                                break;
                            case 1:
                                Utils.gotoGaodeMap(LocationActivity.this, info.getEqlng(), info.getEqlat(), info.getEqaddr());
                                break;
                            default:
                                break;
                        }
                    }
                }).show();

    }
}

