package com.dgzrdz.mobile.cocobee.view;

import android.content.Context;
import android.os.CountDownTimer;
import android.widget.TextView;

import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.common.EventConstants;

import org.greenrobot.eventbus.EventBus;

public class TimeCountUnFinish extends CountDownTimer {

    private final TextView mTextView;
    private final Context mContext;

    public TimeCountUnFinish(Context context, long millisInFuture, long countDownInterval, TextView textView) {
        super(millisInFuture, countDownInterval);
        mContext = context;
        mTextView = textView;
    }


    @Override
    public void onTick(long millisUntilFinished) {
        mTextView.setText(millisUntilFinished / 1000 + "s 后返回提交页面");
    }

    @Override
    public void onFinish() {
        mTextView.setText("返回提交页面");
        EventBus.getDefault().post(new EventManager(EventConstants.UNFINISH_PAY_BACK_HOME));
    }
}