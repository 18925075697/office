package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.BindApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.BindingCarInfo;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

import butterknife.BindView;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 车辆信息
 * Created by Administrator on 2018/5/16.
 */

public class CarInfoFragment extends BaseFragment {
    private static String cid;
    @BindView(R.id.et_car_type)
    TextView mEtCarType;
    @BindView(R.id.tv_car_color)
    TextView mTvCarColor;
    @BindView(R.id.et_car_motor)
    TextView mEtCarMotor;
    @BindView(R.id.et_car_frame)
    TextView mEtCarFrame;
    @BindView(R.id.et_buy_price)
    TextView mEtBuyPrice;
    @BindView(R.id.tv_buy_time)
    TextView mTvBuyTime;
    @BindView(R.id.iv_buy_invoice)
    ImageView mIvBuyInvoice;
    @BindView(R.id.iv_car_front)
    ImageView mIvCarFront;
    @BindView(R.id.iv_car_back)
    ImageView mIvCarBack;
    @BindView(R.id.iv_car_left)
    ImageView mIvCarLeft;
    @BindView(R.id.iv_car_right)
    ImageView mIvCarRight;
    @BindView(R.id.iv_low_effec_pic)
    ImageView mIvLowEffectPic;
    @BindView(R.id.ll_low_effect)
    LinearLayout mLlLowEffect;
    private UserInfo mUserLoginInfo;

    public static CarInfoFragment getInstance(String cid) {
        CarInfoFragment.cid = cid;
        CarInfoFragment fragment = new CarInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        initData();
    }

    /**
     * 获取车辆信息
     */
    private void initData() {
        BindApiUtils.getCarDetailInfo(_mActivity, cid, new DialogCallback<BindingCarInfo>(_mActivity, "获取车辆信息中...") {
            @Override
            public void onSuccess(BindingCarInfo bindingCarInfo, Call call, Response response) {
                if (bindingCarInfo != null) {
                    setCarInfo(bindingCarInfo);
                }
            }
        });
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("车辆信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_car_info;
    }

    /**
     * 设置车辆信息
     *
     * @param bindingCarInfo
     */
    private void setCarInfo(BindingCarInfo bindingCarInfo) {
        mEtCarType.setText(bindingCarInfo.getBuyType());
        mEtCarMotor.setText(bindingCarInfo.getDevice());
        mTvCarColor.setText(bindingCarInfo.getColor());
        mEtCarFrame.setText(bindingCarInfo.getFrame());
        mTvBuyTime.setText(bindingCarInfo.getBuyTime());
        mEtBuyPrice.setText(bindingCarInfo.getBuyPrice() + "");
        List<BindingCarInfo.PictureBean> picture = bindingCarInfo.getPicture();
        if (picture == null){
            return;
        }
        for (int i = 0; i < picture.size(); i++) {
            BindingCarInfo.PictureBean pictureBean = picture.get(i);
//            if (CheckUtils.equalsString(pictureBean.getProperty(), "13")) {//车辆前照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvCarFront);
//            } else if (CheckUtils.equalsString(pictureBean.getProperty(), "14")) {//车辆后照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvCarBack);
//            } else if (CheckUtils.equalsString(pictureBean.getProperty(), "12")) {//车辆左照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvCarLeft);
//            } else if (CheckUtils.equalsString(pictureBean.getProperty(), "16")) {//车辆右照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvCarRight);
//            } else if (CheckUtils.equalsString(pictureBean.getProperty(), "15")) {//发票照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvBuyInvoice);
//            } else if (CheckUtils.equalsString(pictureBean.getProperty(), "17")) {//安装标签照
//                ImageUtil.loadCarPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + pictureBean.getUrlX(), mIvLowEffectPic);
//            }
        }
    }

}
