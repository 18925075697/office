package com.dgzrdz.mobile.cocobee.fragment.base;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bql.pulltorefreshandloadmore.loadmoreview.LoadMoreRecyclerView;
import com.bql.pulltorefreshandloadmore.loadmoreview.OnLoadMoreListener;
import com.bql.pulltorefreshandloadmore.ultraptr.OnDefaultRefreshListener;
import com.bql.pulltorefreshandloadmore.ultraptr.PtrClassicFrameLayout;
import com.bql.pulltorefreshandloadmore.ultraptr.PtrFrameLayout;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.dgzrdz.mobile.cocobee.view.animator.NoAlphaItemAnimator;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * ViewPager Tablayout基类
 * Created by Administrator on 2018/6/26.
 */

public abstract class BaseViewPagerFragment<T extends Object> extends Fragment implements OnLoadMoreListener {
    //数据集合
    public List<T> mList = new ArrayList<>();
    @BindView(R.id.rcv_load_more)
    public LoadMoreRecyclerView mRcvLoadMore;
    @BindView(R.id.prt_layout_)
    PtrClassicFrameLayout mPrtLayout;
    Unbinder unbinder;
    private View mRootView;
    public Context _mActivity;
    //当前页数
    public int mCurPage = 1;

    //每页大小
    public int pageSize = 20;

    private boolean mFirstVisible = false;
    private boolean mVisible;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (registerEventBus()) {
            if (!EventBus.getDefault().isRegistered(this)) {
                EventBus.getDefault().register(this);
            }
        }
        if (getContentViewLayoutID() == 0) {
            throw new IllegalArgumentException("You must return a right contentView layout resource Id");
        }
        mRootView = inflater.inflate(getContentViewLayoutID(), container, false);
        unbinder = ButterKnife.bind(this, mRootView);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mFirstVisible = true;
        _mActivity = getContext();
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        if (userLoginInfo == null){
            Utils.gotoLogin();
            return;
        }
        initViewsAndEvents(savedInstanceState);
        initView();
        initData(1, false);
        //        if (lazyLoadMode()) {
        //            layzeMode();
        //        } else {
        //            initData(mCurPage, false);
        //        }
    }

    //    @Override
    //    public void setUserVisibleHint(boolean isVisibleToUser) {
    //        super.setUserVisibleHint(isVisibleToUser);
    //        if (lazyLoadMode()) {
    //            if (getUserVisibleHint()) {
    //                mVisible = true;
    //                layzeMode();
    //            } else {
    //                mVisible = false;
    //            }
    //        }
    //    }
    //
    //    /**
    //     * 如果是通过FragmentTransaction的show和hide的方法来控制显示，调用的是onHiddenChanged.
    //     *
    //     * @param hidden
    //     */
    //    @Override
    //    public void onHiddenChanged(boolean hidden) {
    //        super.onHiddenChanged(hidden);
    //        if (lazyLoadMode()) {
    //            if (!hidden) {
    //                mVisible = true;
    //                layzeMode();
    //            } else {
    //                mVisible = false;
    //            }
    //        }
    //    }
    //
    //    private void layzeMode() {
    //        if (mVisible && mFirstVisible) {
    //            mFirstVisible = false;
    //            initData(mCurPage, false);
    //        }
    //    }
    //
    //
    //    /**
    //     * 懒加载模式
    //     *
    //     * @return
    //     */
    //    protected boolean lazyLoadMode() {
    //        return true;
    //    }

    public abstract void initViewsAndEvents(Bundle savedInstanceState);

    private void initView() {
        if (getAdapter() == null) {
            throw new NullPointerException("The getAdapter() method must not be null");
        }
        mRcvLoadMore.setItemAnimator(new NoAlphaItemAnimator());
        mRcvLoadMore.setLayoutManager(new LinearLayoutManager(getContext()));
        mRcvLoadMore.addItemDecoration(new ListLineDecoration());
        mRcvLoadMore.setAdapter(getAdapter());
        mRcvLoadMore.setHideLoadingView(true);
        mRcvLoadMore.setOnLoadMoreListener(this);
        mPrtLayout.disableWhenHorizontalMove(true);
        mPrtLayout.setOnRefreshListener(new OnDefaultRefreshListener() {
            @Override
            public void onRefreshBegin(PtrFrameLayout ptrFrameLayout) {
                onRefresh();
            }

            @Override
            public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
                return canRefresh() ? super.checkCanDoRefresh(frame, content, header) : false;
            }
        });
        mRcvLoadMore.setOnItemClickListener((holder, position) -> onRcvItemClick(holder, position));
    }

    protected abstract int getContentViewLayoutID();

    /**
     * 是否注册EventBus  默认不注册
     *
     * @return
     */
    public boolean registerEventBus() {
        return false;
    }

    @Subscribe
    public void onEventMainThread(EventManager eventManager) {
        if (null != eventManager) {
            onHandleEvent(eventManager);
        }
    }

    /**
     * handle something when event coming
     *
     * @return
     */
    protected void onHandleEvent(EventManager eventManager) {

    }

    protected abstract void onRcvItemClick(RecyclerView.ViewHolder holder, int position);

    protected abstract void onRefresh();

    protected boolean canRefresh() {
        return true;
    }

    protected abstract RecyclerView.Adapter getAdapter();

    protected abstract void initData(int curPage, boolean isPullToRefresh);

    /**
     * 结束刷新和加载
     */
    public void completeRefreshAndLoad() {
        if (mPrtLayout != null) {
            mPrtLayout.onRefreshComplete();
        }
        if (mRcvLoadMore != null) {
            mRcvLoadMore.onLoadMoreComplete();
        }

    }

    /**
     * 处理刷新加载得到的数据
     *
     * @param curPage             当前页
     * @param loadingViewCallback 加载视图
     * @param list                数据集合
     */
    public void handleRefreshAndLoadListData(int curPage, LoadingViewCallback loadingViewCallback, List<T> list) {
        mCurPage = curPage;
        if ((list == null || list.size() == 0) && mCurPage == 1) {
            loadingViewCallback.showEmpty();
        } else if (list != null) {
            if (mCurPage == 1) {
                mList.clear();
                getAdapter().notifyDataSetChanged();
            }
            mCurPage = mCurPage + 1;
            mList.addAll(list);
            getAdapter().notifyDataSetChanged();

            if (mRcvLoadMore != null) {
                if (list.size() < pageSize || list.size() == 0) {
                    mRcvLoadMore.setCanLoadMore(false);
                } else {
                    mRcvLoadMore.setCanLoadMore(true);
                }
            }
        } else {
            if (mRcvLoadMore != null) {
                mRcvLoadMore.setCanLoadMore(false);
            }
        }
    }


    /**
     * 处理刷新得到的数据
     *
     * @param list
     */
    public void handleRefreshListData(LoadingViewCallback loadingViewCallback, List<T> list, String tips) {
        if (list.size() == 0) {
            if (tips == null) {
                loadingViewCallback.showEmpty();
            } else {
                loadingViewCallback.showEmpty(tips);
            }
        } else {
            mList.clear();
            mList.addAll(list);
            getAdapter().notifyDataSetChanged();
        }

    }


    /**
     * 刷新加载回调
     *
     * @param <T>
     */
    public abstract class RefreshAndLoadCallback<T> extends LoadingViewCallback<T> {

        public RefreshAndLoadCallback(boolean isPullToRefresh) {
            super(_mActivity, getView(), isPullToRefresh);
        }


        @Override
        public void onAfter(T t, Exception e) {
            super.onAfter(t, e);
            completeRefreshAndLoad();
        }
    }

    @Override
    public void onDestroyView() {
        if (registerEventBus()) {
            if (EventBus.getDefault().isRegistered(this)) {//加上判断
                EventBus.getDefault().unregister(this);
            }
        }
        OkGo.getInstance().cancelTag(this);
        unbinder.unbind();
        super.onDestroyView();
    }
}
