package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.MsgResponse;

import butterknife.BindView;

/**
 * Description:消息详情
 * Author: Liubingren
 * Data:  2018/11/24
 * Time:  15:07
 */

public class MessageDetailFragment extends BaseFragment {

    private static MsgResponse msgResponse;
    @BindView(R.id.tv_title)
    TextView mTvTitle;
    @BindView(R.id.tv_send_time)
    TextView mTvSendTime;
    @BindView(R.id.tv_app_sender)
    TextView mTvAppSender;
    @BindView(R.id.tv_content)
    TextView mTvContent;

    public static MessageDetailFragment getInstance(MsgResponse msgResponse) {
        MessageDetailFragment.msgResponse = msgResponse;
        MessageDetailFragment fragment = new MessageDetailFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initView();
    }

    /**
     * 初始化页面
     */
    private void initView() {
        mTvTitle.setText(msgResponse.getSysMessageTitle());
        mTvSendTime.setText(msgResponse.getSysMessageAddTime());
        mTvContent.setText(msgResponse.getSysMessageContent());
        mTvAppSender.setText(msgResponse.getSysMessageSender());
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("消息详情");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_message_detail;
    }
}
