package com.dgzrdz.mobile.cocobee.activity.manager;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.response.LabelInfoResponse;
import com.dgzrdz.mobile.cocobee.response.TagResponse;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.lzy.okgo.OkGo;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 标签详情页面
 * Created by _H_JY on 2017/1/9.
 */
public class TagDetailActivity extends BaseToolbarActivity {
    @BindView(R.id.tv_label_num)
    TextView mTvLabelNum;
    @BindView(R.id.tv_name)
    TextView mTvName;
    @BindView(R.id.tv_sex)
    TextView mTvSex;
    @BindView(R.id.tv_birth_time)
    TextView mTvBirthTime;
    @BindView(R.id.tv_address_now)
    TextView mTvAddressNow;
    @BindView(R.id.tv_address_origin)
    TextView mTvAddressOrigin;
    @BindView(R.id.tv_phone_num)
    TextView mTvPhoneNum;
    @BindView(R.id.tv_identity)
    TextView mTvIdentity;
    @BindView(R.id.tv_work_place)
    TextView mTvWorkPlace;
    @BindView(R.id.tv_illegal_registration)
    TextView mTvIllegalRegistration;

    private TagResponse mTagResponse;
    private int mScanType;
    private LabelInfoResponse mLabelInfoResponse;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_tag_detail;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mTagResponse = (TagResponse) getIntent().getSerializableExtra("tagResponse");
        mScanType = mTagResponse.getScanType();
        if (mScanType == 1) {
            initToolbar("发卡模式");
        } else if (mScanType == 2) {
            initToolbar("查车模式");
        }
        initView();
        getLabelInfo();
    }

    private void initView() {
        mTvLabelNum.setText(mTagResponse.getLno());
    }

    @OnClick({R.id.tv_illegal_registration})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_illegal_registration:
                gotoRegister();
                break;
        }
    }

    /**
     * 进入违章登记
     */
    private void gotoRegister() {
        //申请定位权限
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取定位权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                //已经禁止提示了
                Toast.makeText(this, "您已禁止定位权限，需要重新开启", Toast.LENGTH_SHORT).show();
                return;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 11);
            }
        }

        if (mLabelInfoResponse == null) {
            XToastUtils.showShortToast("未获取到车辆信息,不能登记");
            return;
        }
        Intent intent = new Intent(this, IllegalRegistrationActivity.class);
        intent.putExtra("cno", mLabelInfoResponse.getCno());
        intent.putExtra("cid", mLabelInfoResponse.getCid());
        startActivity(intent);
    }

    //获取标签信息
    private void getLabelInfo() {
        Map<String, String> params = new HashMap<>();
        params.put("BQCODE", mTagResponse.getLno());

        OkGo.post(Path.SEARCH_CAR_DOWNLOAD).params(params).execute(new DialogCallback<LabelInfoResponse>(TagDetailActivity.this, "正在加载...") {

            @Override
            public void onSuccess(LabelInfoResponse labelInfoResponse, Call call, Response response) {
                mLabelInfoResponse = labelInfoResponse;
                if (labelInfoResponse != null) {
                    setView(labelInfoResponse);
                } else {
                    XToastUtils.showShortToast("暂无相关信息");
                }
            }
        });

    }

    private void setView(LabelInfoResponse labelInfoResponse) {
        mTvName.setText(labelInfoResponse.getPname());
        if (CheckUtils.equalsString(labelInfoResponse.getSex(), "0")) {
            mTvSex.setText("男");
        } else {
            mTvSex.setText("女");
        }
        mTvBirthTime.setText(labelInfoResponse.getBirthday());
        mTvAddressNow.setText(labelInfoResponse.getAddress());
        mTvAddressOrigin.setText(labelInfoResponse.getRegiaddr());
        mTvPhoneNum.setText(labelInfoResponse.getMobile());
        mTvIdentity.setText(labelInfoResponse.getIdcard());
        mTvWorkPlace.setText(labelInfoResponse.getUnit());
    }

}
