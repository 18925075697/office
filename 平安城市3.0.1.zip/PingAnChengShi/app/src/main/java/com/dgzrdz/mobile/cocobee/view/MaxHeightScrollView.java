package com.dgzrdz.mobile.cocobee.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;

import com.dgzrdz.mobile.cocobee.utils.Utils;


/**
 * 限制ScrollView的最大高度的ScrollView
 */
public class MaxHeightScrollView extends ScrollView {
    private Context mContext;

    public MaxHeightScrollView(Context context) {
        super(context);
        init(context);
    }

    public MaxHeightScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);

    }

    public MaxHeightScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        mContext = context;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        try {
            //此处是关键，设置控件高度不能超过屏幕高度一半（d.heightPixels / 2）（在此替换成自己需要的高度）
            int screenHeight = Utils.getScreenHeight();
            if (screenHeight*7/10 < Utils.dp2px(544 + 55)) {//屏幕的70%小于这个高度,使其最大高度为屏幕的70%
                heightMeasureSpec = MeasureSpec.makeMeasureSpec(screenHeight*7/10, MeasureSpec.AT_MOST);
            } else {
                heightMeasureSpec = MeasureSpec.makeMeasureSpec(Utils.dp2px(544), MeasureSpec.AT_MOST);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        //重新计算控件高、宽
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}