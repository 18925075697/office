package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;
import com.dgzrdz.mobile.cocobee.response.ObjectValueResponse;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  首页
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class HomeApiUtils {
    private static Gson gson = new Gson();

    /**
     * 加载首页信息
     *
     * @param context
     * @param appMemberId app管理员id
     * @param callback    回调
     */
    public static void getIndexMoreInfo(Context context, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        OkGo.post(Path.GET_INDEX_MORE_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 获取业务统计
     *
     * @param context
     * @param appMemberId app管理员id
     * @param callback    回调
     */
    public static void getBussinessInfo(Context context, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        OkGo.post(Path.GET_BUSSINESS_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 首页获取组织机构选择信息
     *
     * @param context
     * @param sysAreaPId 组织机构id
     * @param callback   回调
     */
    public static void getIndexOrgSelect(Context context, String sysAreaPId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaPId", sysAreaPId);
        OkGo.get(Path.GET_INDEX_ORG_SELECT_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 首页保存组织机构选择信息
     *
     * @param context
     * @param orgPid   组织机构编号
     * @param callback 回调
     */
    public static void saveIndexOrgSelect(Context context, String peopleId, String orgPid, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("peopleId", peopleId);
        params.put("orgId", orgPid);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.SAVE_INDEX_ORG_SELECT_PATH).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 预登记注册用户
     *
     * @param context
     * @param memberAccount         手机号
     * @param sysAreaId             组织机构id
     * @param memberName            姓名
     * @param memberCardId          身份证
     * @param memberSix             性别1男2女
     * @param memberRegisterAddress 户籍地址
     * @param memberLiveAddress     现居地址
     * @param appMemberId           业务录入人员
     * @param callback              回调
     */
    public static void preRegistration(Context context, String memberAccount, String sysAreaId, String memberName, String memberCardId, String memberSix,
                                       String memberRegisterAddress, String memberLiveAddress, String appMemberId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberAccount", memberAccount);
        params.put("sysAreaId", sysAreaId);
        params.put("memberName", memberName);
        params.put("memberCardId", memberCardId);
        if (CheckUtils.equalsString(memberSix, "男")) {
            params.put("memberSix", "1");
        } else {
            params.put("memberSix", "2");
        }
        params.put("memberRegisterAddress", memberRegisterAddress);
        params.put("memberLiveAddress", memberLiveAddress);
        params.put("appMemberId", appMemberId);

        OkGo.post(Path.PRE_REGISTRATION_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 预登记修改用户信息
     *
     * @param context
     * @param memberAccount         手机号
     * @param memberName            姓名
     * @param memberCardId          身份证
     * @param memberSix             性别1男2女
     * @param memberRegisterAddress 户籍地址
     * @param memberLiveAddress     现居地址
     * @param memberId              业务录入人员
     * @param sysAreaId             组织机构id
     * @param callback              回调
     */
    public static void updateUserInfo(Context context, String memberAccount, String memberName, String memberCardId, String memberSix, String memberRegisterAddress,
                                      String memberLiveAddress, String memberId, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberAccount", memberAccount);
        params.put("memberName", memberName);
        params.put("memberCardId", memberCardId);
        if (CheckUtils.equalsString(memberSix, "男")) {
            params.put("memberSix", "1");
        } else {
            params.put("memberSix", "2");
        }
        params.put("memberRegisterAddress", memberRegisterAddress);
        params.put("memberLiveAddress", memberLiveAddress);
        params.put("memberId", memberId);
        params.put("sysAreaId", sysAreaId);

        OkGo.post(Path.UPDATE_USER_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 预登记上传监护对象信息
     *
     * @param context
     * @param memberId             所属用户Id
     * @param sysAreaId            组织机构id
     * @param sysServiceTypeId     监护对象类型id
     * @param appMemberId          录入人员id
     * @param memberServiceObjName 监护对象类型名称
     * @param sysPropertyJson      服务对象属性json
     * @param callback             回调
     */
    public static void uploadObjectInfo(Context context, String memberId, String sysAreaId, String sysServiceTypeId, String appMemberId, String memberServiceObjName,
                                        List<ObjectValueResponse> sysPropertyJson, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberId", memberId);
        params.put("sysAreaId", sysAreaId);
        params.put("sysServiceTypeId", sysServiceTypeId);
        params.put("appMemberId", appMemberId);
        params.put("memberServiceObjName", memberServiceObjName);

        String s = gson.toJson(sysPropertyJson);
        params.put("sysPropertyJson", s);

        OkGo.post(Path.PRE_UPLOAD_CAR_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 修改监护对象信息
     *
     * @param context
     * @param memberServiceObjId      对象id
     * @param appMemberId             录入人员id
     * @param memberServiceActiveTime 对象生效时间
     * @param sysPropertyJson         服务对象属性json
     * @param callback                回调
     */
    public static void updateObjectInfo(Context context, String memberServiceObjId,String appMemberId, String memberServiceActiveTime, List<GuardianObjectDetailResponse.CustomizeBean> sysPropertyJson, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberServiceObjId", memberServiceObjId);
        params.put("appMemberId", appMemberId);
        if (!CheckUtils.isEmpty(memberServiceActiveTime)) {
            params.put("memberServiceActiveTime", memberServiceActiveTime);
        }
        String s = gson.toJson(sysPropertyJson);
        params.put("sysPropertyJson", s);

        OkGo.post(Path.UPDATE_CAR_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 修改标签信息
     *
     * @param context
     * @param memberServiceObjId         对象id
     * @param hLabelNo                   标签号
     * @param sysAreaId                  组织机构id
     * @param appMemberId                录入人员id
     * @param cnoPrefix                  车牌前缀名称
     * @param cnpType                    车牌类型
     * @param cnoNumber                  车牌号
     * @param memberServiceObjActiveFlag 对象状态
     * @param callback                   回调
     */
    public static void updateTagInfo(Context context, String memberServiceObjId, String hLabelNo, String sysAreaId, String appMemberId, String cnoPrefix,
                                     String cnpType, String cnoNumber, String memberServiceObjActiveFlag, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberServiceObjId", memberServiceObjId);
        params.put("hLabelNo", hLabelNo);
        params.put("sysAreaId", sysAreaId);
        params.put("appMemberId", appMemberId);
        params.put("cnoPrefix", cnoPrefix);
        params.put("cnpType", cnpType);
        params.put("cnoNumber", cnoNumber);
        params.put("memberServiceObjActiveFlag", memberServiceObjActiveFlag);

        OkGo.post(Path.UPDATE_TAG_INFO_PATH).tag(context).params(params).execute(callback);
    }


    /**
     * 删除监护对象
     *
     * @param context
     * @param memberServiceObjId 对象id
     * @param callback           回调
     */
    public static void deleteObject(Context context, String memberServiceObjId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberServiceObjId", memberServiceObjId);

        OkGo.post(Path.DELETE_CAR_INFO_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 获取安装点信息
     *
     * @param context
     * @param code     组织机构编号
     * @param callback 回调
     */
    public static void getInstallPoint(Context context, String code, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("code", code);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.GET_INSTALL_POINT).tag(context).upJson(jsonObject).execute(callback);
    }

}
