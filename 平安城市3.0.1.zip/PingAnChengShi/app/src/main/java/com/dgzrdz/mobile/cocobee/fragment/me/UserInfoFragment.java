package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Description: 管理员资料
 * Author: Liubingren
 * Data:  2018/6/11
 * Time:  11:00
 */

public class UserInfoFragment extends BaseFragment {

    @BindView(R.id.tv_user_role)
    TextView mTvUserRole;
    @BindView(R.id.tv_select_org)
    TextView mTvSelectOrg;
    @BindView(R.id.tv_user_mobile)
    TextView mTvUserMobile;
    @BindView(R.id.tv_change)
    TextView mTvChange;
    @BindView(R.id.tv_name)
    TextView mTvName;
    @BindView(R.id.tv_sex)
    TextView mTvSex;
    @BindView(R.id.tv_card_id)
    TextView mTvCardId;
    private UserInfo mUserLoginInfo;

    public static UserInfoFragment getInstance() {
        UserInfoFragment fragment = new UserInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        initView();
    }

    private void initView() {
        mTvUserRole.setText(mUserLoginInfo.getDataList().getRoleName());
        mTvSelectOrg.setText(mUserLoginInfo.getDataList().getSysAreaName());
        mTvUserMobile.setText(mUserLoginInfo.getDataList().getAppMemberAccount());
        mTvName.setText(mUserLoginInfo.getDataList().getAppMemberName());
        mTvSex.setText(CheckUtils.equalsString(mUserLoginInfo.getDataList().getAppMemberSex(), "1") ? "男" : "女");
        mTvCardId.setText(Utils.getIdCardFirstAndEnd(mUserLoginInfo.getDataList().getAppMemberCardId()));
    }


    @Override
    protected void initToolbarHere() {
        initToolbar("管理员资料");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_user_info;
    }

    @OnClick({R.id.tv_change})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_change://修改
                start(ChangePhoneFragment.getInstance());
                break;

        }
    }
}
