package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.pay.SelectPayTypeActivity;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.response.PayResponse;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/27
 * Time:  14:28
 */

public class OrderSearchAdapter extends QuickRcvAdapter<OrderStatusResponse> {

    private final List<OrderStatusResponse> mData;
    private final Context mContext;

    public OrderSearchAdapter(Context context, List<OrderStatusResponse> data, int... layoutId) {
        super(context, data, layoutId);
        mContext = context;
        mData = data;
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, OrderStatusResponse item) {
        viewHolder.setText(R.id.tv_first_head_word, item.getMemberName() + "(" + item.getMemberAccount() + ")");

        TextView cancleOrder = viewHolder.getView(R.id.tv_cancel_order);
        TextView payNow = viewHolder.getView(R.id.tv_pay_now);
        TextView tvBaoxian = viewHolder.getView(R.id.tv_bao_xian_tao_can);
        TextView tvTaocan = viewHolder.getView(R.id.tv_taocan);

        if (CheckUtils.equalsString(item.getMemberOrderProcess(), "1")) {//待付款
            viewHolder.setText(R.id.tv_car_type, "待付款");
            viewHolder.setTextColor(R.id.tv_car_type, R.color.color_ff0000);
            cancleOrder.setVisibility(View.VISIBLE);
            payNow.setVisibility(View.VISIBLE);
        } else if (CheckUtils.equalsString(item.getMemberOrderProcess(), "2")) {//已付款
            viewHolder.setText(R.id.tv_car_type, "已付款");
            viewHolder.setTextColor(R.id.tv_car_type, R.color.color_12bc00);
            cancleOrder.setVisibility(View.GONE);
            payNow.setVisibility(View.GONE);
        } else if (CheckUtils.equalsString(item.getMemberOrderProcess(), "3")) {//已取消
            viewHolder.setText(R.id.tv_car_type, "已取消");
            viewHolder.setTextColor(R.id.tv_car_type, R.color.color_666666);
            cancleOrder.setVisibility(View.GONE);
            payNow.setVisibility(View.GONE);
        } else {//已过期
            viewHolder.setText(R.id.tv_car_type, "已过期");
            viewHolder.setTextColor(R.id.tv_car_type, R.color.color_999999);
            cancleOrder.setVisibility(View.GONE);
            payNow.setVisibility(View.GONE);
        }

        viewHolder.setText(R.id.tv_object_type, item.getSysServiceTypeName());

        if (CheckUtils.isEmpty(item.getMemberServiceObjNumber())) {
            viewHolder.setText(R.id.tv_label_car_num, "标签号:  " + item.getHLabelNo());
        } else {
            viewHolder.setText(R.id.tv_label_car_num, "标签号:  " + item.getHLabelNo() + "   车牌号:  " + item.getMemberServiceObjNumber());
        }

        //订单类型，\n1 服务+保险\n2 服务\n3 保险
        if (CheckUtils.equalsString(item.getMemberOrderType(), "1")) {
            tvTaocan.setVisibility(View.VISIBLE);
            tvBaoxian.setVisibility(View.VISIBLE);
            tvTaocan.setText("标签服务      " + item.getSysServiceSetYears() + "年");
        } else if (CheckUtils.equalsString(item.getMemberOrderType(), "2")) {
            tvBaoxian.setVisibility(View.GONE);
            tvTaocan.setVisibility(View.VISIBLE);
            tvTaocan.setText("标签服务      " + item.getSysServiceSetYears() + "年");
        } else {
            tvBaoxian.setVisibility(View.VISIBLE);
            tvTaocan.setVisibility(View.GONE);
        }

        List<OrderStatusResponse.SysInsuranceValuerBean> sysInsuranceValuer = item.getSysInsuranceValuer();
        if (sysInsuranceValuer != null && sysInsuranceValuer.size() > 0) {//保险套餐集合不为空
            String str = "";
            for (int i = 0; i < sysInsuranceValuer.size(); i++) {
                OrderStatusResponse.SysInsuranceValuerBean sysInsuranceValuerBean = sysInsuranceValuer.get(i);
                str = str + sysInsuranceValuerBean.getSysInsuranceTypeName() + "     " + sysInsuranceValuerBean.getSysInsuranceConfYears() + "年";
                if (i != sysInsuranceValuer.size() - 1) {
                    str = str + "\n";
                }
            }
            tvBaoxian.setVisibility(View.VISIBLE);
            tvBaoxian.setText(str);
        } else {
            tvBaoxian.setVisibility(View.GONE);
        }
        MoneyTextView tvPayNum = viewHolder.getView(R.id.mtv_pay_num);
        tvPayNum.setAmount(item.getMemberOrderTotalPay());

        cancleOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCancelDialog(item, position);
            }
        });
        payNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoPay(item);
            }
        });
    }

    /**
     * 显示取消订单提示
     *
     * @param orderStatusResponse
     * @param position
     */
    private void showCancelDialog(OrderStatusResponse orderStatusResponse, int position) {
        SweetAlertDialog dialog = new SweetAlertDialog(mContext, SweetAlertDialog.WARNING_TYPE);
        dialog.setContentText("确定取消此订单吗?");
        dialog.setTitleText("温馨提示");
        dialog.showCancelButton(true).setCancelText("暂不");
        dialog.setConfirmText("确定取消");
        dialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismissWithAnimation();
                userCancelOrder(orderStatusResponse, position);
            }
        }).show();
    }

    /**
     * 用户主动取消订单
     *
     * @param orderStatusResponse
     * @param position
     */
    private void userCancelOrder(OrderStatusResponse orderStatusResponse, int position) {
        PayApiUtils.userCancelOrder(mContext, orderStatusResponse.getMemberOrderType(), orderStatusResponse.getMemberOrderId(), orderStatusResponse.getMemberServiceObjId(),new DialogCallback<PayResponse>(mContext, "取消支付订单...") {
            @Override
            public void onSuccess(PayResponse payResponse, Call call, Response response) {
                XToastUtils.showShortToast("订单已取消");
                orderStatusResponse.setMemberOrderProcess("3");
                notifyItemChanged(position);
                Intent intent = new Intent();
                intent.putExtra("pageNum", "5");
                EventBus.getDefault().post(new EventManager(EventConstants.ORDER_CANCEL_SUCCESS, intent));
            }
        });
    }

    /**
     * 去支付
     *
     * @param orderStatusResponse
     */
    private void gotoPay(OrderStatusResponse orderStatusResponse) {
        Intent intent = new Intent(mContext, SelectPayTypeActivity.class);
        intent.putExtra("memberOrderId", orderStatusResponse.getMemberOrderId());
        mContext.startActivity(intent);
    }
}