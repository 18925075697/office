package com.dgzrdz.mobile.cocobee.fragment.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.map.TraceActivity;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.SearchRecResponse;
import com.dgzrdz.mobile.cocobee.response.TraceResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.jzxiang.pickerview.TimePickerDialog;
import com.jzxiang.pickerview.data.Type;
import com.jzxiang.pickerview.listener.OnDateSetListener;

import java.io.Serializable;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/6/20
 * Time:  10:44
 */

public class TraceTimeSelectFragment extends BaseFragment implements OnDateSetListener {

    private static SearchRecResponse searchRecResponse;
    @BindView(R.id.tv_start_time)
    TextView mTvStartTime;
    @BindView(R.id.tv_end_time)
    TextView mTvEndTime;
    @BindView(R.id.tv_get_trace)
    TextView mTvGetTrace;

    private TimePickerDialog mDialogAll;
    private TimePickerDialog.Builder timePickerBuilder;
    long tenYears = 10L * 365 * 1000 * 60 * 60 * 24L;
    private int timeDialogFlag = 0;

    private long startMill;
    private long endMill;

    public static TraceTimeSelectFragment getInstance(SearchRecResponse searchRecResponse) {
        TraceTimeSelectFragment.searchRecResponse = searchRecResponse;
        TraceTimeSelectFragment fragment = new TraceTimeSelectFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initTimePick();
        initFirst();
    }

    private void initFirst() {
        long millis = System.currentTimeMillis();
        endMill = millis;
        startMill = millis - 30 * 60 * 1000;
        mTvStartTime.setText(DateUtils.getDateToString(startMill ,DateUtils.DATE_TIME_FORMAT_S));
        mTvEndTime.setText(DateUtils.getDateToString(endMill,DateUtils.DATE_TIME_FORMAT_S));
        mTvStartTime.setCompoundDrawables(null, null, null, null);
        mTvEndTime.setCompoundDrawables(null, null, null, null);
    }

    private void initTimePick() {
        timePickerBuilder = new TimePickerDialog.Builder()
                .setCallBack(this)
                .setCancelStringId("取消")
                .setSureStringId("确定")
                .setTitleStringId("请选择时间")
                .setYearText("年")
                .setMonthText("月")
                .setDayText("日")
                .setHourText("时")
                .setMinuteText("分")
                .setCyclic(false)
                .setMinMillseconds(System.currentTimeMillis() - 3 * tenYears)
                .setMaxMillseconds(System.currentTimeMillis())
                .setThemeColor(getResources().getColor(R.color.timepicker_dialog_bg))
                .setType(Type.ALL)
                .setWheelItemTextNormalColor(getResources().getColor(R.color.timetimepicker_default_text_color))
                .setWheelItemTextSelectorColor(getResources().getColor(R.color.timepicker_toolbar_bg))
                .setWheelItemTextSize(12);

        mDialogAll = timePickerBuilder.build();
    }

    @Override
    protected void initToolbarHere() {
        if (searchRecResponse == null){
            return;
        }
        initToolbar(searchRecResponse.getPersonName());
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_trace_time_select;
    }

    @OnClick({R.id.tv_start_time, R.id.tv_end_time, R.id.tv_get_trace})
    public void onViewClicked(View view) {
        if (!Utils.isFastClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_start_time:
                if (endMill != 0) {
                    timePickerBuilder.setMinMillseconds(endMill - 3 * 24 * 60 * 60 * 1000);
                    timePickerBuilder.setMaxMillseconds(endMill);
                } else {
                    timePickerBuilder.setCurrentMillseconds(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
                    timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                }

                if (!mDialogAll.isAdded()) { //判断是否已经添加，避免因重复添加导致异常
                    mDialogAll.show(getFragmentManager(), "all");
                }

                timeDialogFlag = 1;
                break;
            case R.id.tv_end_time:
                if (startMill != 0) {
                    timePickerBuilder.setMinMillseconds(startMill);
                    if (System.currentTimeMillis() < (startMill + 3 * 24 * 60 * 60 * 1000)) {
                        timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                    } else {
                        timePickerBuilder.setMaxMillseconds(startMill + 3 * 24 * 60 * 60 * 1000);
                    }
                } else {
                    timePickerBuilder.setCurrentMillseconds(System.currentTimeMillis());
                    timePickerBuilder.setMaxMillseconds(System.currentTimeMillis());
                }

                if (!mDialogAll.isAdded()) {
                    mDialogAll.show(getFragmentManager(), "all");
                }

                timeDialogFlag = 2;
                break;
            case R.id.tv_get_trace://查询轨迹
                String startTime = mTvStartTime.getText().toString().trim();
                String endTime = mTvEndTime.getText().toString().trim();
                if (CheckUtils.isEmpty(startTime)) {
                    XToastUtils.showShortToast("请选择开始时间");
                } else if (CheckUtils.isEmpty(endTime)) {
                    XToastUtils.showShortToast("请选择结束时间");
                } else if (CheckUtils.isEmpty(searchRecResponse.getLno())) {
                    XToastUtils.showShortToast("标签号为空,无法查询轨迹");
                } else {
                    getTrace(startTime, endTime);
                }
                break;
        }
    }

    /**
     * 获取轨迹
     *
     * @param startTime
     * @param endTime
     */
    private void getTrace(String startTime, String endTime) {
        ManagerApiUtils.getLabelTrace(_mActivity, searchRecResponse.getLno(), startTime, endTime, new DialogCallback<List<TraceResponse>>(_mActivity, "获取轨迹...") {
            @Override
            public void onSuccess(List<TraceResponse> traceResponses, Call call, Response response) {
                if (traceResponses != null && traceResponses.size() > 0) {
                    toTrace(traceResponses);
                } else {
                    XToastUtils.showShortToast("暂无轨迹信息");
                }
            }
        });
    }

    /**
     * 跳转轨迹
     *
     * @param traceResponses
     */
    private void toTrace(List<TraceResponse> traceResponses) {
        Intent intent;
        intent = new Intent(_mActivity, TraceActivity.class);
        intent.putExtra("traceResponses", (Serializable) traceResponses);
        startActivity(intent);

    }

    @Override
    public void onDateSet(TimePickerDialog timePickerView, long millseconds) {
        switch (timeDialogFlag) {
            case 1:
                mTvStartTime.setText(DateUtils.getDateToString(millseconds ,DateUtils.DATE_TIME_FORMAT_S));
                mTvStartTime.setCompoundDrawables(null, null, null, null);
                startMill = millseconds;
                break;
            case 2:
                mTvEndTime.setText(DateUtils.getDateToString(millseconds ,DateUtils.DATE_TIME_FORMAT_S));
                mTvEndTime.setCompoundDrawables(null, null, null, null);
                endMill = millseconds;
                break;
        }
    }

}
