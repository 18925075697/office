package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description: 生成订单Response
 * Author: Liubingren
 * Data:  2017/1/19
 * Time:  10:10
 */
public class AddOrderResponse implements Serializable {
    private String memberOrderNo;//订单号
    private String memberOrderId;//订单id
    private double payPrice;//支付金额
    private String memberOrderAddTime;//下单时间
    private String currentTime;//当前时间

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getMemberOrderAddTime() {
        return memberOrderAddTime;
    }

    public void setMemberOrderAddTime(String memberOrderAddTime) {
        this.memberOrderAddTime = memberOrderAddTime;
    }

    public String getMemberOrderNo() {
        return memberOrderNo;
    }

    public void setMemberOrderNo(String memberOrderNo) {
        this.memberOrderNo = memberOrderNo;
    }

    public String getMemberOrderId() {
        return memberOrderId;
    }

    public void setMemberOrderId(String memberOrderId) {
        this.memberOrderId = memberOrderId;
    }

    public double getPayPrice() {
        return payPrice;
    }

    public void setPayPrice(double payPrice) {
        this.payPrice = payPrice;
    }
}
