package com.dgzrdz.mobile.cocobee.fragment.pay;

import android.os.Bundle;
import android.widget.TextView;

import com.bql.utils.EventManager;
import com.bql.utils.SystemBarUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.view.TimeCountUnFinish;

import butterknife.BindView;

/**
 * Created by Administrator on 2018/5/2.
 */

public class UnFinishPayFragment extends BaseFragment {
    @BindView(R.id.tv_time_count)
    TextView mTvTimeCount;
    private TimeCountUnFinish timeCount;

    public static UnFinishPayFragment getInstance() {
        UnFinishPayFragment fragment = new UnFinishPayFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        //状态栏完全透明
        SystemBarUtils.immersiveStatusBar(_mActivity, 0);
        timeCount = new TimeCountUnFinish(_mActivity, 3000, 1000, mTvTimeCount);
        timeCount.start();
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {

    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_un_finish_pay;
    }

    private void stopCountTimer() {
        if (timeCount != null) {
            timeCount.cancel();
            timeCount = null;
        }
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.UNFINISH_PAY_BACK_HOME://未完成支付返回首页
                _mActivity.finish();
                break;
        }
    }

    @Override
    public void onDestroy() {
        stopCountTimer();
        super.onDestroy();
    }
}
