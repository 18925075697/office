package com.dgzrdz.mobile.cocobee.activity.manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ZoomControls;

import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseAct;
import com.dgzrdz.mobile.cocobee.api.ManagerApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.model.Equipment;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.lzy.okgo.OkGo;

import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * 设备信息查看页面（安装调试上报设备信息到后台成功后，跳转到这个页面显示设备的位置信息）
 * Created by _H_JY on 2017/2/27.
 */
public class EquipPosLookAct extends BaseAct implements View.OnClickListener {

    private Context context;
    private ImageView back_ib;
    private EditText device_id_et;
    private TextView title_tv;
    private Button right_btn;
    private MapView mapView;
    private BaiduMap baiduMap;
    private String collectorId; //设备ID
    private int flag;
    /*软键盘管理器*/
    private InputMethodManager imm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_activity);

        context = this;

        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        Intent i = getIntent();
        flag = i.getIntExtra("flag", -1);
        if (flag == Constant.AFTER_UPLOAD_DEVICE_INFO_SUCCESS) {
            collectorId = getIntent().getStringExtra("collectorId");
        }

        initView();
        lookDeviceInfo();
    }


    private void initView() {
        back_ib = (ImageView) findViewById(R.id.back_ib);
        title_tv = (TextView) findViewById(R.id.title_tv);
        right_btn = (Button) findViewById(R.id.sure_btn);
        mapView = (MapView) findViewById(R.id.mapView);
        device_id_et = (EditText) findViewById(R.id.device_id_et);

        back_ib.setOnClickListener(this);

        //隐藏logo
        View child = mapView.getChildAt(1);
        if (child != null && (child instanceof ImageView || child instanceof ZoomControls)) {
            child.setVisibility(View.INVISIBLE);
        }


        if (flag == Constant.AFTER_UPLOAD_DEVICE_INFO_SUCCESS) {
            title_tv.setText("采集器位置");
            device_id_et.setVisibility(View.GONE);
            right_btn.setVisibility(View.GONE);
        }


        if (flag == Constant.AFTER_CHOOSE_LOOK_DEVICE_INFO) {
            right_btn.setVisibility(View.VISIBLE);
            title_tv.setVisibility(View.GONE);
            device_id_et.setVisibility(View.VISIBLE);
            right_btn.setBackgroundResource(R.drawable.search_white);
            right_btn.setOnClickListener(this);
        }


        baiduMap = mapView.getMap(); //得到百度地图
        baiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL); //设置地图为正常模式


        if (flag == Constant.AFTER_CHOOSE_LOOK_DEVICE_INFO) {
            //设定中心点坐标
            LatLng cenpt = new LatLng(23.755673407168032, 114.7049539242698);
            MapStatusUpdate mapStatusUpdate = MapStatusUpdateFactory.newLatLngZoom(cenpt, 15f);
            //改变地图状态
            if (baiduMap != null) {
                baiduMap.animateMapStatus(mapStatusUpdate);
            }
        }


        baiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                //LatLng latLng = marker.getPosition();
                Bundle bundle = marker.getExtraInfo();
                String connStatus = bundle.getString("isConn");
                AlertDialog.Builder builder = new AlertDialog.Builder(context);

                if (TextUtils.equals(connStatus, "1")) { //在线
                    builder.setTitle(Html.fromHtml("采集器信息:(<font color='#136006'>在线</font>)"));
                } else {
                    builder.setTitle(Html.fromHtml("采集器信息:(<font color='red'>离线</font>)"));
                }


                View view = LayoutInflater.from(context).inflate(R.layout.dialog_collector_layout, null);
                TextView deviceIdTv = (TextView) view.findViewById(R.id.device_id_tv);
                deviceIdTv.setText("设备ID：" + bundle.getString("deviceId"));


                TextView deviceIpTv = (TextView) view.findViewById(R.id.device_ip_tv);
                deviceIpTv.setText("IP地址：" + bundle.getString("deviceIp"));

                TextView devicePortTv = (TextView) view.findViewById(R.id.device_port_tv);
                devicePortTv.setText("端口号：" + bundle.getString("devicePort"));

                TextView addressTv = (TextView) view.findViewById(R.id.address_tv);
                addressTv.setText("所在地：" + bundle.getString("deviceAddress"));

                TextView createTimeTv = (TextView) view.findViewById(R.id.create_time_tv);
                createTimeTv.setText("创建时间：" + bundle.getString("createtime"));

                TextView heartTimeTv = (TextView) view.findViewById(R.id.heart_time_tv);
                heartTimeTv.setText("心跳时间：" + bundle.getString("hearttime"));


                builder.setView(view);

                builder.setPositiveButton("关闭", null);
                builder.create().show();

                return false;
            }
        });
    }

    private void lookDeviceInfo() {

        ManagerApiUtils.checkStationHas(this, collectorId, new JsonCallback<Equipment>(this) {
            @Override
            public void onSuccess(Equipment equipment, Call call, Response response) {
                List<Equipment.ListBean> list = equipment.getList();
                if (list == null || list.size() == 0) {
                    XToastUtils.showShortToast(msg);
                    return;
                }
                Equipment.ListBean listBean = list.get(0);
                if (listBean != null) {
                    if (baiduMap != null) {
                        baiduMap.clear(); //加载之前先清空
                    }

                    double lat = Double.parseDouble(listBean.getEqlat());
                    double lng = Double.parseDouble(listBean.getEqlng());

                    //设定中心点坐标
                    LatLng cenpt = new LatLng(lat, lng);
                    MapStatusUpdate mapStatusUpdate = MapStatusUpdateFactory.newLatLngZoom(cenpt, 15f);
                    //改变地图状态
                    if (baiduMap != null) {
                        baiduMap.animateMapStatus(mapStatusUpdate);
                    }

                    BitmapDescriptor currentMarker;
                    if (TextUtils.equals(listBean.getEqisconn(), "1")) { //在线
                        currentMarker = BitmapDescriptorFactory.fromResource(R.drawable.p1);
                    } else {
                        currentMarker = BitmapDescriptorFactory.fromResource(R.drawable.p2);
                    }

                    LatLng geoPoint = new LatLng(lat, lng);
                    Bundle bundle = new Bundle();
                    bundle.putString("deviceId", listBean.getEqno()); //设备id
                    bundle.putString("deviceIp", listBean.getEqip()); //ip地址
                    bundle.putString("devicePort", listBean.getEqport()); //端口
                    bundle.putString("deviceAddress", listBean.getEqaddr()); //地址
                    bundle.putString("createtime", listBean.getCreatetime()); //创建时间
                    bundle.putString("hearttime", listBean.getHearttime()); //心跳时间
                    bundle.putString("isConn", listBean.getEqisconn());

                    OverlayOptions option = new MarkerOptions().extraInfo(bundle).position(geoPoint).icon(currentMarker).zIndex(8).draggable(true);

                    if (baiduMap != null) {
                        baiduMap.addOverlay(option);
                    }
                } else {
                    XToastUtils.showShortToast(msg);
                }
            }

        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_ib:
                finish();
                break;


            case R.id.sure_btn:
                collectorId = device_id_et.getText().toString().trim();
                if (TextUtils.isEmpty(collectorId)) {
                    Toast.makeText(context, "请输入采集器号", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (imm != null && imm.isActive()) {
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);//隐藏软键盘
                }
                lookDeviceInfo();

                break;


        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (mapView != null) {
            mapView.onResume();
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mapView != null) {
            mapView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        if (mapView != null) {
            mapView.onDestroy();
            mapView = null;
        }
        OkGo.getInstance().cancelTag(this);

        super.onDestroy();
    }
}
