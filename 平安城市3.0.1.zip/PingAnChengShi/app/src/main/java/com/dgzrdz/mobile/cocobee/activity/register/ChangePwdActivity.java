package com.dgzrdz.mobile.cocobee.activity.register;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.bql.utils.MD5;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.LoginApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 设置密码页面
 * Created by _H_JY on 2017/2/21.
 */
public class ChangePwdActivity extends BaseToolbarActivity {
    @BindView(R.id.tv_car_num)
    EditText mRegPwd;
    @BindView(R.id.iv_see_pwd)
    CheckBox mIvSeePwd;
    @BindView(R.id.vi_num)
    EditText mAgainPwd;
    @BindView(R.id.reg_next)
    TextView mRegNext;
    private String mPhone;
    private String mType;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_change_pwd;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("设置密码");
        Intent intent = getIntent();
        mPhone = intent.getStringExtra("phone");
        mType = intent.getStringExtra("type");
        initListener();
    }

    private void initListener() {
        mIvSeePwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    //选择状态 显示明文--设置为可见的密码
                    mRegPwd.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    mIvSeePwd.setBackground(getResources().getDrawable(R.drawable.login_seegr));
                } else {
                    //默认状态显示密码--设置文本 要一起写才能起作用 InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                    mRegPwd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    mIvSeePwd.setBackground(getResources().getDrawable(R.drawable.login_seecl));
                }
            }
        });
    }


    @OnClick({R.id.reg_next})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.reg_next:
                setPwd();
                break;
        }
    }

    private void setPwd() {
        String pwd = mRegPwd.getText().toString().trim();
        String againPwd = mAgainPwd.getText().toString().trim();
        if (CheckUtils.isEmpty(pwd)) {
            XToastUtils.showShortToast("请输入密码");
        } else if (CheckUtils.isEmpty(againPwd)) {
            XToastUtils.showShortToast("请再次输入密码");
        } else if (!CheckUtils.equalsString(pwd, againPwd)) {
            XToastUtils.showShortToast("两次填写的密码不一致");
        } else if (CheckUtils.equalsString(mType, "1")) {//注册
            setPwdReg(MD5.md5(pwd));
        } else if (CheckUtils.equalsString(mType, "2")) {//忘记密码
            setPwdForget(MD5.md5(pwd));
        }
    }

    private void setPwdReg(String pwd) {
        LoginApiUtils.register(this, mPhone, pwd, new DialogCallback<Object>(this, "注册中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("注册成功");
                EventBus.getDefault().post(new EventManager(EventConstants.REGISTER_SUCCESS));
                finish();
            }
        });
    }

    private void setPwdForget(String pwd) {
        LoginApiUtils.forgetPwd(this, mPhone, pwd, new DialogCallback<Object>(this, "设置密码中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("密码设置成功,请重新登录");
                EventBus.getDefault().post(new EventManager(EventConstants.FORGETPWD_SUCCESS));
                finish();
            }
        });
    }
}

