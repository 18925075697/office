package com.dgzrdz.mobile.cocobee.utils;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;

/**
 * Created by Administrator on 2018/8/3.
 */

public class PermissionUtils {

    /**
     * 返回true表示已经有权限了
     * <p>
     * Activity使用
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    public static boolean requestPermission(Activity activity, String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(activity, permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(activity)
                        .setMessage(info)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(activity, new String[]{permissions}, requestCode);
                            }
                        })
                        .show();
            } else {
                ActivityCompat.requestPermissions(activity, new String[]{permissions}, requestCode);
            }
            return false;
        }

        return true;
    }

    /**
     * 返回true表示已经有权限了
     * Fragment使用
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    public static boolean requestPermission(Fragment fragment, String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(fragment.getActivity(), permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(fragment.getActivity(), permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(fragment.getActivity()).setMessage(info).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        fragment.requestPermissions(new String[]{permissions}, requestCode);
                    }
                }).show();
            } else {
                fragment.requestPermissions(new String[]{permissions}, requestCode);
            }
            return false;
        }
        return true;
    }

    /**
     * 判断用户是否点击过不再提醒
     *
     * @param
     * @param permission
     */
    public static void sureIfNotNotifiy(Activity activity, String permission, String msg, String toast) {
        //点击了不在提醒
        if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            new AlertDialog.Builder(activity)
                    .setMessage(msg)
                    .setPositiveButton("设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + activity.getPackageName()));
                            activity.startActivity(intent);
                        }
                    }).setNegativeButton("取消", null).create().show();
        } else {
            XToastUtils.showShortToast(toast);
        }
    }

}
