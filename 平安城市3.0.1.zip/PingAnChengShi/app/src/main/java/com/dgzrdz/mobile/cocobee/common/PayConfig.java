package com.dgzrdz.mobile.cocobee.common;

/**
 * Author: liu
 */
public class PayConfig {
    /**
     * 微信appId
     */
    public static final String WX_APP_ID = "wx396f22f90b6b9def";
}
