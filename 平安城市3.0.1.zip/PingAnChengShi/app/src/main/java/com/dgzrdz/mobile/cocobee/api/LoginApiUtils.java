package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.dgzrdz.mobile.cocobee.common.Path;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  登录注册
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class LoginApiUtils {
    /**
     * 登录
     *
     * @param context
     * @param memberAccount 帐号
     * @param memberPass    密码
     * @param callback      回调
     */
    public static void login(Context context, String memberAccount, String memberPass, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberAccount", memberAccount);
        params.put("memberPass", memberPass);
        OkGo.post(Path.LOGIIN_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 忘记密码 发送验证码
     *
     * @param context
     * @param mobile   手机号
     * @param callback 回调
     */
    public static void sendCheckCode(Context context, String mobile, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        OkGo.post(Path.GET_CHECK_CODE_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 忘记密码 验证验证码
     *
     * @param context
     * @param memberAccount 账号
     * @param memberNewPass 新密码
     * @param auth          验证码
     * @param callback      回调
     */
    public static void verificationCode(Context context, String memberAccount, String memberNewPass, String auth, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("memberAccount", memberAccount);
        params.put("memberNewPass", memberNewPass);
        params.put("auth", auth);
        OkGo.post(Path.CHECK_CHECK_CODE_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 忘记密码
     *
     * @param context
     * @param mobile   手机号
     * @param password 密码
     * @param callback 回调
     */
    public static void forgetPwd(Context context, String mobile, String password, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        params.put("password", password);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.FORGET_PWD_PATH).tag(context).upJson(jsonObject).execute(callback);
    }


    /**
     * 注册 发送验证码
     *
     * @param context
     * @param mobile   手机号
     * @param callback 回调
     */
    public static void sendCheckCodeReg(Context context, String mobile, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        OkGo.post(Path.GET_CHECK_CODE_REG_PATH).tag(context).params(params).execute(callback);
    }

    /**
     * 注册 验证验证码
     *
     * @param context
     * @param mobile   手机号
     * @param code     验证码
     * @param callback 回调
     */
    public static void verificationCodeReg(Context context, String mobile, String code, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        params.put("code", code);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.CHECK_CHECK_CODE_REG_PATH).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 注册
     *
     * @param context
     * @param mobile   手机号
     * @param password 密码
     * @param callback 回调
     */
    public static void register(Context context, String mobile, String password, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        params.put("password", password);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.REGISTER_PATH).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 意见反馈
     *
     * @param context
     * @param type        意见类型：1功能异常，体验问题，3新功能建议，其他
     * @param peopleid    反馈用户id
     * @param content     反馈内容
     * @param FeedbackUrl 反馈图片
     * @param creator     创建人
     * @param callback    回调
     */
    public static void ideaFeedBack(Context context, String type, String peopleid, String content, String FeedbackUrl, String creator, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("type", type);
        params.put("peopleid", peopleid);
        params.put("content", content);
        params.put("FeedbackUrl", FeedbackUrl);
        params.put("creator", creator);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.IDEA_BACK).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 修改密码
     *
     * @param context
     * @param appMemberId      登录人id
     * @param appMemberPass    旧密码
     * @param NewappMemberPass 新密码
     * @param callback         回调
     */
    public static void changePwd(Context context, String appMemberId, String appMemberPass, String NewappMemberPass, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appMemberId", appMemberId);
        params.put("appMemberPass", appMemberPass);
        params.put("NewappMemberPass", NewappMemberPass);
        OkGo.post(Path.CHENGE_PASSWORD).tag(context).params(params).execute(callback);
    }
}
