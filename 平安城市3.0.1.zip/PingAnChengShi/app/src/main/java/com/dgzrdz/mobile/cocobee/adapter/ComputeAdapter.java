package com.dgzrdz.mobile.cocobee.adapter;


import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.ComputeResponse;

import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2017/5/5
 * Time:  10:08
 */

public class ComputeAdapter extends QuickRcvAdapter<ComputeResponse> {

    public ComputeAdapter(Context context, List data, int... layoutId) {
        super(context, data, R.layout.item_car_type);
    }


    @Override
    protected void bindDataHelper(QuickRcvHolder viewHolder, int position, ComputeResponse item) {
        viewHolder.setText(R.id.tv_car_type,item.getSysGroupName());
    }
}
