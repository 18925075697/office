package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.dgzrdz.mobile.cocobee.adapter.InstallPointAdapter;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.InstallPointInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import okhttp3.Response;

/**
 * 安装点
 * Created by Administrator on 2018/6/21.
 */

public class InstallPointFragment extends RefreshAndLoadFragment<InstallPointInfoResponse> {
    private InstallPointAdapter mInstallPointAdapter;
    private static String code;

    public static InstallPointFragment getInstance(String code) {
        InstallPointFragment.code = code;
        InstallPointFragment fragment = new InstallPointFragment();
        return fragment;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        InstallPointInfoResponse installPointInfoResponse = mList.get(position);
        List<InstallPointInfoResponse.InstallerBean> installer = installPointInfoResponse.getInstaller();
        if (installer != null && installer.size() > 0) {
            start(InstallPointInfoFragment.getInstance(installer));
        } else {
            XToastUtils.showShortToast("该安装点暂无联系人");
        }
    }

    @Override
    public QuickRcvAdapter<InstallPointInfoResponse> getAdapter() {
        return mInstallPointAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
        loadDataList(1, true);
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        HomeApiUtils.getInstallPoint(getContext(), code, new RefreshAndLoadCallback<List<InstallPointInfoResponse>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<InstallPointInfoResponse> installPointInfoResponses, @Nullable Response response, LoadingViewCallback callback) {
                handleRefreshListData(callback, installPointInfoResponses, null);
            }

        });
    }

    @Override
    public void onLoadMore() {

    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mInstallPointAdapter = new InstallPointAdapter(_mActivity, mList);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("安装点");
    }


}
