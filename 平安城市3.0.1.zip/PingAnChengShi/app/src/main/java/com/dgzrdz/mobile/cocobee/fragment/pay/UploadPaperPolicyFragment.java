package com.dgzrdz.mobile.cocobee.fragment.pay;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.baoyz.actionsheet.ActionSheet;
import com.bql.utils.CheckUtils;
import com.bql.utils.ThreadPool;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.BindApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 上传纸质保单
 * Created by Administrator on 2018/5/2.
 */

public class UploadPaperPolicyFragment extends BaseFragment {
    private static final int PS_CAMERA_REQ = 1111;
    private static final int PS_STORAGE_REQ = 2222;
    private static final int RESULT_SUCESS = 33333;
    private static final int RESULT_ERROR = 4444;
    private static String cid;
    @BindView(R.id.iv_front)
    ImageView mIvFront;
    @BindView(R.id.iv_back)
    ImageView mIvBack;
    @BindView(R.id.tv_save)
    TextView mTvSave;
    private int camara_gallery = 0;// 1 拍照 2 相册
    private int pic_type = 0;// 1 正面 2 反面
    private String frontStr, backStr, frontStrBase64, backStrBase64;
    private UserInfo mUserLoginInfo;
    private SweetAlertDialog dialog;

    public static UploadPaperPolicyFragment getInstance(String cid) {
        UploadPaperPolicyFragment.cid = cid;
        UploadPaperPolicyFragment fragment = new UploadPaperPolicyFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        initDialog();
    }

    private void initDialog() {
        dialog = new SweetAlertDialog(_mActivity, SweetAlertDialog.PROGRESS_TYPE);
        dialog.setTitleText("保单上传中...");
        dialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("上传保单照片");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_upload_paper_policy;
    }

    @OnClick({R.id.iv_front, R.id.iv_back, R.id.tv_save})
    public void onViewClicked(View view) {
        if (!Utils.isFastClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.iv_front://正面照
                pic_type = 1;
                showPicSelect();
                break;
            case R.id.iv_back://背面照
                pic_type = 2;
                showPicSelect();
                break;
            case R.id.tv_save://保存
                save();
                break;
        }
    }

    /**
     * 保存
     */
    private void save() {
        if (CheckUtils.isEmpty(frontStr)) {
            XToastUtils.showShortToast("请上传正面照");
        } else if (CheckUtils.isEmpty(backStr)) {
            XToastUtils.showShortToast("请上传反面照");
        } else if (!CheckUtils.isEmpty(frontStrBase64) && !CheckUtils.isEmpty(backStrBase64)) {//解码完成直接上传
            upload();
        } else {//还未解码完成,先解码后上传
            showDialog();
            ThreadPool.runOnWorker(new Runnable() {
                @Override
                public void run() {
                    while (CheckUtils.isEmpty(frontStrBase64) || CheckUtils.isEmpty(backStrBase64)) {
                    }
                    uploadLater();
                }
            });
        }
    }

    /**
     * 直接上传
     */
    private void upload() {
        BindApiUtils.uploadPaperPolicy(_mActivity, cid, mUserLoginInfo.getDataList().getAppMemberName(), frontStrBase64, backStrBase64, new DialogCallback<Object>(_mActivity, "保单上传中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("上传成功");
                _mActivity.finish();
            }
        });
    }

    /**
     * 上传
     */
    private void uploadLater() {
        BindApiUtils.uploadPaperPolicy(_mActivity, cid, mUserLoginInfo.getDataList().getAppMemberName(), frontStrBase64, backStrBase64, new JsonCallback<Object>(_mActivity) {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                handler.sendEmptyMessage(RESULT_SUCESS);
                _mActivity.finish();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                handler.sendEmptyMessage(RESULT_ERROR);
            }
        });
    }

    /**
     * 显示拍照选择
     */
    private void showPicSelect() {
        ActionSheet.createBuilder(_mActivity, getFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("打开相册(Open Gallery)", "拍照(Camera)")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                camara_gallery = 2;
                                if (requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openGallerySingle(PS_STORAGE_REQ, mOnHanlderResultCallback);
                                }
                                break;
                            case 1:
                                camara_gallery = 1;
                                String[] permissions = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                                if (requestPermission(permissions[0], PS_CAMERA_REQ, "权限申请：\n我们需要您开启拍照权限") && requestPermission(permissions[1], PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openCamera(PS_CAMERA_REQ, mOnHanlderResultCallback);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }).show();
    }


    private GalleryFinal.OnHanlderResultCallback mOnHanlderResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
            if (resultList != null) {
                switch (pic_type) {
                    case 1://正面
                        frontStr = resultList.get(0).getPhotoPath();
                        base64Pic(frontStr);
                        ImageUtil.loadPaperPicCommen(_mActivity, frontStr, mIvFront);
                        break;
                    case 2://反面
                        backStr = resultList.get(0).getPhotoPath();
                        base64Pic(backStr);
                        ImageUtil.loadPaperPicCommen(_mActivity, backStr, mIvBack);
                        break;
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            XToastUtils.showShortToast(errorMsg);
        }
    };

    /**
     * base64图片
     *
     * @param str
     */
    private void base64Pic(String str) {
        ThreadPool.runOnWorker(new Runnable() {
            @Override
            public void run() {
                switch (pic_type) {
                    case 1:
                        frontStrBase64 = Utils.base64Pic(_mActivity, str);
                        break;
                    case 2:
                        backStrBase64 = Utils.base64Pic(_mActivity, str);
                        break;
                }
            }
        });
    }

    /**
     * 返回true表示已经有权限了
     *
     * @param permissions
     * @param requestCode
     * @return
     */
    private boolean requestPermission(String permissions, int requestCode, String info) {
    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
        if (ContextCompat.checkSelfPermission(_mActivity, permissions) != PackageManager.PERMISSION_GRANTED) {
            //进入到这里代表没有获取权限
            if (ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permissions)) {
                //用户拒绝授权
                new AlertDialog.Builder(_mActivity)
                        .setMessage(info)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(new String[]{permissions}, requestCode);
                            }
                        })
                        .show();
            } else {
                requestPermissions(new String[]{permissions}, requestCode);
            }
            return false;
        }
        return true;
    }

    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PS_CAMERA_REQ:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                        GalleryFinal.openCamera(PS_STORAGE_REQ, mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启拍照权限,是否去设置?", "用户拒绝拍照授权");
                }
                break;
            case PS_STORAGE_REQ:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (camara_gallery == 1) {
                        if (requestPermission(Manifest.permission.CAMERA, PS_CAMERA_REQ, "权限申请：\n我们需要您开启拍照权限")) {
                            GalleryFinal.openCamera(PS_CAMERA_REQ, mOnHanlderResultCallback);
                        }
                    } else if (camara_gallery == 2) {
                        GalleryFinal.openGallerySingle(PS_STORAGE_REQ, mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    sureIfNotNotifiy(permissions[0], "app需要开启设备存储权限,是否去设置?", "用户拒绝设备存储授权");
                }
                break;
        }
    }

    /**
     * 判断用户是否点击过不再提醒
     *
     * @param
     * @param permission
     */
    private void sureIfNotNotifiy(String permission, String msg, String toast) {
        //点击了不在提醒
        if (!ActivityCompat.shouldShowRequestPermissionRationale(_mActivity, permission)) {
            new AlertDialog.Builder(_mActivity)
                    .setMessage(msg)
                    .setPositiveButton("设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + _mActivity.getPackageName()));
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .create()
                    .show();
        } else {
            XToastUtils.showShortToast(toast);
        }
    }

    private void dismissDialog() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    private void showDialog() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            dismissDialog();
            switch (msg.what) {
                case RESULT_SUCESS:
                    //网络请求结束后关闭对话框
                    XToastUtils.showShortToast("上传成功");
                    break;
                case RESULT_ERROR:
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void onDestroy() {
        dismissDialog();
        mOnHanlderResultCallback = null;
        super.onDestroy();
    }
}
