package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/5/10.
 */

public class ManagerResponse implements Serializable{

    public ManagerResponse(String name, String permissionValue, int drawableRes) {
        this.name = name;
        this.permissionValue = permissionValue;
        this.uri = drawableRes;
    }

    /**
     * icon : sss
     * id : 431n32421hjn3io21j37o213
     * name : 链接设备
     * permissionValue : Linkingdevice
     * uri : sss
     */

    private String icon;
    private String id;
    private String name;
    private String permissionValue;
    private int uri;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPermissionValue() {
        return permissionValue;
    }

    public void setPermissionValue(String permissionValue) {
        this.permissionValue = permissionValue;
    }

    public int getUri() {
        return uri;
    }

    public void setUri(int uri) {
        this.uri = uri;
    }
}
