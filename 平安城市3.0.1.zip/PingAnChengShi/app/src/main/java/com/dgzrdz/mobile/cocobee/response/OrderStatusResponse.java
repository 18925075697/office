package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/27
 * Time:  14:31
 */

public class OrderStatusResponse implements Serializable {

    /**
     * hLabelNo : 20181101
     * sysInsuranceValuer : [{"sysInsuranceExpiredTime":"2019-11-07 16:00:00","appMemberId":"1","sysInsuranceValueId":"1","sysInstallPlaceId":"2","sysAreaId":"12","sysInsuranceConfYears":"1","sysServiceTypeId":"1","sysInsurancePrice":"100.00","sysInsuranceActiveTime":"2018-11-07 16:00:00","sysInsuranceAddTime":"2018-11-07 16:00:00","dataId":"6","sysInsuranceConfPriceId":"0","sysInsuranceTypeId":"1","sysInsuranceProcess":"2","sysCityId":"1","sysInsuranceTypeName":"三责险","memberServiceObjId":"8","sysInsuranceId":"1"},{"sysInsuranceExpiredTime":"2020-11-07 16:00:00","appMemberId":"1","sysInsuranceValueId":"2","sysInstallPlaceId":"2","sysAreaId":"12","sysInsuranceConfYears":"2","sysServiceTypeId":"1","sysInsurancePrice":"300.00","sysInsuranceActiveTime":"2018-11-07 16:00:00","sysInsuranceAddTime":"2018-11-07 16:00:00","dataId":"6","sysInsuranceConfPriceId":"0","sysInsuranceTypeId":"1","sysInsuranceProcess":"2","sysCityId":"1","sysInsuranceTypeName":"盗抢险","memberServiceObjId":"8","sysInsuranceId":"1"}]
     * memberOrderTotalPay : 100.00
     * memberOrderId : 6
     * memberName : ck
     * memberServiceObjNumber : 火车站街M145678135
     * memberAccount : 13242967410
     * sysServiceTypeName : 老人
     */

    private String hLabelNo;//标签
    private double memberOrderTotalPay;//总金额
    private String memberOrderId;//用户订单ID
    private String memberName;//真实姓名
    private String memberServiceObjNumber;//车牌号
    private String memberAccount;//用户手机号
    private String sysServiceTypeName;//对象类型
    private String memberOrderProcess;//订单状态\n1 下单成功，待付款\n2 已付款\n3 已取消\n4 已过期
    private String memberOrderAddTime;//订单生成时间
    private String memberOrderType;//订单类型
    private String memberOrderNo;//订单号
    private String sysPropertyValueStr;//对象属性值，排序第一个值
    private String timeNow;//服务器时间
    private String sysServiceSetYears;//标签年限
    private String memberServiceObjId;//服务 对象id
    private String paymentTime;//支付时间
    private List<SysInsuranceValuerBean> sysInsuranceValuer;

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public String getSysServiceSetYears() {
        return sysServiceSetYears;
    }

    public void setSysServiceSetYears(String sysServiceSetYears) {
        this.sysServiceSetYears = sysServiceSetYears;
    }

    public String getTimeNow() {
        return timeNow;
    }

    public void setTimeNow(String timeNow) {
        this.timeNow = timeNow;
    }

    public String getMemberOrderAddTime() {
        return memberOrderAddTime;
    }

    public void setMemberOrderAddTime(String memberOrderAddTime) {
        this.memberOrderAddTime = memberOrderAddTime;
    }

    public String getMemberOrderType() {
        return memberOrderType;
    }

    public void setMemberOrderType(String memberOrderType) {
        this.memberOrderType = memberOrderType;
    }

    public String getMemberOrderNo() {
        return memberOrderNo;
    }

    public void setMemberOrderNo(String memberOrderNo) {
        this.memberOrderNo = memberOrderNo;
    }

    public String getSysPropertyValueStr() {
        return sysPropertyValueStr;
    }

    public void setSysPropertyValueStr(String sysPropertyValueStr) {
        this.sysPropertyValueStr = sysPropertyValueStr;
    }

    public String getMemberOrderProcess() {
        return memberOrderProcess;
    }

    public void setMemberOrderProcess(String memberOrderProcess) {
        this.memberOrderProcess = memberOrderProcess;
    }

    public String getHLabelNo() {
        return hLabelNo;
    }

    public void setHLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }

    public double getMemberOrderTotalPay() {
        return memberOrderTotalPay;
    }

    public void setMemberOrderTotalPay(double memberOrderTotalPay) {
        this.memberOrderTotalPay = memberOrderTotalPay;
    }

    public String getMemberOrderId() {
        return memberOrderId;
    }

    public void setMemberOrderId(String memberOrderId) {
        this.memberOrderId = memberOrderId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberServiceObjNumber() {
        return memberServiceObjNumber;
    }

    public void setMemberServiceObjNumber(String memberServiceObjNumber) {
        this.memberServiceObjNumber = memberServiceObjNumber;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }

    public List<SysInsuranceValuerBean> getSysInsuranceValuer() {
        return sysInsuranceValuer;
    }

    public void setSysInsuranceValuer(List<SysInsuranceValuerBean> sysInsuranceValuer) {
        this.sysInsuranceValuer = sysInsuranceValuer;
    }

    public static class SysInsuranceValuerBean implements Serializable {
        /**
         * sysInsuranceExpiredTime : 2019-11-07 16:00:00
         * appMemberId : 1
         * sysInsuranceValueId : 1
         * sysInstallPlaceId : 2
         * sysAreaId : 12
         * sysInsuranceConfYears : 1
         * sysServiceTypeId : 1
         * sysInsurancePrice : 100.00
         * sysInsuranceActiveTime : 2018-11-07 16:00:00
         * sysInsuranceAddTime : 2018-11-07 16:00:00
         * dataId : 6
         * sysInsuranceConfPriceId : 0
         * sysInsuranceTypeId : 1
         * sysInsuranceProcess : 2
         * sysCityId : 1
         * sysInsuranceTypeName : 三责险
         * memberServiceObjId : 8
         * sysInsuranceId : 1
         */

        private String sysInsuranceExpiredTime;//过期时间
        private String appMemberId;//App报单人
        private String sysInsuranceValueId;//保险套餐id
        private String sysInstallPlaceId;//安装点
        private String sysAreaId;//机构id
        private String sysInsuranceConfYears;//年限
        private String sysServiceTypeId;//服务类型id
        private String sysInsurancePrice;//价格
        private String sysInsuranceActiveTime;//激活时间
        private String sysInsuranceAddTime;//添加时间
        private String dataId;//对应订单id
        private String sysInsuranceConfPriceId;//保险t套餐配置表id
        private String sysInsuranceTypeId;//险种id
        private String sysInsuranceProcess;//订单状态\n1 下单成功，待付款\n2 已付款\n3 已取消\n4 已过期
        private String sysCityId;//行政区
        private String sysInsuranceTypeName;//险种名称
        private String memberServiceObjId;//服务对象ID
        private String sysInsuranceId;//保险公司id

        public String getSysInsuranceExpiredTime() {
            return sysInsuranceExpiredTime;
        }

        public void setSysInsuranceExpiredTime(String sysInsuranceExpiredTime) {
            this.sysInsuranceExpiredTime = sysInsuranceExpiredTime;
        }

        public String getAppMemberId() {
            return appMemberId;
        }

        public void setAppMemberId(String appMemberId) {
            this.appMemberId = appMemberId;
        }

        public String getSysInsuranceValueId() {
            return sysInsuranceValueId;
        }

        public void setSysInsuranceValueId(String sysInsuranceValueId) {
            this.sysInsuranceValueId = sysInsuranceValueId;
        }

        public String getSysInstallPlaceId() {
            return sysInstallPlaceId;
        }

        public void setSysInstallPlaceId(String sysInstallPlaceId) {
            this.sysInstallPlaceId = sysInstallPlaceId;
        }

        public String getSysAreaId() {
            return sysAreaId;
        }

        public void setSysAreaId(String sysAreaId) {
            this.sysAreaId = sysAreaId;
        }

        public String getSysInsuranceConfYears() {
            return sysInsuranceConfYears;
        }

        public void setSysInsuranceConfYears(String sysInsuranceConfYears) {
            this.sysInsuranceConfYears = sysInsuranceConfYears;
        }

        public String getSysServiceTypeId() {
            return sysServiceTypeId;
        }

        public void setSysServiceTypeId(String sysServiceTypeId) {
            this.sysServiceTypeId = sysServiceTypeId;
        }

        public String getSysInsurancePrice() {
            return sysInsurancePrice;
        }

        public void setSysInsurancePrice(String sysInsurancePrice) {
            this.sysInsurancePrice = sysInsurancePrice;
        }

        public String getSysInsuranceActiveTime() {
            return sysInsuranceActiveTime;
        }

        public void setSysInsuranceActiveTime(String sysInsuranceActiveTime) {
            this.sysInsuranceActiveTime = sysInsuranceActiveTime;
        }

        public String getSysInsuranceAddTime() {
            return sysInsuranceAddTime;
        }

        public void setSysInsuranceAddTime(String sysInsuranceAddTime) {
            this.sysInsuranceAddTime = sysInsuranceAddTime;
        }

        public String getDataId() {
            return dataId;
        }

        public void setDataId(String dataId) {
            this.dataId = dataId;
        }

        public String getSysInsuranceConfPriceId() {
            return sysInsuranceConfPriceId;
        }

        public void setSysInsuranceConfPriceId(String sysInsuranceConfPriceId) {
            this.sysInsuranceConfPriceId = sysInsuranceConfPriceId;
        }

        public String getSysInsuranceTypeId() {
            return sysInsuranceTypeId;
        }

        public void setSysInsuranceTypeId(String sysInsuranceTypeId) {
            this.sysInsuranceTypeId = sysInsuranceTypeId;
        }

        public String getSysInsuranceProcess() {
            return sysInsuranceProcess;
        }

        public void setSysInsuranceProcess(String sysInsuranceProcess) {
            this.sysInsuranceProcess = sysInsuranceProcess;
        }

        public String getSysCityId() {
            return sysCityId;
        }

        public void setSysCityId(String sysCityId) {
            this.sysCityId = sysCityId;
        }

        public String getSysInsuranceTypeName() {
            return sysInsuranceTypeName;
        }

        public void setSysInsuranceTypeName(String sysInsuranceTypeName) {
            this.sysInsuranceTypeName = sysInsuranceTypeName;
        }

        public String getMemberServiceObjId() {
            return memberServiceObjId;
        }

        public void setMemberServiceObjId(String memberServiceObjId) {
            this.memberServiceObjId = memberServiceObjId;
        }

        public String getSysInsuranceId() {
            return sysInsuranceId;
        }

        public void setSysInsuranceId(String sysInsuranceId) {
            this.sysInsuranceId = sysInsuranceId;
        }
    }
}
