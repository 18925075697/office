package com.dgzrdz.mobile.cocobee.activity.register;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.LoginApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.TimeCount;
import com.lzy.okgo.OkGo;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 忘记密码页面
 * Created by _H_JY on 2017/3/14.
 */
public class ForgetPwdActivity extends BaseToolbarActivity {

    @BindView(R.id.phone_et)
    EditText mPhoneEt;
    @BindView(R.id.check_code_et)
    EditText mCheckCodeEt;
    @BindView(R.id.get_checkcode_btn)
    TextView mGetCheckcodeBtn;
    @BindView(R.id.et_new_pwd)
    EditText mEtNewPwd;
    @BindView(R.id.sure_btn)
    TextView mSureBtn;

    private TimeCount timeCount;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_forget_pwd;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("找回密码");
        timeCount = new TimeCount(this, 60000, 1000, mGetCheckcodeBtn);
    }

    /**
     * 获取验证码
     */
    private void getCheckCode() {
        String phone = mPhoneEt.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            XToastUtils.showShortToast("请填写手机号码");
            return;
        }

        if (!CheckUtils.isMobilePhone(phone)) {
            XToastUtils.showShortToast("手机号码格式不正确");
            return;
        }

        LoginApiUtils.sendCheckCode(this, phone, new DialogCallback<Object>(this, "获取验证码...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                timeCount.start();
            }
        });
    }

    private void sure() {
        String phone = mPhoneEt.getText().toString().trim();
        String checkCode = mCheckCodeEt.getText().toString().trim();
        String newPwd = mEtNewPwd.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            XToastUtils.showShortToast("请填写手机号码");
            return;
        } else if (!CheckUtils.isMobilePhone(phone)) {
            XToastUtils.showShortToast("手机号码格式不正确");
            return;
        } else if (TextUtils.isEmpty(checkCode)) {
            XToastUtils.showShortToast("请填写验证码");
            return;
        } else if (CheckUtils.isEmpty(newPwd)) {
            XToastUtils.showShortToast("请输入新密码");
            return;
        }
        LoginApiUtils.verificationCode(this, phone, newPwd, checkCode, new DialogCallback<Object>(this, "正在验证...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast(msg);
                finish();
            }
        });
    }

    @OnClick({R.id.get_checkcode_btn, R.id.sure_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.get_checkcode_btn:
                getCheckCode();
                break;
            case R.id.sure_btn:
                sure();
                break;
        }
    }

    private void stopCountTimer() {
        if (timeCount != null) {
            timeCount.cancel();
            timeCount = null;
        }
    }

    @Override
    protected void onDestroy() {
        stopCountTimer();
        OkGo.getInstance().cancelTag(this);
        super.onDestroy();
    }
}
