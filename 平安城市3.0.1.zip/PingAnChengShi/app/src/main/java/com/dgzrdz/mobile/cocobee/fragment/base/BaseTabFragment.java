package com.dgzrdz.mobile.cocobee.fragment.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.View;

import com.bql.tablayout.SlidingTabLayout;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.MyPagerAdapter;
import com.dgzrdz.mobile.cocobee.view.CustomViewPager;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * ClassName: BaseTabFragment <br>
 * Description: Tab切换的Fragment 继承自 {@link BaseFragment}<br>
 * Author: Cyarie <br>
 * Created: 2016/7/18 14:37 <br>
 * Update Time：<br>
 * Update Description：<br>
 */
public abstract class BaseTabFragment extends BaseFragment implements SlidingTabLayout.OnViewPageSelected {

    @BindView(R.id.sliding_tab)
    public SlidingTabLayout mSlidingTab;
    @BindView(R.id.viewpager)
    public CustomViewPager mViewpager;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initSlidingTab();
    }

    /**
     * 初始化SlidingTab
     */
    public void initSlidingTab() {
        if (mSlidingTab == null || mViewpager == null) {
            throw new IllegalArgumentException("SlidingTabLayout or ViewPager cannot be null");
        }
        mViewpager.setPagingEnabled(canScroll());
        mViewpager.setOffscreenPageLimit(getInitPageNum());
        mSlidingTab.setTabSpaceEqual(isTabSpaceEqual());
        mViewpager.setAdapter(new MyPagerAdapter(getChildFragmentManager(),getFragments(),getTabTitles()));
        mSlidingTab.setViewPager(mViewpager);
        mSlidingTab.setOnViewPageSelected(this);

    }
    public boolean canScroll() {
        return true;
    }

    public boolean isTabSpaceEqual() {
        return true;
    }

    /**
     * 获取Tab标题
     *
     * @return
     */
    public abstract String[] getTabTitles();

    /**
     * 获取Fragments集合
     *
     * @return
     */
    public abstract ArrayList<Fragment> getFragments();

    /**
     * 初始化的页数 默认为1
     *
     * @return
     */
    public int getInitPageNum() {
        return 2;
    }

    @Override
    public void onViewPageSelected(int position) {

    }
}
