package com.dgzrdz.mobile.cocobee.activity.data;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.baoyz.actionsheet.ActionSheet;
import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.bql.utils.ThreadPool;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.adapter.JianhuObjectUnArcXialaAdapter;
import com.dgzrdz.mobile.cocobee.adapter.PicDetailAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectDetailResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.SysPropertyOptionListBean;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;
import com.jzxiang.pickerview.TimePickerDialog;
import com.jzxiang.pickerview.data.Type;
import com.jzxiang.pickerview.listener.OnDateSetListener;

import org.greenrobot.eventbus.EventBus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 未激活状态的监护对象详情支持修改,删除
 * Created by admin on 2018/4/19.
 */

public class JianHuObjectUnArcActivity extends BaseToolbarActivity implements OnDateSetListener {
    @BindView(R.id.ll_info)
    LinearLayout mLlInfo;
    @BindView(R.id.tv_car_type)
    TextView mTvCarType;
    private static final int PS_CAMERA_REQ = 1111;
    private static final int PS_STORAGE_REQ = 2222;
    private static final int RESULT_SUCESS = 33333;
    private static final int RESULT_ERROR = 4444;
    private int camara_gallery = 0;// 1 拍照 2 相册

    long tenYears = 10L * 365 * 1000 * 60 * 60 * 24L;
    private TimePickerDialog mDialogAll;
    private UserInfo mUserLoginInfo;
    private UserBeanResponse mUserBeanResponse;
    private SweetAlertDialog dialog;
    private int timeClickPosition;
    private int picClickPosition;
    private int xiaLaClickPosition;
    private List<GuardianObjectDetailResponse.CustomizeBean> picList = new ArrayList<>();//图片属性集合
    private List<GuardianObjectDetailResponse.CustomizeBean> valueList = new ArrayList<>();//正常属性集合
    private PicDetailAdapter mPicAdapter;
    private List<GuardianObjectDetailResponse.CustomizeBean> uploadList = new ArrayList<GuardianObjectDetailResponse.CustomizeBean>();
    private GuardianObjectResponse mGuardianObjectResponse;
    private GuardianObjectDetailResponse mGuardianObjectDetailResponse;
    private boolean mIsSelect;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_jian_hu_object;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initIntent();
        if (mIsSelect) {//选择页面过来的不支持删除
            initToolbar("状态:未激活");
        } else {
            initToolbarWithRightDrawable("状态:未激活", R.drawable.search_clear);
        }
        initTimePick();
        mUserLoginInfo = Utils.getUserLoginInfo();
        getJianhuDetail();
    }

    /**
     * 获取监护对象详情
     */
    private void getJianhuDetail() {
        DatasApiUtils.getJianhuDetail(this, mGuardianObjectResponse.getMemberServiceObjId(), new DialogCallback<GuardianObjectDetailResponse>(this, "获取监护对象详情...") {
            @Override
            public void onSuccess(GuardianObjectDetailResponse guardianObjectDetailResponse, Call call, Response response) {
                if (guardianObjectDetailResponse != null) {
                    mGuardianObjectDetailResponse = guardianObjectDetailResponse;
                    mTvCarType.setText(guardianObjectDetailResponse.getSysServiceTypeName());
                    mTvCarType.setCompoundDrawables(null, null, null, null);

                    picList.clear();
                    valueList.clear();
                    getValueList(guardianObjectDetailResponse.getCustomize());
                } else {
                    XToastUtils.showShortToast("暂无信息");
                }
            }
        });
    }

    /**
     * 获取用户输入选择的值
     *
     * @param type     属性类型1.文本输入框,2数字+点号（价格）,3日期格式,4图片文件,5下拉框选择输入
     * @param position 子view的位置
     * @return
     */
    private String getInputInfo(int type, int position) {

        LinearLayout linearLayout = (LinearLayout) mLlInfo.getChildAt(position);
        String string = "";
        switch (type) {
            case 1:
            case 2:
                EditText editText = (EditText) linearLayout.getChildAt(2);
                string = editText.getText().toString().trim();
                break;
            case 3:
            case 5:
                TextView textView = (TextView) linearLayout.getChildAt(2);
                string = textView.getText().toString().trim();
                break;
        }
        return string;
    }

    /**
     * 添加下拉选择模式控件
     *
     * @param customizeBean
     * @param position      子控件的位置
     */
    private void addXialaView(GuardianObjectDetailResponse.CustomizeBean customizeBean, int position) {
        View view = View.inflate(this, R.layout.xia_la_view, null);
        TextView tvMustXiala = (TextView) view.findViewById(R.id.tv_must_xia_la);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        TextView tvSelect = (TextView) view.findViewById(R.id.tv_select);
        tvSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<SysPropertyOptionListBean> sysPropertyOptionList = customizeBean.getSysPropertyOptionList();
                if (sysPropertyOptionList != null && sysPropertyOptionList.size() > 10) {
                    xiaLaClickPosition = position;
                    Intent intent = new Intent(JianHuObjectUnArcActivity.this, CarBrandActivity.class);
                    intent.putExtra("sysPropertyOptionList", (Serializable) sysPropertyOptionList);
                    intent.putExtra("title",customizeBean.getSysPropertyName());
                    startActivity(intent);
                } else {
                    showCarColorDialog(customizeBean.getSysPropertyOptionList(), tvSelect);
                }
            }
        });

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);

        tvTitle.setText(customizeBean.getSysPropertyName());
        tvSelect.setText(customizeBean.getSysPropertyValue());
        if (CheckUtils.equalsString(customizeBean.getSysPropertyRequired(), "1")) {//必填
            tvMustXiala.setVisibility(View.VISIBLE);
        } else {
            tvMustXiala.setVisibility(View.GONE);
        }
    }

    /**
     * 添加文本输入模式控件
     *
     * @param objectValueResponse
     * @param position            子控件的位置
     */
    private void addTextView(GuardianObjectDetailResponse.CustomizeBean objectValueResponse, int position) {
        View view = View.inflate(this, R.layout.text_view, null);
        TextView tvMustText = (TextView) view.findViewById(R.id.tv_must_text);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        EditText etText = (EditText) view.findViewById(R.id.et_text);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);

        tvTextTitle.setText(objectValueResponse.getSysPropertyName());
        etText.setText(objectValueResponse.getSysPropertyValue());
        if (CheckUtils.equalsString(objectValueResponse.getSysPropertyRequired(), "1")) {//必填
            tvMustText.setVisibility(View.VISIBLE);
        } else {
            tvMustText.setVisibility(View.GONE);
        }


    }

    /**
     * 添加日期模式控件
     *
     * @param objectValueResponse
     * @param position            子控件的位置
     */
    private void addDateView(GuardianObjectDetailResponse.CustomizeBean objectValueResponse, int position) {
        View view = View.inflate(this, R.layout.date_view, null);
        TextView tvMustDate = (TextView) view.findViewById(R.id.tv_must_date);
        TextView tvTime = (TextView) view.findViewById(R.id.tv_time);
        TextView tvSelectTime = (TextView) view.findViewById(R.id.tv_select_time);

        tvSelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mDialogAll.isAdded()) {
                    mDialogAll.show(getSupportFragmentManager(), "all");
                    timeClickPosition = position;
                }
            }
        });

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);

        tvTime.setText(objectValueResponse.getSysPropertyName());
        tvSelectTime.setText(objectValueResponse.getSysPropertyValue());
        if (CheckUtils.equalsString(objectValueResponse.getSysPropertyRequired(), "1")) {//必填
            tvMustDate.setVisibility(View.VISIBLE);
        } else {
            tvMustDate.setVisibility(View.GONE);
        }
    }

    /**
     * 添加图片列表模式控件
     */
    private void addPicView() {
        View view = View.inflate(this, R.layout.pic_list_view, null);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycle_view);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));

        mPicAdapter = new PicDetailAdapter(this, picList);
        recyclerView.setAdapter(mPicAdapter);
        mPicAdapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH bh, int i) {
                showPicSelect(i);
            }
        });

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);
    }

    /**
     * 添加数字输入模式控件
     *
     * @param objectValueResponse
     * @param position            子控件的位置
     */
    private void addNumView(GuardianObjectDetailResponse.CustomizeBean objectValueResponse, int position) {
        View view = View.inflate(this, R.layout.num_view, null);
        TextView tvMustNum = (TextView) view.findViewById(R.id.tv_must_num);
        TextView tvNumTitle = (TextView) view.findViewById(R.id.tv_num_title);
        EditText etNum = (EditText) view.findViewById(R.id.et_num);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlInfo.addView(view, layoutParams);

        tvNumTitle.setText(objectValueResponse.getSysPropertyName());
        etNum.setText(objectValueResponse.getSysPropertyValue());
        if (CheckUtils.equalsString(objectValueResponse.getSysPropertyRequired(), "1")) {//必填
            tvMustNum.setVisibility(View.VISIBLE);
        } else {
            tvMustNum.setVisibility(View.GONE);
        }

    }

    private void initDialog() {
        dialog = new SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        dialog.setTitleText("修改监护对象信息中...");
        dialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
    }

    private void initIntent() {
        Intent intent = getIntent();
        mUserBeanResponse = (UserBeanResponse) intent.getSerializableExtra("userBean");
        mGuardianObjectResponse = (GuardianObjectResponse) intent.getSerializableExtra("guardianObjectResponse");
        mIsSelect = intent.getBooleanExtra("isSelect", false);
    }

    /**
     * 初始化TimePick
     */
    private void initTimePick() {
        mDialogAll = new TimePickerDialog.Builder()
                .setCallBack(this)
                .setCancelStringId("取消")
                .setSureStringId("确定")
                .setTitleStringId("请选择时间")
                .setYearText("年")
                .setMonthText("月")
                .setDayText("日")
                .setCyclic(false)
                .setMinMillseconds(System.currentTimeMillis() - 15 * tenYears) //当前时间减去一百五十年
                .setMaxMillseconds(System.currentTimeMillis())
                .setCurrentMillseconds(System.currentTimeMillis())
                .setThemeColor(getResources().getColor(R.color.timepicker_dialog_bg))
                .setType(Type.YEAR_MONTH_DAY)
                .setWheelItemTextNormalColor(getResources().getColor(R.color.timetimepicker_default_text_color))
                .setWheelItemTextSelectorColor(getResources().getColor(R.color.timepicker_toolbar_bg))
                .setWheelItemTextSize(12)
                .build();
    }

    @Override
    public void onDateSet(TimePickerDialog timePickerView, long millseconds) {
        LinearLayout childAt = (LinearLayout) mLlInfo.getChildAt(timeClickPosition);
        TextView textView = (TextView) childAt.getChildAt(2);
        textView.setText(Utils.getDateToString(millseconds));
    }


    @OnClick({R.id.tv_save_car_info})
    public void onViewClicked(View view) {
        //防止一秒内点击多次
        if (!Utils.isFastClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_save_car_info://保存
                uploadList.clear();
                boolean isInput = false;
                //最少天一项才能通过
                for (int i = 0; i < valueList.size(); i++) {
                    GuardianObjectDetailResponse.CustomizeBean customizeBean = valueList.get(i);
                    int sysPropertyInputType = customizeBean.getSysPropertyInputType();
                    String inputInfo = getInputInfo(sysPropertyInputType, i + 1);
                    if (!CheckUtils.isEmpty(inputInfo)) {//已经填了
                        isInput = true;
                    }
                }
                if (!isInput) {//一项都没有填
                    XToastUtils.showShortToast("请至少填写一项");
                    return;
                }
                //获取上传集合
                for (int i = 0; i < valueList.size(); i++) {
                    GuardianObjectDetailResponse.CustomizeBean customizeBean = valueList.get(i);
                    int sysPropertyInputType = customizeBean.getSysPropertyInputType();
                    String inputInfo = getInputInfo(sysPropertyInputType, i + 1);
                    if (customizeBean.getSysPropertyInputType() == 5) {//下拉选择,传选中的id
                        List<SysPropertyOptionListBean> sysPropertyOptionList = customizeBean.getSysPropertyOptionList();
                        for (int j = 0; j < sysPropertyOptionList.size(); j++) {
                            SysPropertyOptionListBean sysPropertyOptionListBean = sysPropertyOptionList.get(j);
                            if (CheckUtils.equalsString(sysPropertyOptionListBean.getSysPropertyOptionValue(), inputInfo)) {
                                customizeBean.setSysPropertyOptionId(sysPropertyOptionListBean.getSysPropertyOptionId());
                                customizeBean.setSysPropertyId(sysPropertyOptionListBean.getSysPropertyId());
                                customizeBean.setSysPropertyValue(sysPropertyOptionListBean.getSysPropertyOptionValue());
                            }
                        }
                    } else {//传填写的值
                        customizeBean.setSysPropertyValue(inputInfo);
                    }
                    uploadList.add(customizeBean);
                }

                showWornDialog();
                break;
        }
    }

    @Override
    public void btnRightImageClick() {
        showDelDialog();
    }

    /**
     * 删除提示框
     */
    private void showDelDialog() {
        SweetAlertDialog continueDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        continueDialog.setTitleText("确定删除该对象吗");
        continueDialog.showCancelButton(true).setCancelText("否");
        continueDialog.setConfirmText("是");
        continueDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();
                //删除
                deleteObject();
            }
        });

        continueDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismiss();
            }
        });
        continueDialog.show();
    }

    /**
     * 删除对应的监护对象
     */
    private void deleteObject() {
        HomeApiUtils.deleteObject(this, mGuardianObjectDetailResponse.getMemberServiceObjId(), new DialogCallback<Object>(this, "删除中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("删除成功");
                EventBus.getDefault().post(new EventManager(EventConstants.DELETE_CAR_INFO_SUCCESS));
                finish();
            }
        });
    }

    /**
     * 获取属性和图片属性的集合
     *
     * @param customizeBeans
     */
    private void getValueList(List<GuardianObjectDetailResponse.CustomizeBean> customizeBeans) {
        for (int i = 0; i < customizeBeans.size(); i++) {
            GuardianObjectDetailResponse.CustomizeBean customizeBean = customizeBeans.get(i);
            int sysPropertyInputType = customizeBean.getSysPropertyInputType();
            if (sysPropertyInputType == 4) {//图片样式
                picList.add(customizeBean);
            } else {
                valueList.add(customizeBean);
            }
        }

        if (valueList.size() > 0) {
            setValue(valueList);
        }
        if (picList.size() > 0) {
            addPicView();
        }
    }

    /**
     * 设置属性
     *
     * @param customizeBeans
     */
    private void setValue(List<GuardianObjectDetailResponse.CustomizeBean> customizeBeans) {
        for (int i = 0; i < customizeBeans.size(); i++) {
            GuardianObjectDetailResponse.CustomizeBean customizeBean = customizeBeans.get(i);
            int sysPropertyInputType = customizeBean.getSysPropertyInputType();
            if (sysPropertyInputType == 1) {//文本输入
                addTextView(customizeBean, i + 1);
            } else if (sysPropertyInputType == 2) {//数字+点号输入(价格)
                addNumView(customizeBean, i + 1);
            } else if (sysPropertyInputType == 3) {//日期样式
                addDateView(customizeBean, i + 1);
            } else if (sysPropertyInputType == 5) {//下拉选择样式
                addXialaView(customizeBean, i + 1);
            }
        }
    }

    /**
     * 弹框显示信息
     */
    private void showCarColorDialog(List<SysPropertyOptionListBean> sysPropertyOptionListBeans, TextView tvSelect) {
        View view = View.inflate(JianHuObjectUnArcActivity.this, R.layout.label_list, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(JianHuObjectUnArcActivity.this, view, 270, 218);
        RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.listView);
        TextView tvTitleCarLabel = (TextView) alertDialog.findViewById(R.id.tv_title_car_label);
        tvTitleCarLabel.setText("请选择");
        JianhuObjectUnArcXialaAdapter adapter = new JianhuObjectUnArcXialaAdapter(JianHuObjectUnArcActivity.this, sysPropertyOptionListBeans);
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new ListLineDecoration());
        recyclerView.setLayoutManager(new LinearLayoutManager(JianHuObjectUnArcActivity.this));
        adapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH viewHolder, int position) {
                alertDialog.dismiss();
                SysPropertyOptionListBean sysPropertyOptionListBean = sysPropertyOptionListBeans.get(position);
                tvSelect.setText(sysPropertyOptionListBean.getSysPropertyOptionValue());
            }
        });
    }

    /**
     * 提醒用户确认信息无误
     */
    private void showWornDialog() {
        SweetAlertDialog dialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        dialog.setContentText("请确认信息无误");
        dialog.setTitleText("温馨提示");
        dialog.showCancelButton(true).setCancelText("取消");
        dialog.setConfirmText("确定");
        dialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismissWithAnimation();

                initDialog();
                showDialog();
                ThreadPool.runOnWorker(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 0; i < picList.size(); i++) {
                            GuardianObjectDetailResponse.CustomizeBean customizeBean = picList.get(i);
                            while (!CheckUtils.isEmpty(customizeBean.getLocalUrl()) && CheckUtils.isEmpty(customizeBean.getSysPropertyValue())) {
                            }
                            if (!CheckUtils.isEmpty(customizeBean.getLocalUrl())) {
                                uploadList.add(customizeBean);
                            }
                        }


                        updateCarInfoLater();
                    }
                });

            }
        }).show();
    }

    /**
     * 等待解码后 修改车辆属性信息
     */
    private void updateCarInfoLater() {
        HomeApiUtils.updateObjectInfo(this, mGuardianObjectDetailResponse.getMemberServiceObjId(), mUserLoginInfo.getDataList().getAppMemberId(), mGuardianObjectDetailResponse.getMemberServiceActiveTime(), uploadList, new JsonCallback<Object>(this) {
            @Override
            public void onSuccess(Object object, Call call, Response response) {
                handler.sendEmptyMessage(RESULT_SUCESS);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                handler.sendEmptyMessage(RESULT_ERROR);
            }
        });
    }

    /**
     * 显示拍照选择
     *
     * @param i
     */
    private void showPicSelect(int i) {
        ActionSheet.createBuilder(this, getSupportFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("打开相册(Open Gallery)", "拍照(Camera)")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        picClickPosition = i;
                        switch (index) {
                            case 0:
                                camara_gallery = 2;
                                if (PermissionUtils.requestPermission(JianHuObjectUnArcActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openGallerySingle(PS_STORAGE_REQ, mOnHanlderResultCallback);
                                }
                                break;
                            case 1:
                                camara_gallery = 1;
                                String[] permissions = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                                if (PermissionUtils.requestPermission(JianHuObjectUnArcActivity.this, permissions[0], PS_CAMERA_REQ, "权限申请：\n我们需要您开启拍照权限") && PermissionUtils.requestPermission(JianHuObjectUnArcActivity.this, permissions[1], PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                                    GalleryFinal.openCamera(PS_CAMERA_REQ, mOnHanlderResultCallback);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }).show();
    }

    private GalleryFinal.OnHanlderResultCallback mOnHanlderResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
            if (resultList != null) {
                String invoiceStr = resultList.get(0).getPhotoPath();
                GuardianObjectDetailResponse.CustomizeBean picInfo = picList.get(picClickPosition);
                picInfo.setLocalUrl(invoiceStr);
                picInfo.setSysPropertyValue("");
                mPicAdapter.notifyDataSetChanged();
                base64Pic(invoiceStr);
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            XToastUtils.showShortToast(errorMsg);
        }
    };

    /**
     * base64图片
     *
     * @param invoiceStr
     */
    private void base64Pic(String invoiceStr) {
        ThreadPool.runOnWorker(new Runnable() {
            @Override
            public void run() {
                String base64Pic = Utils.base64Pic(JianHuObjectUnArcActivity.this, invoiceStr);
                GuardianObjectDetailResponse.CustomizeBean picInfo = picList.get(picClickPosition);
                picInfo.setSysPropertyValue(base64Pic);
            }
        });
    }

    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PS_CAMERA_REQ:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (PermissionUtils.requestPermission(JianHuObjectUnArcActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, PS_STORAGE_REQ, "权限申请：\n我们需要您开启设备存储权限")) {
                        GalleryFinal.openCamera(PS_STORAGE_REQ, mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(JianHuObjectUnArcActivity.this, permissions[0], "app需要开启拍照权限,是否去设置?", "用户拒绝拍照授权");
                }
                break;
            case PS_STORAGE_REQ:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (camara_gallery == 1) {
                        if (PermissionUtils.requestPermission(JianHuObjectUnArcActivity.this, Manifest.permission.CAMERA, PS_CAMERA_REQ, "权限申请：\n我们需要您开启拍照权限")) {
                            GalleryFinal.openCamera(PS_CAMERA_REQ, mOnHanlderResultCallback);
                        }
                    } else if (camara_gallery == 2) {
                        GalleryFinal.openGallerySingle(PS_STORAGE_REQ, mOnHanlderResultCallback);
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(JianHuObjectUnArcActivity.this, permissions[0], "app需要开启设备存储权限,是否去设置?", "用户拒绝设备存储授权");
                }
                break;
            default:
                break;
        }
    }

    private void dismissDialog() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    private void showDialog() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    @Override
    protected void onDestroy() {
        dismissDialog();
        mOnHanlderResultCallback = null;
        super.onDestroy();
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            dismissDialog();
            switch (msg.what) {
                case RESULT_SUCESS:
                    EventBus.getDefault().post(new EventManager(EventConstants.UPDATE_CAR_INFO_SUCCESS));
                    XToastUtils.showShortToast("监护对象资料修改成功");
                    finish();
                    break;
                case RESULT_ERROR:
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.SELECT_CAR_BRAND_SUCCESS:
                SysPropertyOptionListBean sysPropertyOptionListBean = (SysPropertyOptionListBean) eventManager.getData();
                LinearLayout childAt = (LinearLayout) mLlInfo.getChildAt(xiaLaClickPosition);
                TextView textView = (TextView) childAt.getChildAt(2);
                textView.setText(sysPropertyOptionListBean.getSysPropertyOptionValue());
                break;
        }
    }
}
