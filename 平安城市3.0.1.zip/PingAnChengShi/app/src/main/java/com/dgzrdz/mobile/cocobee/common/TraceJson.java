package com.dgzrdz.mobile.cocobee.common;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/12/24
 * Time:  17:11
 */

public class TraceJson implements Serializable {

    /**
     * dm_error : 0
     * error_msg : 操作成功
     * data : {"locus":[{"ChannelNo":1,"DeviceId":"100000000000005","Incentiye_Address":0,"TagIOType":0,"TagRssi":"-87","TagStay":0,"TagTime":1545121186,"TagType":"20","Eqlng":0,"EqLat":0},{"ChannelNo":1,"DeviceId":"100000000000104","Incentiye_Address":0,"TagIOType":1,"TagRssi":"-87","TagStay":0,"TagTime":1545121246,"TagType":"20","Eqlng":118.53136709025281,"EqLat":28.94737582044391}]}
     */

    private int dm_error;
    private String error_msg;
    private DataBean data;

    public int getDm_error() {
        return dm_error;
    }

    public void setDm_error(int dm_error) {
        this.dm_error = dm_error;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean implements Serializable{
        private List<LocusBean> locus;

        public List<LocusBean> getLocus() {
            return locus;
        }

        public void setLocus(List<LocusBean> locus) {
            this.locus = locus;
        }

        public static class LocusBean implements Serializable{
            /**
             * ChannelNo : 1
             * DeviceId : 100000000000005
             * Incentiye_Address : 0
             * TagIOType : 0
             * TagRssi : -87
             * TagStay : 0
             * TagTime : 1545121186
             * TagType : 20
             * Eqlng : 0
             * EqLat : 0
             */

            private String ChannelNo;
            private String DeviceId;
            private String Incentiye_Address;
            private String TagIOType;
            private String TagRssi;
            private String TagStay;
            private String TagTime;
            private String TagType;
            private String Eqlng;
            private String EqLat;

            public String getChannelNo() {
                return ChannelNo;
            }

            public void setChannelNo(String channelNo) {
                ChannelNo = channelNo;
            }

            public String getDeviceId() {
                return DeviceId;
            }

            public void setDeviceId(String deviceId) {
                DeviceId = deviceId;
            }

            public String getIncentiye_Address() {
                return Incentiye_Address;
            }

            public void setIncentiye_Address(String incentiye_Address) {
                Incentiye_Address = incentiye_Address;
            }

            public String getTagIOType() {
                return TagIOType;
            }

            public void setTagIOType(String tagIOType) {
                TagIOType = tagIOType;
            }

            public String getTagRssi() {
                return TagRssi;
            }

            public void setTagRssi(String tagRssi) {
                TagRssi = tagRssi;
            }

            public String getTagStay() {
                return TagStay;
            }

            public void setTagStay(String tagStay) {
                TagStay = tagStay;
            }

            public String getTagTime() {
                return TagTime;
            }

            public void setTagTime(String tagTime) {
                TagTime = tagTime;
            }

            public String getTagType() {
                return TagType;
            }

            public void setTagType(String tagType) {
                TagType = tagType;
            }

            public String getEqlng() {
                return Eqlng;
            }

            public void setEqlng(String eqlng) {
                Eqlng = eqlng;
            }

            public String getEqLat() {
                return EqLat;
            }

            public void setEqLat(String eqLat) {
                EqLat = eqLat;
            }
        }
    }
}
