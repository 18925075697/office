package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.me.OrderDetailActivity;
import com.dgzrdz.mobile.cocobee.adapter.OrderStatusAdapter;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseViewPagerFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.response.PayResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.lzy.okgo.OkGo;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/27
 * Time:  14:09
 */

public class UnPayOrderFragment extends BaseViewPagerFragment<OrderStatusResponse> {
    private static int sysConfType;
    private OrderStatusAdapter mOrderStatusAdapter;
    private String currentTime;
    private UserInfo mUserLoginInfo;
    private static final int WHAT_FLAG_CANCEL = 111;
    private List<OrderStatusResponse> unPayList = new ArrayList<>();
    private Timer timer;
    private boolean isResume;//在前台
    private boolean isRun;//计时器任务在运行,不让其继续运行

    public static UnPayOrderFragment getInstance(int sysConfType) {
        UnPayOrderFragment.sysConfType = sysConfType;
        UnPayOrderFragment fragment = new UnPayOrderFragment();
        return fragment;
    }

    @Override
    public void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        mOrderStatusAdapter = new OrderStatusAdapter(_mActivity, "1", mList);
        mOrderStatusAdapter.setOnRefreshLitener(new OrderStatusAdapter.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(1, true);
            }
        });
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.view_ptr_load;
    }

    @Override
    protected void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        OrderStatusResponse orderStatusResponse = mList.get(position);
        Intent intent = new Intent(_mActivity, OrderDetailActivity.class);
        intent.putExtra("orderStatusResponse", orderStatusResponse);
        startActivity(intent);
    }

    @Override
    protected void onRefresh() {
        stopTimer();
        initData(1, true);
    }

    @Override
    protected RecyclerView.Adapter getAdapter() {
        return mOrderStatusAdapter;
    }

    @Override
    protected void initData(int curPage, boolean isPullToRefresh) {
        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }
        PayApiUtils.getOrderInfo(_mActivity, "1", sysConfType + "", mUserLoginInfo.getDataList().getAppMemberId(), "", currentTime, pageSize + "", new RefreshAndLoadCallback<List<OrderStatusResponse>>(isPullToRefresh) {
            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                initData(1, false);
            }

            @Override
            public void onResultSuccess(List<OrderStatusResponse> orderStatusResponses, @Nullable Response response, LoadingViewCallback callback) {
                if (orderStatusResponses != null && orderStatusResponses.size() >= pageSize) {
                    if (mCurPage == 1) {//第一页,存最后一条数据的时间
                        currentTime = orderStatusResponses.get(orderStatusResponses.size() - 1).getMemberOrderAddTime();
                    }
                }
                handleRefreshAndLoadListData(mCurPage, callback, orderStatusResponses);
                unPayList.clear();
                if (orderStatusResponses != null && orderStatusResponses.size() > 0) {
                    for (int i = 0; i < orderStatusResponses.size(); i++) {
                        String memberOrderProcess = orderStatusResponses.get(i).getMemberOrderProcess();
                        if (CheckUtils.equalsString(memberOrderProcess, "1")) {//待付款
                            unPayList.add(orderStatusResponses.get(i));
                        }
                    }
                }
                //有待付款的订单,开启计时器,没有则关闭
                if (unPayList.size() > 0) {
                    startTimer();
                } else {
                    stopTimer();
                }
            }

            @Override
            public Drawable emptyDrawable() {
                return _mActivity.getResources().getDrawable(R.drawable.norecord);
            }

            @Override
            public String emptyContent() {
                return "暂无记录";
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (unPayList.size() == 0) {
                    stopTimer();
                }
            }
        });
    }

    @Override
    public void onLoadMore() {
        stopTimer();
        initData(mCurPage, true);
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.ORDER_CANCEL_SUCCESS://订单取消成功
                if (mUserLoginInfo != null) {
                    Intent data = (Intent) eventManager.getData();
                    String pageNum = data.getStringExtra("pageNum");
                    if (!CheckUtils.equalsString(pageNum, "1")) {//非本页面
                        initData(1, true);
                    }
                }
                break;
            case EventConstants.TOTAL_ORDER_CANCEL_AUTO_SUCCESS://全部页面自动取消订单成功
                if (isResume) {
                    OrderStatusResponse orderStatusResponse = (OrderStatusResponse) eventManager.getData();
                    if (mList.contains(orderStatusResponse)) {
                        mList.remove(orderStatusResponse);
                        mOrderStatusAdapter.notifyDataSetChanged();
                    }
                    if (unPayList.contains(orderStatusResponse)) {
                        unPayList.remove(orderStatusResponse);
                    }
                } else {
                    if (mUserLoginInfo != null) {
                        initData(1, true);
                    }
                }
                break;
            case EventConstants.DETAIL_ORDER_CANCEL_AUTO_SUCCESS://详情页取消订单
                String orderId = (String) eventManager.getData();
                for (int i = 0; i < mList.size(); i++) {
                    OrderStatusResponse orderStatusResponse = mList.get(i);
                    if (CheckUtils.equalsString(orderId, orderStatusResponse.getMemberOrderId())) {
                        mList.remove(i);
                        mOrderStatusAdapter.notifyDataSetChanged();
                        break;
                    }
                }
                break;
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
            case EventConstants.PHONE_CHANGE_SUCCESS://手机号修改成功
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                if (mUserLoginInfo != null) {
                    initData(1, true);
                }
                break;
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            //相当于OnResume(),可见时开启计时器
            isResume = true;
            if (unPayList != null && unPayList.size() > 0) {
                startTimer();
            }
        } else {
            //相当于OnPause(),不可见时取消定时器
            isResume = false;
            stopTimer();
            if (mHandler != null) {
                mHandler.removeMessages(WHAT_FLAG_CANCEL);
            }
        }
    }


    @Override
    public void onDestroyView() {
        stopTimer();
        unPayList.clear();
        mList.clear();
        if (mOrderStatusAdapter != null) {
            mOrderStatusAdapter.notifyDataSetChanged();
        }
        if (mHandler != null) {
            mHandler.removeMessages(WHAT_FLAG_CANCEL);
        }
        OkGo.getInstance().cancelTag(this);
        super.onDestroyView();
    }

    /**
     * 开启计时器
     */
    public void startTimer() {
        if (isResume) {//页面显示才能开启
            if (timer != null) {
                stopTimer();
            }
            timer = new Timer();
            timer.schedule(new MyTimerTask(), 0, 1000); //每秒一次
        }
    }

    /**
     * 停止计时器
     */
    public void stopTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    /**
     * 计时器任务
     */
    public class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            System.out.println("#############unPay计时器任务执行");
            while (mRcvLoadMore.getScrollState() != 0) {
            }
            if (unPayList != null && unPayList.size() > 0 && !isRun) {//有未支付的订单
                isRun = true;
                for (int i = 0; i < unPayList.size(); i++) {
                    if (!isResume) {
                        break;
                    }
                    while (mRcvLoadMore.getScrollState() != 0) {
                    }
                    OrderStatusResponse orderStatusResponse = unPayList.get(i);
                    String timeNow = orderStatusResponse.getTimeNow();//服务器当前时间
                    String memberOrderAddTime = orderStatusResponse.getMemberOrderAddTime();//下单时间
                    long longCurrentTime = DateUtils.getLongFromString(timeNow, "yyyy-MM-dd HH:mm:ss");
                    long longAddTime = DateUtils.getLongFromString(memberOrderAddTime, "yyyy-MM-dd HH:mm:ss");
                    long longEnd = longAddTime + 20 * 60 * 1000;//截止时间
                    if (longEnd <= longCurrentTime) {//倒计时时间到,自动取消订单
                        Message msg = mHandler.obtainMessage();
                        msg.obj = orderStatusResponse;
                        msg.what = WHAT_FLAG_CANCEL;
                        mHandler.sendMessage(msg);
                        unPayList.remove(i);
                        i--;
                        SystemClock.sleep(2000);
                    }
                }
                isRun = false;
            } else {
                stopTimer();
            }
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_FLAG_CANCEL:
                    OrderStatusResponse message = (OrderStatusResponse) msg.obj;
                    if (mRcvLoadMore.getScrollState() == 0) {//非滑动状态
                        userCancelOrder(message);
                    }
                    break;
            }
        }
    };

    /**
     * 用户主动取消订单
     *
     * @param orderStatusResponse
     */
    private void userCancelOrder(OrderStatusResponse orderStatusResponse) {
        PayApiUtils.userCancelOrder(_mActivity, orderStatusResponse.getMemberOrderType(), orderStatusResponse.getMemberOrderId(), orderStatusResponse.getMemberServiceObjId(), new JsonCallback<PayResponse>(_mActivity) {
            @Override
            public void onSuccess(PayResponse payResponse, Call call, Response response) {
                System.out.println("#############unPay待支付时间到,自动取消订单成功");

                //更新页面
                if (mList.size() == 0) {
                    mOrderStatusAdapter.notifyDataSetChanged();
                    stopTimer();
                    return;
                }
                mList.remove(orderStatusResponse);
                mOrderStatusAdapter.notifyDataSetChanged();

                EventBus.getDefault().post(new EventManager(EventConstants.ORDER_CANCEL_AUTO_SUCCESS, orderStatusResponse));
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mList.size() == 0) {
                    stopTimer();
                }
            }
        });
    }

    //    private void updateUI(OrderStatusResponse orderStatusResponse) {

    //        if (mRcvLoadMore == null || mRcvLoadMore.getScrollState() != 0) {
    //            return;
    //        }
    //        //在页面可见的条目才更新
    //        LinearLayoutManager linearManager = (LinearLayoutManager) mRcvLoadMore.getLayoutManager();
    //        //最后一个可见view的位置
    //        int mLastVisibleItemPosition = linearManager.findLastVisibleItemPosition();
    //        //第一个可见view的位置
    //        int mFirstVisibleItemPosition = linearManager.findFirstVisibleItemPosition();
    //
    //        if (mRcvLoadMore.getLoadMoreView() != null && position >= mFirstVisibleItemPosition && position <= mLastVisibleItemPosition) {
    //            mOrderStatusAdapter.notifyItemRemoved(position);
    //            mOrderStatusAdapter.notifyItemRangeChanged(position, mList.size() - 1);
    //        } else if (position >= mFirstVisibleItemPosition && position <= mLastVisibleItemPosition) {
    //            mOrderStatusAdapter.notifyItemRemoved(position);
    //            mOrderStatusAdapter.notifyItemRangeChanged(position, mList.size());
    //
    //        }
    //    }

}