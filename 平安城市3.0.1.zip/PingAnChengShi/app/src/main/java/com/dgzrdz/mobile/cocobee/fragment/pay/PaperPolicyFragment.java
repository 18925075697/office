package com.dgzrdz.mobile.cocobee.fragment.pay;

import android.os.Bundle;
import android.widget.ImageView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.PaperPolicyResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import java.util.List;

import butterknife.BindView;

/**
 * 纸质保单照片
 * Created by Administrator on 2018/5/2.
 */

public class PaperPolicyFragment extends BaseFragment {
    private static List<PaperPolicyResponse> paperPolicyResponses;
    @BindView(R.id.iv_front)
    ImageView mIvFront;
    @BindView(R.id.iv_back)
    ImageView mIvBack;
    private UserInfo mUserLoginInfo;

    public static PaperPolicyFragment getInstance(List<PaperPolicyResponse> paperPolicyResponses) {
        PaperPolicyFragment.paperPolicyResponses = paperPolicyResponses;
        PaperPolicyFragment fragment = new PaperPolicyFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        setView(paperPolicyResponses);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("纸质保单照片");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_paper_policy;
    }


    /**
     * 设置图片
     *
     * @param paperPolicyResponses
     */
    private void setView(List<PaperPolicyResponse> paperPolicyResponses) {
        for (PaperPolicyResponse paperPolicyResponse : paperPolicyResponses) {
            String name = paperPolicyResponse.getName();
            if (CheckUtils.equalsString(name, "7")) {//前照
//                ImageUtil.loadPaperPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + paperPolicyResponse.getUrl(), mIvFront);
            } else {//后照
//                ImageUtil.loadPaperPicCommen(_mActivity, mUserLoginInfo.getPeople().getImgurl() + paperPolicyResponse.getUrl(), mIvBack);
            }
        }
    }
}
