package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2018/4/18.
 */

public class HomeIndexResponse implements Serializable{


    /**
     * MessageList:{"sysMessageAppMemberReadTime":"2018-11-15 11:42:08","sysMessageAddTime":"2018-11-15 10:00:00","sysMessageId":"2","sysMessageAppMemberId":"2","sysMessageSender":"系统管理员","sysMessageTitle":"3.0新版本准备升级，各管理员注意","sysMessageContent":"3.0新版本准备升级，各管理员注意","sysMessageStatus":"1","sysMessageMemberType":"1","sysMessageDelete":"0","sysAreaId":"1","sysMessageAppMemberRead":"0"}
     * installAmountMap : {"total":"4","today":"0","Seven":"0","thirty":"3"}
     * permissionMenuMap : [{"appModuleInfo":"集团业务","appModuleName":"集团业务","appModuleId":"6","appModuleType":"2","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"1"},{"appModuleInfo":"业务办理","appModuleName":"业务办理","appModuleId":"1","appModuleType":"1","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"1"},{"appModuleInfo":"保险补办","appModuleName":"保险补办","appModuleId":"7","appModuleType":"2","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"2"},{"appModuleInfo":"资料库","appModuleName":"资料库","appModuleId":"2","appModuleType":"1","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"2"},{"appModuleInfo":"预登记","appModuleName":"预登记","appModuleId":"8","appModuleType":"2","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"3"},{"appModuleInfo":"轨迹查询","appModuleName":"轨迹查询","appModuleId":"3","appModuleType":"1","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"3"},{"appModuleInfo":"业务统计","appModuleName":"业务统计","appModuleId":"9","appModuleType":"2","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"4"},{"appModuleInfo":"工具","appModuleName":"工具","appModuleId":"4","appModuleType":"1","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"4"},{"appModuleInfo":"我的","appModuleName":"我的","appModuleId":"5","appModuleType":"1","appModuleApiAuth":"/api/mod1/class/","appModuleShowCode":"5"}]
     */

    private InstallAmountMapBean installAmountMap;
    private MessageListBean MessageList;
    private List<PermissionMenuMapBean> permissionMenuMap;

    public MessageListBean getMessageList() {
        return MessageList;
    }

    public void setMessageList(MessageListBean messageList) {
        MessageList = messageList;
    }

    public InstallAmountMapBean getInstallAmountMap() {
        return installAmountMap;
    }

    public void setInstallAmountMap(InstallAmountMapBean installAmountMap) {
        this.installAmountMap = installAmountMap;
    }

    public List<PermissionMenuMapBean> getPermissionMenuMap() {
        return permissionMenuMap;
    }

    public void setPermissionMenuMap(List<PermissionMenuMapBean> permissionMenuMap) {
        this.permissionMenuMap = permissionMenuMap;
    }
    public static class MessageListBean implements Serializable{

        /**
         * sysMessageAppMemberReadTime : 2018-11-15 11:42:08
         * sysMessageAddTime : 2018-11-15 10:00:00
         * sysMessageId : 2
         * sysMessageAppMemberId : 2
         * sysMessageSender : 系统管理员
         * sysMessageTitle : 3.0新版本准备升级，各管理员注意
         * sysMessageContent : 3.0新版本准备升级，各管理员注意
         * sysMessageStatus : 1
         * sysMessageMemberType : 1
         * sysMessageDelete : 0
         * sysAreaId : 1
         * sysMessageAppMemberRead : 0
         */

        private String sysMessageAppMemberReadTime;
        private String sysMessageAddTime;
        private String sysMessageId;
        private String sysMessageAppMemberId;
        private String sysMessageSender;
        private String sysMessageTitle;
        private String sysMessageContent;
        private String sysMessageStatus;
        private String sysMessageMemberType;
        private String sysMessageDelete;
        private String sysAreaId;
        private String sysMessageAppMemberRead;

        public String getSysMessageAppMemberReadTime() {
            return sysMessageAppMemberReadTime;
        }

        public void setSysMessageAppMemberReadTime(String sysMessageAppMemberReadTime) {
            this.sysMessageAppMemberReadTime = sysMessageAppMemberReadTime;
        }

        public String getSysMessageAddTime() {
            return sysMessageAddTime;
        }

        public void setSysMessageAddTime(String sysMessageAddTime) {
            this.sysMessageAddTime = sysMessageAddTime;
        }

        public String getSysMessageId() {
            return sysMessageId;
        }

        public void setSysMessageId(String sysMessageId) {
            this.sysMessageId = sysMessageId;
        }

        public String getSysMessageAppMemberId() {
            return sysMessageAppMemberId;
        }

        public void setSysMessageAppMemberId(String sysMessageAppMemberId) {
            this.sysMessageAppMemberId = sysMessageAppMemberId;
        }

        public String getSysMessageSender() {
            return sysMessageSender;
        }

        public void setSysMessageSender(String sysMessageSender) {
            this.sysMessageSender = sysMessageSender;
        }

        public String getSysMessageTitle() {
            return sysMessageTitle;
        }

        public void setSysMessageTitle(String sysMessageTitle) {
            this.sysMessageTitle = sysMessageTitle;
        }

        public String getSysMessageContent() {
            return sysMessageContent;
        }

        public void setSysMessageContent(String sysMessageContent) {
            this.sysMessageContent = sysMessageContent;
        }

        public String getSysMessageStatus() {
            return sysMessageStatus;
        }

        public void setSysMessageStatus(String sysMessageStatus) {
            this.sysMessageStatus = sysMessageStatus;
        }

        public String getSysMessageMemberType() {
            return sysMessageMemberType;
        }

        public void setSysMessageMemberType(String sysMessageMemberType) {
            this.sysMessageMemberType = sysMessageMemberType;
        }

        public String getSysMessageDelete() {
            return sysMessageDelete;
        }

        public void setSysMessageDelete(String sysMessageDelete) {
            this.sysMessageDelete = sysMessageDelete;
        }

        public String getSysAreaId() {
            return sysAreaId;
        }

        public void setSysAreaId(String sysAreaId) {
            this.sysAreaId = sysAreaId;
        }

        public String getSysMessageAppMemberRead() {
            return sysMessageAppMemberRead;
        }

        public void setSysMessageAppMemberRead(String sysMessageAppMemberRead) {
            this.sysMessageAppMemberRead = sysMessageAppMemberRead;
        }
    }
    public static class InstallAmountMapBean implements Serializable{
        /**
         * total : 4
         * today : 0
         * Seven : 0
         * thirty : 3
         */

        private String total;
        private String today;
        private String Seven;
        private String thirty;

        public String getTotal() {
            return total;
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public String getToday() {
            return today;
        }

        public void setToday(String today) {
            this.today = today;
        }

        public String getSeven() {
            return Seven;
        }

        public void setSeven(String Seven) {
            this.Seven = Seven;
        }

        public String getThirty() {
            return thirty;
        }

        public void setThirty(String thirty) {
            this.thirty = thirty;
        }
    }

    public static class PermissionMenuMapBean implements Serializable{
        /**
         * appModuleInfo : 集团业务
         * appModuleName : 集团业务
         * appModuleId : 6
         * appModuleType : 2
         * appModuleApiAuth : /api/mod1/class/
         * appModuleShowCode : 1
         */

        private String appModuleInfo;
        private String appModuleName;
        private String appModuleId;
        private String appModuleType;
        private String appModuleApiAuth;
        private String appModuleShowCode;
        private String appModuleIcon;

        public String getAppModuleIcon() {
            return appModuleIcon;
        }

        public void setAppModuleIcon(String appModuleIcon) {
            this.appModuleIcon = appModuleIcon;
        }

        public String getAppModuleInfo() {
            return appModuleInfo;
        }

        public void setAppModuleInfo(String appModuleInfo) {
            this.appModuleInfo = appModuleInfo;
        }

        public String getAppModuleName() {
            return appModuleName;
        }

        public void setAppModuleName(String appModuleName) {
            this.appModuleName = appModuleName;
        }

        public String getAppModuleId() {
            return appModuleId;
        }

        public void setAppModuleId(String appModuleId) {
            this.appModuleId = appModuleId;
        }

        public String getAppModuleType() {
            return appModuleType;
        }

        public void setAppModuleType(String appModuleType) {
            this.appModuleType = appModuleType;
        }

        public String getAppModuleApiAuth() {
            return appModuleApiAuth;
        }

        public void setAppModuleApiAuth(String appModuleApiAuth) {
            this.appModuleApiAuth = appModuleApiAuth;
        }

        public String getAppModuleShowCode() {
            return appModuleShowCode;
        }

        public void setAppModuleShowCode(String appModuleShowCode) {
            this.appModuleShowCode = appModuleShowCode;
        }
    }
}
