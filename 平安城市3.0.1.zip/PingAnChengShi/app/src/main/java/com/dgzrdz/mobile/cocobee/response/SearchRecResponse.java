package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/3/27.
 */

public class SearchRecResponse implements Serializable {

    /**
     * lat : null                   纬度
     * lng : null                   经度
     * lno : null
     * mobile : 16644449999
     * name : 明年                 用户姓名
     * orgname : 研发              组织机构名称
     * personName : 最便宜         车牌号/人员姓名
     */

    private String lat;
    private String lng;
    private String lno;
    private String mobile;
    private String name;
    private String orgname;
    private String personName;

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLno() {
        return lno;
    }

    public void setLno(String lno) {
        this.lno = lno;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }
}
