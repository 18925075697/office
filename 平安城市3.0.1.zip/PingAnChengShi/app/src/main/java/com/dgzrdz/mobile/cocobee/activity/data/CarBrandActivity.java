package com.dgzrdz.mobile.cocobee.activity.data;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.databank.CarBrandFragment;
import com.dgzrdz.mobile.cocobee.response.SysPropertyOptionListBean;

import java.util.List;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * 车辆品牌
 * Created by Administrator on 2018/6/28.
 */

public class CarBrandActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            List<SysPropertyOptionListBean> sysPropertyOptionList = (List<SysPropertyOptionListBean>) getIntent().getSerializableExtra("sysPropertyOptionList");
            String title = getIntent().getStringExtra("title");
            loadRootFragment(R.id.fl_container, CarBrandFragment.getInstance(sysPropertyOptionList,title));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}
