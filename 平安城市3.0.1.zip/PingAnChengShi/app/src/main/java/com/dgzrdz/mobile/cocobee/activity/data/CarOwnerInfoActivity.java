package com.dgzrdz.mobile.cocobee.activity.data;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.baoyz.actionsheet.ActionSheet;
import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.model.CarOwnerInfo;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.PhoneResponse;
import com.dgzrdz.mobile.cocobee.response.UploadCarOwnerResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.dialog.AddressSelectUpdateDialog;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kernal.passportreader.sdk.CardsCameraActivity;
import com.kernal.passportreader.sdk.utils.ManageIDCardRecogResult;
import com.lzy.okgo.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;

import java.text.ParseException;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;
import kernal.idcard.android.ResultMessage;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 预登记
 * Created by admin on 2018/4/19.
 */

public class CarOwnerInfoActivity extends BaseToolbarActivity {

    private static final int REQUEST_CAMARA_CODE = 111;
    private static final int REQUEST_READ_PHONE_STATE_CODE = 222;
    @BindView(R.id.tv_select_org)
    TextView mTvSelectOrg;
    @BindView(R.id.ll_ocr)
    LinearLayout mLlOcr;
    @BindView(R.id.nameEdt)
    EditText mNameEdt;
    @BindView(R.id.idEdt)
    EditText mIdEdt;
    @BindView(R.id.sexTxt)
    TextView mSexTxt;
    @BindView(R.id.telEdt)
    EditText mTelEdt;
    @BindView(R.id.addressTxt)
    TextView mAddressTxt;
    @BindView(R.id.addressEdt)
    EditText mAddressEdt;
    @BindView(R.id.tv_save_add_car_info)
    TextView mTvSaveAddCarInfo;
    @BindView(R.id.iv_sex_more)
    ImageView mIvSexMore;
    @BindView(R.id.reg_addressTxt)
    EditText mRegAddress;

    private UserInfo mUserLoginInfo;
    private String mOrgid;

    private boolean isPhoneOk;
    private String mMsg = "手机号校验失败";
    private UserBeanResponse mUserBean;
    private boolean mIsSelect; //是否从选择用户那里过来

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_car_owner_info;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbar("新增实名用户");
        mUserLoginInfo = Utils.getUserLoginInfo();
        initIntent();
        initEidtText();
        initListener();
    }

    /**
     * 获取传过来的intent信息
     */
    private void initIntent() {
        Intent intent = getIntent();
        mUserBean = (UserBeanResponse) intent.getSerializableExtra("userBean");
        mIsSelect = intent.getBooleanExtra("isSelect", false);
        if (mUserBean != null) {
            setView();
            mTelEdt.setText(mUserBean.getMemberAccount());
            isPhoneOk = true;
        }

    }

    private void initListener() {
        //限制姓名输入特殊字符
        mNameEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String editable = mNameEdt.getText().toString();
                String str = Utils.stringFilter(editable.toString());
                if (!editable.equals(str)) {
                    mNameEdt.setText(str);
                    //设置新的光标所在位置
                    mNameEdt.setSelection(str.length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    /**
     * 检测手机号输入框
     */
    private void initEidtText() {
        mTelEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String phone = mTelEdt.getText().toString().trim();
                if (phone.length() >= 11) {
                    if (CheckUtils.isMobilePhone(phone)) {
                        checkPhone(phone);
                    } else {
                        XToastUtils.showShortToast("手机号格式错误");
                        isPhoneOk = false;
                        mMsg = "手机号格式错误";
                    }
                }
            }
        });
    }

    /**
     * 清除
     */
    private void clearInfo() {
        mTvSelectOrg.setText("");
        mTvSelectOrg.setClickable(true);
        mNameEdt.setText("");
        mIdEdt.setText("");
        mSexTxt.setText("");
        mRegAddress.setText("");
        mAddressEdt.setText("");
    }

    /**
     * 验证手机号
     *
     * @param phone
     */
    private void checkPhone(String phone) {
        DatasApiUtils.checkPhone1(this, phone, new StringCallback() {
            @Override
            public void onSuccess(String s, Call call, Response response) {
                if (!TextUtils.isEmpty(s)) {
                    PhoneResponse jr = new Gson().fromJson(s, new TypeToken<PhoneResponse>() {
                    }.getType());
                    if (jr != null && jr.getRetCode() == 202) {//不存在用户
                        isPhoneOk = true;
                        clearInfo();
                        mUserBean = null;
                    } else if (jr != null && jr.getRetCode() == 0) { //存在用户,接收数据
                        if (jr.getData() != null) {
                            mUserBean = jr.getData().getDataList();
                            setView();
                            isPhoneOk = true;
                        } else {
                            XToastUtils.showShortToast(jr.getRetMsg());
                            isPhoneOk = false;
                            mMsg = jr.getRetMsg();
                        }
                    } else if (jr != null && jr.getRetCode() == 401) {
                        XToastUtils.showShortToast(jr.getRetMsg());
                        Utils.gotoLogin();
                    } else if (jr != null) {
                        XToastUtils.showShortToast(jr.getRetMsg());
                        isPhoneOk = false;
                        mMsg = jr.getRetMsg();
                    }
                } else {
                    XToastUtils.showShortToast("服务器异常");
                    isPhoneOk = false;
                    mMsg = "手机号验证服务器异常";
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (response != null) {
                    XToastUtils.showShortToast("网络错误" + response.code());
                } else {
                    XToastUtils.showShortToast("网络错误");
                }
                isPhoneOk = false;
                mMsg = "手机号验证网络错误";
            }
        });
    }

    private void setView() {
        mOrgid = mUserBean.getSysAreaId();
        if (!CheckUtils.isEmpty(mUserBean.getSysAreaName())) {
            mTvSelectOrg.setClickable(false);
        } else {
            mTvSelectOrg.setClickable(true);
        }
        mTvSelectOrg.setText(mUserBean.getSysAreaName());
        mNameEdt.setText(mUserBean.getMemberName());
        mIdEdt.setText(mUserBean.getMemberCardId());
        if (CheckUtils.equalsString(mUserBean.getMemberSix(), "1")) {
            mSexTxt.setText("男");
        } else if (CheckUtils.equalsString(mUserBean.getMemberSix(), "2")) {
            mSexTxt.setText("女");
        } else {
            mSexTxt.setText("");
        }
        mAddressEdt.setText(mUserBean.getMemberLiveAddress());
        mRegAddress.setText(mUserBean.getMemberRegisterAddress());
    }

    private void toCamera() {
//        Utils.startActivity(this, CameraMiddleActivity.class);
        Utils.setOcrValue(getApplicationContext());
        Intent intent = new Intent(this, CardsCameraActivity.class);
        startActivityForResult(intent, 6611);
    }

    /*使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMARA_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (PermissionUtils.requestPermission(CarOwnerInfoActivity.this, Manifest.permission.READ_PHONE_STATE, REQUEST_READ_PHONE_STATE_CODE, "权限申请：\n我们需要您开启手机识别权限")) {
                        toCamera();
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(CarOwnerInfoActivity.this, Manifest.permission.CAMERA, "app需要开启相机权限,是否去设置?", "用户拒绝相机授权");
                }
                break;

            case REQUEST_READ_PHONE_STATE_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    if (PermissionUtils.requestPermission(CarOwnerInfoActivity.this, Manifest.permission.CAMERA, REQUEST_CAMARA_CODE, "权限申请：\n我们需要您开启相机权限")) {
                        toCamera();
                    }
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(CarOwnerInfoActivity.this, Manifest.permission.READ_PHONE_STATE, "app需要开启手机识别权限,是否去设置?", "用户拒绝手机识别授权");
                }
                break;
            default:
                break;
        }
    }

    @OnClick({R.id.tv_select_org, R.id.ll_ocr, R.id.sexTxt, R.id.tv_save_add_car_info})
    public void onViewClicked(View view) {
        //防止一秒内点击多次
        if (!Utils.isFastClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_select_org:
                showOrgSelectDialog();
                break;
            case R.id.ll_ocr:
                if (PermissionUtils.requestPermission(this, Manifest.permission.CAMERA, REQUEST_CAMARA_CODE, "权限申请：\n我们需要您开启相机权限")
                        && PermissionUtils.requestPermission(this, Manifest.permission.READ_PHONE_STATE, REQUEST_READ_PHONE_STATE_CODE, "权限申请：\n我们需要您开启手机识别权限")) {
                    toCamera();
                }
                break;
            case R.id.sexTxt:
                sexSelect();
                break;
            case R.id.tv_save_add_car_info:
                onSave();
                break;
        }
    }

    /**
     * 显示设置组织机构的dialog
     */
    private void showOrgSelectDialog() {
        AddressSelectUpdateDialog dialog = new AddressSelectUpdateDialog();
        dialog.show(getSupportFragmentManager(), "address");
    }

    /**
     * 性别选择
     */
    private void sexSelect() {
        ActionSheet.createBuilder(this, getSupportFragmentManager())
                .setCancelButtonTitle("取消(Cancel)")
                .setOtherButtonTitles("男(man)", "女(woman)")
                .setCancelableOnTouchOutside(true)
                .setListener(new ActionSheet.ActionSheetListener() {
                    @Override
                    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {
                    }

                    @Override
                    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
                        switch (index) {
                            case 0:
                                mSexTxt.setText("男");
                                break;
                            case 1:
                                mSexTxt.setText("女");
                                break;
                        }
                    }
                }).show();
    }

    private void onSave() {
        String selectOrg = mTvSelectOrg.getText().toString().trim();//组织机构
        String ucardidEt = mIdEdt.getText().toString().trim();//身份证
        String unameEt = mNameEdt.getText().toString().trim();//姓名
        String addressNow = mAddressEdt.getText().toString().trim();//现居地址
        String regAddress = mRegAddress.getText().toString().trim();//户籍地址
        String sex = mSexTxt.getText().toString().trim();//性别
        String tel = mTelEdt.getText().toString().trim();
        String idCArdNum = "";

        try {
            idCArdNum = CheckUtils.IDCardValidate(ucardidEt);
        } catch (ParseException e) {
            e.printStackTrace();
            XToastUtils.showLongToast("身份证无效");
        } catch (Exception e) {
            idCArdNum = "身份证格式错误";
            e.printStackTrace();
            XToastUtils.showLongToast("身份证无效");
        }
        if (CheckUtils.isEmpty(tel)) {
            XToastUtils.showShortToast("请输入手机号码");
        } else if (!CheckUtils.isMobilePhone(tel)) {
            XToastUtils.showLongToast("手机号格式不正确");
        } else if (!isPhoneOk) {
            XToastUtils.showShortToast(mMsg);
        } else if (CheckUtils.isEmpty(selectOrg)) {
            XToastUtils.showShortToast("请选择组织机构");
        } else if (CheckUtils.isEmpty(unameEt)) {
            XToastUtils.showLongToast("请输入姓名");
        } else if (CheckUtils.isEmpty(ucardidEt)) {
            XToastUtils.showLongToast("请输入身份证号码");
        } else if (!CheckUtils.equalsString(idCArdNum, "")) {
            XToastUtils.showLongToast("身份证无效");
        } else if (CheckUtils.isEmpty(sex)) {
            XToastUtils.showLongToast("请选择性别");
        } else if (CheckUtils.isEmpty(regAddress)) {
            XToastUtils.showLongToast("请输入户籍地址");
        } else {//下一步
            showWornDialog(ucardidEt, unameEt, regAddress, sex, tel, addressNow);
        }
    }

    /**
     * 提醒用户确认信息无误
     *
     * @param ucardidEt
     * @param unameEt
     * @param regAddress
     * @param sexStr
     * @param tel
     * @param addressNow
     */
    private void showWornDialog(String ucardidEt, String unameEt, String regAddress, String sexStr, String tel, String addressNow) {
        SweetAlertDialog dialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        dialog.setContentText("请确认信息无误");
        dialog.setTitleText("温馨提示");
        dialog.showCancelButton(true).setCancelText("取消");
        dialog.setConfirmText("确定");
        dialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismissWithAnimation();
                if (mUserBean != null) {//修改
                    updateInfo(ucardidEt, unameEt, regAddress, sexStr, tel, addressNow);
                } else {//新增
                    uploadInfo(ucardidEt, unameEt, regAddress, sexStr, tel, addressNow);
                }
            }
        }).show();
    }

    /**
     * 修改用户信息
     *
     * @param ucardidEt  车主身份证
     * @param unameEt    车主姓名
     * @param regAddress 车主户籍地址
     * @param sex        车主性别
     * @param tel        车主手机号
     * @param addressNow 现居地址
     */
    private void updateInfo(String ucardidEt, String unameEt, String regAddress, String sex, String tel, String addressNow) {

        HomeApiUtils.updateUserInfo(this, tel, unameEt, ucardidEt, sex, regAddress, addressNow, mUserBean.getMemberId(), mOrgid,
                new DialogCallback<Object>(this, "上传信息中...") {
                    @Override
                    public void onSuccess(Object o, Call call, Response response) {
                        mUserBean.setMemberLiveAddress(addressNow);
                        mUserBean.setMemberRegisterAddress(regAddress);
                        mUserBean.setMemberAccount(tel);
                        mUserBean.setMemberName(unameEt);
                        if (CheckUtils.equalsString(sex, "男")) {
                            mUserBean.setMemberSix("1");
                        } else {
                            mUserBean.setMemberSix("2");
                        }
                        mUserBean.setMemberCardId(ucardidEt);

                        EventBus.getDefault().post(new EventManager(EventConstants.PRE_REGIST_CAR_OWNER_UP_SUCCESS));
                        Intent intent;
                        if (mIsSelect) {//从选择用户进来
                            intent = new Intent(CarOwnerInfoActivity.this, SelectBindingCarActivity.class);
                        } else {
                            intent = new Intent(CarOwnerInfoActivity.this, BindingCarActivity.class);
                        }
                        intent.putExtra("userBean", mUserBean);
                        startActivity(intent);

                        finish();
                    }

                });
    }

    /**
     * 上传数据
     *
     * @param ucardidEt  车主身份证
     * @param unameEt    车主姓名
     * @param regAddress 车主户籍地址
     * @param sex        车主性别
     * @param tel        车主手机号
     * @param addressNow 现居地址
     */
    private void uploadInfo(String ucardidEt, String unameEt, String regAddress, String sex, String tel, String addressNow) {

        HomeApiUtils.preRegistration(this, tel, mOrgid, unameEt, ucardidEt, sex, regAddress, addressNow, mUserLoginInfo.getDataList().getAppMemberId(),
                new DialogCallback<UploadCarOwnerResponse>(this, "上传信息中...") {
                    @Override
                    public void onSuccess(UploadCarOwnerResponse uploadCarOwnerResponse, Call call, Response response) {
                        if (uploadCarOwnerResponse != null) {
                            String memberId = uploadCarOwnerResponse.getMemberId();
                            UserBeanResponse userBean = new UserBeanResponse();
                            userBean.setMemberLiveAddress(addressNow);
                            userBean.setMemberRegisterAddress(regAddress);
                            userBean.setMemberId(memberId);
                            userBean.setMemberAccount(tel);
                            userBean.setMemberName(unameEt);
                            userBean.setSysAreaName(mUserLoginInfo.getDataList().getSysAreaName());
                            userBean.setSysAreaId(mOrgid);
                            if (CheckUtils.equalsString(sex, "男")) {
                                userBean.setMemberSix("1");
                            } else {
                                userBean.setMemberSix("2");
                            }
                            userBean.setMemberCardId(ucardidEt);
                            userBean.setSysMobileName(uploadCarOwnerResponse.getSysMobileName());
                            userBean.setSysCityName(uploadCarOwnerResponse.getSysCityName());
                            userBean.setSysProName(uploadCarOwnerResponse.getSysProName());

                            EventBus.getDefault().post(new EventManager(EventConstants.PRE_REGIST_CAR_OWNER_UP_SUCCESS));
                            Intent intent;
                            if (mIsSelect) {//从选择用户进来
                                intent = new Intent(CarOwnerInfoActivity.this, SelectBindingCarActivity.class);
                            } else {
                                intent = new Intent(CarOwnerInfoActivity.this, BindingCarActivity.class);
                            }
                            intent.putExtra("userBean", userBean);
                            intent.putExtra("isSelect", mIsSelect);
                            startActivity(intent);
                            finish();
                        } else {
                            XToastUtils.showShortToast(msg);
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 6611) {
            Bundle bundle = data.getBundleExtra("resultbundle");
            ResultMessage resultMessage = (ResultMessage) bundle.getSerializable("resultMessage");
            //数据的封装
            String result = ManageIDCardRecogResult.managerSucessRecogResult(resultMessage);
//            EventBus.getDefault().post(new EventManager(EventConstants.OCR_SCAN_SUCCESS, result));
            ocrSuccess(result);
        }
//        finish();
    }

    @Override
    protected boolean isBindEventBusHere() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.PRE_REGIST_SUCCESS://预登记成功
                finish();
                break;
            case EventConstants.ORGENIZE_SELECT_CAR_OWNER_SUCCESS://组织机构选择成功
                CarOwnerInfo carOwnerInfo = (CarOwnerInfo) eventManager.getData();
                mTvSelectOrg.setText(carOwnerInfo.getOrgname());
                mOrgid = carOwnerInfo.getOrgid();
                break;
            case EventConstants.CURRENT_ORG_HAS_NO_CHILD://当前组织机构没有子组织机构
                mTvSelectOrg.setText(mUserLoginInfo.getDataList().getSysAreaName());
                mOrgid = mUserLoginInfo.getDataList().getSysAreaId();
                break;
            case EventConstants.OCR_SCAN_SUCCESS://ocr扫描成功
                String data = (String) eventManager.getData();
                ocrSuccess(data);
                break;
        }
    }

    /**
     * OCR扫描成功
     *
     * @param data
     */
    private void ocrSuccess(String data) {
        String cardid = "";
        String name = "";
        String gender = "";
        String birth = "";
        String address = "";

        String[] split = data.split(",");
        if (split.length < 6) {
            XToastUtils.showLongToast("未识别身份证");
            return;
        }
        name = split[0].split(":")[1];
        gender = split[1].split(":")[1];
        birth = split[3].split(":")[1];
        address = split[4].split(":")[1];
        cardid = split[5].split(":")[1];


        mNameEdt.setText(name);
        mIdEdt.setText(cardid);
        mSexTxt.setText(gender);
        mRegAddress.setText(address);
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//强制竖屏
    }
}
