package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;

/**
 * Created by admin on 2018/4/19.
 */

public class CarOwnerInfo implements Serializable{

    /**
     * address : 哦哦哦基本最哈安了家墨迹1额
     * birthday : 2018-04-25 00:00:00
     * id : 2ca6e259486211e8b17a00e0703a5aca
     * identity : null
     * mobile : 13026653568
     * name : 3333ell
     * orgname : 研发1
     * sex : 男
     * total : 0
     * idcard
     */

    private String address;
    private String regiaddr;
    private String birthday;
    private String id;
    private String identity;
    private String mobile;
    private String name;
    private String orgname;
    private String orgid;
    private String sex;
    private String idcard;
    private String total;

    public String getRegiaddr() {
        return regiaddr;
    }

    public void setRegiaddr(String regiaddr) {
        this.regiaddr = regiaddr;
    }

    public String getOrgid() {
        return orgid;
    }

    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
