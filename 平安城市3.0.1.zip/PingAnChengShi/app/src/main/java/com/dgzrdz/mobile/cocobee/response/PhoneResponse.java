package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/6/28.
 */

public class PhoneResponse implements Serializable {

    /**
     * data : {"dataList":{"memberLiveProvinceId":"0","memberPass":"96e79218965eb72c92a549dd5a330112","memberSix":"1","appMemberId":"1","memberRegTime":"2018-10-27","memberName":"test","memberStatus":"1","memberLiveDistrictId":"0","sysAreaId":"1","memberEnabled":"1","memberRegisterProvinceId":"0","memberLiveCityId":"0","memberAddTime":"2018-10-11 14:44:32","memberCardId":"431003166563330214","memberRegisterAddress":"1","memberLiveAddress":"1","memberRegisterCityId":"0","memberRegType":"1","memberAccount":"18507552562","memberRegisterDistrictId":"0","memberId":"1"}}
     * retCode : 0
     * retMsg : 查询成功！
     */

    private DataBean data;
    private int retCode;
    private String retMsg;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getRetCode() {
        return retCode;
    }

    public void setRetCode(int retCode) {
        this.retCode = retCode;
    }

    public String getRetMsg() {
        return retMsg;
    }

    public void setRetMsg(String retMsg) {
        this.retMsg = retMsg;
    }

    public static class DataBean implements Serializable {
        /**
         * dataList : {"memberLiveProvinceId":"0","memberPass":"96e79218965eb72c92a549dd5a330112","memberSix":"1","appMemberId":"1","memberRegTime":"2018-10-27","memberName":"test","memberStatus":"1","memberLiveDistrictId":"0","sysAreaId":"1","memberEnabled":"1","memberRegisterProvinceId":"0","memberLiveCityId":"0","memberAddTime":"2018-10-11 14:44:32","memberCardId":"431003166563330214","memberRegisterAddress":"1","memberLiveAddress":"1","memberRegisterCityId":"0","memberRegType":"1","memberAccount":"18507552562","memberRegisterDistrictId":"0","memberId":"1"}
         */

        private UserBeanResponse dataList;

        public UserBeanResponse getDataList() {
            return dataList;
        }

        public void setDataList(UserBeanResponse dataList) {
            this.dataList = dataList;
        }
    }
}
