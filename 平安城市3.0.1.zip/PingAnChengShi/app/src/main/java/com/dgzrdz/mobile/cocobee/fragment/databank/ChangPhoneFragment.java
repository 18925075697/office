package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description: 修改手机号
 * Author: Liubingren
 * Data:  2018/11/12
 * Time:  10:38
 */

public class ChangPhoneFragment extends BaseFragment {
    private static UserBeanResponse userBeanResponse;
    @BindView(R.id.et_old_phone)
    TextView mEtOldPhone;
    @BindView(R.id.et_new_phone)
    EditText mEtNewPhone;
    @BindView(R.id.tv_upload)
    TextView mTvUpload;

    public static ChangPhoneFragment getInstance(UserBeanResponse userBeanResponse) {
        ChangPhoneFragment.userBeanResponse = userBeanResponse;
        ChangPhoneFragment fragment = new ChangPhoneFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mEtOldPhone.setText(userBeanResponse.getMemberAccount());
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("修改手机号码");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_change_phone;
    }

    @OnClick(R.id.tv_upload)
    public void onViewClicked() {
        String newPhone = mEtNewPhone.getText().toString().trim();
        if (CheckUtils.isEmpty(newPhone)) {
            XToastUtils.showShortToast("请输入新手机号");
        } else if (!CheckUtils.isMobilePhone(newPhone)) {
            XToastUtils.showShortToast("新手机号格式错误");
        } else {
            upload(newPhone);
        }

    }

    /**
     * 提交
     *
     * @param newPhone
     */
    private void upload(String newPhone) {
        DatasApiUtils.updateCarHostInfo(_mActivity, newPhone, "", "", "", "", "",
                userBeanResponse.getMemberId(), new DialogCallback<Object>(_mActivity, "修改中...") {
                    @Override
                    public void onSuccess(Object o, Call call, Response response) {
                        userBeanResponse.setMemberAccount(newPhone);
                        EventBus.getDefault().post(new EventManager(EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS, userBeanResponse));
                        XToastUtils.showShortToast("修改成功");
                        pop();
                    }
                });
    }
}
