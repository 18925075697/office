package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;

import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  16:33
 */

public class ItemPolicyAdapter extends QuickRcvAdapter<PolicyServiceResponse.PolicyServiceTypeListBean> {

    private final Context mContext;

    public ItemPolicyAdapter(Context context, List<PolicyServiceResponse.PolicyServiceTypeListBean> data, int... layoutId) {
        super(context, data, R.layout.item_policy_service);
        mContext = context;
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int position, PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean) {
        TextView policyServiceType = quickRcvHolder.getView(R.id.policy_service_type);
        if (policyServiceTypeListBean.getSysInsurancePrice() == 0) {
            policyServiceType.setText(policyServiceTypeListBean.getSysInsuranceConfYearsShow() + "   |   赠送");
        } else {
            policyServiceType.setText(policyServiceTypeListBean.getSysInsuranceConfYearsShow() + "   |   ¥" + policyServiceTypeListBean.getSysInsurancePrice());
        }

        if (policyServiceTypeListBean.getSelect() == position) {//选中的条目
            policyServiceType.setBackgroundResource(R.drawable.tag_service_select);
            policyServiceType.setTextColor(mContext.getResources().getColor(R.color.color_008cff));
        } else {
            policyServiceType.setBackgroundResource(R.drawable.tag_service_normal);
            policyServiceType.setTextColor(mContext.getResources().getColor(R.color.color_333333));
        }

    }
}
