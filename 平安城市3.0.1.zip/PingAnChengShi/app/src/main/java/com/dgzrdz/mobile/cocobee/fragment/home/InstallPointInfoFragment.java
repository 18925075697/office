package com.dgzrdz.mobile.cocobee.fragment.home;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.adapter.InstallPointInfoAdapter;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.InstallPointInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.PermissionUtils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

/**
 * Created by Administrator on 2018/8/3.
 */

public class InstallPointInfoFragment extends RefreshAndLoadFragment<InstallPointInfoResponse.InstallerBean> {
    private static final int REQUEST_CODE_CALL = 1;
    private static List<InstallPointInfoResponse.InstallerBean> installer;
    private InstallPointInfoAdapter mInstallPointInfoAdapter;
    private InstallPointInfoResponse.InstallerBean mInstallerBean;

    public static InstallPointInfoFragment getInstance(List<InstallPointInfoResponse.InstallerBean> installer) {
        InstallPointInfoFragment.installer = installer;
        InstallPointInfoFragment fragment = new InstallPointInfoFragment();
        return fragment;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        mInstallerBean = installer.get(position);
        if (CheckUtils.isEmpty(mInstallerBean.getMobile())) {
            XToastUtils.showShortToast("暂无电话号码,无法拨号");
            return;
        }
        if (PermissionUtils.requestPermission(this, Manifest.permission.CALL_PHONE, REQUEST_CODE_CALL, "权限申请：\n我们需要您开启拨打电话权限")) {
            startCall();
        }
    }

    private void startCall() {
        //用intent启动拨打电话
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + mInstallerBean.getMobile()));
        startActivity(intent);
    }

    @Override
    public QuickRcvAdapter getAdapter() {
        return mInstallPointInfoAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public boolean canRefresh() {
        return false;
    }

    @Override
    public void onRefresh() {

    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {

    }

    @Override
    public void onLoadMore() {

    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mInstallPointInfoAdapter = new InstallPointInfoAdapter(_mActivity, installer);
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("联系人");
    }

    /**
     * 使用6.0的SDK（23）在6.0的手机上，对于危险权限需要在代码中动态申请
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_CALL:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //用户同意授权
                    startCall();
                } else {
                    //用户拒绝授权
                    PermissionUtils.sureIfNotNotifiy(_mActivity, permissions[0], "app需要开启拨打电话权限,是否去设置?", "用户拒绝拨打电话授权");
                }
                break;
            default:
                break;
        }
    }
}
