package com.dgzrdz.mobile.cocobee.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.BigPicActivity;
import com.dgzrdz.mobile.cocobee.adapter.HplateInfoAdapter;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.CarInfoResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;

import butterknife.BindView;

/**
 * Description:车牌相关信息
 * Author: Liubingren
 * Data:  2019/3/15
 * Time:  13:53
 */

public class HplateInfoFragment extends BaseFragment {

    @BindView(R.id.tv_name)
    TextView mTvName;
    @BindView(R.id.tv_phone)
    TextView mTvPhone;
    @BindView(R.id.tv_hplate)
    TextView mTvHplate;
    @BindView(R.id.recycle_view)
    RecyclerView mRecycleView;
    @BindView(R.id.iv_icon)
    ImageView mIvIcon;
    private static CarInfoResponse carInfoResponse;
    private UserInfo mUserLoginInfo;

    public static HplateInfoFragment getInstance(CarInfoResponse carInfoResponse) {
        HplateInfoFragment.carInfoResponse = carInfoResponse;
        HplateInfoFragment fragment = new HplateInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        if (carInfoResponse == null) return;
        initRecycleView();
        initView();
    }

    private void initView() {
        if (carInfoResponse.getParam() == null)
            return;
        mTvName.setText("姓名: " + carInfoResponse.getParam().getMemberName());
        mTvPhone.setText("手机号码: " + carInfoResponse.getParam().getMemberAccount());
        mTvHplate.setText("车牌号: " + carInfoResponse.getParam().getMemberServiceObjNumber());
        mIvIcon.setImageResource(CheckUtils.equalsString(carInfoResponse.getParam().getMemberSix(), "1") ? R.drawable.male_portrait : R.drawable.women);
    }

    private void initRecycleView() {
        if (carInfoResponse.getPics() == null) return;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(_mActivity);
        mRecycleView.setLayoutManager(linearLayoutManager);
        HplateInfoAdapter adapter = new HplateInfoAdapter(_mActivity, carInfoResponse.getPics());
        mRecycleView.setAdapter(adapter);
        adapter.setOnItemClickListener(new QuickRcvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH bh, int i) {
                Intent intent = new Intent(_mActivity, BigPicActivity.class);
                if (CheckUtils.isWebUrl(carInfoResponse.getPics().get(i))) {//是全路径
                    intent.putExtra("picUrl", carInfoResponse.getPics().get(i));
                } else {
                    intent.putExtra("picUrl", mUserLoginInfo.getDataList().getPicture_prefix_url() + carInfoResponse.getPics().get(i));
                }
                startActivity(intent);
            }
        });
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("读取信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_hplate_info;
    }
}
