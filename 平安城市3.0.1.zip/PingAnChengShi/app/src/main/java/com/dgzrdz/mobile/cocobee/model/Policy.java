package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2017/1/19.
 */
public class Policy implements Serializable {
    /**
     * InsuranceStatus : null
     * OrderformPackage : [{"code":"0","money":0,"name":"盗抢险"}]
     * address : melt
     * birthday : null
     * callStatus : 0
     * car_createtime : 2018-07-05
     * cno : null
     * finishTime : 2018-07-05
     * goods_amount : 0.01
     * id : 7a8e4ec37ff311e8b036005056a645a8
     * idcard : 421023199008262975
     * labelId : 2018070309
     * lno : 2018070309
     * maturity_date : null
     * maturity_status : 0          订单是否到期0没到期 1到期
     * mobile : 15122223333
     * name : 么里
     * order_id : 153075454667405
     * order_status : 20
     * paymentMobile : 18576658309
     * paymentName : 谭燕芳
     * paymentOrgName : 研发
     * payment_id : 微信
     * payorderId : a894c6e27ff311e8b036005056a645a8
     * regiaddr : 呢KTV
     * sex : 0
     * theTerm : null
     */

    private String InsuranceStatus;
    private String address;
    private String birthday;
    private String callStatus;
    private String car_createtime;
    private String cno;
    private String finishTime;
    private double goods_amount;
    private String id;
    private String idcard;
    private String labelId;
    private String lno;
    private String maturity_date;
    private String maturity_status;
    private String mobile;
    private String name;
    private String order_id;
    private String order_status;
    private String paymentMobile;
    private String paymentName;
    private String paymentOrgName;
    private String payment_id;
    private String payorderId;
    private String regiaddr;
    private String sex;
    private String theTerm;
    private String buyType;
    private String ownerOrgName;
    private String carTypeName;//车辆类型
    private String newphone;//新卡标识，如果是0则老卡
    private String url;//车辆图片
    private String payTime;//支付时间

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private List<OrderformPackageBean> OrderformPackage;

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCar_createtime() {
        return car_createtime;
    }

    public void setCar_createtime(String car_createtime) {
        this.car_createtime = car_createtime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public double getGoods_amount() {
        return goods_amount;
    }

    public void setGoods_amount(double goods_amount) {
        this.goods_amount = goods_amount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public String getLno() {
        return lno;
    }

    public void setLno(String lno) {
        this.lno = lno;
    }

    public String getMaturity_status() {
        return maturity_status;
    }

    public void setMaturity_status(String maturity_status) {
        this.maturity_status = maturity_status;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getPaymentMobile() {
        return paymentMobile;
    }

    public void setPaymentMobile(String paymentMobile) {
        this.paymentMobile = paymentMobile;
    }

    public String getPaymentName() {
        return paymentName;
    }

    public void setPaymentName(String paymentName) {
        this.paymentName = paymentName;
    }

    public String getPaymentOrgName() {
        return paymentOrgName;
    }

    public void setPaymentOrgName(String paymentOrgName) {
        this.paymentOrgName = paymentOrgName;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getPayorderId() {
        return payorderId;
    }

    public void setPayorderId(String payorderId) {
        this.payorderId = payorderId;
    }

    public String getRegiaddr() {
        return regiaddr;
    }

    public void setRegiaddr(String regiaddr) {
        this.regiaddr = regiaddr;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getInsuranceStatus() {
        return InsuranceStatus;
    }

    public void setInsuranceStatus(String insuranceStatus) {
        InsuranceStatus = insuranceStatus;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getCallStatus() {
        return callStatus;
    }

    public void setCallStatus(String callStatus) {
        this.callStatus = callStatus;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getMaturity_date() {
        return maturity_date;
    }

    public void setMaturity_date(String maturity_date) {
        this.maturity_date = maturity_date;
    }

    public String getTheTerm() {
        return theTerm;
    }

    public void setTheTerm(String theTerm) {
        this.theTerm = theTerm;
    }

    public String getOwnerOrgName() {
        return ownerOrgName;
    }

    public void setOwnerOrgName(String ownerOrgName) {
        this.ownerOrgName = ownerOrgName;
    }

    public List<OrderformPackageBean> getOrderformPackage() {
        return OrderformPackage;
    }

    public void setOrderformPackage(List<OrderformPackageBean> OrderformPackage) {
        this.OrderformPackage = OrderformPackage;
    }

    public String getCarTypeName() {
        return carTypeName;
    }

    public void setCarTypeName(String carTypeName) {
        this.carTypeName = carTypeName;
    }

    public String getNewphone() {
        return newphone;
    }

    public void setNewphone(String newphone) {
        this.newphone = newphone;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public static class OrderformPackageBean {
        /**
         * code : 0
         * money : 0
         * name : 盗抢险
         */

        private String code;
        private double money;
        private String name;
        private String yearLimit;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public double getMoney() {
            return money;
        }

        public void setMoney(double money) {
            this.money = money;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getYearLimit() {
            return yearLimit;
        }

        public void setYearLimit(String yearLimit) {
            this.yearLimit = yearLimit;
        }
    }
}
