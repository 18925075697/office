package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.InstallPointInfoResponse;

import java.util.List;

/**
 * Created by Administrator on 2018/6/21.
 * 安装点联系人adapter
 */

public class InstallPointInfoAdapter extends QuickRcvAdapter<InstallPointInfoResponse.InstallerBean> {

    public InstallPointInfoAdapter(Context context, List<InstallPointInfoResponse.InstallerBean> data, int... layoutId) {
        super(context, data, R.layout.item_install_point_info);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int position, InstallPointInfoResponse.InstallerBean installerBean) {
        quickRcvHolder.setText(R.id.tv_area_name, installerBean.getName());
        quickRcvHolder.setText(R.id.tv_area_num, installerBean.getMobile());
    }
}
