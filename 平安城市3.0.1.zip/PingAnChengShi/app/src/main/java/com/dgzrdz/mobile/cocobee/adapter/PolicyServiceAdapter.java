package com.dgzrdz.mobile.cocobee.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.BH;
import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.baseadapter.recycleView.QuickRcvHolder;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;

import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  17:27
 */

public class PolicyServiceAdapter extends QuickRcvAdapter<PolicyServiceResponse> {

    public PolicyServiceAdapter(Context context, List<PolicyServiceResponse> data, int... layoutId) {
        super(context, data, R.layout.item_tag_service);
    }

    @Override
    protected void bindDataHelper(QuickRcvHolder quickRcvHolder, int i, PolicyServiceResponse policyServiceResponse) {
        RecyclerView recyclerView = quickRcvHolder.getView(R.id.recycle_view);
        TextView title = quickRcvHolder.getView(R.id.tv_title);
        title.setText(policyServiceResponse.getTitle());

        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 2));
        ItemPolicyAdapter adapter = new ItemPolicyAdapter(mContext,  policyServiceResponse.getServiceTypeList());
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(BH bh, int position) {
                mPolicyItemOnClick.onItemClick(i, position);
            }
        });
    }

    private PolicyItemOnClick mPolicyItemOnClick;

    public interface PolicyItemOnClick {
        /**
         * @param position  外层条目
         * @param positions 内层条目
         */
        void onItemClick(int position, int positions);
    }

    public void setPolicyItemOnClickListener(PolicyItemOnClick listener) {
        mPolicyItemOnClick = listener;
    }
}
