package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/12/19
 * Time:  14:18
 */

public class ComputeResponse implements Serializable{

    /**
     * sysGroupName : 腾讯集团
     * sysAreaId : 12
     * sysGroupId : 1
     */

    private String sysGroupName;//集团名称
    private String sysAreaId;//组织机构id
    private String sysGroupId;//集团名称id

    public String getSysGroupName() {
        return sysGroupName;
    }

    public void setSysGroupName(String sysGroupName) {
        this.sysGroupName = sysGroupName;
    }

    public String getSysAreaId() {
        return sysAreaId;
    }

    public void setSysAreaId(String sysAreaId) {
        this.sysAreaId = sysAreaId;
    }

    public String getSysGroupId() {
        return sysGroupId;
    }

    public void setSysGroupId(String sysGroupId) {
        this.sysGroupId = sysGroupId;
    }
}
