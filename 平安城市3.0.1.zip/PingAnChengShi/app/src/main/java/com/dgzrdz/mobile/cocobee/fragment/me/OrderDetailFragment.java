package com.dgzrdz.mobile.cocobee.fragment.me;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectDetailActivity;
import com.dgzrdz.mobile.cocobee.activity.data.JianHuObjectUnArcActivity;
import com.dgzrdz.mobile.cocobee.activity.register.ElectricActivity;
import com.dgzrdz.mobile.cocobee.adapter.TaocanAdapter;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.OrderDetailResponse;
import com.dgzrdz.mobile.cocobee.response.OrderStatusResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:订单详情(已付款/已取消/已过期)
 * Author: Liubingren
 * Data:  2018/11/28
 * Time:  15:15
 */

public class OrderDetailFragment extends BaseFragment {

    private static OrderStatusResponse orderStatusResponse;
    @BindView(R.id.tv_order_status)
    TextView mTvOrderStatus;
    @BindView(R.id.tv_business_type)
    TextView mTvBusinessType;
    @BindView(R.id.tv_user_name_phone)
    TextView mTvUserNamePhone;
    @BindView(R.id.tv_obj_type)
    TextView mTvObjType;
    @BindView(R.id.ll_bao_xian_tao_can)
    LinearLayout mLlBaoXianTaoCan;
    @BindView(R.id.tv_order_total_num_title)
    TextView mTvOrderTotalNumTitle;
    @BindView(R.id.mtv_pay_total_num)
    MoneyTextView mMtvPayTotalNum;
    @BindView(R.id.tv_order_num)
    TextView mTvOrderNum;
    @BindView(R.id.tv_order_time)
    TextView mTvOrderTime;
    @BindView(R.id.tv_pay_time)
    TextView mTvPayTime;
    @BindView(R.id.tv_pay_type)
    TextView mTvPayType;
    @BindView(R.id.tv_payed_num_title)
    TextView mTvPayedNumTitle;
    @BindView(R.id.mtv_payed_total_num)
    MoneyTextView mMtvPayedTotalNum;
    @BindView(R.id.tv_account)
    TextView mTvAccount;
    @BindView(R.id.tv_name)
    TextView mTvName;
    @BindView(R.id.tv_install_position)
    TextView mTvInstallPosition;
    @BindView(R.id.tv_org_name)
    TextView mTvOrgName;
    @BindView(R.id.tv_upload_install_position)
    TextView mTvUploadInstallPosition;
    @BindView(R.id.ll_group_compute)
    LinearLayout mLlGroupCompute;
    @BindView(R.id.tv_group_compute)
    TextView mTvGroupCompute;
    private OrderDetailResponse mOrderDetailResponse;

    public static OrderDetailFragment getInstance(OrderStatusResponse orderStatusResponse) {
        OrderDetailFragment.orderStatusResponse = orderStatusResponse;
        OrderDetailFragment fragment = new OrderDetailFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setStatus(mTvOrderStatus, orderStatusResponse.getMemberOrderProcess());
        initData();
    }

    /**
     * 设置订单状态
     *
     * @param tvOrderStatus
     * @param memberOrderProcess 订单状态 1待付款\n2 已付款\n3 已取消\n4 已过期
     */
    private void setStatus(TextView tvOrderStatus, String memberOrderProcess) {
        if (CheckUtils.equalsString(memberOrderProcess, "1")) {//待付款
            tvOrderStatus.setText("待付款");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_ff0000));
        } else if (CheckUtils.equalsString(memberOrderProcess, "2")) {//已付款
            tvOrderStatus.setText("已付款");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_12bc00));
        } else if (CheckUtils.equalsString(memberOrderProcess, "3")) {//已取消
            tvOrderStatus.setText("已取消");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_666666));
        } else {//已过期
            tvOrderStatus.setText("已过期");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_999999));
        }
    }

    /**
     * 获取订单详情
     */
    private void initData() {
        PayApiUtils.getOrderDetailInfo(_mActivity, orderStatusResponse.getMemberOrderId(), new DialogCallback<OrderDetailResponse>(_mActivity, "获取详情中...") {
            @Override
            public void onSuccess(OrderDetailResponse orderDetailResponse, Call call, Response response) {
                if (orderDetailResponse != null) {
                    mOrderDetailResponse = orderDetailResponse;
                    mLlBaoXianTaoCan.removeAllViews();
                    setView();
                } else {
                    XToastUtils.showShortToast("暂无数据");
                }
            }
        });
    }

    private void setView() {
        if (CheckUtils.equalsString(mOrderDetailResponse.getSysConfType(), "1")) {
            mTvBusinessType.setText("个人业务");
            mLlGroupCompute.setVisibility(View.GONE);
        } else {
            mTvBusinessType.setText("集团业务");
            mLlGroupCompute.setVisibility(View.VISIBLE);
            mTvGroupCompute.setText(mOrderDetailResponse.getSysGroupName());
        }

        //用户对象信息
        if (CheckUtils.isEmpty(mOrderDetailResponse.getSysMobileName()) && CheckUtils.isEmpty(mOrderDetailResponse.getSysProName())
                && CheckUtils.isEmpty(mOrderDetailResponse.getSysCityName())) {//运营商,省市均为空
            mTvUserNamePhone.setText(mOrderDetailResponse.getMemberName() + "\n" + mOrderDetailResponse.getMemberAccount());
        } else {
            mTvUserNamePhone.setText(mOrderDetailResponse.getMemberName() + "\n" + mOrderDetailResponse.getMemberAccount() + "("
                    + (CheckUtils.isEmpty(mOrderDetailResponse.getSysMobileName()) ? "" : mOrderDetailResponse.getSysMobileName())
                    + " " + (CheckUtils.isEmpty(mOrderDetailResponse.getSysProName()) ? "" : mOrderDetailResponse.getSysProName())
                    + (CheckUtils.isEmpty(mOrderDetailResponse.getSysCityName()) ? "" : mOrderDetailResponse.getSysCityName())
                    + ")");
        }

        mTvObjType.setText(mOrderDetailResponse.getSysServiceTypeName() + "(" + mOrderDetailResponse.getSysPropertySort() + ")");

        //标签服务信息
        String memberOrderType = mOrderDetailResponse.getMemberOrderType();//订单类型，1 服务+保险 2 服务 3 保险
        if (!CheckUtils.equalsString(memberOrderType, "3")) {//有标签服务
            addTagService();
        }

        //保险服务信息
        List<OrderDetailResponse.InsurancePackageListBean> insurance_packageList = mOrderDetailResponse.getInsurance_PackageList();
        if (insurance_packageList != null && insurance_packageList.size() > 0) {
            for (int i = 0; i < insurance_packageList.size(); i++) {
                OrderDetailResponse.InsurancePackageListBean insurancePackageListBean = insurance_packageList.get(i);
                addPolicyService(insurancePackageListBean);
            }
        }

        //订单信息
        mMtvPayTotalNum.setAmount(mOrderDetailResponse.getMemberOrderTotalPay());
        mTvOrderNum.setText("订单编号:  " + mOrderDetailResponse.getMemberOrderNo());
        mTvOrderTime.setText("下单时间:  " + mOrderDetailResponse.getMemberOrderAddTime());


        if (CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "1")
                || CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "3")) {//未激活/已取消
            mTvPayTime.setText("取消时间:  " + mOrderDetailResponse.getMemberOrderCancelTime());
            mTvPayType.setVisibility(View.GONE);
            mMtvPayedTotalNum.setVisibility(View.GONE);
            mTvPayedNumTitle.setVisibility(View.GONE);
        } else {
            mTvPayTime.setText("支付时间:  " + mOrderDetailResponse.getPaymentTime());
            int memberOrderPayType = mOrderDetailResponse.getMemberOrderPayType();//支付类型1：微信支付，2：支付宝支付，3：口令支付，4：其他
            if (memberOrderPayType == 1) {//微信支付
                mTvPayType.setText("支付方式:  微信支付");
            } else if (memberOrderPayType == 2) {
                mTvPayType.setText("支付方式:  支付宝支付");
            } else if (memberOrderPayType == 3) {//
                mTvPayType.setText("支付方式:  口令支付(" + mOrderDetailResponse.getAppPasswordPayCodeStr() + ")");
            } else {
                mTvPayType.setText("支付方式:  其他支付");
            }
            mMtvPayedTotalNum.setAmount(mOrderDetailResponse.getMemberOrderActualPay());
        }


        //办理人员信息
        mTvAccount.setText("账号:  " + mOrderDetailResponse.getAppMemberAccount());
        mTvName.setText("姓名:  " + mOrderDetailResponse.getAppMemberName());
        mTvInstallPosition.setText("安装点:  " + mOrderDetailResponse.getSysInstallPlaceName());
        mTvOrgName.setText("组织机构:  " + mOrderDetailResponse.getSysAreaName());
        //订单提交的安装点
        mTvUploadInstallPosition.setText("安装点:  " + mOrderDetailResponse.getOrdersysInstallPlaceName());


    }

    /**
     * 添加标签服务信息
     */
    private void addTagService() {
        View view = View.inflate(_mActivity, R.layout.view_tag_service_order, null);
        TextView tvServiceStatus = (TextView) view.findViewById(R.id.tv_service_status);
        TextView tvYear = (TextView) view.findViewById(R.id.tv_year);
        RecyclerView taocanRecycleView = (RecyclerView) view.findViewById(R.id.taocan_recycle_view);
        MoneyTextView mtvServicePrice = (MoneyTextView) view.findViewById(R.id.mtv_service_price);
        TextView tvServiceEffectTime = (TextView) view.findViewById(R.id.tv_service_effect_time);
        TextView tvServiceEndTime = (TextView) view.findViewById(R.id.tv_service_end_time);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.topMargin = Utils.dp2px(1);
        mLlBaoXianTaoCan.addView(view, layoutParams);

        List<OrderDetailResponse.LabelServicePackageListBean> labelService_packageList = mOrderDetailResponse.getLabelService_PackageList();
        //        if (labelService_packageList != null && labelService_packageList.size() > 0) {
        //            OrderDetailResponse.LabelServicePackageListBean labelServicePackageListBean = labelService_packageList.get(0);
        //        }
        tvYear.setText("年限:  " + mOrderDetailResponse.getSysServiceSetYears() + "年");//年限
        mtvServicePrice.setAmount(mOrderDetailResponse.getSysServiceSetPrice());//金额

        setServiceStatus(tvServiceStatus, mOrderDetailResponse.getMemberOrderProcess());
        if (CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "1")
                || CheckUtils.equalsString(mOrderDetailResponse.getMemberOrderProcess(), "3")) {//未激活
            tvServiceEffectTime.setVisibility(View.GONE);
            tvServiceEndTime.setVisibility(View.GONE);
        } else {
            tvServiceEffectTime.setText("生效时间:  " + mOrderDetailResponse.getMemberOrderAcviveTime());
            tvServiceEndTime.setText("到期时间:  " + mOrderDetailResponse.getMemberOrderExpiredTime());
        }

        taocanRecycleView.setLayoutManager(new LinearLayoutManager(_mActivity));
        TaocanAdapter adapter = new TaocanAdapter(_mActivity, labelService_packageList, mOrderDetailResponse);
        taocanRecycleView.setAdapter(adapter);
    }


    /**
     * 添加保险服务信息
     *
     * @param insurancePackageListBean
     */
    private void addPolicyService(OrderDetailResponse.InsurancePackageListBean insurancePackageListBean) {
        View view = View.inflate(_mActivity, R.layout.view_policy_order, null);
        TextView tvPolicyOrder = (TextView) view.findViewById(R.id.tv_policy_title);
        TextView tvPolicyComply = (TextView) view.findViewById(R.id.tv_policy_comply);
        TextView tvPolicyStatus = (TextView) view.findViewById(R.id.tv_policy_status);
        TextView tvYear = (TextView) view.findViewById(R.id.tv_year);
        MoneyTextView mtvPolicyPrice = (MoneyTextView) view.findViewById(R.id.mtv_policy_price);
        TextView tvPolicyEffectTime = (TextView) view.findViewById(R.id.tv_policy_effect_time);
        TextView tvPolicyEndTime = (TextView) view.findViewById(R.id.tv_policy_end_time);
        TextView tvElectronicCertificates = (TextView) view.findViewById(R.id.tv_electronic_certificates);
        TextView tvPhone = (TextView) view.findViewById(R.id.tv_phone);
        TextView tvChangePhone = (TextView) view.findViewById(R.id.tv_change_phone);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.topMargin = Utils.dp2px(1);
        mLlBaoXianTaoCan.addView(view, layoutParams);

        tvElectronicCertificates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckUtils.isEmpty(insurancePackageListBean.getSysInsuranceTemplateUrl())) {
                    XToastUtils.showShortToast("暂无电子凭证");
                    return;
                }
                Intent intent = new Intent(_mActivity, ElectricActivity.class);
                intent.putExtra("url", insurancePackageListBean.getSysInsuranceTemplateUrl());
                startActivity(intent);
            }
        });

        tvPolicyOrder.setText(insurancePackageListBean.getSysInsuranceTypeName());
        tvPolicyComply.setText("(" + insurancePackageListBean.getSysInsuranceName() + ")");//保险公司
        tvYear.setText("保险年限:  " + insurancePackageListBean.getSysInsuranceConfYears() + "年");//年限
        mtvPolicyPrice.setAmount(insurancePackageListBean.getSysInsurancePrice());

        if (CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceProcess(), "1")
                || CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceProcess(), "3")) {//未激活
            tvPolicyEffectTime.setVisibility(View.GONE);
            tvPolicyEndTime.setVisibility(View.GONE);
            tvElectronicCertificates.setVisibility(View.GONE);
        } else {
            tvPolicyEffectTime.setVisibility(View.VISIBLE);
            tvPolicyEndTime.setVisibility(View.VISIBLE);
            tvElectronicCertificates.setVisibility(View.VISIBLE);
            tvPolicyEffectTime.setText("生效时间:  " + insurancePackageListBean.getSysInsuranceActiveTime());
            tvPolicyEndTime.setText("到期时间:  " + insurancePackageListBean.getSysInsuranceExpiredTime());
        }

        setServiceStatus(tvPolicyStatus, insurancePackageListBean.getSysInsuranceProcess());

        if (CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceTypeInput(), "1")) {//有额外值
            tvPhone.setVisibility(View.VISIBLE);
            tvPhone.setText(insurancePackageListBean.getSysInsuranceTypeInputName() + ":  " + insurancePackageListBean.getSysInsuranceExValueStr()
                    + "(" + insurancePackageListBean.getSysMobileName() + " " + insurancePackageListBean.getSysProName() + insurancePackageListBean.getSysCityName()
                    + ")");
            if (CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceTypeSpecial(), "1")) {//1：校验手机号码 ，2：校验身份证号码，3：校验纯数字，4：其他
                //是手机号且状态为待付款或已激活
                if (CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceProcess(), "1")
                        || CheckUtils.equalsString(insurancePackageListBean.getSysInsuranceProcess(), "2")) {
                    tvChangePhone.setVisibility(View.VISIBLE);
                    tvChangePhone.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showPhoneInputDialog(insurancePackageListBean);
                        }
                    });
                } else {
                    tvChangePhone.setVisibility(View.GONE);
                }

            } else {
                tvPhone.setText(insurancePackageListBean.getSysInsuranceTypeInputName() + ":  " + insurancePackageListBean.getSysInsuranceExValueStr());
                tvChangePhone.setVisibility(View.GONE);
            }
        } else {
            tvPhone.setVisibility(View.GONE);
        }
    }

    /**
     * 展示手机号输入弹框
     *
     * @param insurancePackageListBean
     */
    private void showPhoneInputDialog(OrderDetailResponse.InsurancePackageListBean insurancePackageListBean) {
        View view = View.inflate(_mActivity, R.layout.view_input_phone, null);
        final AlertDialog alertDialog = Utils.showCornerDialog(_mActivity, view, 270, 174);
        EditText newPhone = (EditText) alertDialog.findViewById(R.id.et_new_phone);
        TextView sure = (TextView) alertDialog.findViewById(R.id.tv_sure);
        TextView cancel = (TextView) alertDialog.findViewById(R.id.tv_cancel);

        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = newPhone.getText().toString().trim();
                if (CheckUtils.isEmpty(phone)) {
                    XToastUtils.showShortToast("请输入手机号码");
                } else if (!CheckUtils.isMobilePhone(phone)) {
                    XToastUtils.showShortToast("手机号格式错误");
                } else {
                    changePhone(insurancePackageListBean, phone, alertDialog);
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    /**
     * 修改手机号码
     *
     * @param insurancePackageListBean
     * @param phone
     * @param alertDialog
     */
    private void changePhone(OrderDetailResponse.InsurancePackageListBean insurancePackageListBean, String phone, AlertDialog alertDialog) {
        PayApiUtils.policyChangePhone(_mActivity, insurancePackageListBean.getSysInsuranceValueId(), phone, mOrderDetailResponse.getPaymentTime(), new DialogCallback<Object>(_mActivity, "修改中...") {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                XToastUtils.showShortToast("修改成功");
                EventBus.getDefault().post(new EventManager(EventConstants.PHONE_CHANGE_SUCCESS));
                alertDialog.dismiss();
            }
        });
    }

    /**
     * 设置服务状态
     *
     * @param tvOrderStatus
     * @param memberOrderProcess 订单状态 1待付款\n2 已付款\n3 已取消\n4 已过期
     */
    private void setServiceStatus(TextView tvOrderStatus, String memberOrderProcess) {
        if (CheckUtils.equalsString(memberOrderProcess, "1") || CheckUtils.equalsString(memberOrderProcess, "3")) {//待付款
            tvOrderStatus.setText("未激活");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_666666));
        } else if (CheckUtils.equalsString(memberOrderProcess, "2")) {//已付款
            tvOrderStatus.setText("已激活");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_12bc00));
        } else {//已过期
            tvOrderStatus.setText("已过期");
            tvOrderStatus.setTextColor(getResources().getColor(R.color.color_999999));
        }
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("订单详情");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_order_detail;
    }

    @OnClick({R.id.tv_user_name_phone, R.id.tv_obj_type})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_user_name_phone://用户名电话
                UserBeanResponse userBeanResponse = getUserBeanResponse();
                start(RealNameInfoFragment.getInstance(userBeanResponse));
                break;
            case R.id.tv_obj_type://监护对象
                UserBeanResponse userBeanResponse1 = getUserBeanResponse();
                GuardianObjectResponse guardianObjectResponse = getGuardianObjectResponse();
                Intent intent;
                if (guardianObjectResponse.getMemberServiceObjActiveFlag() == 1) {//未激活
                    intent = new Intent(_mActivity, JianHuObjectUnArcActivity.class);
                    intent.putExtra("userBean", userBeanResponse1);
                } else {
                    intent = new Intent(_mActivity, JianHuObjectDetailActivity.class);
                }
                intent.putExtra("guardianObjectResponse", guardianObjectResponse);
                startActivity(intent);
                break;
        }
    }

    /**
     * 获取监护对象信息
     *
     * @return
     */
    @NonNull
    private GuardianObjectResponse getGuardianObjectResponse() {
        GuardianObjectResponse guardianObjectResponse = new GuardianObjectResponse();
        guardianObjectResponse.setMemberServiceObjId(mOrderDetailResponse.getMemberServiceObjId());
        guardianObjectResponse.setMemberServiceObjActiveFlag(mOrderDetailResponse.getMemberServiceObjActiveFlag());
        return guardianObjectResponse;
    }

    /**
     * 获取用户信息
     *
     * @return
     */
    @NonNull
    private UserBeanResponse getUserBeanResponse() {
        UserBeanResponse userBeanResponse = new UserBeanResponse();
        userBeanResponse.setMemberId(mOrderDetailResponse.getMemberId());
        userBeanResponse.setMemberAccount(mOrderDetailResponse.getMemberAccount());
        userBeanResponse.setSysAreaId(mOrderDetailResponse.getSysAreaId());
        userBeanResponse.setSysAreaName(mOrderDetailResponse.getSysAreaName());
        userBeanResponse.setMemberName(mOrderDetailResponse.getMemberName());
        userBeanResponse.setMemberCardId(mOrderDetailResponse.getMemberCardId());
        userBeanResponse.setMemberSix(mOrderDetailResponse.getMemberSix());
        userBeanResponse.setMemberRegisterAddress(mOrderDetailResponse.getMemberRegisterAddress());
        userBeanResponse.setMemberLiveAddress(mOrderDetailResponse.getMemberLiveAddress());
        return userBeanResponse;
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.PHONE_CHANGE_SUCCESS://手机号修改成功
            case EventConstants.UPDATE_CAR_OWNER_INFO_SUCCESS://车主信息修改成功
                initData();
                break;
            case EventConstants.DELETE_CAR_INFO_SUCCESS://车辆信息删除成功
                if (mOrderDetailResponse != null) {
                    mOrderDetailResponse.setMemberServiceObjActiveFlag(5);
                }
                break;

        }
    }
}
