package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/5/15.
 */

public class AlarmInfoResponse implements Serializable {
    //    id             true   string      报警id
    //    labelId        true   string      标签号
    //    name           true   string      报警人名称
    //    mobile         true   string      报警人电话
    //    idcard         true   string      报警人身份证
    //    cno            true   string      车牌号
    //    buyType        true   string      车辆品牌类型
    //    address        true   string      被盗地址
    //    alarmlng       true   string      报警地址经度
    //    alarmlat       true   string      报警地址纬度
    //    desc           true   string      报警描述
    //    time           true   string      被盗时间
    //    status         true   string      报警状态 演示

    private String id;
    private String labelId;
    private String name;
    private String mobile;
    private String idcard;
    private String cno;
    private String buyType;
    private String address;
    private String alarmlng;
    private String alarmlat;
    private String desc;
    private String time;
    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAlarmlng() {
        return alarmlng;
    }

    public void setAlarmlng(String alarmlng) {
        this.alarmlng = alarmlng;
    }

    public String getAlarmlat() {
        return alarmlat;
    }

    public void setAlarmlat(String alarmlat) {
        this.alarmlat = alarmlat;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
