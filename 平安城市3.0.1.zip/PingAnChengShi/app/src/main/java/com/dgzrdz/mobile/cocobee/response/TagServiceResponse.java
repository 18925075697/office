package com.dgzrdz.mobile.cocobee.response;

import java.io.Serializable;
import java.util.List;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/10/30
 * Time:  16:22
 */

public class TagServiceResponse implements Serializable{

    /**
     * serviceTypeList : [{"name":"1年"},{"name":"2年"},{"name":"3年"}]
     * title : 年限
     */

    private String title;
    private List<ServiceTypeListBean> serviceTypeList;
    private int position = -1;//外层对应的内层选中条目

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<ServiceTypeListBean> getServiceTypeList() {
        return serviceTypeList;
    }

    public void setServiceTypeList(List<ServiceTypeListBean> serviceTypeList) {
        this.serviceTypeList = serviceTypeList;
    }

    public static class ServiceTypeListBean implements Serializable{

        /**
         * name : 1年
         * sysServiceSetConfId : 1
         * sysServiceSetConfPriceId : 4
         * sysServiceSetPrice : 100.00
         * sysServiceSetPropId : 7
         * sysServiceSetPropName : 宽带业务3
         * sysServiceSetPropOptionInput : 1
         * sysServiceSetPropOptionInputInfo : 请输入用于办理套餐的手机号
         * sysServiceSetPropOptionInputName : 手机号码
         * sysServiceSetPropOptionSpecial : 1
         * sysServiceSetYears : 1
         */

        private String sysServiceSetConfId;
        private String sysServiceSetConfPriceId;
        private double sysServiceSetPrice;
        private String sysServiceSetPropId;
        private String sysServiceSetPropName;
        private String sysServiceSetPropOptionInput;//标识是否有额外属性添加 1有
        private String sysServiceSetPropOptionInputInfo;
        private String sysServiceSetPropOptionInputName;
        private String sysServiceSetPropOptionSpecial;//额外校验
        private String sysServiceSetYears;
        private String name;
        private String id;
        private String realid;
        private int select = -1;//选中的条目
        private boolean enable = true;//是否可用

        public String getRealid() {
            return realid;
        }

        public void setRealid(String realid) {
            this.realid = realid;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public boolean isEnable() {
            return enable;
        }

        public void setEnable(boolean enable) {
            this.enable = enable;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getSelect() {
            return select;
        }

        public void setSelect(int select) {
            this.select = select;
        }

        public String getSysServiceSetConfId() {
            return sysServiceSetConfId;
        }

        public void setSysServiceSetConfId(String sysServiceSetConfId) {
            this.sysServiceSetConfId = sysServiceSetConfId;
        }

        public String getSysServiceSetConfPriceId() {
            return sysServiceSetConfPriceId;
        }

        public void setSysServiceSetConfPriceId(String sysServiceSetConfPriceId) {
            this.sysServiceSetConfPriceId = sysServiceSetConfPriceId;
        }

        public double getSysServiceSetPrice() {
            return sysServiceSetPrice;
        }

        public void setSysServiceSetPrice(double sysServiceSetPrice) {
            this.sysServiceSetPrice = sysServiceSetPrice;
        }

        public String getSysServiceSetPropId() {
            return sysServiceSetPropId;
        }

        public void setSysServiceSetPropId(String sysServiceSetPropId) {
            this.sysServiceSetPropId = sysServiceSetPropId;
        }

        public String getSysServiceSetPropName() {
            return sysServiceSetPropName;
        }

        public void setSysServiceSetPropName(String sysServiceSetPropName) {
            this.sysServiceSetPropName = sysServiceSetPropName;
        }

        public String getSysServiceSetPropOptionInput() {
            return sysServiceSetPropOptionInput;
        }

        public void setSysServiceSetPropOptionInput(String sysServiceSetPropOptionInput) {
            this.sysServiceSetPropOptionInput = sysServiceSetPropOptionInput;
        }

        public String getSysServiceSetPropOptionInputInfo() {
            return sysServiceSetPropOptionInputInfo;
        }

        public void setSysServiceSetPropOptionInputInfo(String sysServiceSetPropOptionInputInfo) {
            this.sysServiceSetPropOptionInputInfo = sysServiceSetPropOptionInputInfo;
        }

        public String getSysServiceSetPropOptionInputName() {
            return sysServiceSetPropOptionInputName;
        }

        public void setSysServiceSetPropOptionInputName(String sysServiceSetPropOptionInputName) {
            this.sysServiceSetPropOptionInputName = sysServiceSetPropOptionInputName;
        }

        public String getSysServiceSetPropOptionSpecial() {
            return sysServiceSetPropOptionSpecial;
        }

        public void setSysServiceSetPropOptionSpecial(String sysServiceSetPropOptionSpecial) {
            this.sysServiceSetPropOptionSpecial = sysServiceSetPropOptionSpecial;
        }

        public String getSysServiceSetYears() {
            return sysServiceSetYears;
        }

        public void setSysServiceSetYears(String sysServiceSetYears) {
            this.sysServiceSetYears = sysServiceSetYears;
        }
    }
}
