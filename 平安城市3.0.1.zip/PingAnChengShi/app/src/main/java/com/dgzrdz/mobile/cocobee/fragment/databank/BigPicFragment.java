package com.dgzrdz.mobile.cocobee.fragment.databank;

import android.os.Bundle;
import android.view.View;

import com.bql.convenientlog.CLog;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.utils.ImageUtil;

import butterknife.BindView;
import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

/**
 * Description:
 * Author: Liubingren
 * Data:  2019/1/17
 * Time:  14:58
 */

public class BigPicFragment extends BaseFragment {

    @BindView(R.id.image)
    PhotoView mImage;

    private static String url;

    public static BigPicFragment getInstance(String url) {
        BigPicFragment.url = url;
        BigPicFragment fragment = new BigPicFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        CLog.e("LogInterceptor:",url);
        ImageUtil.loadPic(_mActivity, url, mImage);
        mImage.setOnViewTapListener(new PhotoViewAttacher.OnViewTapListener() {
            @Override
            public void onViewTap(View view, float x, float y) {
                _mActivity.finish();
            }
        });
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {

    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_big_pic;
    }
}
