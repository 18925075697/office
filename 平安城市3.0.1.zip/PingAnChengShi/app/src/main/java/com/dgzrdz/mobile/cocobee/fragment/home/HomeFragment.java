package com.dgzrdz.mobile.cocobee.fragment.home;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.MainActivity;
import com.dgzrdz.mobile.cocobee.activity.data.CarOwnerInfoActivity;
import com.dgzrdz.mobile.cocobee.activity.home.BusinessStatisticsActivity;
import com.dgzrdz.mobile.cocobee.activity.home.InfoInputActivity;
import com.dgzrdz.mobile.cocobee.activity.home.InventoryActivity;
import com.dgzrdz.mobile.cocobee.activity.home.PolicyAddActivity;
import com.dgzrdz.mobile.cocobee.activity.me.MessageActivity;
import com.dgzrdz.mobile.cocobee.adapter.HomeAdapter;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.HomeIndexResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Description: 业务办理fragment
 * Author: Liubingren
 * Data:  2017/4/17
 * Time:  15:33
 */

public class HomeFragment extends BaseFragment {
    @BindView(R.id.recycle_view)
    RecyclerView mRecycleView;
    @BindView(R.id.tv_into_reg)
    TextView mTvIntoReg;
    @BindView(R.id.rl_into_reg)
    LinearLayout mRlIntoReg;
    @BindView(R.id.viewstub_notice)
    ViewStub mViewstubNotice;
    @BindView(R.id.rl_total_order)
    RelativeLayout mRltotalOrder;
    @BindView(R.id.tv_order_total)
    TextView mTvOrderTotal;
    @BindView(R.id.tv_today_num)
    TextView mTvTodayNum;
    @BindView(R.id.tv_week_num)
    TextView mTvWeekNum;
    @BindView(R.id.tv_month_num)
    TextView mTvMonthNum;


    private UserInfo mUserLoginInfo;

    private List<HomeIndexResponse.PermissionMenuMapBean> mHomeList = new ArrayList<>();
    private HomeAdapter mHomeAdapter;
    private TextView mNoticeContent;

    public static HomeFragment getInstance() {
        return new HomeFragment();
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        mUserLoginInfo = Utils.getUserLoginInfo();
        if (mUserLoginInfo == null) {
            Utils.gotoLogin();
            return;
        }
        initRecyclerView();
        initData();
    }

    /**
     * 加载消息
     */
    private void initViewstub() {
        if (mViewstubNotice.getParent() != null) {//没有加载
            View view = mViewstubNotice.inflate();
            mNoticeContent = (TextView) view.findViewById(R.id.tv_notice_content);
            ImageView closeNotice = (ImageView) view.findViewById(R.id.iv_close_notice);
            closeNotice.setOnClickListener(v -> mViewstubNotice.setVisibility(View.GONE));
            mNoticeContent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Utils.startActivity(_mActivity, MessageActivity.class);
                }
            });
        }
    }

    @Override
    protected void initToolbarHere() {
        if (mUserLoginInfo == null) {
            mUserLoginInfo = Utils.getUserLoginInfo();
        }

        if (mUserLoginInfo == null) {
            Utils.gotoLogin();
            return;
        }
        initToolbar(mUserLoginInfo.getDataList().getAppMemberName());
    }

    @Override
    public boolean inVisibleLeftDrawable() {
        return true;
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_home;
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    /**
     * 从服务器获取首页信息
     */
    public void initData() {
        HomeApiUtils.getIndexMoreInfo(_mActivity, mUserLoginInfo.getDataList().getAppMemberId(), new JsonCallback<HomeIndexResponse>(_mActivity) {

            @Override
            public void onSuccess(HomeIndexResponse homeIndexResponse, Call call, Response response) {
                if (homeIndexResponse != null) {
                    //消息
                    HomeIndexResponse.MessageListBean messageList = homeIndexResponse.getMessageList();
                    if (messageList != null) {
                        initViewstub();
                        setMessageView(messageList);
                    } else {
                        if (mViewstubNotice.getParent() == null) {//没有加载
                            mViewstubNotice.setVisibility(View.GONE);
                        }
                    }

                    HomeIndexResponse.InstallAmountMapBean installAmountMap = homeIndexResponse.getInstallAmountMap();
                    if (installAmountMap != null) {
                        setIdentityView(installAmountMap);
                    }
                    //导航
                    List<HomeIndexResponse.PermissionMenuMapBean> permissionMenuMap = homeIndexResponse.getPermissionMenuMap();
                    mHomeList.clear();
                    if (permissionMenuMap != null && permissionMenuMap.size() > 0) {
                        for (int i = 0; i < permissionMenuMap.size(); i++) {
                            HomeIndexResponse.PermissionMenuMapBean permissionMenuMapBean = permissionMenuMap.get(i);
                            if (CheckUtils.equalsString(permissionMenuMapBean.getAppModuleType(), "2")) {//中间的条目
                                mHomeList.add(permissionMenuMapBean);
                            }
                        }
                        //导航有数据时显示,没数据时隐藏
                        mRecycleView.setVisibility(View.VISIBLE);
                    } else {
                        mRecycleView.setVisibility(View.GONE);
                    }
                    mHomeAdapter.notifyDataSetChanged();

                } else {
                    XToastUtils.showShortToast("暂无相关数据");
                }
            }
        });
    }

    /**
     * 设置消息
     *
     * @param messageList 消息数据
     */
    private void setMessageView(HomeIndexResponse.MessageListBean messageList) {
        mNoticeContent.setText(messageList.getSysMessageTitle());
    }

    /**
     * 设置统计数据
     *
     * @param installAmountMap 统计数据
     */
    private void setIdentityView(HomeIndexResponse.InstallAmountMapBean installAmountMap) {
        mTvOrderTotal.setText(installAmountMap.getTotal());
        mTvTodayNum.setText(installAmountMap.getToday());
        mTvWeekNum.setText(installAmountMap.getSeven());
        mTvMonthNum.setText(installAmountMap.getThirty());
    }

    /**
     * 初始化横排的RecycleView
     */
    private void initRecyclerView() {
        mHomeAdapter = new HomeAdapter(_mActivity, mHomeList);
        mRecycleView.setLayoutManager(new GridLayoutManager(_mActivity, 4));
        mRecycleView.setAdapter(mHomeAdapter);
        mHomeAdapter.setOnItemClickListener((viewHolder, position) -> toPaper(position));
    }

    /**
     * 根据标识跳转相应的页面
     *
     * @param position 点击条目的位置
     */
    private void toPaper(int position) {
        if (CheckUtils.isEmpty(mUserLoginInfo.getDataList().getSysAreaId())) {
            XToastUtils.showShortToast("请先选择组织机构");
            return;
        }

        if (!Utils.isFastClick()) {
            return;
        }
        HomeIndexResponse.PermissionMenuMapBean permissionMenuMapBean = mHomeList.get(position);
        //1集团业务 2保险补办 3预登记 4业务统计
        switch (Utils.getNaviValue(permissionMenuMapBean.getAppModuleShowCode())) {
            case 1://集团业务
                Intent intent = new Intent(_mActivity, InfoInputActivity.class);
                intent.putExtra("sysConfType", "2");//业务类型 1个人业务 2集团业务
                startActivity(intent);
                break;
            case 2://保险补办
                Utils.startActivity(_mActivity, PolicyAddActivity.class);
                break;
            case 3://预登记
                Intent intent1 = new Intent(_mActivity, CarOwnerInfoActivity.class);
                intent1.putExtra("isHome", true);
                startActivity(intent1);
                break;
            case 4://业务统计
                Utils.startActivity(_mActivity, BusinessStatisticsActivity.class);
                break;
            case 16://车主资料库
                ((MainActivity) _mActivity).switchToData();
                break;
            case 17://库存查看
                Utils.startActivity(_mActivity, InventoryActivity.class);
                break;
        }
    }

    @OnClick({R.id.rl_into_reg, R.id.rl_total_order})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.rl_into_reg://进入登记
                Intent intent = new Intent(_mActivity, InfoInputActivity.class);
                intent.putExtra("sysConfType", "1");//业务类型 1个人业务 2集团业务
                startActivity(intent);
                break;
            case R.id.rl_total_order://业务办理统计
                Utils.startActivity(_mActivity, BusinessStatisticsActivity.class);
                break;
        }
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
                initData();
                break;
        }
    }
}
