package com.dgzrdz.mobile.cocobee.activity.register;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.SystemBarUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.MainActivity;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.api.LoginApiUtils;
import com.dgzrdz.mobile.cocobee.callback.StringDialogCallback;
import com.dgzrdz.mobile.cocobee.common.JsonToken;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 登录页面
 * Created by _H_JY on 2017/2/27.
 */

public class LoginActivity extends BaseActivity {

    @BindView(R.id.et_login_phone)
    EditText mEtLoginPhone;
    @BindView(R.id.et_login_pwd)
    EditText mEtLoginPwd;
    @BindView(R.id.iv_see_pwd)
    CheckBox mIvSeePwd;
    @BindView(R.id.login)
    TextView mLogin;
    @BindView(R.id.find_pwd_tv)
    TextView mFindPwdTv;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_login;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        SystemBarUtils.immersiveStatusBar(this, 0);
        //不能滑动返回
        setSwipeBackEnable(false);
        String userLoginNum = Utils.getUserLoginNum();
        mEtLoginPhone.setText(userLoginNum);
        mEtLoginPhone.setSelection(userLoginNum.length());
        initListener();
    }


    private void initListener() {
        mIvSeePwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    //选择状态 显示明文--设置为可见的密码
                    mEtLoginPwd.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    mIvSeePwd.setBackground(getResources().getDrawable(R.drawable.login_seegr));
                } else {
                    //默认状态显示密码--设置文本 要一起写才能起作用 InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                    mEtLoginPwd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    mIvSeePwd.setBackground(getResources().getDrawable(R.drawable.login_seecl));
                }
            }
        });
    }

    @OnClick({R.id.login, R.id.find_pwd_tv})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.login://登录
                login();
                break;
            case R.id.find_pwd_tv://忘记密码
                Utils.startActivity(LoginActivity.this, ForgetPwdActivity.class);
                break;
            default:
                break;
        }
    }

    private void login() {
        String phonenumber = mEtLoginPhone.getText().toString();
        String password = mEtLoginPwd.getText().toString();

        if (CheckUtils.isEmpty(phonenumber)) {
            XToastUtils.showShortToast("请输入账号");
            return;
        }

        if (CheckUtils.isEmpty(password)) {
            XToastUtils.showShortToast("请输入密码");
            return;
        }

        //        LoginApiUtils.login(this, phonenumber, password, new DialogCallback<UserInfo>(this, "登录中...") {
        //            @Override
        //            public void onSuccess(UserInfo userInfo, Call call, Response response) {
        //                if (userInfo != null) {
        //                    Utils.putUserLoginInfo(userInfo);
        //                    Utils.putUserLoginNum(phonenumber);
        //                    XToastUtils.showShortToast("登录成功");
        //                    Utils.startActivity(LoginActivity.this, MainActivity.class);
        //                    finish();
        //                } else {
        //                    XToastUtils.showShortToast("登录失败");
        //                }
        //            }
        //        });

        LoginApiUtils.login(this, phonenumber, password, new StringDialogCallback(this, "登录中...") {
            @Override
            public void onSuccess(String s, Call call, Response response) {
                if (!TextUtils.isEmpty(s)) {
                    JsonToken jr = new Gson().fromJson(s, new TypeToken<JsonToken>() {
                    }.getType());
                    if (jr != null && jr.getRetCode() == 0) { //登录成功
                        UserInfo userInfo = jr.getData();
                        if (userInfo != null) {
                            Utils.putUserLoginInfo(userInfo);
                            Utils.putUserLoginNum(phonenumber);
                            XToastUtils.showShortToast("登录成功");
                            Utils.startActivity(LoginActivity.this, MainActivity.class);
                            finish();
                        } else {
                            XToastUtils.showShortToast(jr.getRetMsg());
                        }
                    } else if (jr != null) {
                        XToastUtils.showShortToast(jr.getRetMsg());
                    } else {
                        XToastUtils.showShortToast("登录失败");
                    }
                } else {
                    XToastUtils.showShortToast("登录失败");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (response != null) {
                    XToastUtils.showShortToast("网络错误" + response.code());
                } else {
                    XToastUtils.showShortToast("网络错误");
                }
            }
        });
    }


}
