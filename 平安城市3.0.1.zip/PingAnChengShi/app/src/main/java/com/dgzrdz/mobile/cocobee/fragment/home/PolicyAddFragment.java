package com.dgzrdz.mobile.cocobee.fragment.home;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.CarOwnerSearchActivity;
import com.dgzrdz.mobile.cocobee.activity.data.SelectBindingCarPolicyActivity;
import com.dgzrdz.mobile.cocobee.activity.pay.SelectPayTypeActivity;
import com.dgzrdz.mobile.cocobee.api.PayApiUtils;
import com.dgzrdz.mobile.cocobee.callback.DialogCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.AddOrderResponse;
import com.dgzrdz.mobile.cocobee.response.BaoxianUploadResponse;
import com.dgzrdz.mobile.cocobee.response.GuardianObjectResponse;
import com.dgzrdz.mobile.cocobee.response.PolicyServiceResponse;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;
import com.dgzrdz.mobile.cocobee.view.MoneyTextView;
import com.dgzrdz.mobile.cocobee.view.dialog.SelectPolicyDialog;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:保险补办界面
 * Author: Liubingren
 * Data:  2018/6/25
 * Time:  10:44
 */

public class PolicyAddFragment extends BaseFragment {
    @BindView(R.id.tv_add_car_owner)
    TextView mTvAddCarOwner;
    @BindView(R.id.tv_car_owner_phone)
    TextView mTvCarOwnerPhone;
    @BindView(R.id.ll_car_owner_info)
    LinearLayout mLlCarOwnerInfo;
    @BindView(R.id.iv_car_owner_more)
    TextView mIvCarOwnerMore;
    @BindView(R.id.tv_car_brand_model)
    TextView mTvCarBrandModel;
    @BindView(R.id.iv_car_info_more)
    ImageView mIvCarInfoMore;
    @BindView(R.id.tv_business_type)
    TextView mTvBusinessType;
    @BindView(R.id.mtv_pay_num)
    MoneyTextView mMtvPayNum;
    @BindView(R.id.tv_upload)
    TextView mTvUpload;
    @BindView(R.id.tv_select_title)
    TextView mTvSelectTitle;
    @BindView(R.id.tv_select_baoxian)
    TextView mTvSelectBaoxian;
    @BindView(R.id.ll_select_service)
    LinearLayout mLlSelectService;
    @BindView(R.id.ll_other_add)
    LinearLayout mLlOtherAdd;
    private UserInfo mUserLoginInfo;
    private UserBeanResponse mUserBeanResponse;
    private GuardianObjectResponse mGuardianObjectResponse;
    private double totalPayNum;
    private List<PolicyServiceResponse> mPolicyList = new ArrayList<>();
    private List<PolicyServiceResponse.PolicyServiceTypeListBean> mPolicyServiceTypeListBeans = new ArrayList<>();//选中保险后,存储额外输入的集合

    public static PolicyAddFragment getInstance() {
        PolicyAddFragment fragment = new PolicyAddFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mTvTitle.setCompoundDrawables(null, null, null, null);
        mUserLoginInfo = Utils.getUserLoginInfo();
    }

    @Override
    public boolean isStatusDarkMode() {
        return false;
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("保险补办");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_policy_add;
    }


    @OnClick({R.id.ll_car_owner_info, R.id.tv_car_brand_model, R.id.ll_select_service, R.id.tv_upload, R.id.iv_car_owner_more})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ll_car_owner_info:
            case R.id.iv_car_owner_more:
                startActivity(new Intent(_mActivity, CarOwnerSearchActivity.class));
                break;
            case R.id.tv_car_brand_model://监护对象
                if (mUserBeanResponse == null) {//没选车主信息
                    XToastUtils.showShortToast("请先选择用户");
                } else {
                    Intent intent = new Intent(_mActivity, SelectBindingCarPolicyActivity.class);
                    intent.putExtra("userBean", mUserBeanResponse);
                    startActivity(intent);
                }
                break;
            case R.id.ll_select_service:
                if (mUserBeanResponse == null) {
                    XToastUtils.showShortToast("请先选择用户");
                } else if (mGuardianObjectResponse == null) {
                    XToastUtils.showShortToast("请先选择监护对象");
                } else {
                    showSelectServiceDialog();
                }
                break;
            case R.id.tv_upload:
                checkMust();
                break;
        }
    }

    private void checkMust() {
        String selectService = mTvSelectBaoxian.getText().toString().trim();
        if (mUserBeanResponse == null) {
            XToastUtils.showShortToast("请添加用户");
            return;
        } else if (mGuardianObjectResponse == null) {
            XToastUtils.showShortToast("请选择监护对象");
            return;
        } else if (CheckUtils.isEmpty(selectService)) {
            XToastUtils.showShortToast("请选择保险");
            return;
        }

        //检查保险额外添加的属性是否都填了
        for (int i = 0; i < mPolicyServiceTypeListBeans.size(); i++) {
            PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = mPolicyServiceTypeListBeans.get(i);
            String inputInfo = getInputInfo(i);
            if (CheckUtils.isEmpty(inputInfo)) {
                XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "不能为空");
                return;
            } else if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeSpecial(), "1") && !CheckUtils.isMobilePhone(inputInfo)) {//手机号
                XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "格式不正确");
                return;
            } else if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeSpecial(), "2")) {//身份证
                String idCArdNum = "";

                try {
                    idCArdNum = CheckUtils.IDCardValidate(inputInfo);
                } catch (Exception e) {
                    idCArdNum = "身份证格式错误";
                    e.printStackTrace();
                    XToastUtils.showLongToast("身份证无效");
                }
                if (!CheckUtils.equalsString(idCArdNum, "")) {
                    XToastUtils.showShortToast(policyServiceTypeListBean.getSysInsuranceTypeInputName() + "格式不正确");
                    return;
                }
            }
        }

        creatOrder();
    }

    /**
     * 生成订单
     */
    private void creatOrder() {
        String sysConfType = mGuardianObjectResponse.getSysConfType();
        String sysServiceTypeId = mGuardianObjectResponse.getSysServiceTypeId();
        String memberServiceObjId = mGuardianObjectResponse.getMemberServiceObjId();
        String memberServiceObjActiveFlag = mGuardianObjectResponse.getMemberServiceObjActiveFlag() + "";
        String appMemberId = mUserLoginInfo.getDataList().getAppMemberId();
        String sysAreaId = mUserLoginInfo.getDataList().getSysAreaId();
        String sysInstallPlaceId = mUserLoginInfo.getDataList().getSysInstallPlaceId();
        String memberOrderTotalPay = totalPayNum + "";
        String hLabelNo = mGuardianObjectResponse.gethLabelNo();
        String hPlateNo = mGuardianObjectResponse.gethPlateNo();

        List<BaoxianUploadResponse> porpertyJson = getUploadBaoxian();

        PayApiUtils.creatOrder(_mActivity, sysConfType, sysServiceTypeId, memberServiceObjId, memberServiceObjActiveFlag, appMemberId, sysAreaId, memberOrderTotalPay,
                porpertyJson, null, hLabelNo, hPlateNo, mGuardianObjectResponse.getSysAreaCarNumPrefix() + hPlateNo, "1",
                sysInstallPlaceId, new DialogCallback<AddOrderResponse>(_mActivity, "订单生成中...") {
                    @Override
                    public void onSuccess(AddOrderResponse addOrderResponse, Call call, Response response) {
                        if (addOrderResponse != null) {
                            addOrderResponse.setPayPrice(totalPayNum);
                            gotoPay(addOrderResponse);
                        } else {
                            XToastUtils.showShortToast("生成订单出错");
                        }
                    }

                });
    }

    /**
     * 获取上传的保险json
     */
    private List<BaoxianUploadResponse> getUploadBaoxian() {
        List<BaoxianUploadResponse> baoxianUploadResponses = new ArrayList<>();
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {//该行有被选中的保险
                //被选中的保险
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                BaoxianUploadResponse baoxianUploadResponse = new BaoxianUploadResponse();
                baoxianUploadResponse.setSysInsuranceConfPriceId(policyServiceTypeListBean.getSysInsuranceConfPriceId());
                baoxianUploadResponse.setSysInsuranceId(policyServiceTypeListBean.getSysInsuranceId());
                baoxianUploadResponse.setSysInsuranceTypeId(policyServiceTypeListBean.getSysInsuranceTypeId());
                baoxianUploadResponse.setSysInsuranceTypeName(policyServiceTypeListBean.getSysInsuranceTypeName());
                baoxianUploadResponse.setSysInsuranceConfYears(policyServiceTypeListBean.getSysInsuranceConfYears());
                baoxianUploadResponse.setSysInsurancePrice(policyServiceTypeListBean.getSysInsurancePrice() + "");
                if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeInput(), "1")) {//有额外输入
                    for (int j = 0; j < mPolicyServiceTypeListBeans.size(); j++) {//额外保险输入集合
                        if (CheckUtils.equalsString(mPolicyServiceTypeListBeans.get(j).getSysInsuranceConfId(), policyServiceTypeListBean.getSysInsuranceConfId())) {//id相同,说明是同一个
                            String inputInfo = getInputInfo(j);
                            baoxianUploadResponse.setSysInsuranceExValueStr(inputInfo);
                        }
                    }
                }
                baoxianUploadResponses.add(baoxianUploadResponse);
            }
        }
        return baoxianUploadResponses;
    }

    /**
     * 获取用户输入选择的值
     *
     * @param position 子view的位置
     * @return
     */
    private String getInputInfo(int position) {
        RelativeLayout relativeLayout = (RelativeLayout) mLlOtherAdd.getChildAt(position);

        EditText editText = (EditText) relativeLayout.getChildAt(1);
        String string = editText.getText().toString().trim();

        return string;
    }


    /**
     * 去支付
     *
     * @param addOrderResponse
     */
    private void gotoPay(AddOrderResponse addOrderResponse) {
        EventBus.getDefault().post(new EventManager(EventConstants.ORDER_CREATER_SUCCESS));
        Intent intent = new Intent(_mActivity, SelectPayTypeActivity.class);
        intent.putExtra("memberOrderId", addOrderResponse.getMemberOrderId());
        startActivity(intent);
    }

    /**
     * 显示选择保险dialog
     */
    private void showSelectServiceDialog() {
        SelectPolicyDialog dialog = new SelectPolicyDialog();
        dialog.setGuardianObjectResponse(mGuardianObjectResponse);
        dialog.setPolicyList(mPolicyList);
        dialog.show(getFragmentManager(), "selectPolicy");
    }

    /**
     * 清清除已选的服务信息
     */
    private void clearService() {
        //清除UI
        mTvSelectTitle.setText("选择保险");
        mTvSelectBaoxian.setText("");
        mLlOtherAdd.removeAllViews();
        //清除数据
        mPolicyList.clear();
        totalPayNum = 0;
        mMtvPayNum.setAmount(totalPayNum);
    }


    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.CAR_SELECT_SUCCESS://车辆选择成功
                Intent data = (Intent) eventManager.getData();
                mGuardianObjectResponse = (GuardianObjectResponse) data.getSerializableExtra("guardianObjectResponse");
                mUserBeanResponse = (UserBeanResponse) data.getSerializableExtra("userBean");
                setCarOwnerSelectSuccess();
                setCarInfo();
                clearService();
                break;
            case EventConstants.POLICY_SELECT_SUCCESS://保险选择成功
                Intent intent = (Intent) eventManager.getData();
                List<PolicyServiceResponse> policyList = (List<PolicyServiceResponse>) intent.getSerializableExtra("policyList");
                mPolicyList.clear();
                mPolicyList.addAll(policyList);
                mLlOtherAdd.removeAllViews();
                policySelectSucc();
                break;
            case EventConstants.SURE_USE_FREE_PWD://口令支付成功
            case EventConstants.PAY_SUCCESS://支付成功
                _mActivity.finish();
                break;
        }
    }

    /**
     * 保险选择成功
     */
    private void policySelectSucc() {
        mTvSelectTitle.setText("已选");
        totalPayNum = 0;
        String text = "";
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());
                totalPayNum = totalPayNum + policyServiceTypeListBean.getSysInsurancePrice();
                if (policyServiceTypeListBean.getSysInsurancePrice() == 0) {
                    text = text + policyServiceResponse.getTitle() + ":" + policyServiceTypeListBean.getSysInsuranceConfYearsShow() + " 赠送";
                } else {
                    text = text + policyServiceResponse.getTitle() + ":" + policyServiceTypeListBean.getSysInsuranceConfYearsShow() + " ¥" + policyServiceTypeListBean.getSysInsurancePrice();
                }
                if (i != mPolicyList.size() - 1) {
                    text = text + "\n";
                }
            }
        }
        mTvSelectBaoxian.setText(text);

        mPolicyServiceTypeListBeans.clear();
        //设置保险是否有额外添加属性
        for (int i = 0; i < mPolicyList.size(); i++) {
            PolicyServiceResponse policyServiceResponse = mPolicyList.get(i);
            if (policyServiceResponse.getPosition() != -1) {//该行有被选中的保险
                PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean = policyServiceResponse.getServiceTypeList().get(policyServiceResponse.getPosition());//被选中的具体服务
                if (CheckUtils.equalsString(policyServiceTypeListBean.getSysInsuranceTypeInput(), "1")) {//有额外输入
                    mPolicyServiceTypeListBeans.add(policyServiceTypeListBean);
                    addPolicyTextView(policyServiceTypeListBean);
                }
            }
        }

        mMtvPayNum.setAmount(totalPayNum);
    }

    /**
     * 添加保险文本输入模式控件
     *
     * @param policyServiceTypeListBean
     */
    private void addPolicyTextView(PolicyServiceResponse.PolicyServiceTypeListBean policyServiceTypeListBean) {
        View view = View.inflate(_mActivity, R.layout.service_text_view, null);
        TextView tvNoticeContent = (TextView) view.findViewById(R.id.tv_notice_content);
        TextView tvTextTitle = (TextView) view.findViewById(R.id.tv_text_title);
        EditText etText = (EditText) view.findViewById(R.id.et_text);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.bottomMargin = Utils.dp2px(1);
        mLlOtherAdd.addView(view, layoutParams);

        tvTextTitle.setText(policyServiceTypeListBean.getSysInsuranceTypeInputName());
        etText.setHint(policyServiceTypeListBean.getSysInsuranceTypeInputName());
        tvNoticeContent.setText(policyServiceTypeListBean.getSysInsuranceTypeInputInfo());
    }


    /**
     * 车主选择成功
     */
    private void setCarOwnerSelectSuccess() {
        mTvAddCarOwner.setText(mUserBeanResponse.getMemberName());
        mTvAddCarOwner.setCompoundDrawables(null, null, null, null);
        mTvAddCarOwner.setTextColor(_mActivity.getResources().getColor(R.color.color_666666));
        mIvCarOwnerMore.setText("更换用户");

        mTvCarBrandModel.setText("添加对象");
        mTvCarBrandModel.setTextColor(_mActivity.getResources().getColor(R.color.color_008cff));
        Drawable drawable = _mActivity.getResources().getDrawable(R.drawable.list_add);
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        mTvCarBrandModel.setCompoundDrawablePadding(10);//设置图片和text之间的间距
        mTvCarBrandModel.setCompoundDrawables(drawable, null, null, null);

        mTvCarOwnerPhone.setVisibility(View.VISIBLE);
        if (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) && CheckUtils.isEmpty(mUserBeanResponse.getSysProName())
                && CheckUtils.isEmpty(mUserBeanResponse.getSysCityName())) {//运营商,省市均为空
            mTvCarOwnerPhone.setText(mUserBeanResponse.getMemberAccount());
        } else {
            mTvCarOwnerPhone.setText(mUserBeanResponse.getMemberAccount() + "("
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysMobileName()) ? "" : mUserBeanResponse.getSysMobileName())
                    + " " + (CheckUtils.isEmpty(mUserBeanResponse.getSysProName()) ? "" : mUserBeanResponse.getSysProName())
                    + (CheckUtils.isEmpty(mUserBeanResponse.getSysCityName()) ? "" : mUserBeanResponse.getSysCityName())
                    + ")");
        }
    }


    /**
     * 车辆选择成功
     */
    private void setCarInfo() {
        mTvCarBrandModel.setTextColor(_mActivity.getResources().getColor(R.color.color_666666));
        mTvCarBrandModel.setCompoundDrawables(null, null, null, null);
        mIvCarInfoMore.setVisibility(View.VISIBLE);

        String text = "监护对象类型   (" + mGuardianObjectResponse.getSysServiceTypeName() + ")\n"
                + mGuardianObjectResponse.getSysPropertyValueStr() + "     已激活\n"
                + "标签号   (" + mGuardianObjectResponse.gethLabelNo() + ")";
        //启用车牌
        if (CheckUtils.equalsString(mGuardianObjectResponse.getSysServiceTypeSpecialType(), "1")
                && CheckUtils.equalsString(mGuardianObjectResponse.getSysAreaCarNumEnabled(), "1")) {
            text = text + "\n车牌号   (" + mGuardianObjectResponse.getSysAreaCarNumPrefix() + mGuardianObjectResponse.gethPlateNo() + ")";
        }

        //高亮显示已激活
        mTvCarBrandModel.setText(Utils.matcherSearchText(_mActivity.getResources().getColor(R.color.color_12bc00), text, "已激活"));

        if (CheckUtils.equalsString(mGuardianObjectResponse.getSysConfType(), "1")) {
            mTvBusinessType.setText("个人业务");
        } else {
            mTvBusinessType.setText("集团业务(" + mGuardianObjectResponse.getSysGroupName() + ")");
        }
    }
}
