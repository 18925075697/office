package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;
import java.util.Date;


public class VersionInfo implements Serializable {

    /**
     * AndroidUpdate : 1
     * AndroidVersion : 300
     * IOSUpdated : 1
     * IOSVersion : 300
     */

    private String AndroidUpdate;
    private String AndroidVersion;
    private String IOSUpdated;
    private String IOSVersion;
    private String id;
    private boolean needUpdate;
    private boolean isDownload;// 判断是否正在下载新版本
    private boolean unRemind;//是否点击不再提醒
    private Date date;//点击不再提醒的时间

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isUnRemind() {
        return unRemind;
    }

    public void setUnRemind(boolean unRemind) {
        this.unRemind = unRemind;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isDownload() {
        return isDownload;
    }

    public void setDownload(boolean download) {
        isDownload = download;
    }

    public boolean isNeedUpdate() {
        return needUpdate;
    }

    public void setNeedUpdate(boolean needUpdate) {
        this.needUpdate = needUpdate;
    }

    public String getAndroidUpdate() {
        return AndroidUpdate;
    }

    public void setAndroidUpdate(String AndroidUpdate) {
        this.AndroidUpdate = AndroidUpdate;
    }

    public String getAndroidVersion() {
        return AndroidVersion;
    }

    public void setAndroidVersion(String AndroidVersion) {
        this.AndroidVersion = AndroidVersion;
    }

    public String getIOSUpdated() {
        return IOSUpdated;
    }

    public void setIOSUpdated(String IOSUpdated) {
        this.IOSUpdated = IOSUpdated;
    }

    public String getIOSVersion() {
        return IOSVersion;
    }

    public void setIOSVersion(String IOSVersion) {
        this.IOSVersion = IOSVersion;
    }
}