package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.widget.TextView;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.api.HomeApiUtils;
import com.dgzrdz.mobile.cocobee.callback.JsonCallback;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.BusinessResponse;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import java.util.List;

import butterknife.BindView;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Description:业务统计
 * Author: Liubingren
 * Data:  2018/11/9
 * Time:  14:56
 */

public class BusinessStatisticsFragment extends BaseFragment {
    @BindView(R.id.today_person_num)
    TextView mTodayPersonNum;
    @BindView(R.id.today_group_num)
    TextView mTodayGroupNum;
    @BindView(R.id.week_person_num)
    TextView mWeekPersonNum;
    @BindView(R.id.week_group_num)
    TextView mWeekGroupNum;
    @BindView(R.id.month_person_num)
    TextView mMonthPersonNum;
    @BindView(R.id.month_group_num)
    TextView mMonthGroupNum;
    @BindView(R.id.total_person_num)
    TextView mTotalPersonNum;
    @BindView(R.id.total_group_num)
    TextView mTotalGroupNum;
    private UserInfo mUserLoginInfo;

    public static BusinessStatisticsFragment getInstance() {
        BusinessStatisticsFragment fragment = new BusinessStatisticsFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mUserLoginInfo = Utils.getUserLoginInfo();
        getData();
    }

    /**
     * 获取数据
     */
    private void getData() {
        HomeApiUtils.getBussinessInfo(_mActivity, mUserLoginInfo.getDataList().getAppMemberId(), new JsonCallback<BusinessResponse>(_mActivity) {

            @Override
            public void onSuccess(BusinessResponse businessResponse, Call call, Response response) {
                if (businessResponse != null) {
                    List<BusinessResponse.TotalBean> today = businessResponse.getToday();
                    List<BusinessResponse.TotalBean> seven = businessResponse.getSeven();
                    List<BusinessResponse.TotalBean> thirty = businessResponse.getThirty();
                    List<BusinessResponse.TotalBean> total = businessResponse.getTotal();
                    commenView(today, mTodayGroupNum, mTodayPersonNum);
                    commenView(seven, mWeekGroupNum, mWeekPersonNum);
                    commenView(thirty, mMonthGroupNum, mMonthPersonNum);
                    commenView(total, mTotalGroupNum, mTotalPersonNum);
                }else {
                    XToastUtils.showShortToast("暂无数据");
                }
            }
        });
    }

    private void commenView(List<BusinessResponse.TotalBean> today, TextView todayGroupNum, TextView todayPersonNum) {
        if (today != null) {
            for (int i = 0; i < today.size(); i++) {
                BusinessResponse.TotalBean totalBean = today.get(i);
                if (totalBean.getSysConfType() == 2) {//集团业务
                    todayGroupNum.setText(totalBean.getTotal());
                } else {
                    todayPersonNum.setText(totalBean.getTotal());
                }
            }
        }
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("业务办理统计");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_business_statistics;
    }
}
