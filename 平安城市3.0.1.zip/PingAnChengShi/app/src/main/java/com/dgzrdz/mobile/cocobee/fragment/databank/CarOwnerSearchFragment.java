package com.dgzrdz.mobile.cocobee.fragment.databank;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.bql.utils.EventManager;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.data.SelectBindingCarPolicyActivity;
import com.dgzrdz.mobile.cocobee.adapter.CarOwnerSearchDataAdapter;
import com.dgzrdz.mobile.cocobee.api.DatasApiUtils;
import com.dgzrdz.mobile.cocobee.callback.LoadingViewCallback;
import com.dgzrdz.mobile.cocobee.common.EventConstants;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.response.UserBeanResponse;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * 车主资料库fragment
 * Created by Administrator on 2017/4/17.
 */

public class CarOwnerSearchFragment extends RefreshAndLoadFragment<UserBeanResponse> {
    @BindView(R.id.search_et_input)
    EditText mSearchEtInput;
    @BindView(R.id.search_iv_delete)
    ImageView mSearchIvDelete;

    private CarOwnerSearchDataAdapter adapter;
    private String currentTime;

    public static CarOwnerSearchFragment getInstance() {
        CarOwnerSearchFragment fragment = new CarOwnerSearchFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setSwipeBackEnable(false);
        adapter = new CarOwnerSearchDataAdapter(_mActivity, mList, "");
        initEditText();
    }

    private void initEditText() {
        mSearchEtInput.addTextChangedListener(new EditChangedListener());

        //响应回车键
        mSearchEtInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    notifyStartSearching();
                }
                return true;
            }
        });
    }

    /**
     * 通知监听者 进行搜索操作
     */
    private void notifyStartSearching() {
        //隐藏软键盘
        InputMethodManager imm = (InputMethodManager) _mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        loadDataList(1, true);
    }

    @OnClick({R.id.search_iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.search_iv_delete:
                mSearchEtInput.setText("");
                mSearchIvDelete.setVisibility(View.VISIBLE);
                break;
        }
    }

    private class EditChangedListener implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (!"".equals(charSequence.toString())) {
                mSearchIvDelete.setVisibility(View.VISIBLE);
            } else {
                mSearchIvDelete.setVisibility(View.GONE);
                notifyStartSearching();
            }
            setRecycleView(charSequence.toString());
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    }

    private void setRecycleView(String key) {
        adapter = new CarOwnerSearchDataAdapter(_mActivity, mList, key);
        mRcvLoadMore.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("选择用户");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_car_owner_search;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {
        UserBeanResponse userBeanResponse = mList.get(position);
        Intent intent = new Intent(_mActivity, SelectBindingCarPolicyActivity.class);
        intent.putExtra("userBean", userBeanResponse);
        startActivity(intent);
    }

    @Override
    public QuickRcvAdapter<UserBeanResponse> getAdapter() {
        return adapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {
    }

    @Override
    public boolean canRefresh() {
        return false;
    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        String value = mSearchEtInput.getText().toString().trim();

        mCurPage = curPage;
        if (mCurPage == 1) {
            long millis = System.currentTimeMillis();
            currentTime = DateUtils.format(millis, "yyyy-MM-dd HH:mm:ss");
        }

        DatasApiUtils.carHostSearch(_mActivity, value, userLoginInfo.getDataList().getSysAreaId(), currentTime, curPage + "", pageSize + "", new RefreshAndLoadCallback<List<UserBeanResponse>>(isPullToRefresh) {

            @Override
            public void errorLeftOrEmptyBtnClick(View v) {
                loadDataList(1, false);
            }

            @Override
            public void onResultSuccess(List<UserBeanResponse> carOwnerInfos, @Nullable Response response, LoadingViewCallback callback) {
                if (carOwnerInfos != null) {
                    handleRefreshAndLoadListData(curPage, callback, carOwnerInfos);
                } else {
                    mList.clear();
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideAllView();
            }
        });
    }

    @Override
    public void onLoadMore() {
    }

    @Override
    public boolean registerEventBus() {
        return true;
    }

    @Override
    protected void onHandleEvent(EventManager eventManager) {
        super.onHandleEvent(eventManager);
        switch (eventManager.getEventCode()) {
            case EventConstants.CAR_SELECT_SUCCESS://预登记车辆选择成功
                _mActivity.finish();
                break;
            case EventConstants.PRE_REGIST_SUCCESS://预登记车辆录入成功
                loadDataList(1, true);
                break;
        }
    }
}
