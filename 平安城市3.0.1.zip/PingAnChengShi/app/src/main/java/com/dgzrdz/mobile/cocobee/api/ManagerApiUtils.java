package com.dgzrdz.mobile.cocobee.api;

import android.content.Context;

import com.dgzrdz.mobile.cocobee.common.Path;
import com.dgzrdz.mobile.cocobee.model.UserInfo;
import com.dgzrdz.mobile.cocobee.utils.DateUtils;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2018/4/16.
 * 网络请求接口  管理
 * 一个参数直接传
 * 两个以上参数以Json格式
 */

public class ManagerApiUtils {

    /**
     * 管理页面搜索车主和手机号
     *
     * @param context
     * @param type       1车，2人,搜索类型
     * @param value      搜索值
     * @param createtime 当前时间
     * @param offset     当前页
     * @param limit      每页条数
     * @param callback   回调
     */
    public static void managerSearch(Context context, String type, String value, String createtime, String offset, String limit, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("type", type);
        params.put("value", value);
        params.put("createtime", createtime);
        params.put("offset", offset);
        params.put("limit", limit);
        JSONObject jsonObject = new JSONObject(params);
        OkGo.post(Path.SEARCH_CAR_OWNER_NAME).tag(context).upJson(jsonObject).execute(callback);
    }

    /**
     * 管理页面标签搜索
     *
     * @param context
     * @param sysAreaId 组织机构id
     * @param callback  回调
     */
    public static void getAlarmTagInfos(Context context, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.GET_ALARM_TAG_INFOS).tag(context).params(params).execute(callback);
    }

    /**
     * 管理页面手动踩点上传数据
     *
     * @param context
     * @param createuser 创建人id
     * @param identity   110识别码
     * @param sysAreaId  组织机构id
     * @param eqlng      经度
     * @param eqlat      纬度
     * @param eqaddr     地址
     * @param callback   回调
     */
    public static void shouDongCaiDian(Context context, String createuser, String identity, String sysAreaId, String eqlng, String eqlat, String eqaddr, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("createuser", createuser);
        params.put("identity", identity);
        params.put("sysAreaId", sysAreaId);
        params.put("eqlng", eqlng);
        params.put("eqlat", eqlat);
        params.put("eqaddr", eqaddr);
        OkGo.post(Path.UPLOAD_POINT_INFOS).tag(context).params(params).execute(callback);
    }

    /**
     * 管理页面修改点位数据
     *
     * @param context
     * @param eqaddr    地址
     * @param identity  110编码
     * @param eqid      id
     * @param eqlng     经度
     * @param eqlat     纬度
     * @param sysAreaId 组织机构id
     * @param callback  回调
     */
    public static void updatePointInfo(Context context, String eqaddr, String identity, String eqid, String eqlat, String eqlng, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("eqaddr", eqaddr);
        params.put("identity", identity);
        params.put("eqid", eqid);
        params.put("eqlat", eqlat);
        params.put("eqlng", eqlng);
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.UPDATE_POINTS_INFO).tag(context).params(params).execute(callback);
    }


    /**
     * 管理页面上传便民服务点
     *
     * @param context
     * @param lat      经度
     * @param lng      纬度
     * @param name     便民点名称
     * @param address  地址
     * @param orgids   组织机构
     * @param category 类型：1:加油站 2:充电站 3:维修点
     * @param callback 回调
     */
    public static void uploadConviniencePoint(Context context, String lat, String lng, String name, String address, String orgids, String category, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("lat", lat);
        params.put("lng", lng);
        params.put("name", name);
        params.put("address", address);
        params.put("orgids", orgids);
        params.put("category", category);
        Gson gson = new Gson();
        String s = gson.toJson(params);
        OkGo.post(Path.UPLOAD_CONVINIENCE_POINT).tag(context).upJson(s).execute(callback);
    }

    /**
     * 管理页面修改便民服务点
     *
     * @param context
     * @param address  地址
     * @param lat      经度
     * @param lng      纬度
     * @param name     便民点名称
     * @param orgid    组织机构
     * @param sid      表id
     * @param category 类型：1:加油站 2:充电站 3:维修点
     * @param callback 回调
     */
    public static void updateConviniencePoint(Context context, String address, String lat, String lng, String name, String orgid, String sid, String category, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("lat", lat);
        params.put("lng", lng);
        params.put("name", name);
        params.put("address", address);
        params.put("orgid", orgid);
        params.put("sid", sid);
        params.put("category", category);
        Gson gson = new Gson();
        String s = gson.toJson(params);
        OkGo.post(Path.UPDATE_CONVINIENCE_POINT).tag(context).upJson(s).execute(callback);
    }

    /**
     * 管理页面点位管理
     *
     * @param context
     * @param sysAreaId 组织机构id
     * @param callback  回调
     */
    public static void getPointsInfo(Context context, String sysAreaId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sysAreaId", sysAreaId);
        OkGo.post(Path.GET_POINTS_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 管理页面安装调试采集器查询
     *
     * @param context
     * @param jzxlh    基站序列号
     * @param callback 回调
     */
    public static void checkStationHas(Context context, String jzxlh, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("repeat", "");
        params.put("lng1", "");
        params.put("lat1", "");
        params.put("lng2", "");
        params.put("lat2", "");
        params.put("jzxlh", jzxlh);
        UserInfo userLoginInfo = Utils.getUserLoginInfo();
        OkGo.post(Path.CHECK_STATION_HAS).tag(context).headers("token", userLoginInfo.getToken()).params(params).execute(callback);
    }

    /**
     * 管理页面安装调试上报数据
     *
     * @param context
     * @param eqno            基站序列号
     * @param eqip            采集器Ip
     * @param eqport          采集器端口
     * @param eqlng           经度
     * @param eqlat           纬度
     * @param identity        110快速编码
     * @param eqaddr          采集器地址
     * @param imeino          IMEI卡号
     * @param factoryno       出厂编码
     * @param line_local_ip   本地ip
     * @param line_local_port 本地端口
     * @param line_local_ip2   有线ip
     * @param line_local_port2 有线端口
     * @param orgid           组织机构id
     * @param librepeat       去重过滤时间
     * @param hearttime       停留时间
     * @param createuser      创建人id
     * @param callback        回调
     */
    public static void uploadStationInfo(Context context, String eqno, String eqip, String eqport, String eqlng, String eqlat, String identity, String eqaddr,
                                         String imeino, String factoryno, String line_local_ip, String line_local_port, String line_local_ip2, String line_local_port2, String orgid, String librepeat, String hearttime,
                                         String createuser, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("eqno", eqno);
        params.put("eqip", eqip);
        params.put("eqport", eqport);
        params.put("eqlng", eqlng);
        params.put("eqlat", eqlat);
        params.put("identity", identity);
        params.put("eqaddr", eqaddr);
        params.put("imeino", imeino);
        params.put("factoryno", factoryno);
        params.put("line_local_ip", line_local_ip);
        params.put("line_local_port", line_local_port);
        params.put("line_local_ip2", line_local_ip2);
        params.put("line_local_port2", line_local_port2);
        params.put("orgid", orgid);
        params.put("librepeat", librepeat);
        params.put("hearttime", hearttime);
        params.put("createuser", createuser);

        OkGo.post(Path.UPLOAD_STATION_INFO).tag(context).params(params).execute(callback);
    }

    /**
     * 管理页面获取基站位置信息
     *
     * @param context
     * @param repeat   历史经纬度
     * @param lng1     纬度
     * @param lat1     纬度
     * @param lng2     经度
     * @param lat2     纬度
     * @param jzxlh    基站序列号
     * @param callback 回调
     */
    public static void getStationLocation(Context context, String repeat, String lng1, String lat1, String lng2, String lat2, String jzxlh, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("repeat", repeat);
        params.put("lng1", lng1);
        params.put("lat1", lat1);
        params.put("lng2", lng2);
        params.put("lat2", lat2);
        params.put("jzxlh", jzxlh);
        OkGo.post(Path.GET_STATION_LOCATION).tag(context).params(params).execute(callback);
    }

    /**
     * 管理页面便民服务点查询
     *
     * @param context
     * @param code     组织机构code
     * @param callback 回调
     */
    public static void getConvinience(Context context, String code, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("code", code);
        OkGo.post(Path.GET_CONVINIENCE).tag(context).params(params).execute(callback);
    }

    /**
     * 获取标签最后位置
     *
     * @param context
     * @param labelId  标签号
     * @param callback 回调
     */
    public static void getLabelLastPosition(Context context, String labelId, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("labelId", labelId);
        OkGo.get(Path.GET_CAR_LAST_POSITION).tag(context).params(params).execute(callback);
    }

    /**
     * 获取标签轨迹
     *
     * @param context
     * @param labelId   标签号
     * @param beginTime 开始时间
     * @param endTime   结束时间
     * @param callback  回调
     */
    public static void getLabelTrace(Context context, String labelId, String beginTime, String endTime, AbsCallback callback) {
        OkGo.post(Path.GET_CAR_TRACE).tag(context)
                .params("labelId", labelId)
                .params("beginTime", DateUtils.getLongFromString(beginTime, DateUtils.DATE_TIME_FORMAT_S) / 1000)
                .params("endTime", DateUtils.getLongFromString(endTime, DateUtils.DATE_TIME_FORMAT_S) / 1000)
                .execute(callback);
    }

    /**
     * 通过车牌号获取车主信息和车辆照片
     *
     * @param context
     * @param key      车牌号密文
     * @param callback 回调
     */
    public static void getCarInfoByCno(Context context, String key, AbsCallback callback) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("key", key);
        OkGo.get(Path.GET_CAR_INFO_BY_CNO).tag(context).params(params).execute(callback);
    }
}
