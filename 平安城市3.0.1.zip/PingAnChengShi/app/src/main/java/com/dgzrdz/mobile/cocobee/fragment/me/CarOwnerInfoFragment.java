package com.dgzrdz.mobile.cocobee.fragment.me;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.fragment.base.BaseFragment;
import com.dgzrdz.mobile.cocobee.model.Policy;

import butterknife.BindView;

/**
 * Created by Administrator on 2018/5/16.
 */

public class CarOwnerInfoFragment extends BaseFragment {
    private static Policy policy;
    @BindView(R.id.tv_select_org)
    TextView mTvSelectOrg;
    @BindView(R.id.nameEdt)
    TextView mNameEdt;
    @BindView(R.id.idEdt)
    TextView mIdEdt;
    @BindView(R.id.sexTxt)
    TextView mSexTxt;
    @BindView(R.id.telEdt)
    EditText mTelEdt;
    @BindView(R.id.addressTxt)
    TextView mAddressTxt;
    @BindView(R.id.addressEdt)
    TextView mAddressEdt;
    @BindView(R.id.reg_addressTxt)
    TextView mRegAddressTxt;

    public static CarOwnerInfoFragment getInstance(Policy policy) {
        CarOwnerInfoFragment.policy = policy;
        CarOwnerInfoFragment fragment = new CarOwnerInfoFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        setView();
    }

    private void setView() {
        mTvSelectOrg.setText(policy.getOwnerOrgName());
        mNameEdt.setText(policy.getName());
        mIdEdt.setText(policy.getIdcard());
        mSexTxt.setText(CheckUtils.equalsString(policy.getSex(), "0") ? "男" : "女");
        mTelEdt.setText(policy.getMobile());
        mAddressEdt.setText(policy.getAddress());
        mRegAddressTxt.setText(policy.getRegiaddr());
    }

    @Override
    protected void initToolbarHere() {
        initToolbar("车主信息");
    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_car_owner_info;
    }

}
