package com.dgzrdz.mobile.cocobee.fragment.home;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bql.baseadapter.recycleView.QuickRcvAdapter;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.adapter.CarNumInventoryAdapter;
import com.dgzrdz.mobile.cocobee.fragment.base.RefreshAndLoadFragment;
import com.dgzrdz.mobile.cocobee.response.CarNumInventoryResponse;
import com.dgzrdz.mobile.cocobee.view.ListLineDecoration;

/**
 * Created by Administrator on 2018/6/26.
 */

public class CarNumFragment extends RefreshAndLoadFragment<CarNumInventoryResponse> {
    private CarNumInventoryAdapter mCarNumInventoryAdapter;

    public static LabelFragment getInstance() {
        LabelFragment fragment = new LabelFragment();
        return fragment;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        mCarNumInventoryAdapter = new CarNumInventoryAdapter(_mActivity, mList);
    }

    @Override
    protected boolean isAddHeaderView() {
        return true;
    }

    @Override
    protected View getHeaderView() {
        View view = View.inflate(_mActivity, R.layout.view_car_num_head, null);
        return view;
    }

    @Override
    public boolean isHideToolbarLayout() {
        return true;
    }

    @Override
    protected void initToolbarHere() {

    }

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.view_ptr_load;
    }

    @Override
    public void onRcvItemClick(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public QuickRcvAdapter getAdapter() {
        return mCarNumInventoryAdapter;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return new ListLineDecoration();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(_mActivity);
    }

    @Override
    public void onRefresh() {

    }

    @Override
    public void loadDataList(int curPage, boolean isPullToRefresh) {
        for (int i = 0; i < 5; i++) {
            CarNumInventoryResponse response = new CarNumInventoryResponse();
            mList.add(response);
        }
        mCarNumInventoryAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoadMore() {

    }
}