package com.dgzrdz.mobile.cocobee.activity.manager;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bql.utils.CheckUtils;
import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseToolbarActivity;
import com.dgzrdz.mobile.cocobee.btreader.BlueToothHelper;
import com.dgzrdz.mobile.cocobee.common.Constant;
import com.dgzrdz.mobile.cocobee.response.TestModeResponse;
import com.dgzrdz.mobile.cocobee.utils.Tools;
import com.dgzrdz.mobile.cocobee.utils.Utils;
import com.dgzrdz.mobile.cocobee.utils.XToastUtils;

import butterknife.BindView;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;

/**
 * 天线测试页面
 *
 * @author marktrace
 * @date 16/11/23
 */
public class AntennaTestAct extends BaseToolbarActivity {

    @BindView(R.id.et_tag_id)
    EditText mEtTagId;
    @BindView(R.id.et_rssi_start)
    EditText mEtRssiStart;
    @BindView(R.id.et_rssi_end)
    EditText mEtRssiEnd;
    @BindView(R.id.et_test_result)
    EditText mEtTestResult;
    @BindView(R.id.et_rssi_gprs)
    EditText mEtRssiGprs;
    @BindView(R.id.et_gprs_connect)
    EditText mEtGprsConnect;
    @BindView(R.id.et_net_status)
    EditText mEtNetStatus;
    @BindView(R.id.tx_one_rssi_et)
    EditText mTxOneRssiEt;
    @BindView(R.id.et_one_east)
    EditText mEtOneEast;
    @BindView(R.id.tx_one_rssi_c_et)
    EditText mTxOneRssiCEt;
    @BindView(R.id.et_one_east_c)
    EditText mEtOneEastC;
    @BindView(R.id.tx_two_rssi_et)
    EditText mTxTwoRssiEt;
    @BindView(R.id.et_two_south)
    EditText mEtTwoSouth;
    @BindView(R.id.tx_two_rssi_c_et)
    EditText mTxTwoRssiCEt;
    @BindView(R.id.et_two_south_c)
    EditText mEtTwoSouthC;
    @BindView(R.id.tx_three_rssi_et)
    EditText mTxThreeRssiEt;
    @BindView(R.id.et_three_west)
    EditText mEtThreeWest;
    @BindView(R.id.tx_three_rssi_c_et)
    EditText mTxThreeRssiCEt;
    @BindView(R.id.et_three_west_c)
    EditText mEtThreeWestC;
    @BindView(R.id.tx_four_rssi_et)
    EditText mTxFourRssiEt;
    @BindView(R.id.et_four_north)
    EditText mEtFourNorth;
    @BindView(R.id.tx_four_rssi_c_et)
    EditText mTxFourRssiCEt;
    @BindView(R.id.et_four_north_c)
    EditText mEtFourNorthC;
    @BindView(R.id.start_read_btn)
    TextView mStartReadBtn;
    @BindView(R.id.set_nomal_btn)
    TextView mSetNomalBtn;
    @BindView(R.id.stop_read_btn)
    TextView mStopReadBtn;
    private Context context;
    private BlueToothHelper reader;// Blue Tooth reader
    private MediaPlayer mp;

    private SweetAlertDialog sDialog;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.act_antennadebug_test;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        initToolbarWithRightText("天线测试模式", "天线信息");
        context = this;
        reader = BlueToothHelper.getInstance(handler);
        mp = MediaPlayer.create(AntennaTestAct.this, R.raw.beep);
        initSharprefrence();
    }

    @Override
    public void btnRightTextClick() {
        startActivity(new Intent(context, AntennaInfoAct.class));
    }

    /**
     * 获取保存的标签号和rssi值
     */
    private void initSharprefrence() {
        mEtTagId.setText(Utils.getTestModeTag());
        mEtRssiStart.setText(Utils.getTestModeP());
        mEtRssiEnd.setText(Utils.getTestModeS());
    }

    @Override
    protected void onResume() {
        super.onResume();
        reader = BlueToothHelper.getInstance(handler);
    }

    private Handler handler = new MyHandler(AntennaTestAct.this);

    static class MyHandler extends Handler {

        private final AntennaTestAct mAntennaTestAct;

        public MyHandler(AntennaTestAct antennaTestAct) {
            mAntennaTestAct = antennaTestAct;
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mAntennaTestAct.handleSuccess(msg);
        }
    }

    private void handleSuccess(Message msg) {
        hideDialog();
        if (mp != null) {
            mp.start();
        }
        switch (msg.what) {
            case BlueToothHelper.MSG_SET_TEST_MODE_OK://设置测试模式成功
                XToastUtils.showShortToast("设置测试模式成功,进入测试模式");
                break;
            case BlueToothHelper.MSG_SET_TEST_MODE_FAIL://设置测试模式失败
                XToastUtils.showShortToast("设置测试模式失败");
                break;
            case BlueToothHelper.MSG_NO_BLUETOOTH_SOCKET:
                Toast.makeText(context, "蓝牙Socket已丢失，请重新连接设备", Toast.LENGTH_SHORT).show();
                break;
            case BlueToothHelper.MSG_GET_TEST_RESULT_OK://查询测试结果成功
                TestModeResponse testModeResponse = (TestModeResponse) msg.obj;

                //主天线门限
                //                    mEtRssiStart.setText(testModeResponse.getPrincipal());
                //                    mEtRssiEnd.setText(testModeResponse.getSubordinate());

                mEtTestResult.setText(testModeResponse.getTestResult());
                mEtRssiGprs.setText(testModeResponse.getGprsRssi());
                mEtGprsConnect.setText(testModeResponse.getGprsConnect());
                mEtNetStatus.setText(testModeResponse.getFireConnect());

                //东主
                mTxOneRssiEt.setText(testModeResponse.getEastPRssi());
                mEtOneEast.setText(testModeResponse.getEastP());

                //东从
                mTxOneRssiCEt.setText(testModeResponse.getEastSRssi());
                mEtOneEastC.setText(testModeResponse.getEastS());

                //南主
                mTxTwoRssiEt.setText(testModeResponse.getSouthPRssi());
                mEtTwoSouth.setText(testModeResponse.getSouthP());

                //南从
                mTxTwoRssiCEt.setText(testModeResponse.getSouthSRssi());
                mEtTwoSouthC.setText(testModeResponse.getSouthS());

                //西主
                mTxThreeRssiEt.setText(testModeResponse.getWestPRssi());
                mEtThreeWest.setText(testModeResponse.getWestP());

                //西从
                mTxThreeRssiCEt.setText(testModeResponse.getWestSRssi());
                mEtThreeWestC.setText(testModeResponse.getWestS());

                //北主
                mTxFourRssiEt.setText(testModeResponse.getNorthPRssi());
                mEtFourNorth.setText(testModeResponse.getNorthP());

                //北从
                mTxFourRssiCEt.setText(testModeResponse.getNorthSRssi());
                mEtFourNorthC.setText(testModeResponse.getNorthS());
                break;
            case BlueToothHelper.MSG_GET_TEST_RESULT_FAIL://查询测试结果失败
                XToastUtils.showShortToast("获取测试结果失败");
                break;
            default:
                break;
        }
    }


    /**
     * 隐藏进度框
     */
    private void hideDialog() {
        if (sDialog != null && sDialog.isShowing()) {
            sDialog.dismiss();
        }
    }


    @OnClick({R.id.start_read_btn, R.id.set_nomal_btn, R.id.stop_read_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.start_read_btn://设置测试模式
                if (!isConnected()) {
                    XToastUtils.showShortToast("未连接设备，无法设置");
                    return;
                }
                setTestMode();
                break;
            case R.id.set_nomal_btn://设置正常模式
                if (!isConnected()) {
                    XToastUtils.showShortToast("未连接设备，无法设置");
                    return;
                }

                setNormalMode();
                break;
            case R.id.stop_read_btn://查询测试结果
                getTestResult();
                break;
        }
    }

    /**
     * 设置正常模式
     */
    private void setNormalMode() {
        initDislog();
        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            //            reader.debugTX(BlueToothHelper.DEBUG_TX_COMMAND);
        } else {
            reader.bleSendCmd(Constant.BLE_SET_NORMAL_MODE, BlueToothHelper.SET_NORMAL_MODE, true);
        }
    }

    /**
     * 查询测试结果
     */
    private void getTestResult() {
        initDislog();
        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            reader.debugTX(BlueToothHelper.DEBUG_TX_COMMAND);
        } else {
            reader.bleSendCmd(Constant.BLE_GET_TEST_RESULT, BlueToothHelper.GET_TEST_RESULT, true);
        }
    }

    private void initDislog() {
        sDialog = new SweetAlertDialog(AntennaTestAct.this, SweetAlertDialog.PROGRESS_TYPE);
        sDialog.setTitleText("正在发送...");
        sDialog.getProgressHelper().setBarColor(Color.parseColor("#4169e1"));
        sDialog.setCancelable(true);
        sDialog.setCanceledOnTouchOutside(true);
        sDialog.show();
    }

    /**
     * 设置测试模式
     */
    private void setTestMode() {
        String tagId = mEtTagId.getText().toString().trim();
        String rssiStart = mEtRssiStart.getText().toString().trim();
        String rssiEnd = mEtRssiEnd.getText().toString().trim();

        if (CheckUtils.isEmpty(tagId)) {
            XToastUtils.showShortToast("请输入要测试的标签号");
        } else if (CheckUtils.isEmpty(rssiStart)) {
            XToastUtils.showShortToast("请输入rssi范围最小值");
        } else if (CheckUtils.isEmpty(rssiEnd)) {
            XToastUtils.showShortToast("请输入rssi范围最大值");
        } else {
            initDislog();
            //保存输入的标签号和rssi值
            Utils.putTestModeTag(tagId);
            Utils.putTestModeP(rssiStart);
            Utils.putTestModeS(rssiEnd);

            byte[] cmd = getSendCMD(tagId, rssiStart, rssiEnd);
            if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                reader.debugTX(BlueToothHelper.DEBUG_TX_COMMAND);
            } else {
                reader.bleSendCmd(Constant.BLE_SET_TEST_MODE, cmd, false);
            }
        }

    }

    private byte[] getSendCMD(String tagId, String rssiStart, String rssiEnd) {
        byte[] cmd = new byte[14];
        cmd[0] = 0x0A;  //sof
        cmd[1] = (byte) 0xFF; //addr
        cmd[2] = 0x0B;
        cmd[3] = 0x51;
        cmd[4] = 0x01;
        int cmdIndex = 5;
        byte[] tagid = Tools.hexStringToByte(tagId);
        for (int j = 0; j < 4; j++) {
            cmd[cmdIndex++] = tagid[j];
        }
        cmd[9] = Tools.int2byte(Integer.parseInt(rssiStart))[0];
        cmd[10] = Tools.int2byte(Integer.parseInt(rssiEnd))[0];
        cmd[11] = 0x00;
        cmd[12] = 0x78;
        cmd[13] = Tools.calCheck(cmd);
        return cmd;
    }

    /**
     * 是否连接
     *
     * @return
     */
    private boolean isConnected() {

        SharedPreferences sp = getSharedPreferences(Constant.SP_CONNECT_STATUS, Context.MODE_PRIVATE);
        boolean status = sp.getBoolean(Constant.CONNECT_STATUS, false);

        if (reader.getBluetoothType() == BluetoothDevice.DEVICE_TYPE_CLASSIC && status && (reader.getSocket() == null || !reader.getSocket().isConnected())) { //如果当前标记已连接，但是socket连接实际已经断了
            SharedPreferences.Editor editor = sp.edit();
            editor.putBoolean(Constant.CONNECT_STATUS, false);
            editor.commit();
            status = false;
        }


        return status;
    }

    @Override
    protected void onDestroy() {
        if (mp != null) {
            mp.release();
            mp = null;
        }
        hideDialog();
        super.onDestroy();
    }
}
