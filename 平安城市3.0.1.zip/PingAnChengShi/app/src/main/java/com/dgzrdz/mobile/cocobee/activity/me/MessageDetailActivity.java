package com.dgzrdz.mobile.cocobee.activity.me;

import android.os.Bundle;

import com.dgzrdz.mobile.cocobee.R;
import com.dgzrdz.mobile.cocobee.activity.base.BaseActivity;
import com.dgzrdz.mobile.cocobee.fragment.me.MessageDetailFragment;
import com.dgzrdz.mobile.cocobee.response.MsgResponse;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Description:
 * Author: Liubingren
 * Data:  2018/11/24
 * Time:  15:06
 */

public class MessageDetailActivity extends BaseActivity {
    @Override
    protected int getContentViewLayoutID() {
        return R.layout.fragment_container;
    }

    @Override
    protected void initViewsAndEvents(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            MsgResponse msgResponse = (MsgResponse) getIntent().getSerializableExtra("msgResponse");
            loadRootFragment(R.id.fl_container, MessageDetailFragment.getInstance(msgResponse));
        }
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }
}