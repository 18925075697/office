package com.dgzrdz.mobile.cocobee.model;

import java.io.Serializable;

/**
 * Created by marktrace on 16/11/2.
 */
public class TagRecord implements Serializable {
    /**
     * hLabelNo :
     * memberSix : 1
     * memberName : ck
     * memberServiceObjId :
     * memberServiceObjNumber :
     * memberAccount : 13242967410
     * sysServiceTypeName :
     */

    private String hLabelNo;//标签号
    private String memberSix;
    private String memberName;
    private String memberServiceObjId;//对象id
    private String memberServiceObjNumber;//监护对象名称
    private String memberAccount;
    private String sysServiceTypeName;
    private String memberServiceObjAlertTime;    //被盗时间
    private boolean isLocalRecord = false;

    public TagRecord(String tagId) {
        this.hLabelNo = tagId;
    }

    public String getTime() {
        return memberServiceObjAlertTime;
    }

    public void setTime(String time) {
        this.memberServiceObjAlertTime = time;
    }

    public boolean isLocalRecord() {
        return isLocalRecord;
    }

    public void setLocalRecord(boolean localRecord) {
        isLocalRecord = localRecord;
    }

    public TagRecord(String hLabelNo, String time) {
        this.hLabelNo = hLabelNo;
        this.memberServiceObjAlertTime = time;
    }

    public String getHLabelNo() {
        return hLabelNo;
    }

    public void setHLabelNo(String hLabelNo) {
        this.hLabelNo = hLabelNo;
    }

    public String getMemberSix() {
        return memberSix;
    }

    public void setMemberSix(String memberSix) {
        this.memberSix = memberSix;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberServiceObjId() {
        return memberServiceObjId;
    }

    public void setMemberServiceObjId(String memberServiceObjId) {
        this.memberServiceObjId = memberServiceObjId;
    }

    public String getMemberServiceObjNumber() {
        return memberServiceObjNumber;
    }

    public void setMemberServiceObjNumber(String memberServiceObjNumber) {
        this.memberServiceObjNumber = memberServiceObjNumber;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public String getSysServiceTypeName() {
        return sysServiceTypeName;
    }

    public void setSysServiceTypeName(String sysServiceTypeName) {
        this.sysServiceTypeName = sysServiceTypeName;
    }


    //    /**
    //     * cid : 820ffade5b2d11e8b036005056a645a8
    //     * cno : 1111
    //     * labelId : 101
    //     * mobile : 13099999999
    //     * name : 测试1
    //     * picture : [{"id":"4002b353543e46f29170f16c97b0bb00","picId":"4002b353543e46f29170f16c97b0bb00","property":"1","thirdId":"820ffade5b2d11e8b036005056a645a8","url":"upload/car/2018/05/19/0-4205862.jpg"},{"id":"788d7ddc66074c9a89d210e160c6caad","picId":"788d7ddc66074c9a89d210e160c6caad","property":"2","thirdId":"820ffade5b2d11e8b036005056a645a8","url":"upload/car/2018/05/19/11378879827.jpg"},{"id":"e99b0dc150cf4bd680c028d14d65c299","picId":"e99b0dc150cf4bd680c028d14d65c299","property":"3","thirdId":"820ffade5b2d11e8b036005056a645a8","url":"upload/car/2018/05/19/2-890550355.jpg"},{"id":"2cb4de2ae53e45c68623e3a69bb65f7a","picId":"2cb4de2ae53e45c68623e3a69bb65f7a","property":"4","thirdId":"820ffade5b2d11e8b036005056a645a8","url":"upload/car/2018/05/19/3664409937.jpg"}]
    //     */
    //
    //    private String cid;     //车id
    //    private String thirdIdName;     //车牌号/人员姓名
    //    private String labelId; //标签号
    //    private String mobile;  //电话号码
    //    private String name;    //用户姓名
    //    private String time;    //被盗时间
    //    private boolean isLocalRecord = false;
    //    private String lnoType;//标签类型1车2人
    //    private String sex; //0代表男;1代表女
    //    private List<PictureBean> picture;
    //
    //    public TagRecord() {
    //    }
    //
    //
    //    public TagRecord(String labelId) {
    //        this.labelId = labelId;
    //        this.time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    //    }
    //
    //
    //    public TagRecord(String labelId, String time) {
    //        this.labelId = labelId;
    //        this.time = time;
    //    }
    //
    //    public String getTime() {
    //        return time;
    //    }
    //
    //    public void setTime(String time) {
    //        this.time = time;
    //    }
    //
    //    public String getLnoType() {
    //        return lnoType;
    //    }
    //
    //    public void setLnoType(String lnoType) {
    //        this.lnoType = lnoType;
    //    }
    //
    //    public String getSex() {
    //        return sex;
    //    }
    //
    //    public void setSex(String sex) {
    //        this.sex = sex;
    //    }
    //
    //    public String getThirdIdName() {
    //        return thirdIdName;
    //    }
    //
    //    public void setThirdIdName(String thirdIdName) {
    //        this.thirdIdName = thirdIdName;
    //    }
    //
    //    public boolean isLocalRecord() {
    //        return isLocalRecord;
    //    }
    //
    //    public void setIsLocalRecord(boolean localRecord) {
    //        isLocalRecord = localRecord;
    //    }
    //
    //    public String getCid() {
    //        return cid;
    //    }
    //
    //    public void setCid(String cid) {
    //        this.cid = cid;
    //    }
    //
    //    public String getLabelId() {
    //        return labelId;
    //    }
    //
    //    public void setLabelId(String labelId) {
    //        this.labelId = labelId;
    //    }
    //
    //    public String getMobile() {
    //        return mobile;
    //    }
    //
    //    public void setMobile(String mobile) {
    //        this.mobile = mobile;
    //    }
    //
    //    public String getName() {
    //        return name;
    //    }
    //
    //    public void setName(String name) {
    //        this.name = name;
    //    }
    //
    //    public List<PictureBean> getPicture() {
    //        return picture;
    //    }
    //
    //    public void setPicture(List<PictureBean> picture) {
    //        this.picture = picture;
    //    }
    //
    //    public static class PictureBean implements Serializable{
    //        /**
    //         * id : 4002b353543e46f29170f16c97b0bb00
    //         * picId : 4002b353543e46f29170f16c97b0bb00
    //         * property : 1
    //         * thirdId : 820ffade5b2d11e8b036005056a645a8
    //         * url : upload/car/2018/05/19/0-4205862.jpg
    //         */
    //
    //        private String id;
    //        private String picId;
    //        private String property;
    //        private String thirdId;
    //        private String url;
    //
    //        public String getId() {
    //            return id;
    //        }
    //
    //        public void setId(String id) {
    //            this.id = id;
    //        }
    //
    //        public String getPicId() {
    //            return picId;
    //        }
    //
    //        public void setPicId(String picId) {
    //            this.picId = picId;
    //        }
    //
    //        public String getProperty() {
    //            return property;
    //        }
    //
    //        public void setProperty(String property) {
    //            this.property = property;
    //        }
    //
    //        public String getThirdId() {
    //            return thirdId;
    //        }
    //
    //        public void setThirdId(String thirdId) {
    //            this.thirdId = thirdId;
    //        }
    //
    //        public String getUrl() {
    //            return url;
    //        }
    //
    //        public void setUrl(String url) {
    //            this.url = url;
    //        }
    //    }


    //    private String lid;
    //    private String lno; //标签号
    //    private String date;
    //    private boolean isLocalRecord = false;
    //    private String pname;
    //    private String mobile;
    //
    //    private String cno;
    //    private String flag;//1代表车辆标签信息 2代表人员标签信息
    //    private String ccarpicurl;//车辆图片
    //    private String photourl;//人员图片
    //    private String gender; //0代表男;1代表女
    //
    //
    //    public TagRecord() {
    //    }
    //
    //
    //    public TagRecord(String lno) {
    //        this.lno = lno;
    //        this.date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    //    }
    //
    //
    //    public TagRecord(String lno, String date) {
    //        this.lno = lno;
    //        this.date = date;
    //    }
    //
    //    public String getLno() {
    //        return lno;
    //    }
    //
    //    public void setLno(String lno) {
    //        this.lno = lno;
    //    }
    //
    //    public String getDate() {
    //        return date;
    //    }
    //
    //    public void setDate(String date) {
    //        this.date = date;
    //    }
    //
    //
    //    public String getLid() {
    //        return lid;
    //    }
    //
    //    public void setLid(String lid) {
    //        this.lid = lid;
    //    }
    //
    //    public String getPname() {
    //        return pname;
    //    }
    //
    //    public void setPname(String pname) {
    //        this.pname = pname;
    //    }
    //
    //    public String getMobile() {
    //        return mobile;
    //    }
    //
    //    public void setMobile(String mobile) {
    //        this.mobile = mobile;
    //    }
    //
    //    public String getCno() {
    //        return cno;
    //    }
    //
    //    public void setCno(String cno) {
    //        this.cno = cno;
    //    }
    //
    //    public String getFlag() {
    //        return flag;
    //    }
    //
    //    public void setFlag(String flag) {
    //        this.flag = flag;
    //    }
    //
    //    public String getCcarpicurl() {
    //        return ccarpicurl;
    //    }
    //
    //    public void setCcarpicurl(String ccarpicurl) {
    //        this.ccarpicurl = ccarpicurl;
    //    }
    //
    //    public String getPhotourl() {
    //        return photourl;
    //    }
    //
    //    public void setPhotourl(String photourl) {
    //        this.photourl = photourl;
    //    }
    //
    //    public String getGender() {
    //        return gender;
    //    }
    //
    //    public void setGender(String gender) {
    //        this.gender = gender;
    //    }
    //
    //    public boolean isLocalRecord() {
    //        return isLocalRecord;
    //    }
    //
    //    public void setIsLocalRecord(boolean isLocalRecord) {
    //        this.isLocalRecord = isLocalRecord;
    //    }
    //
    //
    //    @Override
    //    public String toString() {
    //        return "TagRecord{" +
    //                "lid='" + lid + '\'' +
    //                ", lno='" + lno + '\'' +
    //                ", date='" + date + '\'' +
    //                ", isLocalRecord=" + isLocalRecord +
    //                ", pname='" + pname + '\'' +
    //                ", mobile='" + mobile + '\'' +
    //                ", cno='" + cno + '\'' +
    //                ", flag='" + flag + '\'' +
    //                ", ccarpicurl='" + ccarpicurl + '\'' +
    //                ", photourl='" + photourl + '\'' +
    //                ", gender='" + gender + '\'' +
    //                '}';
    //    }
}
