/*
 * Copyright 2016 Yan Zhenjie
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.dgzrdz.mobile.cocobee.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.annotation.ColorInt;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;

import com.dgzrdz.mobile.cocobee.R;


/**
 * Created on 2016/7/12.
 */
public class CountDownProgress extends AppCompatTextView {

    /**
     * 外部轮廓的颜色。
     */
    private int outLineColor = Color.TRANSPARENT;

    /**
     * 外部轮廓的宽度。
     */
    private int outLineWidth = 2;

    /**
     * 内部圆的颜色List。
     */
    private ColorStateList inCircleColors = ColorStateList.valueOf(Color.TRANSPARENT);

    /**
     * 中心圆的目前颜色。
     */
    private int circleColorTemp;

    /**
     * 进度条的颜色。
     */
    private int progressLineColor = Color.RED;

    /**
     * 进度条的宽度。
     */
    private int progressLineWidth = 8;

    /**
     * 画笔。
     */
    private Paint mPaint = new Paint();

    /**
     * 进度条的弧形区域。
     */
    private RectF mArcRect = new RectF();

    /**
     * 进度。
     */
    private int progress = 100;
    //    /**
    //     * 进度条类型。
    //     */
    //    private ProgressType mProgressType = ProgressType.COUNT_BACK;
    //
    //    /**
    //     * 开始位置。
    //     */
    //    private StartPos mStartPos = StartPos.TOP;

    /**
     * 进度倒计时时间。
     */
    private long timeMillis = 5000;

    /**
     * View的显示区域。
     */
    final Rect bounds = new Rect();
    /**
     * 进度条通知。
     */
    private OnCountdownProgressListener mCountdownProgressListener;

    /**
     * 进度条结束。
     */
    private OnFinishListener mOnFinishListener;

    /**
     * Listener what。
     */
    private int listenerWhat = 0;

    public static final int PROGRESS_TYPE_COUNT = 1;
    public static final int PROGRESS_TYPE_COUNT_BACK = 2;

    public static final int FORWARD = 1;
    public static final int REVERSE = 2;

    public static final int START_POS_TOP = 1;
    public static final int START_POS_LEFT = 2;
    public static final int START_POS_RIGHT = 3;
    public static final int START_POS_BOTTOM = 4;


    private int progressType;

    private int startPos;

    private int progressDirection;


    public CountDownProgress(Context context) {
        this(context, null);
    }

    public CountDownProgress(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CountDownProgress(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize(context, attrs);
    }

//    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
//    public CountDownProgress(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
//        super(context, attrs, defStyleAttr, defStyleRes);
//        initialize(context, attrs);
//    }

    /**
     * 初始化。
     *
     * @param context      上下文。
     * @param attributeSet 属性。
     */
    private void initialize(Context context, AttributeSet attributeSet) {
        mPaint.setAntiAlias(true);
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.CountDownProgress);
        if (typedArray.hasValue(R.styleable.CountDownProgress_in_circle_color))
            inCircleColors = typedArray.getColorStateList(R.styleable.CountDownProgress_in_circle_color);
        else
            inCircleColors = ColorStateList.valueOf(Color.TRANSPARENT);
        circleColorTemp = inCircleColors.getColorForState(getDrawableState(), Color.TRANSPARENT);
        outLineColor = typedArray.getColor(R.styleable.CountDownProgress_outLineColor, outLineColor);
        outLineWidth = typedArray.getDimensionPixelSize(R.styleable.CountDownProgress_outLineWidth, outLineWidth);
        progressLineColor = typedArray.getColor(R.styleable.CountDownProgress_outLineColor, progressLineColor);
        progressLineWidth = typedArray.getDimensionPixelSize(R.styleable.CountDownProgress_progressLineWidth, progressLineWidth);
        startPos = typedArray.getInt(R.styleable.CountDownProgress_startPos, START_POS_TOP);
        progressType = typedArray.getInt(R.styleable.CountDownProgress_progressBarType, PROGRESS_TYPE_COUNT);
        progressDirection = typedArray.getInt(R.styleable.CountDownProgress_progressDirection, FORWARD);
        setProgressType(progressType);
        typedArray.recycle();
    }

    /**
     * 设置外部轮廓的颜色。
     *
     * @param outLineColor 颜色值。
     */
    public void setOutLineColor(@ColorInt int outLineColor) {
        this.outLineColor = outLineColor;
        invalidate();
    }

    /**
     * 设置外部轮廓的宽度。
     *
     * @param outLineWidth 宽度值。
     */
    public void setOutLineWidth(@ColorInt int outLineWidth) {
        this.outLineWidth = outLineWidth;
        invalidate();
    }

    /**
     * 设置圆形的填充颜色。
     *
    * @param inCircleColor 颜色值。
            */
    public void setInCircleColor(@ColorInt int inCircleColor) {
        this.inCircleColors = ColorStateList.valueOf(inCircleColor);
        invalidate();
    }

    /**
     * 是否需要更新圆的颜色。
     */
    private void validateCircleColor() {
        int color = inCircleColors.getColorForState(getDrawableState(), Color.TRANSPARENT);
        if (circleColorTemp != color) {
            circleColorTemp = color;
            invalidate();
        }
    }

    /**
     * 设置进度条颜色。
     *
     * @param progressLineColor 颜色值。
     */
    public void setProgressColor(@ColorInt int progressLineColor) {
        this.progressLineColor = progressLineColor;
        invalidate();
    }

    /**
     * 设置进度条线的宽度。
     *
     * @param progressLineWidth 宽度值。
     */
    public void setProgressLineWidth(int progressLineWidth) {
        this.progressLineWidth = progressLineWidth;
        invalidate();
    }

    /**
     * 设置进度。
     *
     * @param progress 进度。
     */
    public void setProgress(int progress) {
        this.progress = validateProgress(progress);
        invalidate();
    }

    /**
     * 验证进度。
     *
     * @param progress 你要验证的进度值。
     * @return 返回真正的进度值。
     */
    private int validateProgress(int progress) {
        if (progress > 100)
            progress = 100;
        else if (progress < 0)
            progress = 0;
        return progress;
    }

    /**
     * 拿到此时的进度。
     *
     * @return 进度值，最大100，最小0。
     */
    public int getProgress() {
        return progress;
    }

    /**
     * 设置倒计时总时间。
     *
     * @param timeMillis 毫秒。
     */
    public void setTimeMillis(long timeMillis) {
        this.timeMillis = timeMillis;
        invalidate();
    }

    /**
     * 拿到进度条计时时间。
     *
     * @return 毫秒。
     */
    public long getTimeMillis() {
        return this.timeMillis;
    }

    /**
     * 设置进度条类型。
     *
     * @param type
     */
    public void setProgressType(int type) {
        this.progressType = type;
        resetProgress();
        invalidate();
    }

    /**
     * 设置进度条开始位置。
     *
     * @param startPos
     */
    public void setStartPos(int startPos) {
        this.startPos = startPos;
        invalidate();
    }

    /**
     * 重置进度。
     */
    private void resetProgress() {
        switch (progressType) {
            case PROGRESS_TYPE_COUNT:
                progress = 0;
                break;
            case PROGRESS_TYPE_COUNT_BACK:
                progress = 100;
                break;
        }
    }


    /**
     * 设置进度监听。
     *
     * @param mCountdownProgressListener 监听器。
     */
    public void setCountdownProgressListener(int what, OnCountdownProgressListener mCountdownProgressListener) {
        this.listenerWhat = what;
        this.mCountdownProgressListener = mCountdownProgressListener;
    }

    /**
     * 设置结束监听。
     *
     * @param onFinishListener 监听器。
     */
    public void setOnFinishListener(OnFinishListener onFinishListener) {
        this.mOnFinishListener = onFinishListener;
    }

    /**
     * 开始。
     */
    public void start() {
        stop();
        post(progressChangeTask);
    }

    /**
     * 重新开始。
     */
    public void reStart() {
        resetProgress();
        start();
    }

    /**
     * 停止。
     */
    public void stop() {
        removeCallbacks(progressChangeTask);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //获取view的边界
        getDrawingRect(bounds);
        int size = bounds.height() > bounds.width() ? bounds.width() : bounds.height();
        float outerRadius = size / 2;

        //画内部背景
        int circleColor = inCircleColors.getColorForState(getDrawableState(), 0);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(circleColor);
        canvas.drawCircle(bounds.centerX(), bounds.centerY(), outerRadius - outLineWidth, mPaint);

        //画边框圆
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(outLineWidth);
        mPaint.setColor(outLineColor);
        canvas.drawCircle(bounds.centerX(), bounds.centerY(), outerRadius - outLineWidth / 2, mPaint);

        //画字
        Paint paint = getPaint();
        paint.setColor(getCurrentTextColor());
        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);
        float textY = bounds.centerY() - (paint.descent() + paint.ascent()) / 2;
        canvas.drawText(getText().toString(), bounds.centerX(), textY, paint);

        //画进度条
        mPaint.setColor(progressLineColor);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(progressLineWidth);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        int deleteWidth = progressLineWidth + outLineWidth;
        mArcRect.set(bounds.left + deleteWidth / 2, bounds.top + deleteWidth / 2, bounds.right - deleteWidth / 2, bounds.bottom - deleteWidth / 2);
        int direction;
        if (progressType == PROGRESS_TYPE_COUNT) {
            if (progressDirection == FORWARD) {
                direction = 1;
            } else {
                direction = -1;
            }
        } else {
            if (progressDirection == FORWARD) {
                direction = -1;
            } else {
                direction = 1;
            }
        }

        if (startPos == START_POS_TOP) {
            canvas.drawArc(mArcRect, -90, direction * 360 * progress / 100, false, mPaint);
        } else if (startPos == START_POS_LEFT) {
            canvas.drawArc(mArcRect, -180, direction * 360 * progress / 100, false, mPaint);
        } else if (startPos == START_POS_RIGHT) {
            canvas.drawArc(mArcRect, 0, direction * 360 * progress / 100, false, mPaint);
        } else if (startPos == START_POS_BOTTOM) {
            canvas.drawArc(mArcRect, 90, direction * 360 * progress / 100, false, mPaint);
        }

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int lineWidth = 4 * (outLineWidth + progressLineWidth);
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int size = (width > height ? width : height) + lineWidth;
        setMeasuredDimension(size, size);
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        validateCircleColor();
    }

    /**
     * 进度更新task。
     */
    private Runnable progressChangeTask = new Runnable() {
        @Override
        public void run() {
            removeCallbacks(this);
            switch (progressType) {
                case PROGRESS_TYPE_COUNT:
                    progress += 1;
                    break;
                case PROGRESS_TYPE_COUNT_BACK:
                    progress -= 1;
                    break;
            }
            if (progress >= 0 && progress <= 100) {
                if (mCountdownProgressListener != null)
                    mCountdownProgressListener.onProgress(listenerWhat, progress);
                invalidate();
                postDelayed(progressChangeTask, timeMillis / 100);
                if ((progressType == PROGRESS_TYPE_COUNT && progress == 100) || (progressType == PROGRESS_TYPE_COUNT_BACK && progress == 0)) {
                    if (mOnFinishListener != null)
                        mOnFinishListener.onFinish();
                }
            } else
                progress = validateProgress(progress);
        }
    };

    //    /**
    //     * 进度条类型。
    //     */
    //    public enum ProgressType {
    //        /**
    //         * 顺数进度条，从0-100；
    //         */
    //        COUNT,
    //
    //        /**
    //         * 倒数进度条，从100-0；
    //         */
    //        COUNT_BACK
    //    }
    //
    //    /**
    //     * 开始位置。
    //     */
    //    public enum StartPos {
    //        TOP,
    //        LEFT,
    //        RIGHT,
    //        BOTTOM
    //    }

    /**
     * 进度监听。
     */
    public interface OnCountdownProgressListener {

        /**
         * 进度通知。
         *
         * @param progress 进度值。
         */
        void onProgress(int what, int progress);
    }

    /**
     * 倒计时结束监听。
     */
    public interface OnFinishListener {

        /**
         * 倒计时结束
         */
        void onFinish();
    }
}
