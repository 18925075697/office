package library.loger;

public interface LogStrategy {

  void log(int priority, String tag, String message);
}
