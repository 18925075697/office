package library.loger;


import library.baselib.BuildConfig;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/19 上午11:09
 * 描述：日志打印工具
 * 修订历史：
 */

public class LogUtils {
    public static final String LOG_TAG = "paic_log";//通用日志tag
    public static final String REQUEST_TAG = "PAIC_REQUEST";//请求日志tag

    /**
     * 打印日志 如果已经开启日志打印功能,传入Tag 与日志内容即可
     *
     * @param tag
     * @param pLog
     */
    public static void logError(String tag, Object pLog) {
        if (BuildConfig.DEBUG){
            Logger.t(tag);
            Logger.e(pLog + "");
        }
    }

    public static void logError(Object pLog) {
        if (BuildConfig.DEBUG){
            Logger.t(LOG_TAG);
            Logger.e(pLog + "");
        }
    }

    public static void logInfo(String tag, String pLog) {
        if (BuildConfig.DEBUG){
            Logger.t(tag);
            Logger.i(pLog);
        }
    }

    public static void logInfo(String pLog) {
        if (BuildConfig.DEBUG) {
            Logger.t(LOG_TAG);
            Logger.i(pLog);
        }
    }

    public static void logJson(String tag,String json){
        if ( BuildConfig.DEBUG) {
            Logger.t(tag);
            Logger.json(json);
        }
    }

    public static void logWarn(String tag, Object pLog) {
        if (BuildConfig.DEBUG){
            Logger.t(tag);
            Logger.w(pLog + "");
        }
    }

    public static void logWarn(String tag, Object pLog, Throwable throwable) {
        if (BuildConfig.DEBUG){
            Logger.t(tag);
            Logger.e(throwable,pLog + "");
        }
    }

    public static void logDebug(String tag, Object pLog) {
        if (BuildConfig.DEBUG) {
            Logger.t(tag);
            Logger.d(pLog + "");
        }
    }

    public static void logDebug(Object pLog) {
        if (BuildConfig.DEBUG){
            Logger.t(LOG_TAG);
            Logger.d(pLog);
        }
    }
}
