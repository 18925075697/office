package com.andview.refreshview.listener;
/**
 * 上拉加载更多的时机
 * @author huxq17@163.com
 *
 */
public interface OnBottomLoadMoreTime {
	public boolean isBottom();
}
