package library.network;

import library.network.progress.ILoadProgress;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午4:30
 * 描述：网络请求工具
 * 修订历史：
 */

public class Request {

    /**
     * 是否在需要加载
     */
    private boolean isLoading;

    /**
     * 加载匡
     */
    private ILoadProgress loadingProgress;
    /**
     * 缓存的key，为空就没有
     */
    private String cacheKey;

    public Request(Builder builder) {
        isLoading = builder.isLoading;
        cacheKey = builder.cacheKey;
        loadingProgress = builder.loadingProgress;
    }


    public class Builder{
        private boolean isLoading;
        private String cacheKey;
        private ILoadProgress loadingProgress;

        public Builder setCache(String cacheKey) {
            this.cacheKey = cacheKey;
            return this;
        }

        public void setLoading(boolean loading) {
            isLoading = loading;
        }


        public void setLoadingProgress(ILoadProgress loadingProgress) {
            this.loadingProgress = loadingProgress;
        }

        public Request build(){
            return new Request(this);
        }


    }
}
