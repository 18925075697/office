package library.network;

import android.content.Context;

import java.util.concurrent.TimeUnit;

import library.baselib.BuildConfig;

import library.network.cookie.RealCookie;
import library.network.cookie.SpCookieStore;
import library.network.progress.CookieExpiredInterceptor;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 上午11:00
 * 描述：网络请求管理
 * 修订历史：
 */

public class NetworkMananger {

    public static NetworkMananger mMananger;
    private Retrofit mRetrofit;
    //写入超时
    private static final int WRITE_TIME_OUT = 30;
    //建立连接的超时时间
    private static final int CONNECT_TIME_OUT = 30;
    //读取超时
    private static final int READ_TIME_OUT = 30;
    private Context mContext;
    private RealCookie realCookie;

    private NetworkMananger(){

    }

    public void init(Context context) {
        this.mContext = context;
        //okhttpclient为内核，可以设置拦截器等配置
        realCookie = new RealCookie(new SpCookieStore(context));
        OkHttpClient.Builder build = new OkHttpClient.Builder()
                .readTimeout(WRITE_TIME_OUT,TimeUnit.SECONDS)
                .writeTimeout(READ_TIME_OUT,TimeUnit.SECONDS)
                .connectTimeout(CONNECT_TIME_OUT,TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .cookieJar(realCookie)
                .addInterceptor(new CookieExpiredInterceptor());
        if (BuildConfig.DEBUG)
            build.addInterceptor(new LogNetInterceptor());
        OkHttpClient client = build.build();
        mRetrofit = new Retrofit.Builder()
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(BuildConfig.HOST)
                .build();
    }

    /**
     *@desc   判断cookie过期
     *@author chenjingkun
     *@time   下午5:16
     *@param
     *@retrun
     */
    public boolean isCookieExpired(String url) {
        return realCookie.isCookieExpired(url);
    }

    public static NetworkMananger getInstance(){
        if (mMananger==null){
            synchronized (NetworkMananger.class){
                mMananger = new NetworkMananger();
            }
            return mMananger;
        }
        return mMananger;
    }


    public Retrofit getRetrofit() {
        return mRetrofit;
    }
}
