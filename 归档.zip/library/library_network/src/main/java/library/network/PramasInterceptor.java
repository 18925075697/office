package library.network;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/30 上午11:47
 * 描述：参数灿节气
 * 修订历史：
 */

public class PramasInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        RequestBody body = request.body();

        return null;
    }
}
