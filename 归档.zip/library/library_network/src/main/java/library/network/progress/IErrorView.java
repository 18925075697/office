package library.network.progress;

import android.view.View;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午5:09
 * 描述：错误页面展示
 * 修订历史：
 */

public interface IErrorView {

    /**
     * 页面展示
     */
    void show();

    /**
     * 页面隐藏
     */
    void hide();

    /**
     * 页面点击
     */
    void onclik(View.OnClickListener clickListener);
}
