package library.network;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 下午2:59
 * 描述：服务器返回的数据格式
 * 修订历史：
 */

public class ResponseResult<T> {

    private String code;//返回的code
    private T data;//数据内容
    private String message;//接口说明



    public boolean isExpired(){
        return NetCode.LOGIN_EXPIRE.equals(code);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String string() {
        return new StringBuilder("{code:").append(code).append(",")
                .append("data:").append(data).append(",")
                .append("message:").append(message).append("}").toString();
    }
}
