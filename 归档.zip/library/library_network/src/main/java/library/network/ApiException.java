package library.network;

import library.loger.LogUtils;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 下午7:56
 * 描述：api 异常
 * 修订历史：
 */

public class ApiException extends Exception{
    private String code;
    private String displayMessage;

    public ApiException(String code, String displayMessage) {
        this.code = code;
        this.displayMessage = displayMessage;
        LogUtils.logDebug(new StringBuilder("异常信息打印：\n").append("状态码:").append(code).append("\n")
        .append("详细信息：").append(displayMessage).append("\n").toString());
    }

    public ApiException(String code, String message, String displayMessage) {
        super(message);
        this.code = code;
        this.displayMessage = displayMessage;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }
}
