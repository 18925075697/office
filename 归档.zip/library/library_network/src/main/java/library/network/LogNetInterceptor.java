package library.network;

import android.os.Build;

import java.io.IOException;
import java.nio.charset.Charset;

import library.loger.LogUtils;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

import static okhttp3.internal.Util.UTF_8;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 下午6:45
 * 描述：网络日志打印拦截器
 * 修订历史：
 */

class LogNetInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();

        long startTime = System.currentTimeMillis();
        Response response = chain.proceed(request);
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        StringBuilder sbLogInfo = getRequestLogInfo(request);
        ResponseBody responseBody = response.peekBody(1*1024);
        sbLogInfo.append("网络响应如下：");
        if (responseBody!=null){
            sbLogInfo.append("响应的json数据：| ")
                    .append(responseBody.string())
                    .append("\n");
        }
        sbLogInfo.append("请求耗时:----------")
                .append(duration)
                .append("毫秒----------").append("\n");
        LogUtils.logDebug(sbLogInfo.toString());
        return response;
    }

    private StringBuilder getRequestLogInfo(Request request) {
        RequestBody body = request.body();
        StringBuilder sbInfo = new StringBuilder();
        sbInfo  .append("手机品牌：").append(android.os.Build.BRAND).append("\n")
                .append("手机型号: ").append(android.os.Build.MODEL).append("\n")
                .append("系统版本号: ").append(Build.VERSION.RELEASE).append("\n");
        sbInfo.append("请求地址：| " ).append(request.url()).append("\n");
        if (body!=null){
            Buffer buffer = new Buffer();
            try {
                body.writeTo(buffer);
                Charset charset = Charset.forName("UTF-8");
                MediaType contentType = body.contentType();
                if (contentType != null) {
                    charset = contentType.charset(UTF_8);
                }
                String params = buffer.readString(charset);
                sbInfo.append("请求参数： | ").append(params).append("\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
          return sbInfo;

    }

}
