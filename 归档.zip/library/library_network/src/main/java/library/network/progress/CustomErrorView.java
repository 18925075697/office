package library.network.progress;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import library.network.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午5:13
 * 描述：网络错误view
 * 修订历史：
 */

public class CustomErrorView extends DialogFragment implements IErrorView{

    private final String TAG = "net_error";
    private TextView tvError;
    private View.OnClickListener clickListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.view_net_error,null,false);
        tvError = view.findViewById(R.id.tv_error);
        tvError.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.onClick(v);
            }
        });
        return view;
    }

    @Override
    public void show() {
        show(getFragmentManager(),TAG);
    }

    @Override
    public void hide() {
       dismiss();
    }

    @Override
    public void onclik(View.OnClickListener clickListener) {
        this.clickListener = clickListener;
    }
}
