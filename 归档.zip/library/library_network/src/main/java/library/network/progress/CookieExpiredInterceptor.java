package library.network.progress;

import com.google.gson.Gson;

import java.io.IOException;

import library.network.CustomException;
import library.network.NetCode;
import library.network.ResponseResult;
import library.network.cookie.CookieException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/30 下午3:07
 * 描述：cookie过期拦截器
 * 修订历史：
 */

public class CookieExpiredInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Response response = chain.proceed(request);
        if (CustomException.HTTP_UNAUTHORIED.equals(String.valueOf(response.code()))){
            ResponseBody responseBody = response.peekBody(1*1024);
            Gson gson = new Gson();
            String content = responseBody.string();
            ResponseResult<String> result = gson.fromJson(content,ResponseResult.class);
            if (result.isExpired()){
                throw new CookieException(NetCode.LOGIN_EXPIRE,content);
            }
        }
        return response;
    }
}
