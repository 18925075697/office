package library.network.progress;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午4:59
 * 描述：通用加载匡
 * 修订历史：
 */

public class CustomLoadingView extends ProgressDialog implements ILoadProgress {


    public CustomLoadingView(Context context) {
        super(context);
    }

    public CustomLoadingView(Context context, int theme) {
        super(context, theme);
    }

    @Override
    public void showLoading() {
        show();
    }

    @Override
    public void hideLoading() {
       hide();
    }
}
