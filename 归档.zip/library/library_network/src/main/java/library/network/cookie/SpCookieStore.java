package library.network.cookie;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import okhttp3.Cookie;
import okhttp3.HttpUrl;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/24 下午4:45
 * 描述：sp 方式保存 cookie
 * 修订历史：
 */

public class SpCookieStore implements ICookieStore {


    //内存的cookie
    private final Map<String,ConcurrentHashMap<String,Cookie>> mCookies;
    List<Cookie> loadCookie = new ArrayList<>();
    private static final String COOKIE_PREFS_NAME = "paic_cookie";
    private static final String COOKIE_NAME_PREFIX = "cookie_name_pre";
    private final SharedPreferences cookiePrefs;



    public SpCookieStore(Context context){
        cookiePrefs = context.getSharedPreferences(COOKIE_PREFS_NAME, Context.MODE_PRIVATE);
        mCookies = new ConcurrentHashMap<>();

        //将持久化的cookies缓存到内存中,数据结构为 Map<Url.host, Map<CookieToken, Cookie>>
        Map<String, ?> prefsMap = cookiePrefs.getAll();
        for (Map.Entry<String, ?> entry : prefsMap.entrySet()) {
            if ((entry.getValue()) != null && !entry.getKey().startsWith(COOKIE_NAME_PREFIX)) {
                //获取url对应的所有cookie的key,用","分割
                String[] cookieNames = TextUtils.split((String) entry.getValue(), ",");
                for (String name : cookieNames) {
                    //根据对应cookie的Key,从xml中获取cookie的真实值
                    String keyName = cookiePrefs.getString(COOKIE_NAME_PREFIX + name, null);
                    if (keyName != null) {
                        Cookie decodedCookie = SerializableCookie.decodeCookie(keyName);
                        if (decodedCookie != null) {
                            if (!mCookies.containsKey(entry.getKey())) {
                                mCookies.put(entry.getKey(), new ConcurrentHashMap<String, Cookie>());
                            }
                            mCookies.get(entry.getKey()).put(name, decodedCookie);
                        }
                    }
                }
            }
        }

    }
    @Override
    public void saveCookie(HttpUrl url, List<Cookie> cookies) {
        for (Cookie cookie : cookies){
            savaCookie(url,cookie);
        }
    }

    /**
     *@desc   cookie的保存
     *@author chenjingkun
     *@time   下午4:53
     *@retrun
     * @param
     * @param url
     */
    private void savaCookie(HttpUrl url, Cookie cookie) {
        if (!mCookies.containsKey(url.host())){
            mCookies.put(url.host(),new ConcurrentHashMap<String, Cookie>());
        }
        if (isCookieExpired(cookie)){
            removeCookie(url,cookie);
        }else {
           String cookieKey = getCookieToken(cookie);
            //内存缓存
           mCookies.get(url.host()).put(cookieKey,cookie);
            //文件缓存
            SharedPreferences.Editor prefsWriter = cookiePrefs.edit();
            prefsWriter.putString(url.host(), TextUtils.join(",", mCookies.get(url.host()).keySet()));
            prefsWriter.putString(COOKIE_NAME_PREFIX+cookieKey, SerializableCookie.encodeCookie(url.host(), cookie));
            prefsWriter.apply();
        }
    }

    /**
     *@desc   判断cookie过期
     *@author chenjingkun
     *@time   下午5:16
     *@param
     *@retrun
     */
    private boolean isCookieExpired(Cookie cookie) {
        return cookie.expiresAt() < System.currentTimeMillis();
    }

    @Override
    public void saveCookie(HttpUrl url, Cookie cookie) {

    }

    @Override
    public List<Cookie> loadCookie(HttpUrl url) {
        return null;
    }

    @Override
    public List<Cookie> getAllCookie() {
        return null;
    }

    @Override
    public List<Cookie> getCookie(HttpUrl url) {
        loadCookie.clear();
        Map<String,Cookie> urlCookies = mCookies.get(url.host());
        if (urlCookies!=null){
            loadCookie.addAll(urlCookies.values());
        }
        return loadCookie;
    }

    @Override
    public boolean removeCookie(HttpUrl url, Cookie cookie) {
        if (!mCookies.containsKey(url.host())) {
            return false;
        }
        String cookieToken = getCookieToken(cookie);
        if (!mCookies.get(url.host()).containsKey(cookieToken)) {
            return false;
        }

        //内存移除
        mCookies.get(url.host()).remove(cookieToken);
        //文件移除
        SharedPreferences.Editor prefsWriter = cookiePrefs.edit();
        if (cookiePrefs.contains(COOKIE_NAME_PREFIX + cookieToken)) {
            prefsWriter.remove(COOKIE_NAME_PREFIX + cookieToken);
        }
        prefsWriter.putString(url.host(), TextUtils.join(",", mCookies.get(url.host()).keySet()));
        prefsWriter.apply();
        return true;
    }

    private String getCookieToken(Cookie cookie) {
        return new StringBuilder().append(cookie.name()).append("@").append(cookie.domain()).toString();
    }

    @Override
    public boolean removeCookie(HttpUrl url) {
        return false;
    }

    @Override
    public boolean removeAllCookie() {
        return false;
    }

    @Override
    public boolean isCookieExpired(String hostUrl) {
        String key = hostUrl.substring(hostUrl.indexOf("://")+"://".length());
        if (!mCookies.containsKey(key))
            return true;
        Map<String,Cookie> cookieMap = mCookies.get(key);

        Set<Map.Entry<String,Cookie>> entries  = cookieMap.entrySet();
        for (Map.Entry<String,Cookie> entry : entries){
            if (isCookieExpired(entry.getValue()))
                return true;
        }
        return false;
    }
}
