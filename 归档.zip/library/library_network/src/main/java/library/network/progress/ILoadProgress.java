package library.network.progress;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午4:55
 * 描述：加载匡抽象
 * 修订历史：
 */

public interface ILoadProgress {
    /**
     * 显示
     */
    void showLoading();

    /**
     * 隐藏
     */
    void hideLoading();
}
