package library.network.cookie;

import java.util.List;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/24 下午4:38
 * 描述：cookie
 * 修订历史：
 */

public class RealCookie implements CookieJar {

    private ICookieStore iCookieStore;


    public RealCookie(ICookieStore iCookieStore) {
        this.iCookieStore = iCookieStore;
    }

    /**
     *@desc   对应url保存cookie
     *@author chenjingkun
     *@time   下午4:39
     *@param
     *@retrun
     */
    @Override
    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
        iCookieStore.saveCookie(url,cookies);
    }

    /**
     *@desc   加载cookie
     *@author chenjingkun
     *@time   下午4:39
     *@param
     *@retrun
     */
    @Override
    public List<Cookie> loadForRequest(HttpUrl url) {
        return iCookieStore.getCookie(url);
    }



    /**
     *@desc   判断cookie过期
     *@author chenjingkun
     *@time   下午5:16
     *@param
     *@retrun
     */
    public boolean isCookieExpired(String url) {
        return iCookieStore.isCookieExpired(url);
    }
}
