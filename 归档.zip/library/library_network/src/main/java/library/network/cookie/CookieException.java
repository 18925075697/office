package library.network.cookie;

import library.loger.LogUtils;
import library.network.NetCode;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/28 下午2:18
 * 描述：cookie失效异常处理
 * 修订历史：
 */

public class CookieException extends RuntimeException {

    private String code;
    private String displayMessage;

    public CookieException(String code, String displayMessage) {
        this.code = code;
        this.displayMessage = displayMessage;
        LogUtils.logDebug(new StringBuilder("异常信息打印：\n").append("状态码:").append(code).append("\n")
                .append("详细信息：").append(displayMessage).append("\n").toString());
        handler();
    }



    private void handler() {
//        ToastUtils.showToastShort(BaseApplication.getInstant(),R.string.common_login_expired);
//        PagesManager.gotoPage(BaseApplication.getInstant(),PagePath.Page_Main_Login);
    }


    /**
     *@desc   cookie是否失效
     *@author chenjingkun
     *@time   下午3:30
     *@param
     *@retrun
     */
    public boolean isCookieExpire() {
        return NetCode.LOGIN_EXPIRE.equals(code);
    }
}
