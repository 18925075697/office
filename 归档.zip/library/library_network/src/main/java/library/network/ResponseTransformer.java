package library.network;


import android.content.Context;

import com.google.gson.Gson;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import library.network.cookie.CookieException;
import retrofit2.Response;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 下午7:59
 * 描述：
 * 修订历史：
 */

public class ResponseTransformer  {


    /**
     *@desc   线程转换
     *@author chenjingkun
     *@time   上午10:49
     *@param
     *@retrun
     */
    public static <T> ObservableTransformer<T, T> applySchedulers() {
        return new ObservableTransformer<T, T>() {
            @Override
            public ObservableSource<T> apply(Observable<T> upstream) {
                return  upstream.subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                       ;
            }

        };
    }


    /**
     *@desc   结果数据处理
     *@author chenjingkun
     *@time   下午1:46
     *@param
     *@retrun
     */
    public static<T> ObservableTransformer<T,T> handleResult() {
        return new ObservableTransformer<T, T>() {
            @Override
            public ObservableSource<T> apply(Observable<T> upstream) {
                return upstream.onErrorResumeNext(new ErrorResumeFunction())
                        .flatMap(new ResponseFunction());
            }
        };
    }

    public static <T> ObservableTransformer<? super T,T> ShowCustumDialog(Context context) {
        return new ObservableTransformer<T, T>() {
            @Override
            public ObservableSource<T> apply(Observable<T> upstream) {

                return upstream;
            }
        };
    }

    /**
     * 非服务器产生的异常，比如本地无无网络请求，Json数据解析错误等等。
     *
     * @param <T>
     */
    private static class ErrorResumeFunction<T> implements Function<Throwable, ObservableSource<? extends ResponseResult<T>>> {

        @Override
        public ObservableSource<? extends ResponseResult<T>> apply(Throwable throwable) throws Exception {
            return Observable.error(CustomException.handleException(throwable));
        }
    }

    /**
     * 服务其返回的数据解析
     * 正常服务器返回数据和服务器可能返回的exception
     *
     * @param
     */
    private static class ResponseFunction<T> implements Function<Response<T>, ObservableSource<Response<T>>> {

        @Override
        public ObservableSource<Response<T>> apply(Response<T> tResponse) throws Exception {

            if (tResponse.isSuccessful()) {
                return Observable.just(tResponse);
            } else if (CustomException.HTTP_UNAUTHORIED.equals(String.valueOf(tResponse.code()))){
                String content = tResponse.errorBody().string();
                if (content!=null){
                    Gson gson = new Gson();
                    ResponseResult<String> result = gson.fromJson(content,ResponseResult.class);
                    if (result.isExpired()){
                        return Observable.error(new CookieException(NetCode.LOGIN_EXPIRE, tResponse.message()));
                    }
                }
                return Observable.error(new ApiException(String.valueOf(tResponse.code()), tResponse.message()));
            }else {
                return Observable.error(new ApiException(String.valueOf(tResponse.code()), tResponse.message()));
            }
        }
    }
}
