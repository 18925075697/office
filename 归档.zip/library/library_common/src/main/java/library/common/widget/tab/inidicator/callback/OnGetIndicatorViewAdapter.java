package library.common.widget.tab.inidicator.callback;

import android.content.Context;

import library.common.widget.tab.inidicator.impl.IPagerIndicator;
import library.common.widget.tab.inidicator.impl.IPagerTitleView;

public class OnGetIndicatorViewAdapter {
    public IPagerTitleView getTitleView(Context context, int index){
        return null;
    }

    public IPagerIndicator getIndicator(Context context){
        return null;
    }

    public void getSelectedIndex(int  index){ }
}
