package library.common.utils;

import library.common.BuildConfig;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/19 上午11:17
 * 描述： build 配置相关
 * 修订历史：
 */

public class BuildUtils {


    public static boolean isDebug(){
        return BuildConfig.DEBUG;
    }
}
