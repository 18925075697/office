package library.common.utils.handler;

import android.os.Handler;
import android.os.Message;

import java.lang.ref.WeakReference;

/** 主要解决内存泄露等问题具有良好的特性
 * Created by chenjk on 2018/10/10.
 */

public class EasyHandler extends Handler {

    private WeakReference<ICallBack> weakICallBack;

    public EasyHandler(ICallBack iCallBack){
        weakICallBack = new WeakReference(iCallBack);
    }
    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        if (weakICallBack!=null&&weakICallBack.get()!=null){
            ICallBack iCallBack = weakICallBack.get();
            iCallBack.handleMessage(msg);
        }
    }

    public interface ICallBack{
        void handleMessage(Message msg);
    }
}
