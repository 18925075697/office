package library.common.widget.tab.inidicator.impl;

/**
 * @date: 2017/7/4
 * @version:
 * @description:
 */

public interface IMeasureablePagerTitleView extends IPagerTitleView {
    int getContentLeft();
    int getContentTop();
    int getContentRight();
    int getContentBottom();
}
