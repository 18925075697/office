package library.common.utils.file;

import android.content.Context;
import android.os.Environment;

import java.io.File;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/19 下午2:03
 * 描述：文件操作相关的工具,在此工具类不判断权限问题，可以采用PermissionHelper进行权限的验证并作业务逻辑回调
 * 修订历史：
 */

public class FileUtils {

    /**
     * 文件根目录
     */
    private static final String ROOT_DIR = "paiccw";
    /**
     * 图片目录
     */
    private  static final String IMAGE_DIR = "image";

    /**
     * crash目录
     */
    private static final String CRASH_DIR = "crash";


    /**
     * 获取图片存储路径
     *
     * @return
     */
    public static String getImagesDir(Context context) {
        String dir = new StringBuilder()
                .append(getCacheRootPath(context))
                .append(IMAGE_DIR)
                .append(File.separator).toString();
        File pathDir = new File(dir);
        if (!pathDir.exists())
            pathDir.mkdirs();
        return dir;
    }

    /**
     *@desc   一般使用这个作为安全目录
     *@author chenjingkun
     *@time   下午2:51
     *@param
     *@retrun
     */
    public static String getCacheRootPath(Context context){
        File file = context.getExternalCacheDir();
        String dir = new StringBuilder()
                .append(File.separator)
                .append(ROOT_DIR)
                .append(File.separator).toString();
        String path = null;
        if (null != file) {
            path = file.getAbsolutePath() + dir;
        } else {
            path = context.getCacheDir().toString() + dir;
        }
        return path;
    }


    /**
     * 获取crash路径
     *
     * @return
     */
    public static String getCrashDir(Context context) {

        String path = new StringBuilder()
                .append(getSdcardRootPath(context))
                .append(CRASH_DIR)
                .append(File.separator).toString();
        File pathDir = new File(path);
        if (!pathDir.exists())
            pathDir.mkdirs();
        return path;
    }


    /**
     *@desc   获取sdkcard目录，一般为了安全问题不用这个，一般在测试阶段使用此目录，其余的使用app缓存目录等,发布版本不可用这个，开发人员需要注意
     * 如果使用，需要先判断是不是非发布版本,
     *@author chenjingkun
     *@time   下午2:40
     *@param
     *@retrun
     */
    public static String getSdcardRootPath(Context context){
        String path = null;
        String dir = new StringBuilder(Environment.getExternalStorageDirectory().getAbsolutePath())
                .append(File.separator)
                .append(ROOT_DIR)
                .append(File.separator).toString();
        return dir;
    }

    /**
     * 创建文件
     * @param path 文件路径
     * @return
     */
    public static File createFile(String path){
       File file = new File(path);
       if (!file.exists()){
           if (!file.getParentFile().exists()){
               file.getParentFile().mkdirs();
           }
           file.mkdir();
       }
       return file;
    }
}
