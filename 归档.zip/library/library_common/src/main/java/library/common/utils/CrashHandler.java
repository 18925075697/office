package library.common.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import library.common.R;
import library.common.base.BaseBuildConfig;
import library.common.utils.file.FileUtils;
import library.common.utils.page.PagesManager;
import library.common.utils.string.StringUtils;
import library.loger.LogUtils;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/5/5 下午1:48
 * 描述：异常捕获工具
 * 修订历史：
 */

public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static CrashHandler INSTANCE ;
    //系统默认的异常捕获器
    private Thread.UncaughtExceptionHandler mDefaultHandler;
    // 用于格式化日期,作为日志文件名的一部分
    private DateFormat formatter = new SimpleDateFormat("yyyyMMdd_HH:mm:ss",
            Locale.CHINA);
    private Context context;
    private String deviceInfo;
    private Handler mHandler;
    private long lastTime;
    private long CRASH_MIN_TIME = 50L;//crash最小时间，如果在这么短时间内一直crash，直接让程序
    private Throwable lastException;
    public static CrashHandler getInstance(){
        if (INSTANCE==null){
            synchronized (CrashHandler.class){
                if (INSTANCE==null){
                    INSTANCE = new CrashHandler();
                }
            }
        }
        return INSTANCE;
    }

    /**
     *@desc   初始化功能
     *@author chenjingkun
     *@time   下午1:52
     *@param
     *@retrun
     */
    public void init(final Context context){
        this.context = context;
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
        mHandler =  new Handler(Looper.getMainLooper());
        mHandler.post(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    try {
                        Looper.loop();
                    } catch (Throwable e) {
                        if (handlerException(Looper.getMainLooper().getThread(), e)){
                            ToastUtils.showToastShort(context, R.string.common_app_crash);
                            if (System.currentTimeMillis()-lastTime<CRASH_MIN_TIME
                                    &&lastException!=null&&e.getMessage().equals(lastException.getMessage())){
                                System.exit(0);
                                return;
                            }
                            if (LoginUtils.isLogin()){
                                PagesManager.gotoMainActivity(context);
                            }else {
                                PagesManager.gotoLoginPage(context);
                            }
                            lastException = e;
                            lastTime = System.currentTimeMillis();
                        }
//                            sUncaughtExceptionHandler.uncaughtException(Looper.getMainLooper().getThread(), e);
                    }
                }
            }
        });


        LogUtils.logDebug("异常捕获器初始化");
    }




    @Override
    public void uncaughtException(Thread t, Throwable e) {
        if (!handlerException(t,e)&&mDefaultHandler!=null){
            //让系统自己去处理
            mDefaultHandler.uncaughtException(t,e);
        }else {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    ToastUtils.showToastShort(context, R.string.common_app_crash);
                }
            });

        }
    }


    /**
     *@desc   处理异常信息
     *@author chenjingkun
     *@time   下午1:57
     *@param
     *@retrun
     */
    private boolean handlerException(Thread t, Throwable e) {
        if (e==null)
            return false;

        String errorMsg = e.getLocalizedMessage();
        if (StringUtils.isEmpty(errorMsg))
            return false;
        e.printStackTrace();
        //收集设备信息
        getTelInfo(context);
        //保存错误信息到文件，发布版本不保存到文件
        if (!BaseBuildConfig.isRelease){
            saveInfoToFile(e);
        }

        //发布版本就上传到网络
        if (BaseBuildConfig.isRelease){
            saveInfoToNet(e);
        }
        if (BaseBuildConfig.isDebug){
            try {
                LogUtils.logError(e);
            } catch (Exception ex) {

            }
        }

        return true;
    }

    /**
     *@desc   保存信息到网络
     *@author chenjingkun
     *@time   下午2:18
     *@retrun
     * @param
     * @param e
     */
    private void saveInfoToNet(Throwable e) {
        LogUtils.logDebug("未实现错误到网络的保存，待实现");
    }

    /**
     *@desc   保存异常信息到文件
     *@author chenjingkun
     *@time   下午2:16
     *@param
     *@retrun
     */
    private void saveInfoToFile(final Throwable ex) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                StringBuffer sb = getTraceInfo(ex);
                Writer writer = new StringWriter();
                PrintWriter printWriter = new PrintWriter(writer);
                ex.printStackTrace(printWriter);
                Throwable cause = ex.getCause();
                while (cause != null) {
                    cause.printStackTrace(printWriter);
                    cause = cause.getCause();
                }
                printWriter.close();
                String result = writer.toString();
                sb.append(result);
                try {
                    String time = formatter.format(new Date());
                    String fileName = "crash_" + time + ".log";
                    if (PermissionHelper.isHasSDPermission(context)) {
                        String path = FileUtils.getCrashDir(context);
                        FileOutputStream fos = new FileOutputStream(path + fileName);
                        fos.write(sb.toString().getBytes());
                        fos.close();
                        LogUtils.logDebug(StringUtils.builderString("保存到错误日志到sdcard成功：\n 路径为：",path,fileName));
                    }

                } catch (Exception e) {
                    LogUtils.logDebug(e);
                }
            }
        }).start();


    }


    /**
     *@desc   获取异常信息
     *@author chenjingkun
     *@time   下午2:26
     *@param
     *@retrun
     */
    private StringBuffer getTraceInfo(Throwable e) {
        StringBuffer sb = new StringBuffer(deviceInfo);
        Throwable ex = e.getCause() == null ? e : e.getCause();
        StackTraceElement[] stacks = ex.getStackTrace();
        for (int i = 0; i < stacks.length; i++) {
//            if (i == 0) {
//                setError(ex.toString());
//                }
            sb.append("class: ").append(stacks[i].getClassName())
                    .append("; method: ").append(stacks[i].getMethodName())
                    .append("; line: ").append(stacks[i].getLineNumber())
                    .append(";  Exception: ").append(ex.toString() + "\n");
        }
        LogUtils.logDebug(sb.toString());
        return sb;
    }

    /**
     *@desc   收集设备信息
     *@author chenjingkun
     *@time   下午2:06
     *@param
     *@retrun
     */
    private void getTelInfo(Context ctx) {
        StringBuilder sb  = new StringBuilder();
        try {
            PackageManager pm = ctx.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(),
                    PackageManager.GET_ACTIVITIES);
            if (pi != null) {
                String versionName = pi.versionName == null ? "null"
                        : pi.versionName;
                String versionCode = pi.versionCode + "";
                sb.append("versionName:").append(versionName).append("\n");
                sb.append("versionCode:").append(versionCode).append("\n");
            }
        } catch (PackageManager.NameNotFoundException e) {
            LogUtils.logDebug("an error occured when collect package info", e);

        }

        Field[] fields = Build.class.getDeclaredFields();
        for (Field field : fields) {
            try {
                field.setAccessible(true);
                sb.append(field.getName()).append(field.get(null).toString()).append("\n");
            } catch (Exception e) {
                LogUtils.logDebug("an error occured when collect crash info", e);
            }
        }
        deviceInfo =  sb.toString();
        LogUtils.logDebug(StringUtils.builderString("错误日志手机与app信息",deviceInfo));
    }
}
