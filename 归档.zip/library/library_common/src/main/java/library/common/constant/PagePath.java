package library.common.constant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 上午10:50
 * 描述： 页面路径信息
 * 修订历史：
 */

public interface PagePath {

    /**
     * webview group
     */
    String Group_Webview = "/group_webview/";

    /**
     * test group
     */
    String Group_Test = "/group_test/";

    /**
     * main group
     */
    String Group_Main = "/group_main/";

    /**
     * flutter group
     */
    String Group_Flutter = "/group_flutter/";



    //-----------------------webview---------------///
    /**
     * 普遍的webview页面
     */
    String Page_Common_Webview = Group_Webview + "page_common_webview";


    String Page_Test_Webview = Group_Test + "page_test_webview";


    //----------------------main-------------------//

    /**
     * 启动页
     */
    String Page_Main_Splash = Group_Main + "page_main_splash";

    /**
     * 主页面
     */
    String Page_Main_MainPage = Group_Main + "page_main_mainpage";

    /**
     * 引导页
     */
    String Page_Main_Guide = Group_Main + "page_main_guide";

    /**
     * 登陆页面
     */
    String Page_Main_Login = Group_Main + "page_main_login";

    /**
     * 通用的flutter页面路由器
     */
    String Page_Common_Flutter_Router = Group_Flutter + "page_flutter_router";
}
