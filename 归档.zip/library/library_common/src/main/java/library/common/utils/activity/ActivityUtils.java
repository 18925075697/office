package library.common.utils.activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;

/**
* @author fanjh
* @date 2018/3/26 18:50
* @description 一些和Activity有关的操作工具类
* @note
**/
public class ActivityUtils {
    /**
     * 设置Activity全屏
     * @param activity 当前要全屏的Activity
     */
    public static void setFullScreen(final Activity activity) {
        if(null == activity){
            return;
        }
        Window window = activity.getWindow();
        if(null != window) {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS );
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1){
                window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            }
        }
    }

    /**
     * 动态设置顶部导航栏的颜色
     *
     * @param color 需要设置的顶部导航栏的颜色
     * @author zhengty
     */
    public static void setActivityBarStatus(int color, Activity context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            SystemBarTintManager tintManager;
            setTranslucentStatus(context,true);
            tintManager = new SystemBarTintManager(context);
            tintManager.setStatusBarTintEnabled(true);
            tintManager.setStatusBarTintResource(color);
        }
    }

    @TargetApi(19)
    public static void setTranslucentStatus(Activity activity ,boolean on) {
        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        final int bits = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    /**
     * 设置当前Activity水平方向展示
     * 注意：在AndroidO_MR1之后，指定方向不再允许和窗体透明同时进行
     * @param activity 当前要水平展示的activity
     */
    public static void setScreenLandscape(final Activity activity) {
        if(null == activity){
            return;
        }
        activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    /**
     * 设置当前Activity竖直方向展示
     * 注意：在AndroidO_MR1之后，指定方向不再允许和窗体透明同时进行
     * @param activity 当前要水平展示的activity
     */
    public static void setScreenPortrait(final Activity activity) {
        if(null == activity){
            return;
        }
        activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

}
