package library.common.entity.webview;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/26 下午2:52
 * 描述：h5
 * 修订历史：
 */

public class PostH5Data<T> {
    /**
     *  事件方法名
     */
    private String methodsName ;
    private T params;


    public String getMethodsName() {
        return methodsName;
    }

    public void setMethodsName(String methodsName) {
        this.methodsName = methodsName;
    }

    public T getParams() {
        return params;
    }

    public void setParams(T params) {
        this.params = params;
    }
}
