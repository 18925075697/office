package library.common.webview;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;


/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 下午8:41
 * 描述：
 * 修订历史：
 */

public class BaseNativeWebview extends WebView {

    public BaseNativeWebview(Context context) {
        super(context);
        init();
    }



    public BaseNativeWebview(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        getSettings().setJavaScriptEnabled(true);
//        getSettings().setDefaultTextEncodingName("utf-8");
//        getSettings().setDomStorageEnabled(true);
//        getSettings().setUseWideViewPort(true);
//        getSettings().setLoadWithOverviewMode(true);
//        getSettings().setBuiltInZoomControls(true);
//        getSettings().setRenderPriority(android.webkit.WebSettings.RenderPriority.HIGH);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
//        }
//        setInitialScale(100);
//        setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        this.setWebViewClient(new BaseNativeWebviewClient());

        this.setWebChromeClient(new NativeWebChromClient());
    }

    private class BaseNativeWebviewClient extends WebViewClient{
        private SimpleLoadingDialog loadingDialog;
//        @Override
//        public WebResourceResponse shouldInterceptRequest(WebView webView, String url) {
//            //做广告拦截，ADFIlterTool 为广告拦截工具类
////        if (!ADFilterTool.hasAd(webView.getContext(),url)){
////            return super.shouldInterceptRequest(webView, url);
////        }else {
//            return new WebResourceResponse(null,null,null);
////        }
//        }
        /**
         * 防止加载网页时调起系统浏览器
         */
        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String url) {
            webView.loadUrl(url);
            return true;
        }
        //在开始的时候，开始loadingDialog
        @Override
        public void onPageStarted(WebView webView, String s, Bitmap bitmap) {
            super.onPageStarted(webView, s, bitmap);
        try{
            loadingDialog = new SimpleLoadingDialog(webView.getContext());
            loadingDialog.show();
        }catch (Exception e){}
        }
        //在页面加载结束的时候，关闭LoadingDialog
        @Override
        public void onPageFinished(WebView webView, String s) {
            super.onPageFinished(webView, s);
        try {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
        } catch (Exception e) {}
        }

//        @Override
//        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, com.tencent.smtt.export.external.interfaces.WebResourceError webResourceError) {
//            super.onReceivedError(webView, webResourceRequest, webResourceError);
//        }

//        @Override
//        public void onReceivedSslError(com.tencent.smtt.sdk.WebView webView, com.tencent.smtt.export.external.interfaces.SslErrorHandler sslErrorHandler, com.tencent.smtt.export.external.interfaces.SslError sslError) {
//            sslErrorHandler.proceed();
//        }
    }


    private class NativeWebChromClient extends WebChromeClient{

    }




}
