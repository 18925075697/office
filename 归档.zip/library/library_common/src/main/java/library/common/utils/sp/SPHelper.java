package library.common.utils.sp;


import java.util.Map;

/**
* @author chenjingkun
* @date 2019/4/17 10:06
* @description 封装基于默认配置文件的操作
* @note 业务可以考虑同一个文件
**/
public class SPHelper {
    private static final String FILENAME = SPConfig.FileName.COMMON_FILE;

    public static void initCommon(){
        SPUtils.getSP(FILENAME);
    }

    public static void put(Map<String,String> params){
        SPUtils.put(FILENAME,params);
    }

    public static void put(String key , String value){
        SPUtils.put(FILENAME,key,value);
    }

    public static String get(String key){
        return SPUtils.getValue(FILENAME,key);
    }

    public static String get(String key,String defaultValue){
        return SPUtils.getValue(FILENAME,key,defaultValue);
    }

    public static void remove(String ...keys){
        SPUtils.remove(FILENAME,keys);
    }


}
