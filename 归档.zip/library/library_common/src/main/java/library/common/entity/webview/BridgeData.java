package library.common.entity.webview;

/**
 *  h5->android.ios webview互调移动数据格式
 *  * @author  cjk
 *
 */
public class BridgeData {
    /**
     *  事件方法名
     */
    private String methodsName ;
    private String params;

    public String getMethodsName() {
        return methodsName;
    }

    public void setMethodsName(String methodsName) {
        this.methodsName = methodsName;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    /**
     *  参数
     */
    static class BridgeParams{
        private String callName;

        public String getCallName() {
            return "参数名为:"+callName;
        }

        public void setCallName(String callName) {
            this.callName = callName;
        }


    }


    public class Event{
        /**
         * 获取设备信息
         */
        public static final String GETDEVICEINFO = "getDeviceInfo";
        public static final String CLOSE_PAGE = "close";
    }
}
