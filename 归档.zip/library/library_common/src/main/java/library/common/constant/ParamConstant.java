package library.common.constant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午7:01
 * 描述： 一些常量信息
 * 修订历史：
 */

public interface ParamConstant {
    /**
     * 页面标题
     */
    String PAGE_TITLE = "page_title";


    /**
     * url地址
     */
    String URL = "url";




}
