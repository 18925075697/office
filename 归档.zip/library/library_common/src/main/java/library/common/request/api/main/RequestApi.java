package library.common.request.api.main;

import org.json.JSONObject;

import io.reactivex.Observable;
import library.common.entity.TestData;
import library.network.ResponseResult;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 上午10:16
 * 描述：请求api
 * 修订历史：
 */

public interface RequestApi {

    @GET("p/{id}")
    Call<ResponseBody> getbook(@Path("id") String id);

    @POST("xx/xx")
    Call<ResponseBody> getPostbook(@Query("id") String id);

    @GET("p/{id}")
    Observable<ResponseBody> getRxjavBook(@Path("id") String id);

    @POST("xx/xx")
    Observable<ResponseBody> postRxjavBook(@Query("id") String id);

    @POST("/login")
    Observable<ResponseResult<JSONObject>> login(@Body RequestBody body);

    @GET("/ifin-isee-gather-service/conferenceBasic/queryConfereneceType.do")
    Observable<TestData>queryConfereneceType();
}
