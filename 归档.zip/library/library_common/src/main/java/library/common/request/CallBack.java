package library.common.request;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/30 下午2:29
 * 描述：回调类集合
 * 修订历史：
 */

public class CallBack {


    public interface IRequestListener<T>{
        /**
         * 成功回调
         * @param data
         */
        void onSuccess(T data);

        /**
         * 失败异常回调
         */
        void onFail();
    }

    public interface ISuccussListener<T>{
        /**
         *
         * @param data 数据
         * @param from 数据来源
         */
        void onCall(T data , int from);
    }


}
