package library.common.base;

import library.baselib.BuildConfig;
import library.common.constant.CommonConstant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/5/5 下午2:07
 * 描述：
 * 修订历史：
 */

public class BaseBuildConfig {

    public static final boolean isRelease = CommonConstant.ONE.equals(BuildConfig.BUILD_TYPE);
    public static final boolean isDebug = CommonConstant.ZERO.equals(BuildConfig.BUILD_TYPE);
}
