package library.common.widget.viewpager.banner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import library.common.R;


/**
* @date 2017/3/30 14:55
* @description 循环广告使用的指示器
**/
public class LoopingIndicator extends View {
    private int mCount;
    private int mSelectIndex;
    private int mSelectColor = R.color.white;
    private int mUnSelectColor = R.color.banner_indicator_unselect;
    private static final int CIRCLE_RADIUS = 3;//dp
    private static final int OVAL_WIDTH = 10;//dp
    private static final int DIVIDER_WIDTH = 5;//dp
    private int mRadius;
    private int mOvalWidth;
    private int mDividerWidth;
    private Paint mPaint;
    private RectF mTemp;

    public LoopingIndicator(Context context) {
        this(context,null);
    }

    public LoopingIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        mRadius = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,CIRCLE_RADIUS,getResources().getDisplayMetrics());
        mOvalWidth = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,OVAL_WIDTH,getResources().getDisplayMetrics());
        mDividerWidth = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,DIVIDER_WIDTH,getResources().getDisplayMetrics());
        mTemp = new RectF();
        initPaint();
    }

    private void initPaint(){
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if(mCount > 1) {
            int num = mCount - 1;
            int width = num * (mRadius << 1) + mOvalWidth + num * mDividerWidth;
            int height = (mRadius << 1);
            setMeasuredDimension(width, height);
        }else{
            setMeasuredDimension(0,0);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if(mCount > 1) {
            int left = 0;
            for (int i = 0; i < mCount; ++i) {
                if (i != mSelectIndex) {
                    mPaint.setColor(getResources().getColor(mUnSelectColor));
                    canvas.drawCircle(left + mRadius, mRadius, mRadius, mPaint);
                    left += (mRadius << 1);
                } else {
                    mPaint.setColor(getResources().getColor(mSelectColor));
                    mTemp.set(left, 0, left + mOvalWidth, getHeight());
                    canvas.drawRoundRect(mTemp, mRadius, mRadius, mPaint);
                    left += mOvalWidth;
                }
                left += mDividerWidth;
            }
        }
    }

    public void setIndex(int index){
        mSelectIndex = index;
        invalidate();
    }

    public void setCount(int count){
        mCount = count;
        requestLayout();
        invalidate();
    }

}
