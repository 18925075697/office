package library.common.utils.photo;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.view.MotionEventCompat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.PopupWindow;

import library.common.R;
import library.common.utils.InputManangerUtilts;


public class PhotoWindows extends PopupWindow {
    private Context context;
    private View background;
    private View buttons;

    public interface OnPopClickListener{
        void onPopClick(PhotoWindows photoWindows);
    }

    public PhotoWindows(final Activity mContext, View parent, final OnPopClickListener popClickListener1,
                        final OnPopClickListener popClickListener2, final OnPopClickListener popClickListener3) {
        context = mContext;
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        background = inflater.inflate(R.layout.common_item_popupwindows, null);
        buttons = background.findViewById(R.id.ll_popup);
        setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        setBackgroundDrawable(new ColorDrawable(mContext.getResources().getColor(R.color.transparent)));
        setFocusable(true);
        setOutsideTouchable(true);
        setTouchable(true);
        setContentView(background);
        InputManangerUtilts.hintSystemInput(mContext);
        showAtLocation(parent, Gravity.BOTTOM, 0, 0);
        //改成部分滑动动画，避免黑色背景一起移动
        Animation dropdown_in = AnimationUtils.loadAnimation(mContext, R.anim.image_popup_in);
        AlphaAnimation animation = new AlphaAnimation(0,1);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.setDuration(150);
        background.startAnimation(animation);
        buttons.startAnimation(dropdown_in);

        Button bt1 = (Button) background.findViewById(R.id.item_popupwindows_camera);
        Button bt2 = (Button) background.findViewById(R.id.item_popupwindows_Photo);
        Button bt3 = (Button) background.findViewById(R.id.item_popupwindows_cancel);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(null != popClickListener1) {
                    popClickListener1.onPopClick(PhotoWindows.this);
                }
                dismiss();
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(null != popClickListener2) {
                    popClickListener2.onPopClick(PhotoWindows.this);
                }
                dismiss();
            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(null != popClickListener3) {
                    popClickListener3.onPopClick(PhotoWindows.this);
                }
                dismiss();
            }
        });
        //add by fanjh on 2016/10/25 点击空白区域关闭
        FrameLayout parentLayout = (FrameLayout) background.findViewById(R.id.fl_parent_layout);
        parentLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(MotionEvent.ACTION_DOWN == MotionEventCompat.getActionMasked(event)){
                    dismiss();
                }
                return false;
            }
        });

    }

    @Override
    public void dismiss() {
        //改成部分滑动动画，避免黑色背景一起移动
        Animation out = AnimationUtils.loadAnimation(context, R.anim.image_popup_out);
        AlphaAnimation animation = new AlphaAnimation(1,0.4f);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                trueDismiss();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        animation.setInterpolator(new AccelerateInterpolator());
        animation.setDuration(300);
        background.startAnimation(animation);
        buttons.startAnimation(out);
    }

    private void trueDismiss(){
        super.dismiss();
    }

}
