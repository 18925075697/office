package library.common.request;

import android.app.ProgressDialog;
import android.content.Context;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import library.common.utils.gson.GsonImpl;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午3:57
 * 描述：网络请求工具
 * 修订历史：
 */

public class RequestFactor {



    /**
     *@desc   创建retrofit的请求体
     *@author chenjingkun
     *@time   下午3:59
     *@param
     *@retrun
     */
    public static RequestBody createRequestBody(RequestParams params){
        String json = GsonImpl.get().toJson(params.getParams());
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json);
        return body;
    }

   public static <T> void execute(Context context, Observable<T> from, final CallBack.IRequestListener<T> listener){
       final ProgressDialog dialog = new ProgressDialog(context);
       from.subscribeOn(Schedulers.io())
               .observeOn(AndroidSchedulers.mainThread())
               .doOnSubscribe(new Consumer<Disposable>() {
           @Override
           public void accept(Disposable disposable) throws Exception {
               dialog.show();
           }
             })
               .observeOn(AndroidSchedulers.mainThread())
               .doFinally(new Action() {
                   @Override
                   public void run() throws Exception {
                       dialog.dismiss();
                   }
               })
               .observeOn(AndroidSchedulers.mainThread())
               .subscribe(new BaseNetSubscriber<T>(context){
                   @Override
                   public void onNext(T tResponseResult) {
                       super.onNext(tResponseResult);
                       listener.onSuccess(tResponseResult);
                   }

                   @Override
                   public void onError(Throwable e) {
                       super.onError(e);
                       listener.onFail();
                   }
               });

   }
}
