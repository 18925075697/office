package library.common.utils.sp;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 上午11:32
 * 描述：
 * 修订历史：
 */

public class SPConfig {

    //引导页启动
    public static final String GUIDE_START = "guide_start";
    /**
     * 用户id
     */
    public static final String USER_ID = "user_id";

    /**
     * 用户名
     */
    public static final String USER_NAME = "user_name";

    /**
     * 用户密码
     */
    public static final String USER_PSD = "user_password";

    /**
     * 上次登陆的时间
     */
    public static final String LAST_LOGIN_TIME = "last_login_time";


    public class FileName {
        public static final String COMMON_FILE = "paic_office_finance";
    }
}
