package library.common.utils.sp;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 上午11:32
 * 描述：
 * 修订历史：
 */

public class SPConfig {

    //引导页启动
    public static final String GUIDE_START = "guide_start";


    public class FileName {
        public static final String COMMON_FILE = "paic_office_finance";
    }
}
