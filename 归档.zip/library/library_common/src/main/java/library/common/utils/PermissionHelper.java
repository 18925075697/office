package library.common.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.PermissionChecker;
import android.util.SparseArray;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import library.common.R;


/**
 * @author cjk
 * @description 权限帮助类
 * @note
 * update by fanjh on 2018/5/16
 * update by cwl on 2018/12/26
 * 兼容部分定制化权限机型
 **/
public class PermissionHelper {
    public static final String ALL_PERMISSION = "all";
    private static final int REQUEST_CODE_EXTERNAL = 1;
    private static final int REQUEST_CODE_READ_PHONE_STATE = 2;
    private static final int REQUEST_CODE_LOCATION_STATE = 3;
    private static final int REQUEST_CODE_CAMERA_STATE = 4;
    private static final int REQUEST_CODE_CONTACTS_STATE = 5;
    private static final int REQUEST_CODE_SMS_STATE = 6;
    private static final int REQUEST_CODE_RECORD = 7;
    private static final int REQUEST_CODE_CALL_PHONE = 8;
    private static final int REQUEST_CODE_CALENDAR = 9;
    private static final String CHECK_OP_NO_THROW = "checkOpNoThrow";
    private static final String OP_POST_NOTIFICATION = "OP_POST_NOTIFICATION";


    private SparseArray<PermissionGrantListener> listeners;
    private String hintContent;
    public interface PermissionGrantListener{
        /**
         * 当前权限组申请成功
         * @param permissionName 权限组名称 {@link Manifest.permission}
         */
        void onGranted(String permissionName);
        /**
         * 当前权限组申请被拒绝
         * @param permissionName 权限组名称 {@link Manifest.permission}
         * @param shouldToSetting true表示应该去设置，意味着当前权限被禁止询问
         */
        void onDenied(String permissionName, boolean shouldToSetting);
    }

    private static class Holder{
        static final PermissionHelper INSTANCE = new PermissionHelper();
    }

    private PermissionHelper() {
        listeners = new SparseArray<>();
    }

    public static PermissionHelper getInstance(){
        return Holder.INSTANCE;
    }

    public PermissionHelper setHintContent(String hintContent) {
        this.hintContent = hintContent;
        return this;
    }

    public void onRequestPermissionsResult(Activity activity, int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        PermissionGrantListener listener = listeners.get(requestCode);
        if(null != listener){
            if(permissions.length <= 0){
                listener.onGranted(ALL_PERMISSION);
                return;
            }
            String permissionGroupName = getPermissionGroupName(permissions[0]);
            if(PackageManager.PERMISSION_GRANTED == grantResults[0]){
                listener.onGranted(permissionGroupName == null?permissions[0]:permissionGroupName);
            }else{
                listener.onDenied(permissionGroupName == null?permissions[0]:permissionGroupName,!ActivityCompat.shouldShowRequestPermissionRationale(activity,permissions[0]));
            }
            listeners.remove(requestCode);
        }
        hintContent = null;
    }

    private String getPermissionGroupName(String permissionName){
        String result = null;
        switch (permissionName){
            case Manifest.permission.READ_EXTERNAL_STORAGE:
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                result = Manifest.permission_group.STORAGE;
                break;
            case Manifest.permission.ACCESS_FINE_LOCATION:
            case Manifest.permission.ACCESS_COARSE_LOCATION:
                result = Manifest.permission_group.LOCATION;
                break;
            case Manifest.permission.READ_PHONE_STATE:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result = Manifest.permission_group.PHONE;
                }
                break;
            case Manifest.permission.CALL_PHONE:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result = Manifest.permission_group.PHONE;
                }
                break;
            case Manifest.permission.CAMERA:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    result = Manifest.permission_group.CAMERA;
                }
                break;
            case Manifest.permission.READ_CONTACTS:
            case  Manifest.permission.WRITE_CONTACTS:
            case Manifest.permission.GET_ACCOUNTS:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result = Manifest.permission_group.CONTACTS;
                }
                break;
            case Manifest.permission.READ_SMS:
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result = Manifest.permission_group.SMS;
                }
                break;
            case Manifest.permission.RECORD_AUDIO:
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    result = Manifest.permission_group.MICROPHONE;
                }
                return result;
            default:
                break;
        }
        return result;
    }


    public void requestStoragePermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_EXTERNAL);
    }

    public void requestReadPhoneStatusPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_READ_PHONE_STATE);
    }

    public void requestCallPhonePermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_CALL_PHONE);
    }

    public void requestLocationPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_LOCATION_STATE);
    }

    public void requestSmsPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_SMS_STATE);
    }

    public void requestCameraPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_CAMERA_STATE);
    }

    public void requestContactsPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_CONTACTS_STATE);
    }

    public void requestRecordPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener,REQUEST_CODE_RECORD);
    }

    public void requestCalendarPermission(Activity activity, PermissionGrantListener listener) {
        requestPermission(activity,listener, REQUEST_CODE_CALENDAR);
    }


    @SuppressLint("NewApi")
    public static   boolean isNotificationEnabled(Context context) {
        AppOpsManager mAppOps =
                (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);

        ApplicationInfo appInfo = context.getApplicationInfo();
        String pkg = context.getApplicationContext().getPackageName();
        int uid = appInfo.uid;
        Class appOpsClass = null;

        try {
            appOpsClass = Class.forName(AppOpsManager.class.getName());

            Method checkOpNoThrowMethod =
                    appOpsClass.getMethod(CHECK_OP_NO_THROW,
                            Integer.TYPE, Integer.TYPE, String.class);

            Field opPostNotificationValue = appOpsClass.getDeclaredField(OP_POST_NOTIFICATION);
            int value = (Integer) opPostNotificationValue.get(Integer.class);

            return ((Integer) checkOpNoThrowMethod.invoke(mAppOps, value, uid, pkg) ==
                    AppOpsManager.MODE_ALLOWED);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }



    private void requestPermission(Activity activity, PermissionGrantListener listener, int code){
        listeners.clear();
        PermissionGroup permissionGroup = getPermissionGroup(code);
        if(null == permissionGroup){
            if(null != listener){
                listener.onGranted(ALL_PERMISSION);
            }
            return;
        }
        for(String permission:permissionGroup.permissions){
            int permissionCheck = ActivityCompat.checkSelfPermission(activity, permission);
            if(PackageManager.PERMISSION_GRANTED != permissionCheck){
                if (ActivityCompat.shouldShowRequestPermissionRationale(activity,permission)) {
                    listeners.put(code,listener);
                    showHintDialog(activity,permission,code);
                    return;
                }
                listeners.put(code,listener);
                ActivityCompat.requestPermissions(activity,new String[]{permission},code);
                return;
            }
        }
        if(null != listener){
            listener.onGranted(permissionGroup.permissionGroupName);
        }
    }

    /**
     * 这里并没有设置权限组里面的所有权限，而是选择了app常用的
     */
    private PermissionGroup getPermissionGroup(int code){
        PermissionGroup result = null;
        switch (code){
            case REQUEST_CODE_EXTERNAL:
                result = new PermissionGroup();
                result.permissionGroupName = Manifest.permission_group.STORAGE;
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    result.permissions = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                }else {
                    result.permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
                }
                return result;
            case REQUEST_CODE_LOCATION_STATE:
                result = new PermissionGroup();
                result.permissionGroupName = Manifest.permission_group.LOCATION;
                result.permissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                return result;
            case REQUEST_CODE_READ_PHONE_STATE:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result.permissionGroupName = Manifest.permission_group.PHONE;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.READ_PHONE_STATE};
                return result;
            case REQUEST_CODE_CALL_PHONE:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result.permissionGroupName = Manifest.permission_group.PHONE;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.CALL_PHONE};
                return result;
            case REQUEST_CODE_CAMERA_STATE:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    result.permissionGroupName = Manifest.permission_group.CAMERA;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.CAMERA};
                return result;
            case REQUEST_CODE_CONTACTS_STATE:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result.permissionGroupName = Manifest.permission_group.CONTACTS;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
                        Manifest.permission.GET_ACCOUNTS};
                return result;
            case REQUEST_CODE_SMS_STATE:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result.permissionGroupName = Manifest.permission_group.SMS;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.READ_SMS};
                return result;
            case REQUEST_CODE_RECORD:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    result.permissionGroupName = Manifest.permission_group.MICROPHONE;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.RECORD_AUDIO};
                return result;
            case REQUEST_CODE_CALENDAR:
                result = new PermissionGroup();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    result.permissionGroupName = Manifest.permission_group.CALENDAR;
                }else{
                    result.permissionGroupName = ALL_PERMISSION;
                }
                result.permissions = new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR};
                return result;
            default:
                return null;
        }
    }

    static class PermissionGroup{
        String[] permissions;
        String permissionGroupName;
    }

    /**
     * 去设置
     * 部分ROM可以在应用中直接修改权限，有的不行
     * 这里区分一下，以后遇到特殊ROM需要进行补充
     * @param activity 当前活动
     */
    public static void jumpToAppHomePage(Activity activity){
        if("oppo".equalsIgnoreCase(Build.MANUFACTURER) || "vivo".equalsIgnoreCase(Build.MANUFACTURER)){
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        }else {
            Uri packageURI = Uri.parse("package:" + activity.getPackageName());
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageURI);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        }
    }

    public static void showSettingDialog(final Activity activity, String hint){
        Dialog dialog = new AlertDialog.Builder(activity).
                setCancelable(false).
                setTitle(R.string.common_warm_prom).
                setMessage(hint).
                setPositiveButton(R.string.common_goto_setting, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        jumpToAppHomePage(activity);
                    }
                }).
                setNegativeButton(R.string.common_cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).
                create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
    public static void showSettingDialogAndGo(final Activity activity, String hint){
        Dialog dialog = new AlertDialog.Builder(activity).
                setCancelable(false).
                setTitle(R.string.common_warm_prom).
                setMessage(hint).
                setPositiveButton(R.string.common_goto_setting, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      gotoPermissionSetting(activity);
                    }
                }).
                setNegativeButton(R.string.common_cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).
                create();
        dialog.setCanceledOnTouchOutside(false);
        DialogUtils.showDialog(activity,dialog);
    }

    /**
     * 跳转到权限设置页
     * @param activity
     * @return
     */
    public static boolean gotoPermissionSetting(Activity activity) {
        boolean success = true;
        Intent intent = new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        String packageName = activity.getPackageName();
        if (RomUtil.isHuaweiRom()) { // 华为
            intent.putExtra("packageName", packageName);
            intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"));

        }
        if (RomUtil.isMeizuRom()) {// 魅族
            intent.setAction("com.meizu.safe.security.SHOW_APPSEC");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            intent.putExtra("packageName", packageName);
        }
        if (RomUtil.isMiui()) { // 小米
            String rom = RomUtil.getMiuiVersion();
            if ("V6".equals(rom) || "V7".equals(rom)) {
                intent.setAction("miui.intent.action.APP_PERM_EDITOR");
                intent.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity");
                intent.putExtra("extra_pkgname", packageName);
            } else if ("V8".equals(rom) || "V9".equals(rom)) {
                intent.setAction("miui.intent.action.APP_PERM_EDITOR");
                intent.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity");
                intent.putExtra("extra_pkgname", packageName);
            } else {
                intent = RomUtil.getAppDetailsSettingsIntent(packageName);
            }
        }
        if (RomUtil.isOppo()) {  // OPPO
            intent.putExtra("packageName", packageName);
            intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity"));
        }
        try {
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            jumpToAppHomePage(activity);//没有适配到跳通用设置
            success = false;
        }
        return success;
    }
    private void showHintDialog(final Activity activity, final String permission, final int requestCode){
        if(null == hintContent){
            switch (requestCode){
                case REQUEST_CODE_CAMERA_STATE:
                    hintContent = activity.getString(R.string.permission_hint_camera_dialog_content);
                    break;
                case REQUEST_CODE_CONTACTS_STATE:
                    hintContent = activity.getString(R.string.permission_hint_contacts_dialog_content);
                    break;
                case REQUEST_CODE_EXTERNAL:
                    hintContent = activity.getString(R.string.permission_hint_storage_dialog_content);
                    break;
                case REQUEST_CODE_LOCATION_STATE:
                    hintContent = activity.getString(R.string.permission_hint_location_dialog_content);
                    break;
                case REQUEST_CODE_READ_PHONE_STATE:
                    hintContent = activity.getString(R.string.permission_hint_phone_dialog_content);
                    break;
                case REQUEST_CODE_RECORD:
                    hintContent = activity.getString(R.string.permission_hint_record_dialog_content);
                    break;
                case REQUEST_CODE_SMS_STATE:
                    hintContent = activity.getString(R.string.permission_hint_dialog_content);
                    break;
                case REQUEST_CODE_CALENDAR:
                    hintContent = activity.getString(R.string.permission_hint_calendar_dialog_content);
                    break;
                default:
                    hintContent = activity.getString(R.string.permission_hint_dialog_content);
                    break;
            }
        }
        Dialog dialog = new AlertDialog.Builder(activity).
                setCancelable(false).
                setTitle(R.string.common_warm_prom).
                setMessage(hintContent).
                setPositiveButton(R.string.common_know, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(activity,new String[]{permission},requestCode);
                    }
                }).create();
        dialog.setCanceledOnTouchOutside(false);
        DialogUtils.showDialog(activity,dialog);
        hintContent = null;
    }

    /**
     * 是否有sdcard权限
     * @return
     */
    public static boolean isHasSDPermission(Context context) {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)&&ActivityCompat.checkSelfPermission(context,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }

    /**
     * 是否有相机权限
     * @param context
     * @return
     */
    public static boolean isHasCameraPermission(Context context) {
        return PermissionChecker.checkCallingOrSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }




}
