package library.common.utils;

import android.content.Context;
import android.support.annotation.StringRes;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Toast;

import library.common.base.BaseApplication;
import library.common.constant.CommonConstant;
import library.common.utils.string.StringUtils;
import library.loger.LogUtils;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/19 上午11:29
 * 描述：吐司工具类
 * 修订历史：
 */

public class ToastUtils {
    /************************
     * Toast  start
     ***************************/
    private static Toast toast;

    /**
     * LENGTH_SHORT toast
     *
     * @param mContext
     * @param context  内容
     */
    public static void showToastShort(Context mContext, String context) {
        if (!StringUtils.isEmpty(context)) {
            showToast(mContext, context, Toast.LENGTH_SHORT);
        }
    }
    /**
     * LENGTH_SHORT toast
     *
     * @param
     * @param toastString  内容
     */
    public static void showToastShort( String toastString) {
        if (!StringUtils.isEmpty(toastString)) {
            showToast(BaseApplication.getInstant(), toastString, Toast.LENGTH_SHORT);
        }
    }

    /**
     * @param context
     * @param stringResId String资源id
     */
    public static void showToastShort(Context context,@StringRes int stringResId){
        showToast(context, context.getString(stringResId), Toast.LENGTH_SHORT);
    }

    /**
     * LENGTH_LONG toast
     *
     * @param mContext
     * @param context  内容
     */
    public static void showToastLong(Context mContext, String context) {
        if (!StringUtils.isEmpty(context)) {
            showToast(mContext, context, Toast.LENGTH_LONG);
        }
    }

    /**
     * 展现toast
     *
     * @param context  上下文
     * @param msg      内容
     * @param duration 展现时长
     */
    private static void showToast(Context context, CharSequence msg,
                                  int duration) {
        showToast(context,msg,duration,-1);
    }

    /**
     * 初始化 toast
     *
     * @param mContext
     * update by fanjh on 2016/9/21
     * 这里不需要static持有view，因为makeText内部会new Toast，同时设置视图。
     */
    private static void getToast(Context mContext) {
        if (toast == null) {
            toast = Toast.makeText(mContext.getApplicationContext(), CommonConstant.NULL, Toast.LENGTH_SHORT);
        }
    }
    /************************ Toast  end***************************/

    private static void showToast(Context context,CharSequence msg,int duration,int gravity){
        try {
            getToast(context);
            toast.setText(msg);
            toast.setDuration(duration);
            if(gravity != -1) {
                toast.setGravity(gravity, 0, 0);
            }else{
                toast.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL, 0 , (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,48,context.getResources().getDisplayMetrics()));
            }
            toast.show();
        } catch (Exception e) {
            LogUtils.logInfo(e.getMessage());
        }
    }

    /**
     * 居中显示
     */
    public static void showToastLongCenter(Context mContext, String context) {
        if (!StringUtils.isEmpty(context)) {
            showToast(mContext, context, Toast.LENGTH_LONG, Gravity.CENTER);
        }
    }
}
