package library.common.utils.photo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.File;

import library.common.R;
import library.common.utils.PermissionHelper;
import library.common.utils.ToastUtils;
import library.loger.LogUtils;

/**
 * @description 主要是处理调用相机及图库，以及获取返回的path等
 * @auther zhengty
 * created at 2016/4/6 14:03
 */
public class Pictureutil {

    //选择图库
    public static void takePicture(Activity mContext, int requestCode) {
        try {
            if (!PermissionHelper.isHasSDPermission(mContext)) {
                ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
                return;
            }

            Intent innerIntent = new Intent();
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                innerIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
//            } else {
                innerIntent.setAction(Intent.ACTION_GET_CONTENT);
//            }
            innerIntent.setType("image/*");
            innerIntent.addCategory(Intent.CATEGORY_OPENABLE);
            Intent intent = Intent.createChooser(innerIntent, "选择图片");
            startImplicitIntent(intent, mContext, requestCode);
        } catch (Exception e) {
            LogUtils.logWarn("Pictureutil", "takePhoto:", e);
        }
    }

    //拍照
    public static void takePhoto(Activity mContext, int requestCode, File file) {
        try {
            if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
                return;
            }
            Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            Uri imageUri = Uri.fromFile(file);
            openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            startImplicitIntent(openCameraIntent, mContext, requestCode);
        } catch (Exception e) {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
            LogUtils.logWarn("Pictureutil", "Unexpected error initializing camera", e);
        }
    }

    /**
     * 一旦发生隐式Intent找不到合适的调用组件的情况，系统就会抛出ActivityNotFoundException的异常，如果我们的应用没有对这个异常做任何处理，那应用就会发生Crash
     *
     * @param intent
     * @param requestCode
     */
    private static void startImplicitIntent(Intent intent, Activity mContext, int requestCode) throws Exception {
        ComponentName componentName = intent.resolveActivity(mContext.getPackageManager());
        if (null != componentName) {
            mContext.startActivityForResult(intent, requestCode);
        } else {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_no_camera_permission));
            return;
        }
    }

    public static String getPath(final Context context, final Uri uri) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && DocumentsContract.isDocumentUri(context, uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    File file = Environment.getExternalStorageDirectory();
                    if(null != file) {
                        return Environment.getExternalStorageDirectory() + "/" + split[1];
                    }else{
                        return null;
                    }
                }
            } else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{split[1]};

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        } else if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (isGooglePhotosUri(uri))
                return uri.getLastPathSegment();

            return getDataColumn(context, uri, null, null);
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }
}
