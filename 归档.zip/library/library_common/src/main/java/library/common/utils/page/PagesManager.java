package library.common.utils.page;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.alibaba.android.arouter.launcher.ARouter;

import library.common.constant.PagePath;
import library.common.constant.ParamConstant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 上午10:19
 * 描述：
 * 修订历史：
 */

public class PagesManager {


    /**
     * 跳转到普通的webview activity,携带参数
     * @param title 页面标题 可为空
     * @param url 页面url，
     */

    public static void gotoCommonWebviewActivity(@NonNull String url , @Nullable String title ){

        ARouter.getInstance().build(PagePath.Group_Webview)
                .withString(ParamConstant.PAGE_TITLE,title)
                .withString(ParamConstant.URL,url)
                .navigation();
    }
    /**
     * 跳转到普通的webview activity,携带参数
     * @param url 页面url，
     */

    public static void gotoCommonWebviewActivity(@NonNull String url){

        ARouter.getInstance().build(PagePath.Page_Common_Webview)
                .withString(ParamConstant.URL,url)
                .navigation();
    }




    /**
     * 跳转到主页面
     * @param context 页面url，
     */
    public static void gotoMainActivity(Context context) {
        ARouter.getInstance().build(PagePath.Page_Main_MainPage)
                .navigation();
    }


    /**
     * 跳转到某个页面，没有携带参数的
     * @param pagePath
     */
    public static void gotoPage(Context context ,String pagePath){
        ARouter.getInstance().build(pagePath)
                .navigation(context);
    }
}
