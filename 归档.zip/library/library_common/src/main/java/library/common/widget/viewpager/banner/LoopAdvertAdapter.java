package library.common.widget.viewpager.banner;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import library.common.R;
import library.common.entity.Banner;
import library.imageloader.ImageLoaderKit;


/**
 * @date 2017/4/7 9:19
 * @description 循环广告使用的视图适配器
 **/
public class LoopAdvertAdapter extends PagerAdapter {
    private Context mContext;
    private List<Banner> mBanners;
    private SparseArray<ImageView> mViews;
    private int mDefaultResId = R.drawable.advert_default;

    public LoopAdvertAdapter(Context mContext) {
        this.mContext = mContext;
        mBanners = new ArrayList<>();
        mViews = new SparseArray<>();
    }

    public void setDefaultResId(int mDefaultResId) {
        this.mDefaultResId = mDefaultResId;
    }

    public void updateList(List<Banner> banners) {
        if (null != banners) {
            if (null == mBanners) {
                mBanners = new ArrayList<>(banners.size());
                mBanners.addAll(banners);
            } else {
                mBanners.clear();
                mBanners.addAll(banners);
            }
        }
    }

    @Override
    public int getCount() {
        int count = mBanners.size();
        if (count > 1) {
            return count + 2;
        } else {
            return count;
        }
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        int realPos = position;
        if (mBanners.size() > 1) {
            if (position == 0) {
                realPos = mBanners.size() - 1;
            } else if (position == getCount() - 1) {
                realPos = 0;
            } else {
                realPos -= 1;
            }
        }
        final Banner banner = mBanners.get(realPos);
        if (null == mViews.get(position)) {
            createView(position, banner);
        }
        final ImageView view = mViews.get(position);
        view.setOnClickListener(getClickListener(mContext, banner, null));
        ImageLoaderKit.displayShowCommonImage(mContext, banner.getImage(), view, mDefaultResId);
        container.removeView(view);
        container.addView(view);
        return view;
    }

    private void createView(int position, Banner banner) {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_XY);
        mViews.put(position, view);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        if (null != mViews.get(position)) {
            container.removeView(mViews.get(position));
            mViews.remove(position);
        }
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    public View.OnClickListener getClickListener(final Context mActivity, final Banner banner, final View.OnClickListener listener) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        };
    }




}