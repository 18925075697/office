package library.common.utils.photo;


import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;


import library.common.R;
import library.common.base.BaseApplication;
import library.common.callback.ActivityResultCallback;
import library.common.callback.RequestCallback;
import library.common.utils.PermissionHelper;
import library.common.utils.ToastUtils;
import library.common.utils.file.FileUtils;
import library.loger.LogUtils;

import static android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION;
import static android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION;



public class ChoosePitchureController{

    Context mContext;
    public static final int TAKE_PICTURE = 0x000000;
    public static final int SELECT_PICTURE = 0x000001;

    public static final int RESULT_OK = -1;

    public Uri path;//存取图片的统一路径

    private String filePath;

    public int crop = 300;// 裁剪大小

    public int cropX=300;

    public int cropY=300;

    public static final int CROP_PHOTO_CODE = 12;
     Fragment resultFragment;

    public ChoosePitchureController(Activity context) {
        this.mContext = context;
    }


    public ChoosePitchureController(Fragment resultFragment) {
        this.resultFragment = resultFragment;
        mContext = resultFragment.getActivity();
    }

    private boolean need_crop;//是否需要裁剪




    /**
     * 底部弹出的PopWindows【外部需要统一调用这种样式】
     *
     * @param parent
     */
    public void displayPopWindows(View parent) {

        new PhotoWindows((Activity) mContext, parent, new PhotoWindows.OnPopClickListener() {
            @Override
            public void onPopClick(PhotoWindows photoWindows) {
                PermissionHelper.getInstance().requestCameraPermission((Activity) mContext, new PermissionHelper.PermissionGrantListener() {
                    @Override
                    public void onGranted(String permissionName) {
                        PermissionHelper.getInstance().requestStoragePermission((Activity) mContext, new PermissionHelper.PermissionGrantListener() {
                            @Override
                            public void onGranted(String permissionName) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                    try {
                                        String fileName = UUID.randomUUID() + ".jpg";
                                        File imagePath = FileUtils.createFile(FileUtils.getImagesDir(BaseApplication.getInstant()));
                                        File newFile = new File(imagePath, fileName);
                                        newFile.createNewFile();
                                        path = takePhotoN((Activity) mContext, TAKE_PICTURE, newFile);
                                        filePath = newFile.getAbsolutePath();
                                    }catch (Exception ex){
                                        ex.printStackTrace();
                                    }
                                } else {
                                    File file = new File(FileUtils.getImagesDir(BaseApplication.getInstant()), String.valueOf(System.currentTimeMillis()) + ".jpg");
                                    takePhoto((Activity) mContext, TAKE_PICTURE, file);
                                    path = Uri.fromFile(file);
                                    filePath = file.getAbsolutePath();
                                }
                            }

                            @Override
                            public void onDenied(String permissionName, boolean shouldToSetting) {
                                if(shouldToSetting){
                                    PermissionHelper.showSettingDialog((Activity) mContext,mContext.getString(R.string.permission_storage_dialog_content));
                                }
                                ToastUtils.showToastShort(mContext, mContext.getString(R.string.permission_storage_denied_hint));
                            }
                        });
                    }

                    @Override
                    public void onDenied(String permissionName, boolean shouldToSetting) {
                        if(shouldToSetting){
                            PermissionHelper.showSettingDialog((Activity) mContext,mContext.getString(R.string.permission_camera_dialog_content));
                        }
                        ToastUtils.showToastShort(mContext, mContext.getString(R.string.permission_camera_denied_hint));
                    }
                });
            }
        }, new PhotoWindows.OnPopClickListener() {
            @Override
            public void onPopClick(PhotoWindows photoWindows) {
                PermissionHelper.getInstance().requestStoragePermission((Activity) mContext, new PermissionHelper.PermissionGrantListener() {
                    @Override
                    public void onGranted(String permissionName) {
                        takePicture((Activity) mContext, SELECT_PICTURE);
                    }

                    @Override
                    public void onDenied(String permissionName, boolean shouldToSetting) {
                        if(shouldToSetting){
                            PermissionHelper.showSettingDialog((Activity) mContext,mContext.getString(R.string.permission_storage_dialog_content));
                        }
                        ToastUtils.showToastShort(mContext, mContext.getString(R.string.permission_storage_denied_hint));
                    }
                });
            }
        }, new PhotoWindows.OnPopClickListener() {
            @Override
            public void onPopClick(PhotoWindows photoWindows) {
            }
        });
    }

    /**
     * 外部统一调用出口
     *
     * @param requestCode
     * @param resultCode
     * @param data
     * @param requestCallback        接口返回图片存储路径
     * @param activityResultCallback 此接口用来回调除拍照和选择图片，其它的requestCode
     */
    public void dealReturnPhoto(int requestCode, int resultCode, Intent data, RequestCallback<String> requestCallback, ActivityResultCallback activityResultCallback) {

        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
            return;
        }
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case SELECT_PICTURE:
                    if (null != data && null != data.getData()) {
                        if (need_crop) {
                            cropPhoto(data.getData());
                        } else {
                            String path = Pictureutil.getPath(mContext, data.getData());
                            requestCallback.onReceived(path, false, false);
                        }
                    }
                    break;
                case TAKE_PICTURE:
                    if (need_crop) {
                        try {
                            //fromFile会出现空指针
                            cropPhoto(path);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        requestCallback.onReceived(filePath, false, false);
                    }
                    break;
                case CROP_PHOTO_CODE:
                    requestCallback.onReceived(filePath, false, false);
                    break;
                default:
                    if (null != activityResultCallback) {
                        activityResultCallback.onResult(requestCode);
                    }
                    break;
            }
        }
    }

    /**
     * 设置裁剪模式
     *
     * @return
     */
    public ChoosePitchureController needCrop() {
        need_crop = true;
        return this;
    }

    /**
     * 图库选择图片
     *
     * @param mContext
     * @param requestCode
     */
    public  void takePicture(Activity mContext, int requestCode) {
        try {
            if (!PermissionHelper.isHasSDPermission(mContext)) {
                ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
                return;
            }

            Intent innerIntent = new Intent();
            //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //  innerIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
            // } else {
            innerIntent.setAction(Intent.ACTION_GET_CONTENT);
            // }
            innerIntent.setType("image/*");
            //innerIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
            innerIntent.addCategory(Intent.CATEGORY_OPENABLE);
            Intent intent = Intent.createChooser(innerIntent, "选择图片");
            startImplicitIntent(intent, requestCode);
        } catch (Exception e) {
            LogUtils.logWarn("Pictureutil", "takePhoto:", e);
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    public  Uri takePhotoN(Activity activity, int requestCode, File file) {
        try {
            if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                ToastUtils.showToastShort(activity, activity.getString(R.string.free_consultation_check_sd));
                return null;
            }
            if (!PermissionHelper.isHasCameraPermission(activity)) {
                ToastUtils.showToastShort(activity, activity.getString(R.string.session_take_photo_permission_hint));
                return null;
            }
            Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            Uri imageUri = FileProvider.getUriForFile(activity, "com.paic.finance.provider", file);
            openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            openCameraIntent.addFlags(FLAG_GRANT_READ_URI_PERMISSION | FLAG_GRANT_WRITE_URI_PERMISSION);

            List<ResolveInfo> activities = activity.getPackageManager().queryIntentActivities(openCameraIntent, PackageManager.MATCH_DEFAULT_ONLY);
            if (activities.size() > 0) {
                startImplicitIntent(openCameraIntent, requestCode);
                return imageUri;
            } else {
                ToastUtils.showToastShort(activity, activity.getString(R.string.session_dont_take_photo));
            }
        } catch (Exception e) {
            ToastUtils.showToastShort(activity, activity.getString(R.string.session_take_photo_fail));
        }
        return null;
    }

    /**
     * 拍照选择图片
     *
     * @param mContext
     * @param requestCode
     * @param file
     */
    public  void takePhoto(Activity mContext, int requestCode, File file) {
        try {
            if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
                return;
            }
            Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            Uri imageUri = Uri.fromFile(file);
            openCameraIntent.putExtra(MediaStore.Images.Media.ORIENTATION, 0);
            openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            startImplicitIntent(openCameraIntent,  requestCode);
        } catch (Exception e) {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
            LogUtils.logWarn("Pictureutil", "Unexpected error initializing camera", e);
        }
    }

    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }

    public static Bitmap rotateImageView(int angle, Bitmap bitmap) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    /**
     * 一旦发生隐式Intent找不到合适的调用组件的情况，系统就会抛出ActivityNotFoundException的异常，如果我们的应用没有对这个异常做任何处理，那应用就会发生Crash
     *
     * @param intent
     * @param requestCode
     */
    private  void startImplicitIntent(Intent intent, int requestCode) throws Exception {
        ComponentName componentName = intent.resolveActivity(mContext.getPackageManager());
        if (null != componentName) {
            if (resultFragment!=null){
                resultFragment.startActivityForResult(intent,requestCode);
            }else {
                ((Activity)mContext).startActivityForResult(intent, requestCode);
            }
        } else {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_no_camera_permission));
            return;
        }
    }



    /**
     * 选择图片后的裁剪图片
     *
     * @param uri
     */
    public void cropPhoto(Uri uri) {
        try {
            String fileName = UUID.randomUUID() + ".jpg";
            File newFile = new File(FileUtils.getImagesDir(BaseApplication.getInstant()), fileName);
            newFile.createNewFile();
            Intent intent = new Intent("com.android.camera.action.CROP");
            intent.addFlags(FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "image/*");
            intent.putExtra("output", Uri.fromFile(newFile));
            intent.putExtra("outputFormat", "JPEG");// 图片格式
            intent.putExtra("crop", true);
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", cropY/cropX);
            intent.putExtra("outputX", cropX);
            intent.putExtra("outputY", cropY);
            intent.putExtra("return-data", false);
            intent.putExtra("noFaceDetection", false);
            startImplicitIntent(intent, CROP_PHOTO_CODE);
            filePath = newFile.getAbsolutePath();
        } catch (Exception e) {
            ToastUtils.showToastShort(mContext, mContext.getString(R.string.free_consultation_check_sd));
        }
    }

}
