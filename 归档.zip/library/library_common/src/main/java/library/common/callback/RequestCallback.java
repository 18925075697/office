package library.common.callback;
/**
* @author fanjh
* @date 2017/3/13 17:21
* @description 数据请求回调
* @note 
**/
public interface RequestCallback<T>{
    /**
    * @date 2017/3/13 17:22
    * @param object 获得的数据结果
     *@param fromCache 是否从缓存中获取
     *@param isCacheExpire 当前缓存是否是过期的
    **/
    void onReceived(T object, boolean fromCache, boolean isCacheExpire);
}