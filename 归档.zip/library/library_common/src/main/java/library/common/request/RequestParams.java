package library.common.request;

import java.util.HashMap;
import java.util.Map;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/29 下午4:08
 * 描述：
 * 修订历史：
 */

public class RequestParams {

    private Map<String,Object> params;


    public RequestParams(){
        params = new HashMap<>();
    }

    public <T extends Object> void put(String key ,T value){
        params.put(key,value);
    }

    public Map<String,Object> getParams() {
        return params;
    }
}
