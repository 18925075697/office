package library.common.utils;

import android.app.Activity;
import android.content.Context;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/19 上午10:51
 * 描述：键盘管理工具
 * 修订历史：
 */

public class InputManangerUtilts  {

    // ======================== 键盘相关 start ========================
    /**
     * 当有焦点的时候强制隐藏软键盘
     */
    public static void hideSystemInputWhenHasFocus(Activity context) {
        if (null != context.getCurrentFocus()) {
            ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow
                    (context.getCurrentFocus().getWindowToken(), 0);
        }
    }

    /**
     * 隐藏软键盘
     */
    public static void hintSystemInput(Activity context) {
        if (context.getCurrentFocus() != null) {
            ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow
                    (context.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 隐藏软键盘
     */
    public static void hintSystemInput(Activity context, EditText editText) {
        ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow
                (editText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }
    // ======================== 键盘相关 end ========================

}
