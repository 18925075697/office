package library.common.entity;

import java.util.List;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/28 下午5:46
 * 描述：
 * 修订历史：
 */

public class TestData {

    /**
     * msg : 查询成功
     * code : 0
     * dataList : [{"id":null,"conferenceTypeId":"1","conferenceTypeName":"会议","createdBy":null,"createddate":null,"updatedBy":null,"updatedDate":null},{"id":null,"conferenceTypeId":"2","conferenceTypeName":"培训","createdBy":null,"createddate":null,"updatedBy":null,"updatedDate":null}]
     */

    private String msg;
    private String code;
    private List<DataListBean> dataList;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<DataListBean> getDataList() {
        return dataList;
    }

    public void setDataList(List<DataListBean> dataList) {
        this.dataList = dataList;
    }

    public static class DataListBean {
        /**
         * id : null
         * conferenceTypeId : 1
         * conferenceTypeName : 会议
         * createdBy : null
         * createddate : null
         * updatedBy : null
         * updatedDate : null
         */

        private Object id;
        private String conferenceTypeId;
        private String conferenceTypeName;
        private Object createdBy;
        private Object createddate;
        private Object updatedBy;
        private Object updatedDate;

        public Object getId() {
            return id;
        }

        public void setId(Object id) {
            this.id = id;
        }

        public String getConferenceTypeId() {
            return conferenceTypeId;
        }

        public void setConferenceTypeId(String conferenceTypeId) {
            this.conferenceTypeId = conferenceTypeId;
        }

        public String getConferenceTypeName() {
            return conferenceTypeName;
        }

        public void setConferenceTypeName(String conferenceTypeName) {
            this.conferenceTypeName = conferenceTypeName;
        }

        public Object getCreatedBy() {
            return createdBy;
        }

        public void setCreatedBy(Object createdBy) {
            this.createdBy = createdBy;
        }

        public Object getCreateddate() {
            return createddate;
        }

        public void setCreateddate(Object createddate) {
            this.createddate = createddate;
        }

        public Object getUpdatedBy() {
            return updatedBy;
        }

        public void setUpdatedBy(Object updatedBy) {
            this.updatedBy = updatedBy;
        }

        public Object getUpdatedDate() {
            return updatedDate;
        }

        public void setUpdatedDate(Object updatedDate) {
            this.updatedDate = updatedDate;
        }
    }
}
