package library.common.utils.string;

import library.common.constant.CommonConstant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 上午11:34
 * 描述：字符串工具类
 * 修订历史：
 */

public class StringUtils {


    /**
     *@desc   判断是否为空
     *@author chenjingkun
     *@time   上午11:39
     *@param
     *@retrun
     */
    public static boolean isEmpty(String input){
        if (input==null||CommonConstant.NULL.equals(input))
            return true;
        return false;
    }


    /**
     *@desc   string字符串拼接，节省内存空间，使用
     *@author chenjingkun
     *@time   上午11:17
     *@param
     *@retrun
     */
    public static String builderString(String... strings) {
        StringBuilder sb = new StringBuilder();
        for (String s : strings){
            sb.append(s);
        }
        return sb.toString();
    }
}
