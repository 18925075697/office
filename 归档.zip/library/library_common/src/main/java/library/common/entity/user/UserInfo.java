package library.common.entity.user;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/26 下午3:22
 * 描述：
 * 修订历史：
 */

public class UserInfo {

    /**
     * userId :
     * userName : CHENJIAWEN516
     * emplId : 23571
     * emplName : 陈佳雯
     * emplStatus : 0
     * lesseeId : PA001
     * status : NORMAL
     * tel : 1377777
     * emplMail : 137@qq.com
     * isVip : 0
     * setId : PA011
     * deptId : S000033557
     * lastLoginDate : 2019-03-20 12:45:24
     * failTimes : 0
     * idEmplBasicInfo :
     * userType : 1
     * emplNo :
     * bizParams : {}
     */

    private String userId;
    private String userName;
    private String emplId;
    private String emplName;
    private int emplStatus;
    private String lesseeId;
    private String status;
    private String tel;
    private String emplMail;
    private String isVip;
    private String setId;
    private String deptId;
    private String lastLoginDate;
    private int failTimes;
    private String idEmplBasicInfo;
    private int userType;
    private String emplNo;
    private BizParamsBean bizParams;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmplId() {
        return emplId;
    }

    public void setEmplId(String emplId) {
        this.emplId = emplId;
    }

    public String getEmplName() {
        return emplName;
    }

    public void setEmplName(String emplName) {
        this.emplName = emplName;
    }

    public int getEmplStatus() {
        return emplStatus;
    }

    public void setEmplStatus(int emplStatus) {
        this.emplStatus = emplStatus;
    }

    public String getLesseeId() {
        return lesseeId;
    }

    public void setLesseeId(String lesseeId) {
        this.lesseeId = lesseeId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmplMail() {
        return emplMail;
    }

    public void setEmplMail(String emplMail) {
        this.emplMail = emplMail;
    }

    public String getIsVip() {
        return isVip;
    }

    public void setIsVip(String isVip) {
        this.isVip = isVip;
    }

    public String getSetId() {
        return setId;
    }

    public void setSetId(String setId) {
        this.setId = setId;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public int getFailTimes() {
        return failTimes;
    }

    public void setFailTimes(int failTimes) {
        this.failTimes = failTimes;
    }

    public String getIdEmplBasicInfo() {
        return idEmplBasicInfo;
    }

    public void setIdEmplBasicInfo(String idEmplBasicInfo) {
        this.idEmplBasicInfo = idEmplBasicInfo;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public String getEmplNo() {
        return emplNo;
    }

    public void setEmplNo(String emplNo) {
        this.emplNo = emplNo;
    }

    public BizParamsBean getBizParams() {
        return bizParams;
    }

    public void setBizParams(BizParamsBean bizParams) {
        this.bizParams = bizParams;
    }

    public static class BizParamsBean {
    }
}
