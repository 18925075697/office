package library.common.entity.webview;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import library.common.base.BaseApplication;
import library.common.utils.gson.GsonImpl;
import library.common.utils.string.StringUtils;
import library.loger.LogUtils;


/**
 *   webview桥数据
 *   * @author  cjk
 */
public class WebBridge {
    private String data;
    private WebView nativeWebview;
    private com.tencent.smtt.sdk.WebView tsWebview;


    public WebBridge(WebView webView) {
        this.nativeWebview = webView;
    }


    public WebBridge(com.tencent.smtt.sdk.WebView webView) {
        this.tsWebview = webView;
    }

    /**
     *@desc   h5->android调用方便
     *@author chenjingkun
     *@time   上午9:51
     *@param  jsonString 遵守 BridgeData 格式的jsonstirng
     *@retrun jsonString 遵守 BridgeData 格式的jsonstirng
     */
    @JavascriptInterface
    public String msgHandler(final String jsonString) {

        BridgeData bridgeData = GsonImpl.get().toObject(jsonString,BridgeData.class);
        if (bridgeData==null||jsonString==null){
            LogUtils.logDebug(StringUtils.builderString("数据格式错误",jsonString));
        }
        switch (bridgeData.getMethodsName()){

            case BridgeData.Event.GETDEVICEINFO:
                  getDeviceInfo();
                  break;

    }
         return null;
    }

    /**
     * 获取设备信息
     * @return
     */
    private String getDeviceInfo() {
        PostH5Data<DeviceInfo> data = new PostH5Data();
        data.setMethodsName("getDeviceInfo");
        DeviceInfo deviceInfo = new DeviceInfo();
        //手机品牌
        deviceInfo.setBrand(new StringBuilder().append("手机品牌：").append(android.os.Build.BRAND).toString());

        // 手机型号
        deviceInfo.setModel(new StringBuilder("手机型号").append(android.os.Build.MODEL).toString());

        data.setParams(deviceInfo);
        String deviceInfoString = GsonImpl.get().toJson(data);
        LogUtils.logDebug(StringUtils.builderString("返回给h5的设备信息:",deviceInfoString));
        if (tsWebview!=null){
            handlerH5Page(tsWebview,deviceInfoString);
        }else {
            handlerH5Page(nativeWebview,deviceInfoString);
        }
        return deviceInfoString;
    }

    @JavascriptInterface
    public String msgHandler(){
                Toast.makeText(BaseApplication.getInstant(),"收到h5发过来的信息,数据为:空的参数",Toast.LENGTH_LONG).show();
        return "平安科技";
    }

    @JavascriptInterface
    public String getData() {
        return data;
    }


    public void setData(String data) {
        this.data = data;
    }

    /**
     *@desc   调用h5 js方法
     *@author chenjingkun
     *@time   下午6:07
     *@param
     *@retrun
     */
    public  void handlerH5Page(final WebView webView, final String data){
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.loadUrl("javascript:handlerH5Page('"+data+"')");
            }
        });
    }

    /**
     *@desc   调用h5 js方法
     *@author chenjingkun
     *@time   下午6:07
     *@param
     *@retrun
     */
    public  void handlerH5Page(final com.tencent.smtt.sdk.WebView webView, final String data){
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.loadUrl("javascript:handlerH5Page('"+data+"')");
            }
        });

    }



}
