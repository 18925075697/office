package library.common.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;

/**
* @description 处理一些对话框相关的事情
* @note
**/
public class DialogUtils {

    /**
     * 展示对话框，首先需要进行一些检查，如果通过的话会展示对话框
     * @param context 上下文
     * @param dialog 要展示的对话框
     */
    public static void showDialog(Context context, Dialog dialog){
        if(null == context || null == dialog || dialog.isShowing()) {
            return;
        }
        if(context instanceof Activity){
            if(((Activity) context).isFinishing()){
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && ((Activity) context).isDestroyed()) {
                return;
            }
            dialog.show();
        }
    }

    /**
     * 隐藏对话框
     * @param context 上下文
     * @param dialog 要隐藏的对话框
     */
    public static void dismissDialog(Context context, Dialog dialog){
        if(null == context || null == dialog || !dialog.isShowing()) {
            return;
        }
        try{
            dialog.dismiss();
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

}
