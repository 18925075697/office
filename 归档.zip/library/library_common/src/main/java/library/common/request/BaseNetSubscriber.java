package library.common.request;

import android.content.Context;
import android.net.ParseException;

import com.google.gson.JsonParseException;

import org.json.JSONException;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import library.common.R;
import library.common.base.BaseApplication;
import library.common.constant.PagePath;
import library.common.utils.ToastUtils;
import library.common.utils.page.PagesManager;
import library.network.cookie.CookieException;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/28 下午3:16
 * 描述：
 * 修订历史：
 */

public class BaseNetSubscriber<T> implements Observer<T> {

    private Context mContext;


    public BaseNetSubscriber(Context mContext) {
        this.mContext = mContext;
    }


    @Override
    public void onSubscribe(Disposable d) {

    }

    @Override
    public void onNext(T tResponseResult) {

    }

    @Override
    public void onError(Throwable e) {
        if (e instanceof JsonParseException
                || e instanceof JSONException
                || e instanceof ParseException) {
            //解析错误
            ToastUtils.showToastShort(BaseApplication.getInstant(),R.string.common_parse_exception);
        } else if (e instanceof ConnectException || e instanceof UnknownHostException || e instanceof SocketTimeoutException) {
            //连接错误
            ToastUtils.showToastShort(BaseApplication.getInstant(),R.string.common_parse_exception);
        } else if (e instanceof CookieException){
            //未知错误
            CookieException exception = (CookieException) e;
            if (exception.isCookieExpire()){
                ToastUtils.showToastShort(mContext,R.string.common_login_expired);
                PagesManager.gotoPage(mContext,PagePath.Page_Main_Login);
            }
        }else {
            ToastUtils.showToastShort(BaseApplication.getInstant(),R.string.common_unkown_exception);
        }
    }

    @Override
    public void onComplete() {

    }
}
