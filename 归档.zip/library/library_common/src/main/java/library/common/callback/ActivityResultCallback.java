package library.common.callback;

/**
 */

public interface ActivityResultCallback {
    void onResult(int requestCode);
}
