package library.common.request.api.main;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 上午10:09
 * 描述：公用的api接口
 * 修订历史：
 */

public interface CommonAPI {
   @GET("book/{id}")
    public Call<ResponseBody> getBook(@Path("id") int id);
}
