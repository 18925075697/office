package library.common.utils.sp;

import android.content.Context;
import android.content.SharedPreferences;


import java.util.Map;

import library.common.base.BaseApplication;

/**
* @author fanjh
* @date 2018/3/27 9:29
* @description SharePreferences工具类
* @note 使用中基于SP的特性，要求必须初始化、轻量级存储及合并提交
**/
public class SPUtils {

    public static SharedPreferences getSP(String fileName){
        return BaseApplication.getInstant().getSharedPreferences(fileName, Context.MODE_PRIVATE);
    }

    public static void put(String fileName,Map<String,String> params){
        if(null == params){
            return;
        }
        SharedPreferences sp = getSP(fileName);
        SharedPreferences.Editor editor = sp.edit();
        for(Map.Entry<String,String> entry:params.entrySet()) {
            editor.putString(entry.getKey(),entry.getValue());
        }
        editor.apply();
    }

    public static void put(String fileName,String key ,String value){
        SharedPreferences sp = getSP(fileName);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key,value);
        editor.apply();
    }

    public static boolean putAndGetResult(String fileName,Map<String,String> params){
        if(null == params){
            return false;
        }
        SharedPreferences sp = getSP(fileName);
        SharedPreferences.Editor editor = sp.edit();
        for(Map.Entry<String,String> entry:params.entrySet()) {
            editor.putString(entry.getKey(),entry.getValue());
        }
        return editor.commit();
    }

    public static String getValue(String fileName,String key){
        return getValue(fileName, key, null);
    }

    public static String getValue(String fileName,String key,String defaultValue){
        if(null == key){
            return null;
        }
        SharedPreferences sp = getSP(fileName);
        return sp.getString(key,defaultValue);
    }

    public static void remove(String fileName,String... keys){
        if(null == keys || keys.length == 0){
            return;
        }
        SharedPreferences sp = getSP(fileName);
        SharedPreferences.Editor editor = sp.edit();
        for(String key:keys){
            editor.remove(key);
        }
        editor.apply();
    }

}
