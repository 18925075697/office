package library.common.base;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;

import io.flutter.app.FlutterFragmentActivity;
import library.common.R;
import library.common.utils.PermissionHelper;
import library.common.utils.activity.ActivityUtils;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/5/7 上午11:16
 * 描述：混合flutter页面类
 * 修订历史：
 */

public class BaseFlutterActivity extends FlutterFragmentActivity implements ActivityCompat.OnRequestPermissionsResultCallback{

    private boolean isOwnStatus;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if (!isOwnStatus)
            initStatuBars();
    }

    /**
     * 是否自定义状态栏，而不跟baseActivity
     * @param ownStatus
     */
    public void setOwnStatus(boolean ownStatus) {
        isOwnStatus = ownStatus;
    }

    /**
     * 设置状态栏是否透明
     * @param on 开关
     */
    @TargetApi(19)
    protected void setTranslucentStatus(boolean on) {
        ActivityUtils.setTranslucentStatus(this,on);
    }

    /**
     * 初始化状态栏
     */
    private void initStatuBars() {
        ActivityUtils.setActivityBarStatus(R.color.common_status_color,this);
    }


    /**
     *@desc   权限相关
     *@author chenjingkun
     *@time   下午3:12
     *@param
     *@retrun
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        PermissionHelper.getInstance().onRequestPermissionsResult(this,requestCode,permissions,grantResults);
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.slide_right_in,R.anim.slide_left_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_right_in,R.anim.slide_left_out);
    }
}
