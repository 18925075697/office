package library.common.base;

import android.app.Application;
import android.util.Log;

import com.alibaba.android.arouter.launcher.ARouter;
import com.tencent.smtt.sdk.QbSdk;

import library.common.BuildConfig;


public class BaseApplication extends Application {
    private static  BaseApplication _instant;
    @Override
    public void onCreate() {
        super.onCreate();
        _instant = this;
        if (BuildConfig.DEBUG) {
            //打印日志
            ARouter.openLog();
            //开启调试模式(如果在InstantRun模式下运行，必须开启调试模式！
            //线上版本需要关闭,否则有安全风险)
            ARouter.openDebug();
        }
        ARouter.init(_instant);

        initX5();
    }


    /**
     *@desc  初始化腾讯x5内核，这是在异步执行的
     *@author chenjingkun
     *@time   下午3:29
     *@param
     *@retrun
     */
    private void initX5() {
        QbSdk.setDownloadWithoutWifi(true);
        if (!QbSdk.isTbsCoreInited()) {
            // 设置X5初始化完成的回调接口
            QbSdk.preInit(getApplicationContext(), null);
        }
        //x5内核初始化接口//搜集本地tbs内核信息并上报服务器，服务器返回结果决定使用哪个内核。
        QbSdk.initX5Environment(getApplicationContext(),  new QbSdk.PreInitCallback() {
            @Override
            public void onViewInitFinished(boolean arg0) {
                //x5內核初始化完成的回调，为true表示x5内核加载成功，否则表示x5内核加载失败，会自动切换到系统内核。
                Log.d("BaseApplication", " onViewInitFinished is " + arg0);
            }
            @Override
            public void onCoreInitFinished() {
                Log.d("BaseApplication", " onViewInitFinished is ");
            }
        });
    }

    /**
     * 获取应用全局实例
     * @return
     */
    public static BaseApplication getInstant() {
        return _instant;
    }
}
