package library.common.utils.gson;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午5:53
 * 描述：
 * 修订历史：
 */
public class GsonImpl extends Json {
    private Gson gson = new Gson();

    @Override
    public String toJson(Object src) {
        return gson.toJson(src);
    }

    @Override
    public <T> T toObject(String json, Type claxx) throws Exception {
        return gson.fromJson(json, claxx);
    }

    @Override
    public <T> T toObject(byte[] bytes, Type claxx) throws Exception {
        return gson.fromJson(new String(bytes), claxx);
    }

    @Override
    public <T> List<T> toList(String json, Type claxx) throws Exception {
        Type type = new ListParameterizedType(claxx);
        List<T> list = gson.fromJson(json, type);
        return list;
    }

    @Override
    public <T> T toObject(String json, Class<T> claxx) {
        return gson.fromJson(json, claxx);
    }

    @Override
    public <T> T toObject(byte[] bytes, Class<T> claxx) {
        return gson.fromJson(new String(bytes), claxx);
    }

    @Override
    public <T> List<T> toList(String json, Class<T> claxx) {
        Type type = new ListParameterizedType(claxx);
        List<T> list = gson.fromJson(json, type);
        return list;
    }

    public <T> List<T> toListByType(String json, String jsonType, Class<T> claxx){
        Type type = new ListParameterizedType(claxx);
        List<T> list = null;
        try {
            JSONObject jsonObject = new JSONObject(json);
            list = gson.fromJson(jsonObject.getString(jsonType), type);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }



    /**
     * 为了解决 泛型擦除 问题引入【只有集合对象的时候才会用到】
     */
    private static class ListParameterizedType implements ParameterizedType {

        private Type type;

        private ListParameterizedType(Type type) {
            this.type = type;
        }

        @Override
        public Type[] getActualTypeArguments() {
            return new Type[]{type};
        }

        @Override
        public Type getRawType() {
            return ArrayList.class;
        }

        @Override
        public Type getOwnerType() {
            return null;
        }
    }
}
