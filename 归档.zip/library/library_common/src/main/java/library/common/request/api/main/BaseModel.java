package library.common.request.api.main;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 上午11:47
 * 描述：
 * 修订历史：
 */

public class BaseModel {

}
