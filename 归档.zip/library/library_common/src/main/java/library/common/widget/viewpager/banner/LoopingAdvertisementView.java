package library.common.widget.viewpager.banner;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.lang.ref.WeakReference;

import library.common.R;
import library.common.utils.DensityUtil;


/**
* @date 2017/3/24 16:10
* @description 循环性广告视图
* @note 结合LoopAdapter使用才有意义
**/
public class LoopingAdvertisementView extends LinearLayout {
    private FrameLayout mLayout;
    private View mTopPadding;
    private LoopingIndicator mIndicator;
    private LoopPager mPager;
    private int mTimes;
    private MainHandler mMainHandler;
    private int limitPageSize;

    public void startLooping(int time){
        if(time > 0) {
            mTimes = time;
        }
        mMainHandler.removeMessages(0);
        if (getVisibility() == VISIBLE && mTimes != 0 && null != mPager && mPager.getCount() > 1) {
            mMainHandler.sendEmptyMessageDelayed(0, mTimes);
        }
    }

    public LoopingAdvertisementView(Context context) {
        this(context,null);
    }

    public LoopingAdvertisementView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mMainHandler = new MainHandler(this);
        initView();
    }

    private void initView(){
        setOrientation(VERTICAL);
        setMotionEventSplittingEnabled(false);
        mLayout = new FrameLayout(getContext());
        initPager();
        initIndicator();
        addView(mLayout);
    }

    public void setLimitPageSize(int limitPageSize){

        this.limitPageSize = limitPageSize;
        if (mPager!=null)
            mPager.setOffscreenPageLimit(limitPageSize);
    }

    private void initPager(){
        mPager = new LoopPager(getContext());
        if (limitPageSize!=0)
            mPager.setOffscreenPageLimit(limitPageSize);
        ViewPagerScroller scroller = new ViewPagerScroller(getContext());
        scroller.setScrollDuration(600);
        scroller.initViewPagerScroll(mPager);
        mPager.addRealListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}
            @Override
            public void onPageSelected(int position) {
                mIndicator.setIndex(position);
            }
            @Override
            public void onPageScrollStateChanged(int state) {}
        });
        mPager.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (MotionEventCompat.getActionMasked(event)){
                    case MotionEvent.ACTION_MOVE:
                        stopLooping();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        startLooping(mTimes);
                        break;
                }
                return false;
            }
        });
        mLayout.addView(mPager);
    }

    private void initIndicator(){
        mIndicator = new LoopingIndicator(getContext());
        mLayout.addView(mIndicator);
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) mIndicator.getLayoutParams();
        params.gravity = Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
        params.bottomMargin = DensityUtil.dip2px(getContext(),7);
    }

    public void notifyIndicator(){
        if(null != mIndicator && null != mPager){
            mIndicator.setCount(mPager.getCount());
        }
    }

    public void notifyDataSetChanged(){
        if(null != mPager) {
            notifyIndicator();
            mPager.setCurrentItem(1, false);
        }
    }

    public void setAdapter(PagerAdapter adapter){
        if(null != mPager && null != mIndicator) {
            mPager.setAdapter(adapter);
            notifyIndicator();
            mIndicator.requestLayout();
            mPager.setCurrentItem(1, false);
        }
    }

    public void stopLooping(){
        mMainHandler.removeMessages(0);
    }

    public void setBounds(int width,int height){
        if(null == mPager){
            return;
        }
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) mPager.getLayoutParams();
        params.width = width;
        params.height = height;
        mPager.setLayoutParams(params);
    }

    public void setTopPadding(int height){
        if(null == mTopPadding ) {
            if(height != 0) {
                mTopPadding = new View(getContext());
                mTopPadding.setBackgroundColor(getResources().getColor(R.color.main_bg));
                mTopPadding.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
                addView(mTopPadding, 0);
            }
        }else{
            mTopPadding.getLayoutParams().height = height;
            mTopPadding.requestLayout();
        }
    }



    /**
    * @author fanjh
    * @date 2017/4/7 10:30
    * @description 主线程Handler
    * @note 因为存在定时任务，并且LoopingAdvertisementView持有Activity的引用
     * 所以这里采用弱引用，主要针对内存回收的时候Activity泄露
    **/
    private static class MainHandler extends Handler {
        private WeakReference<LoopingAdvertisementView> mRef;

        public MainHandler(LoopingAdvertisementView view) {
            super(Looper.getMainLooper());
            this.mRef = new WeakReference<LoopingAdvertisementView>(view);
        }

        @Override
        public void handleMessage(Message msg) {
            LoopingAdvertisementView view = mRef.get();
            if(null != view) {
                switch (msg.what) {
                    case 0:
                        if (null != view.mPager) {
                            /*if(view.mPager.getCurrentItem() > view.mPager.getCount()){
                                view.mPager.setCurrentItem(1, false);
                            }else {
                                view.mPager.setCurrentItem(view.mPager.getCurrentItem() + 1, true);
                            }*/
                            view.mPager.setCurrentItem(view.mPager.getCurrentItem() + 1, true);
                            view.startLooping(-1);
                        }
                        break;
                }
            }
        }
    }

    public LoopAdvertAdapter getAdapter(){
        if(null == mPager || !(mPager.getAdapter() instanceof LoopAdvertAdapter)){
            return null;
        }
        return (LoopAdvertAdapter) mPager.getAdapter();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startLooping(mTimes);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopLooping();
    }
}
