package library.common.entity.webview;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/26 上午10:46
 * 描述：设备信息
 * 修订历史：
 */

public class DeviceInfo {
    //品牌信息
    private String brand;

    //手机型号
    private String model;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
