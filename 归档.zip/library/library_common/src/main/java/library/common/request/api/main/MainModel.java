package library.common.request.api.main;

import android.content.Context;
import android.widget.TextView;

import java.io.IOException;

import library.common.entity.TestData;
import library.common.request.CallBack;
import library.common.request.RequestFactor;
import library.loger.LogUtils;
import library.network.NetworkMananger;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/23 上午11:37
 * 描述：main模块model
 * 修订历史：
 */

public class MainModel extends BaseModel {

    private static RequestApi mApi;


    public MainModel(){

    }


    public RequestApi getApi(){
        return getRequest();
    }

    public static RequestApi getRequest(){
        if (mApi==null)
            synchronized (RequestApi.class){
                if (mApi==null)
                    mApi = NetworkMananger.getInstance().getRetrofit().create(RequestApi.class);
                return mApi;
            }
        return mApi;
    }


    public void getBook(){
        RequestApi requestApi = getRequest();
        requestApi.getbook("2e8b400909b7").enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    LogUtils.logDebug(response.body().string());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
//        requestApi.getRxjavBook("2e8b400909b7")
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
    }

    public void query(final TextView tv_network, Context context) {
        RequestFactor.execute(context, getRequest().queryConfereneceType(), new CallBack.IRequestListener<TestData>() {
            @Override
            public void onSuccess(TestData data) {
                tv_network.setText(data.getMsg());
            }

            @Override
            public void onFail() {
                tv_network.setText("查询失败");
            }
        });
//          getRequest().queryConfereneceType()
//                  .doOnSubscribe(new Consumer<Disposable>() {
//                      @Override
//                      public void accept(Disposable disposable) throws Exception {
//                          showLoading();
//                      }
//                  })
//                  .doFinally(new Action() {
//                      @Override
//                      public void run() throws Exception {
//                          hideLoading();
//                      }
//                  })
//                  .compose(ResponseTransformer.<TestData>applySchedulers())
////                  .compose(ResponseTransformer.<TestData>handleResult())
//                  .subscribe(new BaseNetSubscriber<TestData>(context){
//                      @Override
//                      public void onNext(TestData tResponseResult) {
//                          super.onNext(tResponseResult);
//
//                      }
//                  });


//        Call<ResponseBody> call = MainModel.getRequest().queryConfereneceType();
//        call.enqueue(new Callback<ResponseBody>() {
//            @Override
//            public void onResponse(Call<ResponseBody> call, final Response<ResponseBody> response) {
//                new Handler(Looper.getMainLooper()).post(new Runnable() {
//                    @Override
//                    public void run() {
//                            if (response.body()!=null){
//                                try {
//                                    tv_network.setText(response.body().string());
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
//
//                            }else if (response.errorBody()!=null){
//                                try {
//                                    String body = response.errorBody().string();
//                                    ResponseResult<String> errorData = GsonImpl.get().toObject(body,ResponseResult.class);
//                                    if (errorData.isExpired()){
//                                        ToastUtils.showToastShort(BaseApplication.getInstant(),R.string.common_login_expired);
//                                        PagesManager.gotoPage(BaseApplication.getInstant(),PagePath.Page_Main_Login);
//                                        return;
//                                    }
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
//
//                            }
//
//                    }
//                });
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//
//                LogUtils.logDebug(t.toString());
//                ToastUtils.showToastLong(BaseApplication.getInstant(),"登陆失败，返回信息：\n"+t.toString());
//
//            }
//        });
    }

    private void hideLoading() {

    }

    private void showLoading() {

    }
}
