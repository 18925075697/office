package library.common.utils;

import android.app.Activity;

import org.json.JSONException;
import org.json.JSONObject;

import io.reactivex.Observable;
import library.common.R;
import library.common.base.BaseApplication;
import library.common.constant.CommonConstant;
import library.common.request.CallBack;
import library.common.request.RequestFactor;
import library.common.request.RequestParams;
import library.common.request.api.main.MainModel;
import library.common.utils.page.PagesManager;
import library.common.utils.sp.SPConfig;
import library.common.utils.sp.SPHelper;
import library.common.utils.string.StringUtils;
import library.network.NetworkMananger;
import library.network.ResponseResult;
import okhttp3.RequestBody;


/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/24 上午10:30
 * 描述：登陆相关的工具
 * 修订历史：
 */

public class LoginUtils {


    /**
     *@desc   判断是否登陆
     *@author chenjingkun
     *@time   上午10:31
     *@param
     *@retrun
     */
    public static boolean isLogin(){
        //chenjiawen516这个接口登陆返回的数据userid为空，先不作这个判断
//        return !StringUtils.isEmpty(SPHelper.get(SPConfig.USER_ID));
        if (StringUtils.isEmpty(SPHelper.get(SPConfig.USER_NAME))||StringUtils.isEmpty(SPHelper.get(SPConfig.USER_PSD)))
            return false;
        if (NetworkMananger.getInstance().isCookieExpired(CommonConstant.BuildHost)) {
            ToastUtils.showToastShort(BaseApplication.getInstant(), R.string.common_login_expired);
            return false;
        }
        if (StringUtils.isEmpty(SPHelper.get(SPConfig.LAST_LOGIN_TIME))||
                (CommonConstant.WEEK_ONE<(System.currentTimeMillis()-Long.parseLong(SPHelper.get(SPConfig.LAST_LOGIN_TIME))))){
            return false;
        }
        return true;
    }

    /**
     *@desc   处理登陆逻辑
     *@author chenjingkun
     *@time   上午11:24
     *@param  userName 账号
     * @param password 密码
     *@retrun
     */
    public static void handlerLogin(final Activity activity, final String userName, final String password) {

        JSONObject params = new JSONObject();
        RequestParams requestParams = new RequestParams();
        requestParams.put("userName",userName);
        requestParams.put("userPwd",password);
        try {
            params.put("userName",userName);
            params.put("userPwd",password);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        final RequestBody requestBody = RequestFactor.createRequestBody(requestParams);
        Observable<ResponseResult<JSONObject>> call = MainModel.getRequest().login(requestBody);
        RequestFactor.execute(activity, call, new CallBack.IRequestListener<ResponseResult<JSONObject>>() {
            @Override
            public void onSuccess(ResponseResult<JSONObject> data) {

                SPHelper.put(SPConfig.LAST_LOGIN_TIME,String.valueOf(System.currentTimeMillis()));
                SPHelper.put(SPConfig.USER_NAME,userName);
                SPHelper.put(SPConfig.USER_PSD,password);
//                            SPHelper.put(SPConfig.USER_ID,userInfo.getUserId());
                ToastUtils.showToastLong(BaseApplication.getInstant(),"登陆成功");
                PagesManager.gotoMainActivity(BaseApplication.getInstant());
                activity.finish();
            }

            @Override
            public void onFail() {

            }
        });

    }
}
