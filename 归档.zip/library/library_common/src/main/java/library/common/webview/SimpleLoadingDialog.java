package library.common.webview;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 下午9:04
 * 描述：加载h5页面加载框
 * 修订历史：
 */

class SimpleLoadingDialog extends ProgressDialog {

    public SimpleLoadingDialog(Context context) {
        super(context);
    }

    public SimpleLoadingDialog(Context context, int theme) {
        super(context, theme);
    }
}
