package library.common.entity.event;

import android.support.annotation.IntDef;


/**
* @author chenjingkun
* @date 2018/4/8 16:59
* @description Tab切换事件
* @note
**/
public class TabEvent {
    @IntDef({TabIndex.INDEX_HOME, TabIndex.INDEX_ORDER, TabIndex.INDEX_MESSAGE, TabIndex.INDEX_MINE})
    public @interface TabIndex{
        /**
         * 首页Tab
         */
        public static final int INDEX_HOME = 0;
        /**
         * 订单Tab
         */
        public static final int INDEX_ORDER = 1;
        /**
         * 消息Tab
         */
        public static final int INDEX_MESSAGE = 2;
        /**
         * 我的Tab
         */
        public static final int INDEX_MINE = 3;
    }

    @TabIndex
    public int index;

    public TabEvent(@TabIndex int index) {
        this.index = index;
    }

}
