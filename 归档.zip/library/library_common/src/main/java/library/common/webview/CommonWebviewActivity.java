package library.common.webview;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.widget.LinearLayout;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.R;
import library.common.base.BaseActivity;
import library.common.constant.PagePath;
import library.common.constant.ParamConstant;
import library.common.entity.webview.WebBridge;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午6:52
 * 描述： 公用的webview activity
 * 修订历史：
 */

@Route(path = PagePath.Page_Common_Webview)
public class CommonWebviewActivity extends BaseActivity {
    private BaseTSWebView wvCommon;
    private BaseNativeWebview nativeWebView;
    private LinearLayout vprootParent;
    private String mTitle;
    private String mUrl;
    private boolean isX5;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_webview_activity);
        vprootParent = findViewById(R.id.vp_root_parent);
        if (getIntent() != null) {
            mTitle = getIntent().getStringExtra(ParamConstant.PAGE_TITLE);
            mUrl = getIntent().getStringExtra(ParamConstant.URL);
        }
        initWebview();


    }

    /**
     * @param
     * @desc 功能信息等描述 初始化webview
     * @author chenjingkun
     * @time 上午10:14
     * @retrun
     */
    private void initWebview() {

        WebBridge webBridge = new WebBridge();
        webBridge.setData(mTitle);

        wvCommon = new BaseTSWebView(this, null);
        if (wvCommon.getX5WebViewExtension()==null){
            isX5 = false;
            nativeWebView = new BaseNativeWebview(getApplicationContext());
            vprootParent.addView(nativeWebView, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.FILL_PARENT,
                    LinearLayout.LayoutParams.FILL_PARENT));
            nativeWebView.addJavascriptInterface(webBridge, "EcBridge");
            nativeWebView.loadUrl(mUrl);
        }else {
            isX5 = true;
            vprootParent.addView(wvCommon, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.FILL_PARENT,
                    LinearLayout.LayoutParams.FILL_PARENT));

            wvCommon.addJavascriptInterface(webBridge, "EcBridge");
            wvCommon.loadUrl(mUrl);
        }



    }

    /**
     * 监听系统返回键，判断WebView是否有上一级，有的话就返回WebView的上一级
     * 否则返回页面
     *
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (wvCommon != null && wvCommon.canGoBack()) {
                wvCommon.goBack();
                return true;
            } else if (nativeWebView!=null&&nativeWebView.canGoBack()){
                nativeWebView.goBack();
            }else {
                return super.onKeyDown(keyCode, event);
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
