package library.common.constant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 上午11:33
 * 描述：普遍的常量
 * 修订历史：
 */

public interface CommonConstant {

    String NULL = "";

    String YES = "yes";

    String NO = "no";



}
