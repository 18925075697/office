package library.common.constant;

import library.baselib.BuildConfig;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 上午11:33
 * 描述：普遍的常量
 * 修订历史：
 */

public interface CommonConstant {


    String BuildHost = BuildConfig.HOST;

    String NULL = "";

    String YES = "yes";

    String NO = "no";

    String ZERO = "0";

    String ONE = "1";

    long WEEK_ONE = 7 * 24 * 60 * 60 * 1000;

    long DAY_ONE = 24 * 60 * 60 * 1000;

    long HOUR_ONE = 60 * 60 * 1000;
}
