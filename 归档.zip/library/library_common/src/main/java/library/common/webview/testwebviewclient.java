package library.common.webview;

import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/16 下午5:35
 * 描述：
 * 修订历史：
 */

public class testwebviewclient extends WebViewClient {

    String url;


    public testwebviewclient(String string){
        this.url = string;
    }
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        view.loadUrl(url);
        return true;

    }
}
