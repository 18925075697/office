package library.common.entity;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/22 上午11:16
 * 描述：广告
 * 修订历史：
 */

public class Banner {
    private String image;//图片地址


    public Banner(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }
}
