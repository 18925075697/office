package library.imageloader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.TransitionOptions;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;
import com.bumptech.glide.load.resource.bitmap.DownsampleStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.bumptech.glide.request.transition.Transition;

import java.security.MessageDigest;


public class ImageLoaderKit {

    /**
     * 初始化，必须在Application的onCreate中调用
     */
    public static void init(){
        ViewTarget.setTagId(R.id.glide_request);
    }

    /**
     * 初始化ImageLoader.DisplayImage配置
     *
     * @param stubImage        加载中图片
     * @param imageForEmptyUri 空的url 时的占位图
     * @param imageOnFail      加载失败 的占位图
     * @return
     */
    public static DisplayImageOptions createImageOptions(int stubImage, int imageForEmptyUri, int imageOnFail) {

        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder().build();
        defaultOptions.errorID = imageOnFail;
        defaultOptions.placeHolderID = 0;
        defaultOptions.fallbackID = imageForEmptyUri;

        return defaultOptions;
    }

    public static DisplayImageOptions createImageOptions(int stubImage) {

        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder().build();
        defaultOptions.errorID = stubImage;
        defaultOptions.placeHolderID = 0;
        defaultOptions.fallbackID = stubImage;

        return defaultOptions;
    }

    private static RequestOptions getDefaultOptions(){
        return RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.RESOURCE).
                downsample(DownsampleStrategy.AT_LEAST).error(R.drawable.img_loading_default_small).
                fallback(R.drawable.img_loading_default_small);
    }

    private static boolean isResUri(String uri){
        return null != uri && uri.startsWith("drawable://");
    }

    private static int getResValue(String uri){
        try{
            return Integer.parseInt(uri.substring("drawable://".length()));
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return 0;
    }

    private static <T> RequestListener<T> getDefaultListener(final ImageLoaderListener<T> listener){
        return new RequestListener<T>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<T> target, boolean isFirstResource) {
                if(null != listener){
                    listener.loadFailure();
                }
                return false;
            }

            @Override
            public boolean onResourceReady(T resource, Object model, Target<T> target, DataSource dataSource, boolean isFirstResource) {
                if(null != listener){
                    listener.loadSuccess(resource);
                }
                return false;
            }
        };
    }

    private static RequestOptions getRequestOptions(final DisplayImageOptions options){
        RequestOptions requestOptions = getDefaultOptions();
        if(null != options) {
            if (options.placeHolderID >= 0) {
                requestOptions.placeholder(options.placeHolderID);
            }
            if (options.errorID >= 0) {
                requestOptions.error(options.errorID);
            }
            if (options.fallbackID >= 0) {
                requestOptions.fallback(options.fallbackID);
            }
            requestOptions.skipMemoryCache(options.skipMemory);
            requestOptions.diskCacheStrategy(options.cacheInDisk ? DiskCacheStrategy.RESOURCE : DiskCacheStrategy.NONE);
            if(options.multiTransformation != null){
                requestOptions.transform(options.multiTransformation);
            }else if(options.bitmapTransform != null){
                requestOptions.transform(new BitmapTransformation() {
                    @Override
                    protected Bitmap transform(@NonNull BitmapPool bitmapPool, @NonNull Bitmap bitmap, int i, int i1) {
                        return options.bitmapTransform.transform(bitmap);
                    }

                    @Override
                    public void updateDiskCacheKey(MessageDigest messageDigest) {

                    }
                });
            }
            if(options.height > 0 || options.width > 0) {
                //指定压缩比例
                requestOptions.override(options.width > 0?options.width:-1,options.height > 0?options.height:-1);
            }
        }
        return requestOptions;
    }

    private static TransitionOptions<DrawableTransitionOptions, Drawable> getTransitionOptions(DisplayImageOptions options){
        if(null == options){
            return null;
        }
        TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions = null;
        if(options.crossFade){
            transitionOptions = new DrawableTransitionOptions().crossFade();
        }
        return transitionOptions;
    }


    /**
     * 先下载图片，然后在加载
     *
     * @param uri      图片地址
     * @param listener 下载过程监听器
     */
    public static void displayBitmapImage(Context context, String uri, DisplayImageOptions options, final ImageLoaderListener<Bitmap> listener) {
        Target<Bitmap> target = new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap o, Transition transition) {

            }
        };
        RequestOptions requestOptions = getRequestOptions(options);
        displayBitmapImage(context,uri,target,requestOptions,getDefaultListener(listener));
    }

    /**
     * 单纯加载图片
     *
     * @param uri        图片地址
     * @param imageAware 展现控件
     */
    public static void displayImage(Context context, String uri, ImageView imageAware) {
        displayImage(context, uri, imageAware,getDefaultOptions(),null,getTransitionOptions(null));
    }

    public static void displayImage(Context context, String uri) {
        displayImage(context, uri, new SimpleTarget<Drawable>() {
                    @Override
                    public void onResourceReady(Drawable o, Transition transition) {

                    }
                },getDefaultOptions(),null,getTransitionOptions(null));
    }

    /**
     * 加载圆形图片
     * @param context
     * @param uri 图片地址
     * @param imageAware 展现控件
     */
    public static void displayCircleImage(final Context context, String uri, ImageView imageAware, int defaultImage){
        RequestOptions mRequestOptions = RequestOptions.centerCropTransform().error(defaultImage) //错误的时候加载的图片
                .fallback(defaultImage)//地址为空的是加载的图片
                .diskCacheStrategy(DiskCacheStrategy.NONE)//不做磁盘缓存
                .skipMemoryCache(true);//不做内存缓存
        Glide.with(context).asBitmap().load(uri).apply(mRequestOptions).into(new CircleBitmapTarget(imageAware));
    }

    /**
     * 设置个性化配置 的加载图片
     *
     * @param uri        图片地址
     * @param imageAware 展现控件
     * @param options    个性加载配置
     */
    public static void displayImage(Context context, String uri, ImageView imageAware, DisplayImageOptions options) {
        displayImage(context,uri,imageAware,getRequestOptions(options),getDefaultListener(new ImageLoaderListener<Drawable>() {
            @Override
            public void loadSuccess(Drawable resource) {
                Log.d("paic","");
            }

            @Override
            public void loadFailure() {
                Log.d("paic","");
            }
        }),getTransitionOptions(options));
    }

    public static void displayBitmapImage(Context context, String uri, ImageView imageView, DisplayImageOptions options, ImageLoaderListener<Bitmap> listener){
        displayStringBitmapImage(context, uri, imageView, getRequestOptions(options),getDefaultListener(listener));
    }

    public static void displayImage(Context context, String uri, ImageView imageView, DisplayImageOptions options, ImageLoaderListener<Drawable> listener){
        displayStringImage(context, uri, imageView, getRequestOptions(options),getDefaultListener(listener),getTransitionOptions(options));
    }

    public static void displayImage(Context context, int resID, ImageView imageView, DisplayImageOptions options){
        displayResImage(context, resID, imageView, getRequestOptions(options),null,getTransitionOptions(options));
    }

    public static void displayImage(Context context, int resID, ImageView imageView, DisplayImageOptions options, ImageLoaderListener<Drawable> listener){
        displayResImage(context, resID, imageView, getRequestOptions(options),getDefaultListener(listener),getTransitionOptions(options));
    }

    public static void displayImage(Context context, int resID, ImageView imageView){
        displayResImage(context, resID, imageView, getRequestOptions(null),null,getTransitionOptions(null));
    }

    private static void displayBitmapImage(Context context, String uri, Target<Bitmap> target, RequestOptions options, RequestListener<Bitmap> listener){
        try {
            if (isResUri(uri)) {
                displayResBitmapImage(context, getResValue(uri), target, options, listener);
            } else {
                displayStringBitmapImage(context, uri, target, options, listener);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayImage(Context context, String uri, Target<Drawable> target, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            if (isResUri(uri)) {
                displayResImage(context, getResValue(uri), target, options, listener, transitionOptions);
            } else {
                displayStringImage(context, uri, target, options, listener, transitionOptions);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayImage(Context context, String uri, ImageView imageView, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            if (isResUri(uri)) {
                displayResImage(context, getResValue(uri), imageView, options, listener, transitionOptions);
            } else {
                displayStringImage(context, uri, imageView, options, listener, transitionOptions);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /** **/

    private static void displayStringImage(Context context, String uri, Target<Drawable> target, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            if (null != transitionOptions) {
                Glide.with(context).load(uri).transition(transitionOptions).listener(listener).apply(options).into(target);
            } else {
                Glide.with(context).load(uri).listener(listener).apply(options).into(target);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayStringBitmapImage(Context context, String uri, ImageView imageView, RequestOptions options, RequestListener<Bitmap> listener){
        try {
            Glide.with(context).asBitmap().load(uri).listener(listener).apply(options).into(imageView);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayStringImage(Context context, String uri, ImageView imageView, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            if (null != transitionOptions) {
                Glide.with(context).load(uri).transition(transitionOptions).listener(listener).apply(options).into(imageView);
            } else {
                Glide.with(context).load(uri).listener(listener).apply(options).into(imageView);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayStringBitmapImage(Context context, String uri, Target<Bitmap> imageView, RequestOptions options, RequestListener<Bitmap> listener){
        try {
            Glide.with(context).asBitmap().load(uri).listener(listener).apply(options).into(imageView);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /** **/

    private static void displayResBitmapImage(Context context, int resID, ImageView target, RequestOptions options, RequestListener<Bitmap> listener){
        try {
            options.diskCacheStrategy(DiskCacheStrategy.NONE);
            Glide.with(context).asBitmap().load(resID).listener(listener).apply(options).into(target);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayResImage(Context context, int resID, ImageView target, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            options.diskCacheStrategy(DiskCacheStrategy.NONE);
            Glide.with(context).load(resID).listener(listener).apply(options).into(target);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayResImage(Context context, int resID, Target<Drawable> target, RequestOptions options, RequestListener<Drawable> listener, TransitionOptions<DrawableTransitionOptions, Drawable> transitionOptions){
        try {
            options.diskCacheStrategy(DiskCacheStrategy.NONE);
            Glide.with(context).load(resID).listener(listener).apply(options).into(target);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static void displayResBitmapImage(Context context, int resID, Target<Bitmap> target, RequestOptions options, RequestListener<Bitmap> listener){
        try {
            options.diskCacheStrategy(DiskCacheStrategy.NONE);
            Glide.with(context).asBitmap().load(resID).listener(listener).apply(options).into(target);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /********************************************分割************************************************/

    /**
     * 使失败，地址为空，正在加载中的图片的默认地址保持统一
     *
     * @param pImageUrl    图片的路径
     * @param pImageView   图片控件
     * @param defaultImage 默认图片（失败，地址为空，正在加载中的图片的统一默认地址）
     */
    public static void displayShowCommonImage(Context context, String pImageUrl, ImageView pImageView, int defaultImage) {
        displayImage(context,pImageUrl,pImageView,createImageOptions(defaultImage));
    }

    /**  默认加载图片（加载、失败、空）
     * @param targetImage 图片控件
     * @param url 图片的路径
     */
    public static void display(Context context ,ImageView targetImage, String url){
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder().build();
        defaultOptions.errorID = R.drawable.ic_picture_failed;
        defaultOptions.placeHolderID = R.drawable.ic_default_info;
        defaultOptions.fallbackID = R.drawable.ic_picture_failed;
        displayImage(context,url,targetImage,defaultOptions);
    }








    /** end **/


    public interface ImageLoaderListener<T>{
        void loadSuccess(T resource);
        void loadFailure();
    }

    public static class DisplayImageOptions{
        int placeHolderID;
        int errorID;
        int fallbackID;
        int width;
        int height;
        boolean cacheInDisk;
        boolean skipMemory;
        boolean crossFade;
        BitmapTransform bitmapTransform;
        MultiTransformation<Bitmap> multiTransformation;

        private DisplayImageOptions(Builder builder) {
            placeHolderID = builder.placeHolderID;
            errorID = builder.errorID;
            fallbackID = builder.fallbackID;
            width = builder.width;
            height = builder.height;
            cacheInDisk = builder.cacheInDisk;
            skipMemory = builder.skipMemory;
            crossFade = builder.crossFade;
            bitmapTransform = builder.bitmapTransform;
            multiTransformation = builder.multiTransformation;
        }


        public static final class Builder {
            private int placeHolderID = -1;
            private int errorID = -1;
            private int fallbackID = -1;
            private int width;
            private int height;
            private boolean cacheInDisk;
            private boolean skipMemory;
            private boolean crossFade;
            private BitmapTransform bitmapTransform;
            private MultiTransformation<Bitmap> multiTransformation;

            public Builder() {
            }

            public Builder placeHolderID(int val) {
                placeHolderID = val;
                return this;
            }

            public Builder errorID(int val) {
                errorID = val;
                return this;
            }

            public Builder fallbackID(int val) {
                fallbackID = val;
                return this;
            }

            public Builder width(int val) {
                width = val;
                return this;
            }

            public Builder height(int val) {
                height = val;
                return this;
            }

            public Builder cacheInDisk(boolean val) {
                cacheInDisk = val;
                return this;
            }

            public Builder skipMemory(boolean val) {
                skipMemory = val;
                return this;
            }

            public Builder crossFade(boolean val) {
                crossFade = val;
                return this;
            }

            public Builder bitmapTransform(BitmapTransform val) {
                bitmapTransform = val;
                return this;
            }

            public Builder multiTransformation(MultiTransformation<Bitmap> val) {
                multiTransformation = val;
                return this;
            }

            public DisplayImageOptions build() {
                return new DisplayImageOptions(this);
            }
        }
    }

    public interface BitmapTransform{
        Bitmap transform(Bitmap bitmap);
    }

    /** end **/

}
