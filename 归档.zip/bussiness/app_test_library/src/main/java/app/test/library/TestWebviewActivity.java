package app.test.library;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.constant.PagePath;
import library.common.entity.webview.WebBridge;
import library.common.webview.BaseNativeWebview;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午3:06
 * 描述：通用的webview Activity
 * 修订历史：
 */

@Route(path = PagePath.Page_Test_Webview)
public class TestWebviewActivity extends BaseActivity {

    private BaseNativeWebview baseTSWebView;
    private EditText editText;
    private String text;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_webview_main);
        baseTSWebView = findViewById(R.id.wb_common);
        baseTSWebView.loadUrl("file:///android_asset/index2.html");
        editText = findViewById(R.id.edt_text);
        final WebBridge webBridge = new WebBridge(baseTSWebView);
        baseTSWebView.addJavascriptInterface(webBridge, "EcBridge");
        findViewById(R.id.btn_test_has).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text = editText.getText().toString();
                webBridge.handlerH5Page(baseTSWebView,text);

            }
        });
    }





}
