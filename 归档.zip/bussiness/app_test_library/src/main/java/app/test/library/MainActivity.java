package app.test.library;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.alibaba.android.arouter.launcher.ARouter;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import library.common.constant.PagePath;
import library.common.utils.page.PagesManager;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.btn_test_h5)
    Button btnTestH5;
    @BindView(R.id.btn_common)
    Button btnCommon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_activity_main);
        ButterKnife.bind(this);

    }

    @OnClick({R.id.btn_test_h5, R.id.btn_common})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_test_h5:
                ARouter.getInstance().build(PagePath.Page_Test_Webview).navigation();
                break;
            case R.id.btn_common:
                PagesManager.gotoCommonWebviewActivity("https://www.jianshu.com/p/fcebd23cbebb");
                break;
        }
    }
}
