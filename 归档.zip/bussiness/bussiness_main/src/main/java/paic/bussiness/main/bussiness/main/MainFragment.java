package paic.bussiness.main.bussiness.main;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import library.common.adapter.CommonFragmentPagerAdapter;
import library.common.widget.tab.inidicator.TabIndicator;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午5:36
 * 描述：
 * 修订历史：
 */

public class MainFragment extends Fragment {

    private ViewPager pager;
    private TabIndicator tabs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment_main,null,false);
        pager = (ViewPager) view.findViewById(R.id.pager);
        tabs = (TabIndicator) view.findViewById(R.id.tabs);
        ArrayList<String> list = new ArrayList<>();
        ArrayList<Fragment> fragments = new ArrayList<>(10);
        for (int i = 1; i < 11; i++) {
            list.add("页面 " + i);
            fragments.add(SecondFragment.newInstance());
        }
        pager.setAdapter(new CommonFragmentPagerAdapter(getActivity().getSupportFragmentManager(),fragments, list));
        tabs.setupWithViewPager(pager);
        pager.setCurrentItem(0);
        return view;
    }

    /**
     * 对PagerSlidingTabStrip的各项属性进行赋值。
     */
//    private void setTabsValue() {
//        // 设置Tab是自动填充满屏幕的
//        tabs.setShouldExpand(true);
//
//        // 设置Tab的分割线的颜色
//        tabs.setDividerColor(getResources().getColor(R.color.color_80cbc4));
//        // 设置分割线的上下的间距,传入的是dp
//        tabs.setDividerPaddingTopBottom(12);
//
//        // 设置Tab底部线的高度,传入的是dp
//        tabs.setUnderlineHeight(1);
//        //设置Tab底部线的颜色
//        tabs.setUnderlineColor(getResources().getColor(R.color.color_1A000000));
//
//        // 设置Tab 指示器Indicator的高度,传入的是dp
//        tabs.setIndicatorHeight(4);
//        // 设置Tab Indicator的颜色
//        tabs.setIndicatorColor(getResources().getColor(R.color.color_45c01a));
//
//        // 设置Tab标题文字的大小,传入的是dp
//        tabs.setTextSize(16);
//        // 设置选中Tab文字的颜色
//        tabs.setSelectedTextColor(getResources().getColor(R.color.color_45c01a));
//        //设置正常Tab文字的颜色
//        tabs.setTextColor(getResources().getColor(R.color.color_C231C7));
//
//        //  设置点击Tab时的背景色
////        tabs.setTabBackground(R.drawable.background_tab);
//
//        //是否支持动画渐变(颜色渐变和文字大小渐变)
//        tabs.setFadeEnabled(true);
//        // 设置最大缩放,是正常状态的0.3倍
//        tabs.setZoomMax(0.3F);
//        //设置Tab文字的左右间距,传入的是dp
//        tabs.setTabPaddingLeftRight(20);
//    }

    public static Fragment newInstance() {
        return new MainFragment();
    }
}
