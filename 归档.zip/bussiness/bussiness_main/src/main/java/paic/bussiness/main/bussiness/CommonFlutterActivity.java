package paic.bussiness.main.bussiness;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.alibaba.android.arouter.facade.annotation.Route;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.flutter.facade.Flutter;
import io.flutter.view.FlutterView;
import library.common.base.BaseFlutterActivity;
import library.common.constant.PagePath;
import paic.bussiness.main.R;
import paic.bussiness.main.R2;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/5/6 下午7:23
 * 描述：
 * 修订历史：
 */
@Route(path = PagePath.Page_Common_Flutter_Router)
public class CommonFlutterActivity extends BaseFlutterActivity {


    @BindView(R2.id.ll_parent)
    FrameLayout llParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_flutter_router);
        ButterKnife.bind(this);
        FlutterView flutterView = Flutter.createView(this, getLifecycle(), "main/flutter");
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
//        addContentView(flutterView, params);
        llParent.addView(flutterView);


    }
}
