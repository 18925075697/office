package paic.bussiness.main.bussiness.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import library.common.callback.RequestCallback;
import library.common.utils.photo.ChoosePitchureController;
import library.common.widget.image.round.RoundedImageView;
import library.imageloader.ImageLoaderKit;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午5:36
 * 描述：
 * 修订历史：
 */

public class MineFragment extends Fragment {

    RoundedImageView ivHead;
    RelativeLayout rl_mine;
    ChoosePitchureController picChooser;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment_mine,null,false);
        ivHead = view.findViewById(R.id.iv_head);
        rl_mine = view.findViewById(R.id.rl_mine);
        ImageLoaderKit.displayImage(getContext(),R.drawable.ic_default_info,ivHead);
        picChooser = new ChoosePitchureController(this);

        ivHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picChooser.displayPopWindows(rl_mine);
            }
        });

        return view;
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        picChooser.needCrop().dealReturnPhoto(requestCode, resultCode, data, new RequestCallback<String>() {
            @Override
            public void onReceived(String object, boolean fromCache, boolean isCacheExpire) {
                String path = (String) object;
                ImageLoaderKit.displayImage(getContext(),path,ivHead);
            }
        }, null);
    }

    public static Fragment newInstance() {
        return new MineFragment();
    }
}
