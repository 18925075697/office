package paic.bussiness.main.bussiness;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.KeyEvent;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.constant.CommonConstant;
import library.common.constant.PagePath;
import library.common.utils.LoginUtils;
import library.common.utils.PermissionHelper;
import library.common.utils.activity.ActivityUtils;
import library.common.utils.handler.EasyHandler;
import library.common.utils.page.PagesManager;
import library.common.utils.sp.SPConfig;
import library.common.utils.sp.SPHelper;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 上午9:51
 * 描述： 启动页
 * 修订历史：
 */

@Route(path = PagePath.Page_Main_Splash)
public class SplashActivity extends BaseActivity implements EasyHandler.ICallBack{

    private EasyHandler mHandler = new EasyHandler(this);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_splash);
        //解决安装完成点击 打开所产生的混乱，详见：http://blog.csdn.net/nupt123456789/article/details/34415849
        if ((getIntent().getFlags() & Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) != 0) {
            finish();
            return;
        }
        requestaAllPermissions();
        init();


    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.setOwnStatus(true);
        super.onPostCreate(savedInstanceState);
        ActivityUtils.setFullScreen(this);

    }

    /**
     *@desc   请求部分权限
     *@author chenjingkun
     *@time   上午10:42
     *@param
     *@retrun
     */
    private void requestaAllPermissions() {
      requestNetWorkPermission();
    }



    private void requestNetWorkPermission(){
        PermissionHelper.getInstance().requestStoragePermission(this, new PermissionHelper.PermissionGrantListener() {
            @Override
            public void onGranted(String permissionName) {
                mHandler.sendEmptyMessageDelayed(0x0001,3000);
            }

            @Override
            public void onDenied(String permissionName, boolean shouldToSetting) {
                mHandler.sendEmptyMessageDelayed(0x0001,3000);
            }
        });
    }


    /**
     *@desc   初始化
     *@author chenjingkun
     *@time   上午11:26
     *@param
     *@retrun
     */
    private void init() {
//        mHandler.sendEmptyMessageDelayed(0x0001,3000);
    }



    @Override
    public void handleMessage(Message msg) {
       if (CommonConstant.YES.equals(SPHelper.get(SPConfig.GUIDE_START))){
           if (LoginUtils.isLogin()){
               PagesManager.gotoMainActivity(getApplicationContext());
               finish();
               return;
           }
           PagesManager.gotoPage(this,PagePath.Page_Main_Login);
           finish();
       }else {
           SPHelper.put(SPConfig.GUIDE_START,CommonConstant.YES);
           PagesManager.gotoPage(getApplicationContext(),PagePath.Page_Main_Guide);
           finish();
       }

    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==KeyEvent.KEYCODE_BACK)
            return true;
        return super.onKeyDown(keyCode, event);
    }
}
