package paic.bussiness.main.widget;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import library.common.entity.event.TabEvent;
import library.common.utils.string.StringUtils;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午5:05
 * 描述：主页面tab
 * 修订历史：
 */

public class MainBottomTab extends LinearLayout {


    private Tab[] tabs;
    private int initialIndex;
    private ViewPager container;

    public MainBottomTab(Context context) {
        super(context);
        init();
    }

    public MainBottomTab(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
    }

    public void setTab(Tab[] tabs,int initialIndex){
        this.tabs = tabs;
        this.initialIndex = initialIndex;
        removeAllViews();
        for(int i = 0;i < tabs.length;++i){
            Tab tab = tabs[i];
            View view = LayoutInflater.from(getContext()).inflate(R.layout.main_view_common_tab,this,false);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT,1);
            view.setLayoutParams(params);
            ImageView icon = view.findViewById(R.id.view_red_point_rely);
            if(tab.imageId == 0){
                icon.setVisibility(GONE);
            }else{
                icon.setImageResource(tab.imageId);
            }
            TextView text = view.findViewById(R.id.tv_tab_text);
            if(StringUtils.isEmpty(tab.text)){
                text.setVisibility(GONE);
            }else{
                text.setText(tab.text);
            }
            tab.imageView = icon;
            tab.textView = text;
            tab.layout = (ViewGroup) view;
            if(i == initialIndex){
                //初始选中
                tab.imageView.setSelected(true);
                tab.textView.setSelected(true);
            }
            addView(view);
        }
    }


    /**
     * 关联ViewPager，从而可以进行一些操作上面的联动效果
     * @param container 关联的ViewPager
     */
    public void attachViewPager(final ViewPager container) {
        if(null == tabs){
            throw new IllegalArgumentException("请先设置tab！");
        }
        if(container.getAdapter() == null){
            throw new IllegalArgumentException("ViewPager要关联tab，请先设置adapter！");
        }
        if(container.getAdapter().getCount() != tabs.length){
            throw new IllegalArgumentException("ViewPager中的数据必须和设置的tab一致！");
        }
        this.container = container;
        container.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                boolean isSelected;
                for(int i = 0;i < tabs.length;++i){
                    isSelected = (i == position);
                    tabs[i].imageView.setSelected(isSelected);
                    tabs[i].textView.setSelected(isSelected);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        for(int i = 0;i < tabs.length;++i){
            final int finalI = i;
            tabs[i].layout.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch (finalI){
                        case TabEvent.TabIndex.INDEX_ORDER:
                            break;
                        case TabEvent.TabIndex.INDEX_MESSAGE:
                            break;
                        default:
                            break;
                    }
                    container.setCurrentItem(finalI,false);
                }
            });
        }
        container.setCurrentItem(initialIndex,false);
    }

    public static class Tab{
        String text;
        int imageId;
        ImageView imageView;
        TextView textView;
        ViewGroup layout;
//        CustomRedBubble redBubble;

        public Tab(String text, int imageId) {
            this.text = text;
            this.imageId = imageId;
        }

        public Tab(int imageId) {
            this.imageId = imageId;
        }

        public Tab(String text) {
            this.text = text;
        }

//        /**
//         * 设置小红点数目
//         * @param num 数量
//         */
//        public void setRedPointNumber(int num){
//            if(null != redBubble){
//                redBubble.setNum(num);
//            }
//        }

    }


}
