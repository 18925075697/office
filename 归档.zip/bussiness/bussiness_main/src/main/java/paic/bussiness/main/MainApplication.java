package paic.bussiness.main;

import library.common.base.BaseApplication;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午2:36
 * 描述：main模块的应用全局，在组件化开发的时候使用，集成的是否不发挥作用，主要是为了配置一些登陆信息等
 * 修订历史：
 */

public class MainApplication extends BaseApplication {
}
