package paic.bussiness.main.bussiness.main;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午5:36
 * 描述：
 * 修订历史：
 */

public class ThirdFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment_third,null,false);
        return view;
    }

    public static Fragment newInstance() {
        return new ThirdFragment();
    }
}
