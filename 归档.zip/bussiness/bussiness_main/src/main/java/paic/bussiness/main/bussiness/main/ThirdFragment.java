package paic.bussiness.main.bussiness.main;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.android.arouter.launcher.ARouter;

import java.util.LinkedList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import library.common.constant.PagePath;
import library.common.entity.Banner;
import library.common.widget.viewpager.banner.LoopAdvertAdapter;
import library.common.widget.viewpager.banner.LoopingAdvertisementView;
import paic.bussiness.main.R;
import paic.bussiness.main.R2;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午5:36
 * 描述：
 * 修订历史：
 */

public class ThirdFragment extends Fragment {



    TextView tv_network;
    @BindView(R2.id.view_loop_banner)
    LoopingAdvertisementView viewLoopBanner;
    @BindView(R2.id.tv_network)
    TextView tvNetwork;
    @BindView(R2.id.btn_crash)
    Button btnCrash;
    Unbinder unbinder;

    TextView tv_crash;
    String test;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment_third, null, false);
        viewLoopBanner = view.findViewById(R.id.view_loop_banner);
        tv_network = view.findViewById(R.id.tv_network);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (getContext().getResources().getDisplayMetrics().widthPixels / getWidthRadio())));
        LoopAdvertAdapter advertAdapter = new LoopAdvertAdapter(getContext());
        List<Banner> banners = new LinkedList<>();
        banners.add(new Banner("https://nba.sports.qq.com/media/img/players/head/260x190/201935.png"));
        banners.add(new Banner("http://img3.imgtn.bdimg.com/it/u=2030899601,183019654&fm=26&gp=0.jpg"));
        banners.add(new Banner("https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1513451746,4095393542&fm=26&gp=0.jpg"));
        banners.add(new Banner("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=267925903,3380168198&fm=26&gp=0.jpg"));
        advertAdapter.updateList(banners);
        viewLoopBanner.setAdapter(advertAdapter);
        viewLoopBanner.setLimitPageSize(banners.size());
        viewLoopBanner.startLooping(5000);
        tv_network.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                new MainModel().query(tv_network, getActivity());
//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        test.length();
//                    }
//                }).start();
                ARouter.getInstance().build(PagePath.Page_Common_Flutter_Router).navigation();

            }
        });

        unbinder = ButterKnife.bind(this, view);
//        btnCrash.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String s = tv_crash.getText().toString();
//                tv_crash.setText("1");
//            }
//        });
        return view;
    }


    /**
     * 宽高比
     *
     * @return
     */
    private double getWidthRadio() {
        return 1242.00 / 566.00;//double 除以 double 为 double; int  除以 int  为 int
    }

    public static Fragment newInstance() {
        return new ThirdFragment();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
