package paic.bussiness.main.bussiness;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.constant.PagePath;
import library.common.utils.activity.ActivityUtils;
import library.common.utils.page.PagesManager;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/17 下午1:39
 * 描述： 引导页页面
 * 修订历史：
 */


@Route(path = PagePath.Page_Main_Guide)
public class GuidePageActivity extends BaseActivity {

    private ViewPager vpImage;
    private int[] drawables = new int[]{R.drawable.common_first_guide_one,R.drawable.common_first_guide_two,R.drawable.common_first_guide_three};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_guide);
        vpImage = findViewById(R.id.vp_image);
        vpImage.setOffscreenPageLimit(2);
        vpImage.setAdapter(new ImageAdapter(drawables));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        setOwnStatus(true);
        ActivityUtils.setFullScreen(this);
        super.onPostCreate(savedInstanceState);
    }

    private  class ImageAdapter extends PagerAdapter{

        private int[] drawables;

        public ImageAdapter(int[] drawables) {

            this.drawables = drawables;
        }

        @Override
        public int getCount() {
            return drawables.length;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view==o;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull final ViewGroup container, int position) {
            View view = LayoutInflater.from(container.getContext()).inflate(R.layout.main_item_guide_image,null,false);
            AppCompatImageView imageView = view.findViewById(R.id.iv_show);
            AppCompatButton btnGo = view.findViewById(R.id.btn_go);
            btnGo.setVisibility(position==drawables.length-1?View.VISIBLE:View.GONE);
            btnGo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PagesManager.gotoMainActivity(container.getContext());
                    GuidePageActivity.this.finish();
                }
            });
            imageView.setImageResource(drawables[position]);
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
            super.destroyItem(container, position, object);
        }
    }
}
