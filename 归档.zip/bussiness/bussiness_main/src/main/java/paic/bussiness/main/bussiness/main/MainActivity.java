package paic.bussiness.main.bussiness.main;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.KeyEvent;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.base.BaseApplication;
import library.common.constant.PagePath;
import library.common.entity.event.TabEvent;
import library.common.utils.ToastUtils;
import paic.bussiness.main.R;
import paic.bussiness.main.widget.MainBottomTab;


@Route(path = PagePath.Page_Main_MainPage)
public class MainActivity extends BaseActivity {


    MainBottomTab viewTab;
    ViewPager vpContent;
    private MainBottomTab.Tab[] tabs = new MainBottomTab.Tab[4];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_main);
        viewTab =findViewById(R.id.view_tab);
        vpContent = findViewById(R.id.vp_content);
        initView();
    }

    private void initView() {
        initTab();
    }

    private void initTab() {
        MainBottomTab.Tab firstTab = new MainBottomTab.Tab(getString(R.string.first_tab), R.drawable.ic_tab_register);
        MainBottomTab.Tab secondTab = new MainBottomTab.Tab(getString(R.string.second_tab), R.drawable.ic_tab_consult);
        MainBottomTab.Tab thirdTab = new MainBottomTab.Tab(getString(R.string.third_tab), R.drawable.ic_tab_message);
        MainBottomTab.Tab fourthTab = new MainBottomTab.Tab(getString(R.string.fourth_tab), R.drawable.ic_tab_mine);
        tabs[0] = firstTab;
        tabs[1] = secondTab;
        tabs[2] = thirdTab;
        tabs[3] = fourthTab;
        viewTab.setTab(tabs, 0);
        vpContent.setAdapter(new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                switch (position) {
                    case TabEvent.TabIndex.INDEX_HOME:
                        return MainFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_ORDER:
                        return SecondFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_MESSAGE:
                        return ThirdFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_MINE:
                        return MineFragment.newInstance();
                    default:
                        return null;
                }
            }

            @Override
            public int getCount() {
                return tabs.length;
            }
        });
        vpContent.setOffscreenPageLimit(3);
        viewTab.attachViewPager(vpContent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    private  final long BACK_CLICK_TIME = 1000;//回退健点击最长时间间隔
    private  long last_time = 0;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_DOWN){
            long nowTime = System.currentTimeMillis();
            if (nowTime-last_time>BACK_CLICK_TIME){
                last_time = nowTime;
                ToastUtils.showToastShort(BaseApplication.getInstant(),String.format(getString(R.string.click_back_app)
                        ,getString(R.string.app_name)));
                return true;
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0,0);
    }
}
