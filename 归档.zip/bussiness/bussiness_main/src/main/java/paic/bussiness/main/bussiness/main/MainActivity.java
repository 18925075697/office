package paic.bussiness.main.bussiness.main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.constant.PagePath;
import library.common.entity.event.TabEvent;
import paic.bussiness.main.R;
import paic.bussiness.main.widget.MainBottomTab;


@Route(path = PagePath.Page_Main_MainPage)
public class MainActivity extends BaseActivity {


    MainBottomTab viewTab;
    ViewPager vpContent;
    private MainBottomTab.Tab[] tabs = new MainBottomTab.Tab[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_main);
        viewTab =findViewById(R.id.view_tab);
        vpContent = findViewById(R.id.vp_content);
        initView();
    }

    private void initView() {
        initTab();
    }

    private void initTab() {
        MainBottomTab.Tab firstTab = new MainBottomTab.Tab(getString(R.string.first_tab), R.drawable.ic_tab_register);
        MainBottomTab.Tab secondTab = new MainBottomTab.Tab(getString(R.string.second_tab), R.drawable.ic_tab_consult);
        MainBottomTab.Tab thirdTab = new MainBottomTab.Tab(getString(R.string.third_tab), R.drawable.ic_tab_message);
        MainBottomTab.Tab fourthTab = new MainBottomTab.Tab(getString(R.string.fourth_tab), R.drawable.ic_tab_mine);
        tabs[0] = firstTab;
        tabs[1] = secondTab;
        tabs[2] = thirdTab;
        tabs[3] = fourthTab;
        viewTab.setTab(tabs, 0);
        vpContent.setAdapter(new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                switch (position) {
                    case TabEvent.TabIndex.INDEX_HOME:
                        return MainFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_ORDER:
                        return SecondFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_MESSAGE:
                        return ThirdFragment.newInstance();
                    case TabEvent.TabIndex.INDEX_MINE:
                        return FourFragment.newInstance();
                    default:
                        return null;
                }
            }

            @Override
            public int getCount() {
                return tabs.length;
            }
        });
        vpContent.setOffscreenPageLimit(3);
        viewTab.attachViewPager(vpContent);
    }

}
