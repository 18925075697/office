package paic.bussiness.main.bussiness;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.EditText;

import com.alibaba.android.arouter.facade.annotation.Route;

import library.common.base.BaseActivity;
import library.common.constant.PagePath;
import library.common.utils.LoginUtils;
import library.common.utils.ToastUtils;
import library.common.utils.sp.SPConfig;
import library.common.utils.sp.SPHelper;
import library.common.utils.string.StringUtils;
import paic.bussiness.main.R;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/24 上午9:59
 * 描述：登陆界面
 * 修订历史：
 */


@Route(path = PagePath.Page_Main_Login)
public class LoginActivity extends BaseActivity {

    private EditText edtUser;
    private EditText edtPsd;
    private AppCompatButton btnLogin;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_login);
        edtUser = findViewById(R.id.edt_user);
        edtPsd = findViewById(R.id.edt_psd);
        btnLogin = findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlerLogin();
            }
        });
        initData();
    }

    private void initData() {
        if (!StringUtils.isEmpty(SPHelper.get(SPConfig.USER_NAME)))
            edtUser.setText(SPHelper.get(SPConfig.USER_NAME));
        if (!StringUtils.isEmpty(SPHelper.get(SPConfig.USER_PSD)))
            edtPsd.setText(SPHelper.get(SPConfig.USER_PSD));
    }

    /**
     *@desc   处理登陆
     *@author chenjingkun
     *@time   上午11:20
     *@param
     *@retrun
     */
    private void handlerLogin() {
        if (StringUtils.isEmpty(edtUser.getText().toString())
                ||StringUtils.isEmpty(edtPsd.getText().toString())){
            ToastUtils.showToastLong(getApplicationContext(),"请输入账号密码");
            return;
        }
        LoginUtils.handlerLogin(LoginActivity.this ,edtUser.getText().toString(),edtPsd.getText().toString());
    }
}
