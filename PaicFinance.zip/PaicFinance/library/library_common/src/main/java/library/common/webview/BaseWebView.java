package library.common.webview;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import android.webkit.WebView;

import library.common.entity.WebBridge;

/**
 * webview 基类
 * @author  cjk
 */
public class BaseWebView extends WebView {

    public BaseWebView(Context context) {
        super(context);
        init();
    }



    public BaseWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    private void init() {
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        addJavascriptInterface(new WebBridge(),"EcBridge");
    }
}
