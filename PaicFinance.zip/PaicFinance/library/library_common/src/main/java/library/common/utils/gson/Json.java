package library.common.utils.gson;

import java.lang.reflect.Type;
import java.util.List;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午5:53
 * 描述：
 * 修订历史：
 */
public abstract class Json {
	private static Json json;

	Json() {
	}

	public static Json get() {
		if (json == null) {
			json = new GsonImpl();
		}
		return json;
	}

	public abstract String toJson(Object src);

	public abstract <T> T toObject(String json, Class<T> claxx);

	public abstract <T> T toObject(byte[] bytes, Class<T> claxx);

	public abstract <T> List<T> toList(String json, Class<T> claxx);

	public abstract  <T> List<T> toListByType(String json, String jsonType, Class<T> claxx);

	public abstract <T> T toObject(String json, Type claxx) throws Exception;

	public abstract <T> T toObject(byte[] bytes, Type claxx) throws Exception;

	public abstract <T> List<T> toList(String json, Type claxx) throws Exception;

}
