package library.common.entity;

import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import library.common.base.BaseApplication;
import library.common.utils.gson.GsonImpl;


/**
 *   webview桥数据
 *   * @author  cjk
 */
public class WebBridge {
    private String data;


    @JavascriptInterface
    public String msgHandler(final String jsonString){

//        BridgeData bridgeData = GsonImpl.get().toObject(jsonString,BridgeData.class);


        Toast.makeText(BaseApplication.getInstant(),"收到h5发过来的信息,数据为:/n"+jsonString,Toast.LENGTH_LONG).show();
//        Toast.makeText(BaseApplication.getInstant(),"收到h5发过来的信息,数据为:/n"+bridgeData.getMethodsName()+"/n"+bridgeData.getParams().getCallName(),Toast.LENGTH_LONG).show();
        return "平安科技";
    }
    @JavascriptInterface
    public String msgHandler(){
                Toast.makeText(BaseApplication.getInstant(),"收到h5发过来的信息,数据为:空的参数",Toast.LENGTH_LONG).show();
        return "平安科技";
    }

    @JavascriptInterface
    public String getData() {
        return data;
    }

    /**
     *@desc   调用h5 js方法
     *@author chenjingkun
     *@time   下午6:07
     *@param
     *@retrun
     */
    public static String HandlerH5Page(WebView webView, String data){
        webView.loadUrl("javascript:HandlerH5Page('"+data+"')");
        return null;
    }
}
