package library.common.webview;

import android.os.Bundle;
import android.provider.SyncStateContract;
import android.support.annotation.Nullable;

import library.common.R;
import library.common.base.BaseActivity;
import library.common.constant.Constant;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午6:52
 * 描述： 公用的webview activity
 * 修订历史：
 */

public class CommonWebviewActivity extends BaseActivity {
    private BaseWebView wvCommon;
    private String mTitle;
    private String mUrl;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_webview_activity);
        if (getIntent()!=null){
            mTitle = getIntent().getStringExtra(Constant.PAGE_TITLE);
            mUrl = getIntent().getStringExtra(Constant.URL);
        }
        wvCommon.loadUrl(mUrl);

    }
}
