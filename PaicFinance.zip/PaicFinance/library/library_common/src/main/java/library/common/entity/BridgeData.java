package library.common.entity;

/**
 *  h5->android.ios webview互调移动数据格式
 *  * @author  cjk
 *
 */
public class BridgeData {
    /**
     *  事件方法名
     */
    private String methodsName;
    private String params;

    public String getMethodsName() {
        return "方法名为："+methodsName;
    }

    public void setMethodsName(String methodsName) {
        this.methodsName = methodsName;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    /**
     *  参数
     */
    static class BridgeParams{
        private String callName;

        public String getCallName() {
            return "参数名为:"+callName;
        }

        public void setCallName(String callName) {
            this.callName = callName;
        }


    }        ;
}
