package library.common.base;

import android.app.Application;

import com.alibaba.android.arouter.launcher.ARouter;

import library.common.BuildConfig;


public class BaseApplication extends Application {
    private static  BaseApplication _instant;
    @Override
    public void onCreate() {
        super.onCreate();
        _instant = this;
        if (BuildConfig.DEBUG) {
            //打印日志
            ARouter.openLog();
            //开启调试模式(如果在InstantRun模式下运行，必须开启调试模式！
            //线上版本需要关闭,否则有安全风险)
            ARouter.openDebug();
        }
        ARouter.init(_instant);
    }

    /**
     * 获取应用全局实例
     * @return
     */
    public static BaseApplication getInstant() {
        return _instant;
    }
}
