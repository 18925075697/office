package library.common.base;

import android.support.v7.app.AppCompatActivity;

/**
 *  activity 基类
 * @author chenjingkun
 */
public class BaseActivity extends AppCompatActivity {

}
