package app.test.library;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;

import library.common.base.BaseActivity;
import library.common.webview.BaseWebView;
import library.common.entity.WebBridge;

/**
 * 版权：平安通信科技
 * 作者：chenjingkun
 * 创建日期：2019/4/12 下午3:06
 * 描述：通用的webview Activity
 * 修订历史：
 */

public class CommonWebviewActivity extends BaseActivity {

    private BaseWebView baseWebView;
    private EditText editText;
    private String text;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_webview_main);
        baseWebView = findViewById(R.id.wb_common);
        baseWebView.loadUrl("file:///android_asset/index.html");
        editText = findViewById(R.id.edt_text);


        findViewById(R.id.btn_test_has).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text = editText.getText().toString();
                WebBridge.HandlerH5Page(baseWebView,text);

            }
        });
    }





}
